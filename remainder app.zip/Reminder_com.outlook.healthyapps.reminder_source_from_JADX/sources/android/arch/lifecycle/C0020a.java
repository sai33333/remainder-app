package android.arch.lifecycle;

import android.arch.lifecycle.C0024c.C0025a;
import com.google.android.gms.C0276a.C0278b;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

/* renamed from: android.arch.lifecycle.a */
class C0020a {

    /* renamed from: a */
    static C0020a f52a = new C0020a();

    /* renamed from: b */
    private final Map<Class, C0021a> f53b = new HashMap();

    /* renamed from: c */
    private final Map<Class, Boolean> f54c = new HashMap();

    /* renamed from: android.arch.lifecycle.a$a */
    static class C0021a {

        /* renamed from: a */
        final Map<C0025a, List<C0022b>> f55a = new HashMap();

        /* renamed from: b */
        final Map<C0022b, C0025a> f56b;

        C0021a(Map<C0022b, C0025a> map) {
            this.f56b = map;
            for (Entry entry : map.entrySet()) {
                C0025a aVar = (C0025a) entry.getValue();
                List list = (List) this.f55a.get(aVar);
                if (list == null) {
                    list = new ArrayList();
                    this.f55a.put(aVar, list);
                }
                list.add(entry.getKey());
            }
        }

        /* renamed from: a */
        private static void m78a(List<C0022b> list, C0028e eVar, C0025a aVar, Object obj) {
            if (list != null) {
                for (int size = list.size() - 1; size >= 0; size--) {
                    ((C0022b) list.get(size)).mo57a(eVar, aVar, obj);
                }
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo56a(C0028e eVar, C0025a aVar, Object obj) {
            m78a((List) this.f55a.get(aVar), eVar, aVar, obj);
            m78a((List) this.f55a.get(C0025a.ON_ANY), eVar, aVar, obj);
        }
    }

    /* renamed from: android.arch.lifecycle.a$b */
    static class C0022b {

        /* renamed from: a */
        final int f57a;

        /* renamed from: b */
        final Method f58b;

        C0022b(int i, Method method) {
            this.f57a = i;
            this.f58b = method;
            this.f58b.setAccessible(true);
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo57a(C0028e eVar, C0025a aVar, Object obj) {
            try {
                switch (this.f57a) {
                    case C0278b.AdsAttrs_adSize /*0*/:
                        this.f58b.invoke(obj, new Object[0]);
                        return;
                    case 1:
                        this.f58b.invoke(obj, new Object[]{eVar});
                        return;
                    case 2:
                        this.f58b.invoke(obj, new Object[]{eVar, aVar});
                        return;
                    default:
                        return;
                }
            } catch (InvocationTargetException e) {
                throw new RuntimeException("Failed to call observer method", e.getCause());
            } catch (IllegalAccessException e2) {
                throw new RuntimeException(e2);
            }
        }

        public boolean equals(Object obj) {
            boolean z = true;
            if (this == obj) {
                return true;
            }
            if (obj == null || getClass() != obj.getClass()) {
                return false;
            }
            C0022b bVar = (C0022b) obj;
            if (this.f57a != bVar.f57a || !this.f58b.getName().equals(bVar.f58b.getName())) {
                z = false;
            }
            return z;
        }

        public int hashCode() {
            return (this.f57a * 31) + this.f58b.getName().hashCode();
        }
    }

    C0020a() {
    }

    /* renamed from: a */
    private C0021a m73a(Class cls, Method[] methodArr) {
        int i;
        Class superclass = cls.getSuperclass();
        HashMap hashMap = new HashMap();
        if (superclass != null) {
            C0021a b = mo55b(superclass);
            if (b != null) {
                hashMap.putAll(b.f56b);
            }
        }
        for (Class b2 : cls.getInterfaces()) {
            for (Entry entry : mo55b(b2).f56b.entrySet()) {
                m74a(hashMap, (C0022b) entry.getKey(), (C0025a) entry.getValue(), cls);
            }
        }
        if (methodArr == null) {
            methodArr = m75c(cls);
        }
        boolean z = false;
        for (Method method : methodArr) {
            C0037l lVar = (C0037l) method.getAnnotation(C0037l.class);
            if (lVar != null) {
                Class[] parameterTypes = method.getParameterTypes();
                if (parameterTypes.length <= 0) {
                    i = 0;
                } else if (parameterTypes[0].isAssignableFrom(C0028e.class)) {
                    i = 1;
                } else {
                    throw new IllegalArgumentException("invalid parameter type. Must be one and instanceof LifecycleOwner");
                }
                C0025a a = lVar.mo71a();
                if (parameterTypes.length > 1) {
                    if (!parameterTypes[1].isAssignableFrom(C0025a.class)) {
                        throw new IllegalArgumentException("invalid parameter type. second arg must be an event");
                    } else if (a == C0025a.ON_ANY) {
                        i = 2;
                    } else {
                        throw new IllegalArgumentException("Second arg is supported only for ON_ANY value");
                    }
                }
                if (parameterTypes.length <= 2) {
                    m74a(hashMap, new C0022b(i, method), a, cls);
                    z = true;
                } else {
                    throw new IllegalArgumentException("cannot have more than 2 params");
                }
            }
        }
        C0021a aVar = new C0021a(hashMap);
        this.f53b.put(cls, aVar);
        this.f54c.put(cls, Boolean.valueOf(z));
        return aVar;
    }

    /* renamed from: a */
    private void m74a(Map<C0022b, C0025a> map, C0022b bVar, C0025a aVar, Class cls) {
        C0025a aVar2 = (C0025a) map.get(bVar);
        if (aVar2 != null && aVar != aVar2) {
            Method method = bVar.f58b;
            StringBuilder sb = new StringBuilder();
            sb.append("Method ");
            sb.append(method.getName());
            sb.append(" in ");
            sb.append(cls.getName());
            sb.append(" already declared with different @OnLifecycleEvent value: previous value ");
            sb.append(aVar2);
            sb.append(", new value ");
            sb.append(aVar);
            throw new IllegalArgumentException(sb.toString());
        } else if (aVar2 == null) {
            map.put(bVar, aVar);
        }
    }

    /* renamed from: c */
    private Method[] m75c(Class cls) {
        try {
            return cls.getDeclaredMethods();
        } catch (NoClassDefFoundError e) {
            throw new IllegalArgumentException("The observer class has some methods that use newer APIs which are not available in the current OS version. Lifecycles cannot access even other methods so you should make sure that your observer classes only access framework classes that are available in your min API level OR use lifecycle:compiler annotation processor.", e);
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public boolean mo54a(Class cls) {
        if (this.f54c.containsKey(cls)) {
            return ((Boolean) this.f54c.get(cls)).booleanValue();
        }
        Method[] c = m75c(cls);
        for (Method annotation : c) {
            if (((C0037l) annotation.getAnnotation(C0037l.class)) != null) {
                m73a(cls, c);
                return true;
            }
        }
        this.f54c.put(cls, Boolean.valueOf(false));
        return false;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public C0021a mo55b(Class cls) {
        C0021a aVar = (C0021a) this.f53b.get(cls);
        return aVar != null ? aVar : m73a(cls, null);
    }
}
