package android.arch.lifecycle;

import android.arch.lifecycle.C0024c.C0025a;

/* renamed from: android.arch.lifecycle.b */
public interface C0023b {
    /* renamed from: a */
    void mo60a(C0028e eVar, C0025a aVar, boolean z, C0034i iVar);
}
