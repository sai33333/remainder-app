package android.arch.lifecycle;

/* renamed from: android.arch.lifecycle.c */
public abstract class C0024c {

    /* renamed from: android.arch.lifecycle.c$a */
    public enum C0025a {
        ON_CREATE,
        ON_START,
        ON_RESUME,
        ON_PAUSE,
        ON_STOP,
        ON_DESTROY,
        ON_ANY
    }

    /* renamed from: android.arch.lifecycle.c$b */
    public enum C0026b {
        DESTROYED,
        INITIALIZED,
        CREATED,
        STARTED,
        RESUMED;

        /* renamed from: a */
        public boolean mo64a(C0026b bVar) {
            return compareTo(bVar) >= 0;
        }
    }

    /* renamed from: a */
    public abstract C0026b mo61a();

    /* renamed from: a */
    public abstract void mo62a(C0027d dVar);

    /* renamed from: b */
    public abstract void mo63b(C0027d dVar);
}
