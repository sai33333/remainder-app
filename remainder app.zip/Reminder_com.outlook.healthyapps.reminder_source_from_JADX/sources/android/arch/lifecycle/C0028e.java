package android.arch.lifecycle;

/* renamed from: android.arch.lifecycle.e */
public interface C0028e {
    /* renamed from: a */
    C0024c mo65a();
}
