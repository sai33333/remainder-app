package android.arch.lifecycle;

import android.arch.lifecycle.C0024c.C0025a;
import android.arch.lifecycle.C0024c.C0026b;
import android.arch.p001a.p003b.C0008a;
import android.util.Log;
import com.google.android.gms.internal.C1217ty;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map.Entry;

/* renamed from: android.arch.lifecycle.f */
public class C0029f extends C0024c {

    /* renamed from: a */
    private C0008a<C0027d, C0031a> f65a = new C0008a<>();

    /* renamed from: b */
    private C0026b f66b;

    /* renamed from: c */
    private final WeakReference<C0028e> f67c;

    /* renamed from: d */
    private int f68d = 0;

    /* renamed from: e */
    private boolean f69e = false;

    /* renamed from: f */
    private boolean f70f = false;

    /* renamed from: g */
    private ArrayList<C0026b> f71g = new ArrayList<>();

    /* renamed from: android.arch.lifecycle.f$1 */
    static /* synthetic */ class C00301 {

        /* renamed from: a */
        static final /* synthetic */ int[] f72a = new int[C0025a.values().length];

        /* renamed from: b */
        static final /* synthetic */ int[] f73b = new int[C0026b.values().length];

        /* JADX WARNING: Can't wrap try/catch for region: R(26:0|(2:1|2)|3|(2:5|6)|7|(2:9|10)|11|(2:13|14)|15|(2:17|18)|19|21|22|23|24|25|26|27|28|29|30|31|32|33|34|36) */
        /* JADX WARNING: Can't wrap try/catch for region: R(27:0|(2:1|2)|3|(2:5|6)|7|(2:9|10)|11|13|14|15|(2:17|18)|19|21|22|23|24|25|26|27|28|29|30|31|32|33|34|36) */
        /* JADX WARNING: Can't wrap try/catch for region: R(28:0|1|2|3|(2:5|6)|7|(2:9|10)|11|13|14|15|(2:17|18)|19|21|22|23|24|25|26|27|28|29|30|31|32|33|34|36) */
        /* JADX WARNING: Can't wrap try/catch for region: R(30:0|1|2|3|5|6|7|(2:9|10)|11|13|14|15|17|18|19|21|22|23|24|25|26|27|28|29|30|31|32|33|34|36) */
        /* JADX WARNING: Code restructure failed: missing block: B:37:?, code lost:
            return;
         */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:23:0x0053 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:25:0x005d */
        /* JADX WARNING: Missing exception handler attribute for start block: B:27:0x0067 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:29:0x0071 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:31:0x007b */
        /* JADX WARNING: Missing exception handler attribute for start block: B:33:0x0086 */
        static {
            /*
                android.arch.lifecycle.c$b[] r0 = android.arch.lifecycle.C0024c.C0026b.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                f73b = r0
                r0 = 1
                int[] r1 = f73b     // Catch:{ NoSuchFieldError -> 0x0014 }
                android.arch.lifecycle.c$b r2 = android.arch.lifecycle.C0024c.C0026b.INITIALIZED     // Catch:{ NoSuchFieldError -> 0x0014 }
                int r2 = r2.ordinal()     // Catch:{ NoSuchFieldError -> 0x0014 }
                r1[r2] = r0     // Catch:{ NoSuchFieldError -> 0x0014 }
            L_0x0014:
                r1 = 2
                int[] r2 = f73b     // Catch:{ NoSuchFieldError -> 0x001f }
                android.arch.lifecycle.c$b r3 = android.arch.lifecycle.C0024c.C0026b.CREATED     // Catch:{ NoSuchFieldError -> 0x001f }
                int r3 = r3.ordinal()     // Catch:{ NoSuchFieldError -> 0x001f }
                r2[r3] = r1     // Catch:{ NoSuchFieldError -> 0x001f }
            L_0x001f:
                r2 = 3
                int[] r3 = f73b     // Catch:{ NoSuchFieldError -> 0x002a }
                android.arch.lifecycle.c$b r4 = android.arch.lifecycle.C0024c.C0026b.STARTED     // Catch:{ NoSuchFieldError -> 0x002a }
                int r4 = r4.ordinal()     // Catch:{ NoSuchFieldError -> 0x002a }
                r3[r4] = r2     // Catch:{ NoSuchFieldError -> 0x002a }
            L_0x002a:
                r3 = 4
                int[] r4 = f73b     // Catch:{ NoSuchFieldError -> 0x0035 }
                android.arch.lifecycle.c$b r5 = android.arch.lifecycle.C0024c.C0026b.RESUMED     // Catch:{ NoSuchFieldError -> 0x0035 }
                int r5 = r5.ordinal()     // Catch:{ NoSuchFieldError -> 0x0035 }
                r4[r5] = r3     // Catch:{ NoSuchFieldError -> 0x0035 }
            L_0x0035:
                r4 = 5
                int[] r5 = f73b     // Catch:{ NoSuchFieldError -> 0x0040 }
                android.arch.lifecycle.c$b r6 = android.arch.lifecycle.C0024c.C0026b.DESTROYED     // Catch:{ NoSuchFieldError -> 0x0040 }
                int r6 = r6.ordinal()     // Catch:{ NoSuchFieldError -> 0x0040 }
                r5[r6] = r4     // Catch:{ NoSuchFieldError -> 0x0040 }
            L_0x0040:
                android.arch.lifecycle.c$a[] r5 = android.arch.lifecycle.C0024c.C0025a.values()
                int r5 = r5.length
                int[] r5 = new int[r5]
                f72a = r5
                int[] r5 = f72a     // Catch:{ NoSuchFieldError -> 0x0053 }
                android.arch.lifecycle.c$a r6 = android.arch.lifecycle.C0024c.C0025a.ON_CREATE     // Catch:{ NoSuchFieldError -> 0x0053 }
                int r6 = r6.ordinal()     // Catch:{ NoSuchFieldError -> 0x0053 }
                r5[r6] = r0     // Catch:{ NoSuchFieldError -> 0x0053 }
            L_0x0053:
                int[] r0 = f72a     // Catch:{ NoSuchFieldError -> 0x005d }
                android.arch.lifecycle.c$a r5 = android.arch.lifecycle.C0024c.C0025a.ON_STOP     // Catch:{ NoSuchFieldError -> 0x005d }
                int r5 = r5.ordinal()     // Catch:{ NoSuchFieldError -> 0x005d }
                r0[r5] = r1     // Catch:{ NoSuchFieldError -> 0x005d }
            L_0x005d:
                int[] r0 = f72a     // Catch:{ NoSuchFieldError -> 0x0067 }
                android.arch.lifecycle.c$a r1 = android.arch.lifecycle.C0024c.C0025a.ON_START     // Catch:{ NoSuchFieldError -> 0x0067 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0067 }
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0067 }
            L_0x0067:
                int[] r0 = f72a     // Catch:{ NoSuchFieldError -> 0x0071 }
                android.arch.lifecycle.c$a r1 = android.arch.lifecycle.C0024c.C0025a.ON_PAUSE     // Catch:{ NoSuchFieldError -> 0x0071 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0071 }
                r0[r1] = r3     // Catch:{ NoSuchFieldError -> 0x0071 }
            L_0x0071:
                int[] r0 = f72a     // Catch:{ NoSuchFieldError -> 0x007b }
                android.arch.lifecycle.c$a r1 = android.arch.lifecycle.C0024c.C0025a.ON_RESUME     // Catch:{ NoSuchFieldError -> 0x007b }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x007b }
                r0[r1] = r4     // Catch:{ NoSuchFieldError -> 0x007b }
            L_0x007b:
                int[] r0 = f72a     // Catch:{ NoSuchFieldError -> 0x0086 }
                android.arch.lifecycle.c$a r1 = android.arch.lifecycle.C0024c.C0025a.ON_DESTROY     // Catch:{ NoSuchFieldError -> 0x0086 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0086 }
                r2 = 6
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0086 }
            L_0x0086:
                int[] r0 = f72a     // Catch:{ NoSuchFieldError -> 0x0091 }
                android.arch.lifecycle.c$a r1 = android.arch.lifecycle.C0024c.C0025a.ON_ANY     // Catch:{ NoSuchFieldError -> 0x0091 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0091 }
                r2 = 7
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0091 }
            L_0x0091:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: android.arch.lifecycle.C0029f.C00301.<clinit>():void");
        }
    }

    /* renamed from: android.arch.lifecycle.f$a */
    static class C0031a {

        /* renamed from: a */
        C0026b f74a;

        /* renamed from: b */
        GenericLifecycleObserver f75b;

        C0031a(C0027d dVar, C0026b bVar) {
            this.f75b = C0033h.m106a((Object) dVar);
            this.f74a = bVar;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo68a(C0028e eVar, C0025a aVar) {
            C0026b b = C0029f.m89b(aVar);
            this.f74a = C0029f.m87a(this.f74a, b);
            this.f75b.mo35a(eVar, aVar);
            this.f74a = b;
        }
    }

    public C0029f(C0028e eVar) {
        this.f67c = new WeakReference<>(eVar);
        this.f66b = C0026b.INITIALIZED;
    }

    /* renamed from: a */
    static C0026b m87a(C0026b bVar, C0026b bVar2) {
        return (bVar2 == null || bVar2.compareTo(bVar) >= 0) ? bVar : bVar2;
    }

    /* renamed from: a */
    private void m88a(C0028e eVar) {
        C0014d c = this.f65a.mo15c();
        while (c.hasNext() && !this.f70f) {
            Entry entry = (Entry) c.next();
            C0031a aVar = (C0031a) entry.getValue();
            while (aVar.f74a.compareTo(this.f66b) < 0 && !this.f70f && this.f65a.mo10c(entry.getKey())) {
                m95c(aVar.f74a);
                aVar.mo68a(eVar, m98e(aVar.f74a));
                m94c();
            }
        }
    }

    /* renamed from: b */
    static C0026b m89b(C0025a aVar) {
        switch (C00301.f72a[aVar.ordinal()]) {
            case 1:
            case 2:
                return C0026b.CREATED;
            case 3:
            case C1217ty.f4597d /*4*/:
                return C0026b.STARTED;
            case C1217ty.f4598e /*5*/:
                return C0026b.RESUMED;
            case C1217ty.f4599f /*6*/:
                return C0026b.DESTROYED;
            default:
                StringBuilder sb = new StringBuilder();
                sb.append("Unexpected event value ");
                sb.append(aVar);
                throw new IllegalArgumentException(sb.toString());
        }
    }

    /* renamed from: b */
    private void m90b(C0026b bVar) {
        if (this.f66b != bVar) {
            this.f66b = bVar;
            if (this.f69e || this.f68d != 0) {
                this.f70f = true;
                return;
            }
            this.f69e = true;
            m97d();
            this.f69e = false;
        }
    }

    /* renamed from: b */
    private void m91b(C0028e eVar) {
        Iterator b = this.f65a.mo14b();
        while (b.hasNext() && !this.f70f) {
            Entry entry = (Entry) b.next();
            C0031a aVar = (C0031a) entry.getValue();
            while (aVar.f74a.compareTo(this.f66b) > 0 && !this.f70f && this.f65a.mo10c(entry.getKey())) {
                C0025a d = m96d(aVar.f74a);
                m95c(m89b(d));
                aVar.mo68a(eVar, d);
                m94c();
            }
        }
    }

    /* renamed from: b */
    private boolean m92b() {
        boolean z = true;
        if (this.f65a.mo12a() == 0) {
            return true;
        }
        C0026b bVar = ((C0031a) this.f65a.mo16d().getValue()).f74a;
        C0026b bVar2 = ((C0031a) this.f65a.mo17e().getValue()).f74a;
        if (!(bVar == bVar2 && this.f66b == bVar2)) {
            z = false;
        }
        return z;
    }

    /* renamed from: c */
    private C0026b m93c(C0027d dVar) {
        Entry d = this.f65a.mo11d(dVar);
        C0026b bVar = null;
        C0026b bVar2 = d != null ? ((C0031a) d.getValue()).f74a : null;
        if (!this.f71g.isEmpty()) {
            ArrayList<C0026b> arrayList = this.f71g;
            bVar = (C0026b) arrayList.get(arrayList.size() - 1);
        }
        return m87a(m87a(this.f66b, bVar2), bVar);
    }

    /* renamed from: c */
    private void m94c() {
        ArrayList<C0026b> arrayList = this.f71g;
        arrayList.remove(arrayList.size() - 1);
    }

    /* renamed from: c */
    private void m95c(C0026b bVar) {
        this.f71g.add(bVar);
    }

    /* renamed from: d */
    private static C0025a m96d(C0026b bVar) {
        switch (C00301.f73b[bVar.ordinal()]) {
            case 1:
                throw new IllegalArgumentException();
            case 2:
                return C0025a.ON_DESTROY;
            case 3:
                return C0025a.ON_STOP;
            case C1217ty.f4597d /*4*/:
                return C0025a.ON_PAUSE;
            case C1217ty.f4598e /*5*/:
                throw new IllegalArgumentException();
            default:
                StringBuilder sb = new StringBuilder();
                sb.append("Unexpected state value ");
                sb.append(bVar);
                throw new IllegalArgumentException(sb.toString());
        }
    }

    /* renamed from: d */
    private void m97d() {
        C0028e eVar = (C0028e) this.f67c.get();
        if (eVar == null) {
            Log.w("LifecycleRegistry", "LifecycleOwner is garbage collected, you shouldn't try dispatch new events from it.");
            return;
        }
        while (!m92b()) {
            this.f70f = false;
            if (this.f66b.compareTo(((C0031a) this.f65a.mo16d().getValue()).f74a) < 0) {
                m91b(eVar);
            }
            Entry e = this.f65a.mo17e();
            if (!this.f70f && e != null && this.f66b.compareTo(((C0031a) e.getValue()).f74a) > 0) {
                m88a(eVar);
            }
        }
        this.f70f = false;
    }

    /* renamed from: e */
    private static C0025a m98e(C0026b bVar) {
        switch (C00301.f73b[bVar.ordinal()]) {
            case 1:
            case C1217ty.f4598e /*5*/:
                return C0025a.ON_CREATE;
            case 2:
                return C0025a.ON_START;
            case 3:
                return C0025a.ON_RESUME;
            case C1217ty.f4597d /*4*/:
                throw new IllegalArgumentException();
            default:
                StringBuilder sb = new StringBuilder();
                sb.append("Unexpected state value ");
                sb.append(bVar);
                throw new IllegalArgumentException(sb.toString());
        }
    }

    /* renamed from: a */
    public C0026b mo61a() {
        return this.f66b;
    }

    /* renamed from: a */
    public void mo66a(C0025a aVar) {
        m90b(m89b(aVar));
    }

    /* renamed from: a */
    public void mo67a(C0026b bVar) {
        m90b(bVar);
    }

    /* renamed from: a */
    public void mo62a(C0027d dVar) {
        C0031a aVar = new C0031a(dVar, this.f66b == C0026b.DESTROYED ? C0026b.DESTROYED : C0026b.INITIALIZED);
        if (((C0031a) this.f65a.mo8a(dVar, aVar)) == null) {
            C0028e eVar = (C0028e) this.f67c.get();
            if (eVar != null) {
                boolean z = this.f68d != 0 || this.f69e;
                C0026b c = m93c(dVar);
                this.f68d++;
                while (aVar.f74a.compareTo(c) < 0 && this.f65a.mo10c(dVar)) {
                    m95c(aVar.f74a);
                    aVar.mo68a(eVar, m98e(aVar.f74a));
                    m94c();
                    c = m93c(dVar);
                }
                if (!z) {
                    m97d();
                }
                this.f68d--;
            }
        }
    }

    /* renamed from: b */
    public void mo63b(C0027d dVar) {
        this.f65a.mo9b(dVar);
    }
}
