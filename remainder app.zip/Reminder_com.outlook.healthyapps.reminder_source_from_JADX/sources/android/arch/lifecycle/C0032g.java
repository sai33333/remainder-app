package android.arch.lifecycle;

@Deprecated
/* renamed from: android.arch.lifecycle.g */
public interface C0032g extends C0028e {
    /* renamed from: b */
    C0029f mo69b();
}
