package android.arch.lifecycle;

/* renamed from: android.arch.lifecycle.j */
public class C0035j<T> extends LiveData<T> {
    /* renamed from: a */
    public void mo45a(T t) {
        super.mo45a(t);
    }
}
