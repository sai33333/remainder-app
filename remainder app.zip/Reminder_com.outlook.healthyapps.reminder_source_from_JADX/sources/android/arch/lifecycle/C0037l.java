package android.arch.lifecycle;

import android.arch.lifecycle.C0024c.C0025a;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
/* renamed from: android.arch.lifecycle.l */
public @interface C0037l {
    /* renamed from: a */
    C0025a mo71a();
}
