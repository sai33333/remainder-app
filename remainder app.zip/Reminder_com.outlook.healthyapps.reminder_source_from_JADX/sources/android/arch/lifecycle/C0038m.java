package android.arch.lifecycle;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.arch.lifecycle.C0024c.C0025a;
import android.os.Bundle;

/* renamed from: android.arch.lifecycle.m */
public class C0038m extends Fragment {

    /* renamed from: a */
    private C0039a f79a;

    /* renamed from: android.arch.lifecycle.m$a */
    interface C0039a {
        /* renamed from: a */
        void mo78a();

        /* renamed from: b */
        void mo79b();

        /* renamed from: c */
        void mo80c();
    }

    /* renamed from: a */
    public static void m116a(Activity activity) {
        FragmentManager fragmentManager = activity.getFragmentManager();
        if (fragmentManager.findFragmentByTag("android.arch.lifecycle.LifecycleDispatcher.report_fragment_tag") == null) {
            fragmentManager.beginTransaction().add(new C0038m(), "android.arch.lifecycle.LifecycleDispatcher.report_fragment_tag").commit();
            fragmentManager.executePendingTransactions();
        }
    }

    /* renamed from: a */
    private void m117a(C0025a aVar) {
        Activity activity = getActivity();
        if (activity instanceof C0032g) {
            ((C0032g) activity).mo69b().mo66a(aVar);
            return;
        }
        if (activity instanceof C0028e) {
            C0024c a = ((C0028e) activity).mo65a();
            if (a instanceof C0029f) {
                ((C0029f) a).mo66a(aVar);
            }
        }
    }

    /* renamed from: a */
    private void m118a(C0039a aVar) {
        if (aVar != null) {
            aVar.mo78a();
        }
    }

    /* renamed from: b */
    private void m119b(C0039a aVar) {
        if (aVar != null) {
            aVar.mo79b();
        }
    }

    /* renamed from: c */
    private void m120c(C0039a aVar) {
        if (aVar != null) {
            aVar.mo80c();
        }
    }

    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        m118a(this.f79a);
        m117a(C0025a.ON_CREATE);
    }

    public void onDestroy() {
        super.onDestroy();
        m117a(C0025a.ON_DESTROY);
        this.f79a = null;
    }

    public void onPause() {
        super.onPause();
        m117a(C0025a.ON_PAUSE);
    }

    public void onResume() {
        super.onResume();
        m120c(this.f79a);
        m117a(C0025a.ON_RESUME);
    }

    public void onStart() {
        super.onStart();
        m119b(this.f79a);
        m117a(C0025a.ON_START);
    }

    public void onStop() {
        super.onStop();
        m117a(C0025a.ON_STOP);
    }
}
