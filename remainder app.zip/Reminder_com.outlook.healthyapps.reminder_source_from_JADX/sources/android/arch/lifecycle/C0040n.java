package android.arch.lifecycle;

/* renamed from: android.arch.lifecycle.n */
public abstract class C0040n {
    /* access modifiers changed from: protected */
    /* renamed from: a */
    public void mo81a() {
    }
}
