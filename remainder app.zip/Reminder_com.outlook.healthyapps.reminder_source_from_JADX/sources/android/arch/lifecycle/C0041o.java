package android.arch.lifecycle;

/* renamed from: android.arch.lifecycle.o */
public class C0041o {

    /* renamed from: a */
    private final C0042a f80a;

    /* renamed from: b */
    private final C0043p f81b;

    /* renamed from: android.arch.lifecycle.o$a */
    public interface C0042a {
        /* renamed from: a */
        <T extends C0040n> T mo84a(Class<T> cls);
    }

    public C0041o(C0043p pVar, C0042a aVar) {
        this.f80a = aVar;
        this.f81b = pVar;
    }

    /* renamed from: a */
    public <T extends C0040n> T mo82a(Class<T> cls) {
        String canonicalName = cls.getCanonicalName();
        if (canonicalName != null) {
            StringBuilder sb = new StringBuilder();
            sb.append("android.arch.lifecycle.ViewModelProvider.DefaultKey:");
            sb.append(canonicalName);
            return mo83a(sb.toString(), cls);
        }
        throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
    }

    /* renamed from: a */
    public <T extends C0040n> T mo83a(String str, Class<T> cls) {
        T a = this.f81b.mo85a(str);
        if (cls.isInstance(a)) {
            return a;
        }
        T a2 = this.f80a.mo84a(cls);
        this.f81b.mo87a(str, a2);
        return a2;
    }
}
