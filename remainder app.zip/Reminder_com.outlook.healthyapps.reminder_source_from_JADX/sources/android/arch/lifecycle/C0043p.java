package android.arch.lifecycle;

import java.util.HashMap;

/* renamed from: android.arch.lifecycle.p */
public class C0043p {

    /* renamed from: a */
    private final HashMap<String, C0040n> f82a = new HashMap<>();

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public final C0040n mo85a(String str) {
        return (C0040n) this.f82a.get(str);
    }

    /* renamed from: a */
    public final void mo86a() {
        for (C0040n a : this.f82a.values()) {
            a.mo81a();
        }
        this.f82a.clear();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public final void mo87a(String str, C0040n nVar) {
        C0040n nVar2 = (C0040n) this.f82a.put(str, nVar);
        if (nVar2 != null) {
            nVar2.mo81a();
        }
    }
}
