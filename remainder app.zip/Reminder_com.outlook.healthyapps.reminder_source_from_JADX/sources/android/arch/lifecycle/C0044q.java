package android.arch.lifecycle;

/* renamed from: android.arch.lifecycle.q */
public interface C0044q {
    /* renamed from: b */
    C0043p mo88b();
}
