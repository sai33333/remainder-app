package android.arch.lifecycle;

import android.arch.lifecycle.C0024c.C0025a;

public class CompositeGeneratedAdaptersObserver implements GenericLifecycleObserver {

    /* renamed from: a */
    private final C0023b[] f29a;

    CompositeGeneratedAdaptersObserver(C0023b[] bVarArr) {
        this.f29a = bVarArr;
    }

    /* renamed from: a */
    public void mo35a(C0028e eVar, C0025a aVar) {
        C0034i iVar = new C0034i();
        for (C0023b a : this.f29a) {
            a.mo60a(eVar, aVar, false, iVar);
        }
        for (C0023b a2 : this.f29a) {
            a2.mo60a(eVar, aVar, true, iVar);
        }
    }
}
