package android.arch.lifecycle;

interface FullLifecycleObserver extends C0027d {
    /* renamed from: a */
    void mo36a(C0028e eVar);

    /* renamed from: b */
    void mo37b(C0028e eVar);

    /* renamed from: c */
    void mo38c(C0028e eVar);

    /* renamed from: d */
    void mo39d(C0028e eVar);

    /* renamed from: e */
    void mo40e(C0028e eVar);

    /* renamed from: f */
    void mo41f(C0028e eVar);
}
