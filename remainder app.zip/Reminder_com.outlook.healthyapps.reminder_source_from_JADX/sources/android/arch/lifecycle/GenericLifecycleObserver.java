package android.arch.lifecycle;

import android.arch.lifecycle.C0024c.C0025a;

public interface GenericLifecycleObserver extends C0027d {
    /* renamed from: a */
    void mo35a(C0028e eVar, C0025a aVar);
}
