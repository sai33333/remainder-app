package android.arch.lifecycle;

import android.arch.lifecycle.C0024c.C0025a;
import android.arch.lifecycle.C0024c.C0026b;
import android.arch.p001a.p002a.C0003a;
import android.arch.p001a.p003b.C0009b;
import java.util.Map.Entry;

public abstract class LiveData<T> {
    /* access modifiers changed from: private */

    /* renamed from: b */
    public static final Object f32b = new Object();
    /* access modifiers changed from: private */

    /* renamed from: a */
    public final Object f33a = new Object();

    /* renamed from: c */
    private C0009b<C0036k<T>, C0019a> f34c = new C0009b<>();
    /* access modifiers changed from: private */

    /* renamed from: d */
    public int f35d = 0;

    /* renamed from: e */
    private volatile Object f36e;
    /* access modifiers changed from: private */

    /* renamed from: f */
    public volatile Object f37f;

    /* renamed from: g */
    private int f38g;

    /* renamed from: h */
    private boolean f39h;

    /* renamed from: i */
    private boolean f40i;

    /* renamed from: j */
    private final Runnable f41j;

    class LifecycleBoundObserver extends C0019a implements GenericLifecycleObserver {

        /* renamed from: a */
        final C0028e f43a;

        LifecycleBoundObserver(C0028e eVar, C0036k<T> kVar) {
            super(kVar);
            this.f43a = eVar;
        }

        /* renamed from: a */
        public void mo35a(C0028e eVar, C0025a aVar) {
            if (this.f43a.mo65a().mo61a() == C0026b.DESTROYED) {
                LiveData.this.mo44a(this.f45c);
            } else {
                mo53a(mo50a());
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public boolean mo50a() {
            return this.f43a.mo65a().mo61a().mo64a(C0026b.STARTED);
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public boolean mo51a(C0028e eVar) {
            return this.f43a == eVar;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public void mo52b() {
            this.f43a.mo65a().mo63b(this);
        }
    }

    /* renamed from: android.arch.lifecycle.LiveData$a */
    private abstract class C0019a {

        /* renamed from: c */
        final C0036k<T> f45c;

        /* renamed from: d */
        boolean f46d;

        /* renamed from: e */
        int f47e = -1;

        C0019a(C0036k<T> kVar) {
            this.f45c = kVar;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo53a(boolean z) {
            if (z != this.f46d) {
                this.f46d = z;
                int i = 1;
                boolean z2 = LiveData.this.f35d == 0;
                LiveData liveData = LiveData.this;
                int c = liveData.f35d;
                if (!this.f46d) {
                    i = -1;
                }
                liveData.f35d = c + i;
                if (z2 && this.f46d) {
                    LiveData.this.mo46b();
                }
                if (LiveData.this.f35d == 0 && !this.f46d) {
                    LiveData.this.mo47c();
                }
                if (this.f46d) {
                    LiveData.this.m53b(this);
                }
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public abstract boolean mo50a();

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public boolean mo51a(C0028e eVar) {
            return false;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public void mo52b() {
        }
    }

    public LiveData() {
        Object obj = f32b;
        this.f36e = obj;
        this.f37f = obj;
        this.f38g = -1;
        this.f41j = new Runnable() {
            public void run() {
                Object b;
                synchronized (LiveData.this.f33a) {
                    b = LiveData.this.f37f;
                    LiveData.this.f37f = LiveData.f32b;
                }
                LiveData.this.mo45a(b);
            }
        };
    }

    /* renamed from: a */
    private void m49a(C0019a aVar) {
        if (aVar.f46d) {
            if (!aVar.mo50a()) {
                aVar.mo53a(false);
                return;
            }
            int i = aVar.f47e;
            int i2 = this.f38g;
            if (i < i2) {
                aVar.f47e = i2;
                aVar.f45c.mo70a(this.f36e);
            }
        }
    }

    /* renamed from: a */
    private static void m51a(String str) {
        if (!C0003a.m0a().mo4b()) {
            StringBuilder sb = new StringBuilder();
            sb.append("Cannot invoke ");
            sb.append(str);
            sb.append(" on a background");
            sb.append(" thread");
            throw new IllegalStateException(sb.toString());
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: b */
    public void m53b(C0019a aVar) {
        if (this.f39h) {
            this.f40i = true;
            return;
        }
        this.f39h = true;
        do {
            this.f40i = false;
            if (aVar == null) {
                C0014d c = this.f34c.mo15c();
                while (c.hasNext()) {
                    m49a((C0019a) ((Entry) c.next()).getValue());
                    if (this.f40i) {
                        break;
                    }
                }
            } else {
                m49a(aVar);
                aVar = null;
            }
        } while (this.f40i);
        this.f39h = false;
    }

    /* renamed from: a */
    public T mo42a() {
        T t = this.f36e;
        if (t != f32b) {
            return t;
        }
        return null;
    }

    /* renamed from: a */
    public void mo43a(C0028e eVar, C0036k<T> kVar) {
        if (eVar.mo65a().mo61a() != C0026b.DESTROYED) {
            LifecycleBoundObserver lifecycleBoundObserver = new LifecycleBoundObserver(eVar, kVar);
            C0019a aVar = (C0019a) this.f34c.mo8a(kVar, lifecycleBoundObserver);
            if (aVar != null && !aVar.mo51a(eVar)) {
                throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
            } else if (aVar == null) {
                eVar.mo65a().mo62a(lifecycleBoundObserver);
            }
        }
    }

    /* renamed from: a */
    public void mo44a(C0036k<T> kVar) {
        m51a("removeObserver");
        C0019a aVar = (C0019a) this.f34c.mo9b(kVar);
        if (aVar != null) {
            aVar.mo52b();
            aVar.mo53a(false);
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public void mo45a(T t) {
        m51a("setValue");
        this.f38g++;
        this.f36e = t;
        m53b(null);
    }

    /* access modifiers changed from: protected */
    /* renamed from: b */
    public void mo46b() {
    }

    /* access modifiers changed from: protected */
    /* renamed from: c */
    public void mo47c() {
    }

    /* renamed from: d */
    public boolean mo48d() {
        return this.f35d > 0;
    }
}
