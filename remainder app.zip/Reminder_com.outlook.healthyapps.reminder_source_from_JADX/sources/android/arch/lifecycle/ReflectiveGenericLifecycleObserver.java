package android.arch.lifecycle;

import android.arch.lifecycle.C0024c.C0025a;

class ReflectiveGenericLifecycleObserver implements GenericLifecycleObserver {

    /* renamed from: a */
    private final Object f49a;

    /* renamed from: b */
    private final C0021a f50b = C0020a.f52a.mo55b(this.f49a.getClass());

    ReflectiveGenericLifecycleObserver(Object obj) {
        this.f49a = obj;
    }

    /* renamed from: a */
    public void mo35a(C0028e eVar, C0025a aVar) {
        this.f50b.mo56a(eVar, aVar, this.f49a);
    }
}
