package android.arch.lifecycle;

import android.arch.lifecycle.C0024c.C0025a;

public class SingleGeneratedAdapterObserver implements GenericLifecycleObserver {

    /* renamed from: a */
    private final C0023b f51a;

    SingleGeneratedAdapterObserver(C0023b bVar) {
        this.f51a = bVar;
    }

    /* renamed from: a */
    public void mo35a(C0028e eVar, C0025a aVar) {
        this.f51a.mo60a(eVar, aVar, false, null);
        this.f51a.mo60a(eVar, aVar, true, null);
    }
}
