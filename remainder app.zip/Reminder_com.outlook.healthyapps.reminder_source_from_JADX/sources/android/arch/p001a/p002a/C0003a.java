package android.arch.p001a.p002a;

import java.util.concurrent.Executor;

/* renamed from: android.arch.a.a.a */
public class C0003a extends C0007c {

    /* renamed from: a */
    private static volatile C0003a f7a;

    /* renamed from: d */
    private static final Executor f8d = new Executor() {
        public void execute(Runnable runnable) {
            C0003a.m0a().mo3b(runnable);
        }
    };

    /* renamed from: e */
    private static final Executor f9e = new Executor() {
        public void execute(Runnable runnable) {
            C0003a.m0a().mo2a(runnable);
        }
    };

    /* renamed from: b */
    private C0007c f10b = this.f11c;

    /* renamed from: c */
    private C0007c f11c = new C0006b();

    private C0003a() {
    }

    /* renamed from: a */
    public static C0003a m0a() {
        if (f7a != null) {
            return f7a;
        }
        synchronized (C0003a.class) {
            if (f7a == null) {
                f7a = new C0003a();
            }
        }
        return f7a;
    }

    /* renamed from: a */
    public void mo2a(Runnable runnable) {
        this.f10b.mo2a(runnable);
    }

    /* renamed from: b */
    public void mo3b(Runnable runnable) {
        this.f10b.mo3b(runnable);
    }

    /* renamed from: b */
    public boolean mo4b() {
        return this.f10b.mo4b();
    }
}
