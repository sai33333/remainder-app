package android.arch.p001a.p002a;

import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/* renamed from: android.arch.a.a.b */
public class C0006b extends C0007c {

    /* renamed from: a */
    private final Object f12a = new Object();

    /* renamed from: b */
    private ExecutorService f13b = Executors.newFixedThreadPool(2);

    /* renamed from: c */
    private volatile Handler f14c;

    /* renamed from: a */
    public void mo2a(Runnable runnable) {
        this.f13b.execute(runnable);
    }

    /* renamed from: b */
    public void mo3b(Runnable runnable) {
        if (this.f14c == null) {
            synchronized (this.f12a) {
                if (this.f14c == null) {
                    this.f14c = new Handler(Looper.getMainLooper());
                }
            }
        }
        this.f14c.post(runnable);
    }

    /* renamed from: b */
    public boolean mo4b() {
        return Looper.getMainLooper().getThread() == Thread.currentThread();
    }
}
