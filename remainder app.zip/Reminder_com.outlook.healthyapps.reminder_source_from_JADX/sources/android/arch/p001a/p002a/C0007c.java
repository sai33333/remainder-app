package android.arch.p001a.p002a;

/* renamed from: android.arch.a.a.c */
public abstract class C0007c {
    /* renamed from: a */
    public abstract void mo2a(Runnable runnable);

    /* renamed from: b */
    public abstract void mo3b(Runnable runnable);

    /* renamed from: b */
    public abstract boolean mo4b();
}
