package android.arch.p001a.p003b;

import java.util.HashMap;
import java.util.Map.Entry;

/* renamed from: android.arch.a.b.a */
public class C0008a<K, V> extends C0009b<K, V> {

    /* renamed from: a */
    private HashMap<K, C0013c<K, V>> f15a = new HashMap<>();

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public C0013c<K, V> mo7a(K k) {
        return (C0013c) this.f15a.get(k);
    }

    /* renamed from: a */
    public V mo8a(K k, V v) {
        C0013c a = mo7a(k);
        if (a != null) {
            return a.f21b;
        }
        this.f15a.put(k, mo13b(k, v));
        return null;
    }

    /* renamed from: b */
    public V mo9b(K k) {
        V b = super.mo9b(k);
        this.f15a.remove(k);
        return b;
    }

    /* renamed from: c */
    public boolean mo10c(K k) {
        return this.f15a.containsKey(k);
    }

    /* renamed from: d */
    public Entry<K, V> mo11d(K k) {
        if (mo10c(k)) {
            return ((C0013c) this.f15a.get(k)).f23d;
        }
        return null;
    }
}
