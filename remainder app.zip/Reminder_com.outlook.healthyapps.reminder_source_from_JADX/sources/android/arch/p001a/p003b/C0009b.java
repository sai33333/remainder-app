package android.arch.p001a.p003b;

import java.util.Iterator;
import java.util.Map.Entry;
import java.util.WeakHashMap;

/* renamed from: android.arch.a.b.b */
public class C0009b<K, V> implements Iterable<Entry<K, V>> {
    /* access modifiers changed from: private */

    /* renamed from: a */
    public C0013c<K, V> f16a;

    /* renamed from: b */
    private C0013c<K, V> f17b;

    /* renamed from: c */
    private WeakHashMap<C0016f<K, V>, Boolean> f18c = new WeakHashMap<>();

    /* renamed from: d */
    private int f19d = 0;

    /* renamed from: android.arch.a.b.b$a */
    static class C0011a<K, V> extends C0015e<K, V> {
        C0011a(C0013c<K, V> cVar, C0013c<K, V> cVar2) {
            super(cVar, cVar2);
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public C0013c<K, V> mo21a(C0013c<K, V> cVar) {
            return cVar.f22c;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public C0013c<K, V> mo22b(C0013c<K, V> cVar) {
            return cVar.f23d;
        }
    }

    /* renamed from: android.arch.a.b.b$b */
    private static class C0012b<K, V> extends C0015e<K, V> {
        C0012b(C0013c<K, V> cVar, C0013c<K, V> cVar2) {
            super(cVar, cVar2);
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public C0013c<K, V> mo21a(C0013c<K, V> cVar) {
            return cVar.f23d;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public C0013c<K, V> mo22b(C0013c<K, V> cVar) {
            return cVar.f22c;
        }
    }

    /* renamed from: android.arch.a.b.b$c */
    static class C0013c<K, V> implements Entry<K, V> {

        /* renamed from: a */
        final K f20a;

        /* renamed from: b */
        final V f21b;

        /* renamed from: c */
        C0013c<K, V> f22c;

        /* renamed from: d */
        C0013c<K, V> f23d;

        C0013c(K k, V v) {
            this.f20a = k;
            this.f21b = v;
        }

        public boolean equals(Object obj) {
            boolean z = true;
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof C0013c)) {
                return false;
            }
            C0013c cVar = (C0013c) obj;
            if (!this.f20a.equals(cVar.f20a) || !this.f21b.equals(cVar.f21b)) {
                z = false;
            }
            return z;
        }

        public K getKey() {
            return this.f20a;
        }

        public V getValue() {
            return this.f21b;
        }

        public V setValue(V v) {
            throw new UnsupportedOperationException("An entry modification is not supported");
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append(this.f20a);
            sb.append("=");
            sb.append(this.f21b);
            return sb.toString();
        }
    }

    /* renamed from: android.arch.a.b.b$d */
    private class C0014d implements C0016f<K, V>, Iterator<Entry<K, V>> {

        /* renamed from: b */
        private C0013c<K, V> f25b;

        /* renamed from: c */
        private boolean f26c;

        private C0014d() {
            this.f26c = true;
        }

        /* renamed from: a */
        public Entry<K, V> next() {
            C0013c<K, V> cVar;
            if (this.f26c) {
                this.f26c = false;
                cVar = C0009b.this.f16a;
            } else {
                C0013c<K, V> cVar2 = this.f25b;
                cVar = cVar2 != null ? cVar2.f22c : null;
            }
            this.f25b = cVar;
            return this.f25b;
        }

        /* renamed from: a_ */
        public void mo29a_(C0013c<K, V> cVar) {
            C0013c<K, V> cVar2 = this.f25b;
            if (cVar == cVar2) {
                this.f25b = cVar2.f23d;
                this.f26c = this.f25b == null;
            }
        }

        public boolean hasNext() {
            boolean z = true;
            if (this.f26c) {
                if (C0009b.this.f16a == null) {
                    z = false;
                }
                return z;
            }
            C0013c<K, V> cVar = this.f25b;
            if (cVar == null || cVar.f22c == null) {
                z = false;
            }
            return z;
        }
    }

    /* renamed from: android.arch.a.b.b$e */
    private static abstract class C0015e<K, V> implements C0016f<K, V>, Iterator<Entry<K, V>> {

        /* renamed from: a */
        C0013c<K, V> f27a;

        /* renamed from: b */
        C0013c<K, V> f28b;

        C0015e(C0013c<K, V> cVar, C0013c<K, V> cVar2) {
            this.f27a = cVar2;
            this.f28b = cVar;
        }

        /* renamed from: b */
        private C0013c<K, V> m31b() {
            C0013c<K, V> cVar = this.f28b;
            C0013c<K, V> cVar2 = this.f27a;
            if (cVar == cVar2 || cVar2 == null) {
                return null;
            }
            return mo21a(cVar);
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public abstract C0013c<K, V> mo21a(C0013c<K, V> cVar);

        /* renamed from: a */
        public Entry<K, V> next() {
            C0013c<K, V> cVar = this.f28b;
            this.f28b = m31b();
            return cVar;
        }

        /* renamed from: a_ */
        public void mo29a_(C0013c<K, V> cVar) {
            if (this.f27a == cVar && cVar == this.f28b) {
                this.f28b = null;
                this.f27a = null;
            }
            C0013c<K, V> cVar2 = this.f27a;
            if (cVar2 == cVar) {
                this.f27a = mo22b(cVar2);
            }
            if (this.f28b == cVar) {
                this.f28b = m31b();
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public abstract C0013c<K, V> mo22b(C0013c<K, V> cVar);

        public boolean hasNext() {
            return this.f28b != null;
        }
    }

    /* renamed from: android.arch.a.b.b$f */
    interface C0016f<K, V> {
        /* renamed from: a_ */
        void mo29a_(C0013c<K, V> cVar);
    }

    /* renamed from: a */
    public int mo12a() {
        return this.f19d;
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public C0013c<K, V> mo7a(K k) {
        C0013c<K, V> cVar = this.f16a;
        while (cVar != null && !cVar.f20a.equals(k)) {
            cVar = cVar.f22c;
        }
        return cVar;
    }

    /* renamed from: a */
    public V mo8a(K k, V v) {
        C0013c a = mo7a(k);
        if (a != null) {
            return a.f21b;
        }
        mo13b(k, v);
        return null;
    }

    /* access modifiers changed from: protected */
    /* renamed from: b */
    public C0013c<K, V> mo13b(K k, V v) {
        C0013c<K, V> cVar = new C0013c<>(k, v);
        this.f19d++;
        C0013c<K, V> cVar2 = this.f17b;
        if (cVar2 == null) {
            this.f16a = cVar;
            this.f17b = this.f16a;
            return cVar;
        }
        cVar2.f22c = cVar;
        cVar.f23d = cVar2;
        this.f17b = cVar;
        return cVar;
    }

    /* renamed from: b */
    public V mo9b(K k) {
        C0013c a = mo7a(k);
        if (a == null) {
            return null;
        }
        this.f19d--;
        if (!this.f18c.isEmpty()) {
            for (C0016f a_ : this.f18c.keySet()) {
                a_.mo29a_(a);
            }
        }
        if (a.f23d != null) {
            a.f23d.f22c = a.f22c;
        } else {
            this.f16a = a.f22c;
        }
        if (a.f22c != null) {
            a.f22c.f23d = a.f23d;
        } else {
            this.f17b = a.f23d;
        }
        a.f22c = null;
        a.f23d = null;
        return a.f21b;
    }

    /* renamed from: b */
    public Iterator<Entry<K, V>> mo14b() {
        C0012b bVar = new C0012b(this.f17b, this.f16a);
        this.f18c.put(bVar, Boolean.valueOf(false));
        return bVar;
    }

    /* renamed from: c */
    public C0014d mo15c() {
        C0014d dVar = new C0014d<>();
        this.f18c.put(dVar, Boolean.valueOf(false));
        return dVar;
    }

    /* renamed from: d */
    public Entry<K, V> mo16d() {
        return this.f16a;
    }

    /* renamed from: e */
    public Entry<K, V> mo17e() {
        return this.f17b;
    }

    public boolean equals(Object obj) {
        boolean z = true;
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof C0009b)) {
            return false;
        }
        C0009b bVar = (C0009b) obj;
        if (mo12a() != bVar.mo12a()) {
            return false;
        }
        Iterator it = iterator();
        Iterator it2 = bVar.iterator();
        while (it.hasNext() && it2.hasNext()) {
            Entry entry = (Entry) it.next();
            Object next = it2.next();
            if ((entry == null && next != null) || (entry != null && !entry.equals(next))) {
                return false;
            }
        }
        if (it.hasNext() || it2.hasNext()) {
            z = false;
        }
        return z;
    }

    public Iterator<Entry<K, V>> iterator() {
        C0011a aVar = new C0011a(this.f16a, this.f17b);
        this.f18c.put(aVar, Boolean.valueOf(false));
        return aVar;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        Iterator it = iterator();
        while (it.hasNext()) {
            sb.append(((Entry) it.next()).toString());
            if (it.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append("]");
        return sb.toString();
    }
}
