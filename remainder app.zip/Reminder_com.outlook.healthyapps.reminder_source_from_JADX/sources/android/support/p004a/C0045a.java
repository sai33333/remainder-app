package android.support.p004a;

/* renamed from: android.support.a.a */
public final class C0045a {

    /* renamed from: android.support.a.a$a */
    public static final class C0046a {
        public static final int compat_button_inset_horizontal_material = 2131034114;
        public static final int compat_button_inset_vertical_material = 2131034115;
        public static final int compat_button_padding_horizontal_material = 2131034116;
        public static final int compat_button_padding_vertical_material = 2131034117;
        public static final int compat_control_corner_material = 2131034118;
        public static final int compat_notification_large_icon_max_height = 2131034119;
        public static final int compat_notification_large_icon_max_width = 2131034120;
        public static final int notification_action_icon_size = 2131034127;
        public static final int notification_action_text_size = 2131034128;
        public static final int notification_big_circle_margin = 2131034129;
        public static final int notification_content_margin_start = 2131034130;
        public static final int notification_large_icon_height = 2131034131;
        public static final int notification_large_icon_width = 2131034132;
        public static final int notification_main_column_padding_top = 2131034133;
        public static final int notification_media_narrow_margin = 2131034134;
        public static final int notification_right_icon_size = 2131034135;
        public static final int notification_right_side_padding_top = 2131034136;
        public static final int notification_small_icon_background_padding = 2131034137;
        public static final int notification_small_icon_size_as_large = 2131034138;
        public static final int notification_subtext_size = 2131034139;
        public static final int notification_top_pad = 2131034140;
        public static final int notification_top_pad_large_text = 2131034141;
    }

    /* renamed from: android.support.a.a$b */
    public static final class C0047b {
        public static final int action_container = 2131165186;
        public static final int action_divider = 2131165187;
        public static final int action_image = 2131165188;
        public static final int action_text = 2131165189;
        public static final int actions = 2131165190;
        public static final int async = 2131165194;
        public static final int blocking = 2131165195;
        public static final int chronometer = 2131165222;
        public static final int forever = 2131165237;
        public static final int icon = 2131165239;
        public static final int icon_group = 2131165240;
        public static final int info = 2131165241;
        public static final int italic = 2131165242;
        public static final int line1 = 2131165245;
        public static final int line3 = 2131165246;
        public static final int normal = 2131165251;
        public static final int notification_background = 2131165252;
        public static final int notification_main_column = 2131165253;
        public static final int notification_main_column_container = 2131165254;
        public static final int right_icon = 2131165261;
        public static final int right_side = 2131165262;
        public static final int tag_transition_group = 2131165267;
        public static final int tag_unhandled_key_event_manager = 2131165268;
        public static final int tag_unhandled_key_listeners = 2131165269;
        public static final int text = 2131165270;
        public static final int text2 = 2131165271;
        public static final int time = 2131165275;
        public static final int title = 2131165276;
    }
}
