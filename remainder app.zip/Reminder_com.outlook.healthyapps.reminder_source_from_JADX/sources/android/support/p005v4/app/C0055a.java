package android.support.p005v4.app;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build.VERSION;
import android.os.Handler;
import android.os.Looper;
import android.support.p005v4.p006a.C0048a;

/* renamed from: android.support.v4.app.a */
public class C0055a extends C0048a {

    /* renamed from: a */
    private static C0058b f106a;

    /* renamed from: android.support.v4.app.a$a */
    public interface C0057a {
        void onRequestPermissionsResult(int i, String[] strArr, int[] iArr);
    }

    /* renamed from: android.support.v4.app.a$b */
    public interface C0058b {
        /* renamed from: a */
        boolean mo125a(Activity activity, int i, int i2, Intent intent);

        /* renamed from: a */
        boolean mo126a(Activity activity, String[] strArr, int i);
    }

    /* renamed from: android.support.v4.app.a$c */
    public interface C0059c {
        /* renamed from: a */
        void mo127a(int i);
    }

    /* renamed from: a */
    public static C0058b m167a() {
        return f106a;
    }

    /* renamed from: a */
    public static void m168a(final Activity activity, final String[] strArr, final int i) {
        C0058b bVar = f106a;
        if (bVar == null || !bVar.mo126a(activity, strArr, i)) {
            if (VERSION.SDK_INT >= 23) {
                if (activity instanceof C0059c) {
                    ((C0059c) activity).mo127a(i);
                }
                activity.requestPermissions(strArr, i);
            } else if (activity instanceof C0057a) {
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    public void run() {
                        int[] iArr = new int[strArr.length];
                        PackageManager packageManager = activity.getPackageManager();
                        String packageName = activity.getPackageName();
                        int length = strArr.length;
                        for (int i = 0; i < length; i++) {
                            iArr[i] = packageManager.checkPermission(strArr[i], packageName);
                        }
                        ((C0057a) activity).onRequestPermissionsResult(i, strArr, iArr);
                    }
                });
            }
        }
    }

    /* renamed from: a */
    public static boolean m169a(Activity activity, String str) {
        if (VERSION.SDK_INT >= 23) {
            return activity.shouldShowRequestPermissionRationale(str);
        }
        return false;
    }
}
