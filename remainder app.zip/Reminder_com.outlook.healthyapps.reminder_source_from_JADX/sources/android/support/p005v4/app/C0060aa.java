package android.support.p005v4.app;

import android.app.Activity;
import android.arch.lifecycle.C0024c;
import android.arch.lifecycle.C0024c.C0026b;
import android.arch.lifecycle.C0028e;
import android.arch.lifecycle.C0029f;
import android.arch.lifecycle.C0038m;
import android.os.Bundle;
import android.support.p005v4.p008c.C0165h;
import android.support.p005v4.p009d.C0167a;
import android.support.p005v4.p009d.C0167a.C0168a;
import android.view.KeyEvent;
import android.view.View;

/* renamed from: android.support.v4.app.aa */
public class C0060aa extends Activity implements C0028e, C0168a {

    /* renamed from: a */
    private C0165h<Class<? extends Object>, Object> f110a = new C0165h<>();

    /* renamed from: b */
    private C0029f f111b = new C0029f(this);

    /* renamed from: a */
    public C0024c mo65a() {
        return this.f111b;
    }

    /* renamed from: a */
    public boolean mo128a(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent);
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        View decorView = getWindow().getDecorView();
        if (decorView == null || !C0167a.m761a(decorView, keyEvent)) {
            return C0167a.m760a(this, decorView, this, keyEvent);
        }
        return true;
    }

    public boolean dispatchKeyShortcutEvent(KeyEvent keyEvent) {
        View decorView = getWindow().getDecorView();
        if (decorView == null || !C0167a.m761a(decorView, keyEvent)) {
            return super.dispatchKeyShortcutEvent(keyEvent);
        }
        return true;
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        C0038m.m116a((Activity) this);
    }

    /* access modifiers changed from: protected */
    public void onSaveInstanceState(Bundle bundle) {
        this.f111b.mo67a(C0026b.CREATED);
        super.onSaveInstanceState(bundle);
    }
}
