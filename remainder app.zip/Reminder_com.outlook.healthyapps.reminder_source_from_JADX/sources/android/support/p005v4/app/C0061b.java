package android.support.p005v4.app;

import android.support.p005v4.p008c.C0157e;
import android.util.Log;
import com.google.android.gms.C0276a.C0278b;
import com.google.android.gms.internal.C1217ty;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.Modifier;
import java.util.ArrayList;

/* renamed from: android.support.v4.app.b */
final class C0061b extends C0107p implements C0099h {

    /* renamed from: a */
    final C0085l f112a;

    /* renamed from: b */
    ArrayList<C0062a> f113b = new ArrayList<>();

    /* renamed from: c */
    int f114c;

    /* renamed from: d */
    int f115d;

    /* renamed from: e */
    int f116e;

    /* renamed from: f */
    int f117f;

    /* renamed from: g */
    int f118g;

    /* renamed from: h */
    int f119h;

    /* renamed from: i */
    boolean f120i;

    /* renamed from: j */
    boolean f121j = true;

    /* renamed from: k */
    String f122k;

    /* renamed from: l */
    boolean f123l;

    /* renamed from: m */
    int f124m = -1;

    /* renamed from: n */
    int f125n;

    /* renamed from: o */
    CharSequence f126o;

    /* renamed from: p */
    int f127p;

    /* renamed from: q */
    CharSequence f128q;

    /* renamed from: r */
    ArrayList<String> f129r;

    /* renamed from: s */
    ArrayList<String> f130s;

    /* renamed from: t */
    boolean f131t = false;

    /* renamed from: u */
    ArrayList<Runnable> f132u;

    /* renamed from: android.support.v4.app.b$a */
    static final class C0062a {

        /* renamed from: a */
        int f133a;

        /* renamed from: b */
        C0068f f134b;

        /* renamed from: c */
        int f135c;

        /* renamed from: d */
        int f136d;

        /* renamed from: e */
        int f137e;

        /* renamed from: f */
        int f138f;

        C0062a() {
        }

        C0062a(int i, C0068f fVar) {
            this.f133a = i;
            this.f134b = fVar;
        }
    }

    public C0061b(C0085l lVar) {
        this.f112a = lVar;
    }

    /* renamed from: a */
    private void m175a(int i, C0068f fVar, String str, int i2) {
        Class cls = fVar.getClass();
        int modifiers = cls.getModifiers();
        if (cls.isAnonymousClass() || !Modifier.isPublic(modifiers) || (cls.isMemberClass() && !Modifier.isStatic(modifiers))) {
            StringBuilder sb = new StringBuilder();
            sb.append("Fragment ");
            sb.append(cls.getCanonicalName());
            sb.append(" must be a public static class to be  properly recreated from");
            sb.append(" instance state.");
            throw new IllegalStateException(sb.toString());
        }
        fVar.f165B = this.f112a;
        if (str != null) {
            if (fVar.f173J == null || str.equals(fVar.f173J)) {
                fVar.f173J = str;
            } else {
                StringBuilder sb2 = new StringBuilder();
                sb2.append("Can't change tag of fragment ");
                sb2.append(fVar);
                sb2.append(": was ");
                sb2.append(fVar.f173J);
                sb2.append(" now ");
                sb2.append(str);
                throw new IllegalStateException(sb2.toString());
            }
        }
        if (i != 0) {
            if (i == -1) {
                StringBuilder sb3 = new StringBuilder();
                sb3.append("Can't add fragment ");
                sb3.append(fVar);
                sb3.append(" with tag ");
                sb3.append(str);
                sb3.append(" to container view with no id");
                throw new IllegalArgumentException(sb3.toString());
            } else if (fVar.f171H == 0 || fVar.f171H == i) {
                fVar.f171H = i;
                fVar.f172I = i;
            } else {
                StringBuilder sb4 = new StringBuilder();
                sb4.append("Can't change container ID of fragment ");
                sb4.append(fVar);
                sb4.append(": was ");
                sb4.append(fVar.f171H);
                sb4.append(" now ");
                sb4.append(i);
                throw new IllegalStateException(sb4.toString());
            }
        }
        mo139a(new C0062a(i2, fVar));
    }

    /* renamed from: b */
    private static boolean m176b(C0062a aVar) {
        C0068f fVar = aVar.f134b;
        return fVar != null && fVar.f206u && fVar.f182S != null && !fVar.f175L && !fVar.f174K && fVar.mo201Y();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public int mo133a(boolean z) {
        if (!this.f123l) {
            if (C0085l.f260a) {
                StringBuilder sb = new StringBuilder();
                sb.append("Commit: ");
                sb.append(this);
                Log.v("FragmentManager", sb.toString());
                PrintWriter printWriter = new PrintWriter(new C0157e("FragmentManager"));
                mo141a("  ", (FileDescriptor) null, printWriter, (String[]) null);
                printWriter.close();
            }
            this.f123l = true;
            this.f124m = this.f120i ? this.f112a.mo371a(this) : -1;
            this.f112a.mo388a((C0099h) this, z);
            return this.f124m;
        }
        throw new IllegalStateException("commit already called");
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public C0068f mo134a(ArrayList<C0068f> arrayList, C0068f fVar) {
        C0068f fVar2 = fVar;
        int i = 0;
        while (i < this.f113b.size()) {
            C0062a aVar = (C0062a) this.f113b.get(i);
            switch (aVar.f133a) {
                case 1:
                case C1217ty.f4600g /*7*/:
                    arrayList.add(aVar.f134b);
                    break;
                case 2:
                    C0068f fVar3 = aVar.f134b;
                    int i2 = fVar3.f172I;
                    C0068f fVar4 = fVar2;
                    int i3 = i;
                    boolean z = false;
                    for (int size = arrayList.size() - 1; size >= 0; size--) {
                        C0068f fVar5 = (C0068f) arrayList.get(size);
                        if (fVar5.f172I == i2) {
                            if (fVar5 == fVar3) {
                                z = true;
                            } else {
                                if (fVar5 == fVar4) {
                                    this.f113b.add(i3, new C0062a(9, fVar5));
                                    i3++;
                                    fVar4 = null;
                                }
                                C0062a aVar2 = new C0062a(3, fVar5);
                                aVar2.f135c = aVar.f135c;
                                aVar2.f137e = aVar.f137e;
                                aVar2.f136d = aVar.f136d;
                                aVar2.f138f = aVar.f138f;
                                this.f113b.add(i3, aVar2);
                                arrayList.remove(fVar5);
                                i3++;
                            }
                        }
                    }
                    if (z) {
                        this.f113b.remove(i3);
                        i3--;
                    } else {
                        aVar.f133a = 1;
                        arrayList.add(fVar3);
                    }
                    i = i3;
                    fVar2 = fVar4;
                    break;
                case 3:
                case C1217ty.f4599f /*6*/:
                    arrayList.remove(aVar.f134b);
                    if (aVar.f134b != fVar2) {
                        break;
                    } else {
                        this.f113b.add(i, new C0062a(9, aVar.f134b));
                        i++;
                        fVar2 = null;
                        break;
                    }
                case C1217ty.f4601h /*8*/:
                    this.f113b.add(i, new C0062a(9, fVar2));
                    i++;
                    fVar2 = aVar.f134b;
                    break;
            }
            i++;
        }
        return fVar2;
    }

    /* renamed from: a */
    public C0107p mo135a(C0068f fVar) {
        mo139a(new C0062a(3, fVar));
        return this;
    }

    /* renamed from: a */
    public C0107p mo136a(C0068f fVar, String str) {
        m175a(0, fVar, str, 1);
        return this;
    }

    /* renamed from: a */
    public void mo137a() {
        ArrayList<Runnable> arrayList = this.f132u;
        if (arrayList != null) {
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                ((Runnable) this.f132u.get(i)).run();
            }
            this.f132u = null;
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo138a(int i) {
        if (this.f120i) {
            if (C0085l.f260a) {
                StringBuilder sb = new StringBuilder();
                sb.append("Bump nesting in ");
                sb.append(this);
                sb.append(" by ");
                sb.append(i);
                Log.v("FragmentManager", sb.toString());
            }
            int size = this.f113b.size();
            for (int i2 = 0; i2 < size; i2++) {
                C0062a aVar = (C0062a) this.f113b.get(i2);
                if (aVar.f134b != null) {
                    aVar.f134b.f164A += i;
                    if (C0085l.f260a) {
                        StringBuilder sb2 = new StringBuilder();
                        sb2.append("Bump nesting of ");
                        sb2.append(aVar.f134b);
                        sb2.append(" to ");
                        sb2.append(aVar.f134b.f164A);
                        Log.v("FragmentManager", sb2.toString());
                    }
                }
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo139a(C0062a aVar) {
        this.f113b.add(aVar);
        aVar.f135c = this.f114c;
        aVar.f136d = this.f115d;
        aVar.f137e = this.f116e;
        aVar.f138f = this.f117f;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo140a(C0074c cVar) {
        for (int i = 0; i < this.f113b.size(); i++) {
            C0062a aVar = (C0062a) this.f113b.get(i);
            if (m176b(aVar)) {
                aVar.f134b.mo216a(cVar);
            }
        }
    }

    /* renamed from: a */
    public void mo141a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        mo142a(str, printWriter, true);
    }

    /* renamed from: a */
    public void mo142a(String str, PrintWriter printWriter, boolean z) {
        String str2;
        if (z) {
            printWriter.print(str);
            printWriter.print("mName=");
            printWriter.print(this.f122k);
            printWriter.print(" mIndex=");
            printWriter.print(this.f124m);
            printWriter.print(" mCommitted=");
            printWriter.println(this.f123l);
            if (this.f118g != 0) {
                printWriter.print(str);
                printWriter.print("mTransition=#");
                printWriter.print(Integer.toHexString(this.f118g));
                printWriter.print(" mTransitionStyle=#");
                printWriter.println(Integer.toHexString(this.f119h));
            }
            if (!(this.f114c == 0 && this.f115d == 0)) {
                printWriter.print(str);
                printWriter.print("mEnterAnim=#");
                printWriter.print(Integer.toHexString(this.f114c));
                printWriter.print(" mExitAnim=#");
                printWriter.println(Integer.toHexString(this.f115d));
            }
            if (!(this.f116e == 0 && this.f117f == 0)) {
                printWriter.print(str);
                printWriter.print("mPopEnterAnim=#");
                printWriter.print(Integer.toHexString(this.f116e));
                printWriter.print(" mPopExitAnim=#");
                printWriter.println(Integer.toHexString(this.f117f));
            }
            if (!(this.f125n == 0 && this.f126o == null)) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbTitleRes=#");
                printWriter.print(Integer.toHexString(this.f125n));
                printWriter.print(" mBreadCrumbTitleText=");
                printWriter.println(this.f126o);
            }
            if (!(this.f127p == 0 && this.f128q == null)) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbShortTitleRes=#");
                printWriter.print(Integer.toHexString(this.f127p));
                printWriter.print(" mBreadCrumbShortTitleText=");
                printWriter.println(this.f128q);
            }
        }
        if (!this.f113b.isEmpty()) {
            printWriter.print(str);
            printWriter.println("Operations:");
            StringBuilder sb = new StringBuilder();
            sb.append(str);
            sb.append("    ");
            sb.toString();
            int size = this.f113b.size();
            for (int i = 0; i < size; i++) {
                C0062a aVar = (C0062a) this.f113b.get(i);
                switch (aVar.f133a) {
                    case C0278b.AdsAttrs_adSize /*0*/:
                        str2 = "NULL";
                        break;
                    case 1:
                        str2 = "ADD";
                        break;
                    case 2:
                        str2 = "REPLACE";
                        break;
                    case 3:
                        str2 = "REMOVE";
                        break;
                    case C1217ty.f4597d /*4*/:
                        str2 = "HIDE";
                        break;
                    case C1217ty.f4598e /*5*/:
                        str2 = "SHOW";
                        break;
                    case C1217ty.f4599f /*6*/:
                        str2 = "DETACH";
                        break;
                    case C1217ty.f4600g /*7*/:
                        str2 = "ATTACH";
                        break;
                    case C1217ty.f4601h /*8*/:
                        str2 = "SET_PRIMARY_NAV";
                        break;
                    case 9:
                        str2 = "UNSET_PRIMARY_NAV";
                        break;
                    default:
                        StringBuilder sb2 = new StringBuilder();
                        sb2.append("cmd=");
                        sb2.append(aVar.f133a);
                        str2 = sb2.toString();
                        break;
                }
                printWriter.print(str);
                printWriter.print("  Op #");
                printWriter.print(i);
                printWriter.print(": ");
                printWriter.print(str2);
                printWriter.print(" ");
                printWriter.println(aVar.f134b);
                if (z) {
                    if (!(aVar.f135c == 0 && aVar.f136d == 0)) {
                        printWriter.print(str);
                        printWriter.print("enterAnim=#");
                        printWriter.print(Integer.toHexString(aVar.f135c));
                        printWriter.print(" exitAnim=#");
                        printWriter.println(Integer.toHexString(aVar.f136d));
                    }
                    if (aVar.f137e != 0 || aVar.f138f != 0) {
                        printWriter.print(str);
                        printWriter.print("popEnterAnim=#");
                        printWriter.print(Integer.toHexString(aVar.f137e));
                        printWriter.print(" popExitAnim=#");
                        printWriter.println(Integer.toHexString(aVar.f138f));
                    }
                }
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public boolean mo143a(ArrayList<C0061b> arrayList, int i, int i2) {
        if (i2 == i) {
            return false;
        }
        int size = this.f113b.size();
        int i3 = -1;
        for (int i4 = 0; i4 < size; i4++) {
            C0062a aVar = (C0062a) this.f113b.get(i4);
            int i5 = aVar.f134b != null ? aVar.f134b.f172I : 0;
            if (!(i5 == 0 || i5 == i3)) {
                for (int i6 = i; i6 < i2; i6++) {
                    C0061b bVar = (C0061b) arrayList.get(i6);
                    int size2 = bVar.f113b.size();
                    for (int i7 = 0; i7 < size2; i7++) {
                        C0062a aVar2 = (C0062a) bVar.f113b.get(i7);
                        if ((aVar2.f134b != null ? aVar2.f134b.f172I : 0) == i5) {
                            return true;
                        }
                    }
                }
                i3 = i5;
            }
        }
        return false;
    }

    /* renamed from: a */
    public boolean mo144a(ArrayList<C0061b> arrayList, ArrayList<Boolean> arrayList2) {
        if (C0085l.f260a) {
            StringBuilder sb = new StringBuilder();
            sb.append("Run: ");
            sb.append(this);
            Log.v("FragmentManager", sb.toString());
        }
        arrayList.add(this);
        arrayList2.add(Boolean.valueOf(false));
        if (this.f120i) {
            this.f112a.mo397b(this);
        }
        return true;
    }

    /* renamed from: b */
    public int mo145b() {
        return mo133a(false);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public C0068f mo146b(ArrayList<C0068f> arrayList, C0068f fVar) {
        for (int i = 0; i < this.f113b.size(); i++) {
            C0062a aVar = (C0062a) this.f113b.get(i);
            int i2 = aVar.f133a;
            if (i2 != 1) {
                if (i2 != 3) {
                    switch (i2) {
                        case C1217ty.f4599f /*6*/:
                            break;
                        case C1217ty.f4600g /*7*/:
                            break;
                        case C1217ty.f4601h /*8*/:
                            fVar = null;
                            break;
                        case 9:
                            fVar = aVar.f134b;
                            break;
                    }
                }
                arrayList.add(aVar.f134b);
            }
            arrayList.remove(aVar.f134b);
        }
        return fVar;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public void mo147b(boolean z) {
        for (int size = this.f113b.size() - 1; size >= 0; size--) {
            C0062a aVar = (C0062a) this.f113b.get(size);
            C0068f fVar = aVar.f134b;
            if (fVar != null) {
                fVar.mo207a(C0085l.m436d(this.f118g), this.f119h);
            }
            int i = aVar.f133a;
            if (i != 1) {
                switch (i) {
                    case 3:
                        fVar.mo206a(aVar.f137e);
                        this.f112a.mo386a(fVar, false);
                        break;
                    case C1217ty.f4597d /*4*/:
                        fVar.mo206a(aVar.f137e);
                        this.f112a.mo427j(fVar);
                        break;
                    case C1217ty.f4598e /*5*/:
                        fVar.mo206a(aVar.f138f);
                        this.f112a.mo425i(fVar);
                        break;
                    case C1217ty.f4599f /*6*/:
                        fVar.mo206a(aVar.f137e);
                        this.f112a.mo431l(fVar);
                        break;
                    case C1217ty.f4600g /*7*/:
                        fVar.mo206a(aVar.f138f);
                        this.f112a.mo429k(fVar);
                        break;
                    case C1217ty.f4601h /*8*/:
                        this.f112a.mo437o(null);
                        break;
                    case 9:
                        this.f112a.mo437o(fVar);
                        break;
                    default:
                        StringBuilder sb = new StringBuilder();
                        sb.append("Unknown cmd: ");
                        sb.append(aVar.f133a);
                        throw new IllegalArgumentException(sb.toString());
                }
            } else {
                fVar.mo206a(aVar.f138f);
                this.f112a.mo422h(fVar);
            }
            if (!(this.f131t || aVar.f133a == 3 || fVar == null)) {
                this.f112a.mo413e(fVar);
            }
        }
        if (!this.f131t && z) {
            C0085l lVar = this.f112a;
            lVar.mo376a(lVar.f278l, true);
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public boolean mo148b(int i) {
        int size = this.f113b.size();
        for (int i2 = 0; i2 < size; i2++) {
            C0062a aVar = (C0062a) this.f113b.get(i2);
            int i3 = aVar.f134b != null ? aVar.f134b.f172I : 0;
            if (i3 != 0 && i3 == i) {
                return true;
            }
        }
        return false;
    }

    /* renamed from: c */
    public int mo149c() {
        return mo133a(true);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: d */
    public void mo150d() {
        int size = this.f113b.size();
        for (int i = 0; i < size; i++) {
            C0062a aVar = (C0062a) this.f113b.get(i);
            C0068f fVar = aVar.f134b;
            if (fVar != null) {
                fVar.mo207a(this.f118g, this.f119h);
            }
            int i2 = aVar.f133a;
            if (i2 != 1) {
                switch (i2) {
                    case 3:
                        fVar.mo206a(aVar.f136d);
                        this.f112a.mo422h(fVar);
                        break;
                    case C1217ty.f4597d /*4*/:
                        fVar.mo206a(aVar.f136d);
                        this.f112a.mo425i(fVar);
                        break;
                    case C1217ty.f4598e /*5*/:
                        fVar.mo206a(aVar.f135c);
                        this.f112a.mo427j(fVar);
                        break;
                    case C1217ty.f4599f /*6*/:
                        fVar.mo206a(aVar.f136d);
                        this.f112a.mo429k(fVar);
                        break;
                    case C1217ty.f4600g /*7*/:
                        fVar.mo206a(aVar.f135c);
                        this.f112a.mo431l(fVar);
                        break;
                    case C1217ty.f4601h /*8*/:
                        this.f112a.mo437o(fVar);
                        break;
                    case 9:
                        this.f112a.mo437o(null);
                        break;
                    default:
                        StringBuilder sb = new StringBuilder();
                        sb.append("Unknown cmd: ");
                        sb.append(aVar.f133a);
                        throw new IllegalArgumentException(sb.toString());
                }
            } else {
                fVar.mo206a(aVar.f135c);
                this.f112a.mo386a(fVar, false);
            }
            if (!(this.f131t || aVar.f133a == 1 || fVar == null)) {
                this.f112a.mo413e(fVar);
            }
        }
        if (!this.f131t) {
            C0085l lVar = this.f112a;
            lVar.mo376a(lVar.f278l, true);
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: e */
    public boolean mo151e() {
        for (int i = 0; i < this.f113b.size(); i++) {
            if (m176b((C0062a) this.f113b.get(i))) {
                return true;
            }
        }
        return false;
    }

    /* renamed from: f */
    public String mo152f() {
        return this.f122k;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("BackStackEntry{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        if (this.f124m >= 0) {
            sb.append(" #");
            sb.append(this.f124m);
        }
        if (this.f122k != null) {
            sb.append(" ");
            sb.append(this.f122k);
        }
        sb.append("}");
        return sb.toString();
    }
}
