package android.support.p005v4.app;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import android.util.Log;
import java.util.ArrayList;

/* renamed from: android.support.v4.app.c */
final class C0063c implements Parcelable {
    public static final Creator<C0063c> CREATOR = new Creator<C0063c>() {
        /* renamed from: a */
        public C0063c createFromParcel(Parcel parcel) {
            return new C0063c(parcel);
        }

        /* renamed from: a */
        public C0063c[] newArray(int i) {
            return new C0063c[i];
        }
    };

    /* renamed from: a */
    final int[] f139a;

    /* renamed from: b */
    final int f140b;

    /* renamed from: c */
    final int f141c;

    /* renamed from: d */
    final String f142d;

    /* renamed from: e */
    final int f143e;

    /* renamed from: f */
    final int f144f;

    /* renamed from: g */
    final CharSequence f145g;

    /* renamed from: h */
    final int f146h;

    /* renamed from: i */
    final CharSequence f147i;

    /* renamed from: j */
    final ArrayList<String> f148j;

    /* renamed from: k */
    final ArrayList<String> f149k;

    /* renamed from: l */
    final boolean f150l;

    public C0063c(Parcel parcel) {
        this.f139a = parcel.createIntArray();
        this.f140b = parcel.readInt();
        this.f141c = parcel.readInt();
        this.f142d = parcel.readString();
        this.f143e = parcel.readInt();
        this.f144f = parcel.readInt();
        this.f145g = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.f146h = parcel.readInt();
        this.f147i = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.f148j = parcel.createStringArrayList();
        this.f149k = parcel.createStringArrayList();
        this.f150l = parcel.readInt() != 0;
    }

    public C0063c(C0061b bVar) {
        int size = bVar.f113b.size();
        this.f139a = new int[(size * 6)];
        if (bVar.f120i) {
            int i = 0;
            int i2 = 0;
            while (i < size) {
                C0062a aVar = (C0062a) bVar.f113b.get(i);
                int i3 = i2 + 1;
                this.f139a[i2] = aVar.f133a;
                int i4 = i3 + 1;
                this.f139a[i3] = aVar.f134b != null ? aVar.f134b.f200o : -1;
                int i5 = i4 + 1;
                this.f139a[i4] = aVar.f135c;
                int i6 = i5 + 1;
                this.f139a[i5] = aVar.f136d;
                int i7 = i6 + 1;
                this.f139a[i6] = aVar.f137e;
                int i8 = i7 + 1;
                this.f139a[i7] = aVar.f138f;
                i++;
                i2 = i8;
            }
            this.f140b = bVar.f118g;
            this.f141c = bVar.f119h;
            this.f142d = bVar.f122k;
            this.f143e = bVar.f124m;
            this.f144f = bVar.f125n;
            this.f145g = bVar.f126o;
            this.f146h = bVar.f127p;
            this.f147i = bVar.f128q;
            this.f148j = bVar.f129r;
            this.f149k = bVar.f130s;
            this.f150l = bVar.f131t;
            return;
        }
        throw new IllegalStateException("Not on back stack");
    }

    /* renamed from: a */
    public C0061b mo154a(C0085l lVar) {
        C0061b bVar = new C0061b(lVar);
        int i = 0;
        int i2 = 0;
        while (i < this.f139a.length) {
            C0062a aVar = new C0062a();
            int i3 = i + 1;
            aVar.f133a = this.f139a[i];
            if (C0085l.f260a) {
                StringBuilder sb = new StringBuilder();
                sb.append("Instantiate ");
                sb.append(bVar);
                sb.append(" op #");
                sb.append(i2);
                sb.append(" base fragment #");
                sb.append(this.f139a[i3]);
                Log.v("FragmentManager", sb.toString());
            }
            int i4 = i3 + 1;
            int i5 = this.f139a[i3];
            aVar.f134b = i5 >= 0 ? (C0068f) lVar.f272f.get(i5) : null;
            int[] iArr = this.f139a;
            int i6 = i4 + 1;
            aVar.f135c = iArr[i4];
            int i7 = i6 + 1;
            aVar.f136d = iArr[i6];
            int i8 = i7 + 1;
            aVar.f137e = iArr[i7];
            int i9 = i8 + 1;
            aVar.f138f = iArr[i8];
            bVar.f114c = aVar.f135c;
            bVar.f115d = aVar.f136d;
            bVar.f116e = aVar.f137e;
            bVar.f117f = aVar.f138f;
            bVar.mo139a(aVar);
            i2++;
            i = i9;
        }
        bVar.f118g = this.f140b;
        bVar.f119h = this.f141c;
        bVar.f122k = this.f142d;
        bVar.f124m = this.f143e;
        bVar.f120i = true;
        bVar.f125n = this.f144f;
        bVar.f126o = this.f145g;
        bVar.f127p = this.f146h;
        bVar.f128q = this.f147i;
        bVar.f129r = this.f148j;
        bVar.f130s = this.f149k;
        bVar.f131t = this.f150l;
        bVar.mo138a(1);
        return bVar;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeIntArray(this.f139a);
        parcel.writeInt(this.f140b);
        parcel.writeInt(this.f141c);
        parcel.writeString(this.f142d);
        parcel.writeInt(this.f143e);
        parcel.writeInt(this.f144f);
        TextUtils.writeToParcel(this.f145g, parcel, 0);
        parcel.writeInt(this.f146h);
        TextUtils.writeToParcel(this.f147i, parcel, 0);
        parcel.writeStringList(this.f148j);
        parcel.writeStringList(this.f149k);
        parcel.writeInt(this.f150l ? 1 : 0);
    }
}
