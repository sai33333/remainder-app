package android.support.p005v4.app;

import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/* renamed from: android.support.v4.app.d */
public final class C0065d {

    /* renamed from: android.support.v4.app.d$a */
    static class C0066a {

        /* renamed from: a */
        private static Method f151a;

        /* renamed from: b */
        private static boolean f152b;

        /* renamed from: a */
        public static IBinder m201a(Bundle bundle, String str) {
            if (!f152b) {
                try {
                    f151a = Bundle.class.getMethod("getIBinder", new Class[]{String.class});
                    f151a.setAccessible(true);
                } catch (NoSuchMethodException e) {
                    Log.i("BundleCompatBaseImpl", "Failed to retrieve getIBinder method", e);
                }
                f152b = true;
            }
            Method method = f151a;
            if (method != null) {
                try {
                    return (IBinder) method.invoke(bundle, new Object[]{str});
                } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e2) {
                    Log.i("BundleCompatBaseImpl", "Failed to invoke getIBinder via reflection", e2);
                    f151a = null;
                }
            }
            return null;
        }
    }

    /* renamed from: a */
    public static IBinder m200a(Bundle bundle, String str) {
        return VERSION.SDK_INT >= 18 ? bundle.getBinder(str) : C0066a.m201a(bundle, str);
    }
}
