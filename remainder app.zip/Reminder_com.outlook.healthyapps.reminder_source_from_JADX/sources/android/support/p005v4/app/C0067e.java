package android.support.p005v4.app;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnDismissListener;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;

/* renamed from: android.support.v4.app.e */
public class C0067e extends C0068f implements OnCancelListener, OnDismissListener {

    /* renamed from: a */
    int f153a = 0;

    /* renamed from: b */
    int f154b = 0;

    /* renamed from: c */
    boolean f155c = true;

    /* renamed from: d */
    boolean f156d = true;

    /* renamed from: e */
    int f157e = -1;

    /* renamed from: f */
    Dialog f158f;

    /* renamed from: g */
    boolean f159g;

    /* renamed from: h */
    boolean f160h;

    /* renamed from: i */
    boolean f161i;

    /* renamed from: a */
    public void mo161a(Dialog dialog, int i) {
        switch (i) {
            case 1:
            case 2:
                break;
            case 3:
                dialog.getWindow().addFlags(24);
                break;
            default:
                return;
        }
        dialog.requestWindowFeature(1);
    }

    /* renamed from: a */
    public void mo162a(Context context) {
        super.mo162a(context);
        if (!this.f161i) {
            this.f160h = false;
        }
    }

    /* renamed from: a */
    public void mo163a(Bundle bundle) {
        super.mo163a(bundle);
        this.f156d = this.f172I == 0;
        if (bundle != null) {
            this.f153a = bundle.getInt("android:style", 0);
            this.f154b = bundle.getInt("android:theme", 0);
            this.f155c = bundle.getBoolean("android:cancelable", true);
            this.f156d = bundle.getBoolean("android:showsDialog", this.f156d);
            this.f157e = bundle.getInt("android:backStackId", -1);
        }
    }

    /* renamed from: a */
    public void mo164a(C0082k kVar, String str) {
        this.f160h = false;
        this.f161i = true;
        C0107p a = kVar.mo350a();
        a.mo136a(this, str);
        a.mo145b();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo165a(boolean z) {
        if (!this.f160h) {
            this.f160h = true;
            this.f161i = false;
            Dialog dialog = this.f158f;
            if (dialog != null) {
                dialog.dismiss();
            }
            this.f159g = true;
            if (this.f157e >= 0) {
                mo256n().mo351a(this.f157e, 1);
                this.f157e = -1;
            } else {
                C0107p a = mo256n().mo350a();
                a.mo135a(this);
                if (z) {
                    a.mo149c();
                } else {
                    a.mo145b();
                }
            }
        }
    }

    /* renamed from: b */
    public LayoutInflater mo166b(Bundle bundle) {
        Context g;
        if (!this.f156d) {
            return super.mo166b(bundle);
        }
        this.f158f = mo168c(bundle);
        Dialog dialog = this.f158f;
        if (dialog != null) {
            mo161a(dialog, this.f153a);
            g = this.f158f.getContext();
        } else {
            g = this.f166C.mo347g();
        }
        return (LayoutInflater) g.getSystemService("layout_inflater");
    }

    /* renamed from: c */
    public int mo167c() {
        return this.f154b;
    }

    /* renamed from: c */
    public Dialog mo168c(Bundle bundle) {
        return new Dialog(mo252l(), mo167c());
    }

    /* renamed from: d */
    public void mo169d() {
        super.mo169d();
        if (!this.f161i && !this.f160h) {
            this.f160h = true;
        }
    }

    /* renamed from: d */
    public void mo170d(Bundle bundle) {
        super.mo170d(bundle);
        if (this.f156d) {
            View q = mo263q();
            if (q != null) {
                if (q.getParent() == null) {
                    this.f158f.setContentView(q);
                } else {
                    throw new IllegalStateException("DialogFragment can not be attached to a container view");
                }
            }
            C0075g l = mo252l();
            if (l != null) {
                this.f158f.setOwnerActivity(l);
            }
            this.f158f.setCancelable(this.f155c);
            this.f158f.setOnCancelListener(this);
            this.f158f.setOnDismissListener(this);
            if (bundle != null) {
                Bundle bundle2 = bundle.getBundle("android:savedDialogState");
                if (bundle2 != null) {
                    this.f158f.onRestoreInstanceState(bundle2);
                }
            }
        }
    }

    /* renamed from: e */
    public void mo171e() {
        super.mo171e();
        Dialog dialog = this.f158f;
        if (dialog != null) {
            this.f159g = false;
            dialog.show();
        }
    }

    /* renamed from: e */
    public void mo172e(Bundle bundle) {
        super.mo172e(bundle);
        Dialog dialog = this.f158f;
        if (dialog != null) {
            Bundle onSaveInstanceState = dialog.onSaveInstanceState();
            if (onSaveInstanceState != null) {
                bundle.putBundle("android:savedDialogState", onSaveInstanceState);
            }
        }
        int i = this.f153a;
        if (i != 0) {
            bundle.putInt("android:style", i);
        }
        int i2 = this.f154b;
        if (i2 != 0) {
            bundle.putInt("android:theme", i2);
        }
        boolean z = this.f155c;
        if (!z) {
            bundle.putBoolean("android:cancelable", z);
        }
        boolean z2 = this.f156d;
        if (!z2) {
            bundle.putBoolean("android:showsDialog", z2);
        }
        int i3 = this.f157e;
        if (i3 != -1) {
            bundle.putInt("android:backStackId", i3);
        }
    }

    /* renamed from: f */
    public void mo173f() {
        super.mo173f();
        Dialog dialog = this.f158f;
        if (dialog != null) {
            dialog.hide();
        }
    }

    /* renamed from: g */
    public void mo174g() {
        super.mo174g();
        Dialog dialog = this.f158f;
        if (dialog != null) {
            this.f159g = true;
            dialog.dismiss();
            this.f158f = null;
        }
    }

    public void onCancel(DialogInterface dialogInterface) {
    }

    public void onDismiss(DialogInterface dialogInterface) {
        if (!this.f159g) {
            mo165a(true);
        }
    }
}
