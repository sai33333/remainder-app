package android.support.p005v4.app;

import android.animation.Animator;
import android.app.Activity;
import android.arch.lifecycle.C0024c;
import android.arch.lifecycle.C0024c.C0025a;
import android.arch.lifecycle.C0028e;
import android.arch.lifecycle.C0029f;
import android.arch.lifecycle.C0035j;
import android.arch.lifecycle.C0043p;
import android.arch.lifecycle.C0044q;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcelable;
import android.support.p005v4.p008c.C0156d;
import android.support.p005v4.p008c.C0165h;
import android.support.p005v4.p009d.C0169b;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnCreateContextMenuListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;

/* renamed from: android.support.v4.app.f */
public class C0068f implements C0028e, C0044q, ComponentCallbacks, OnCreateContextMenuListener {

    /* renamed from: a */
    private static final C0165h<String, Class<?>> f162a = new C0165h<>();

    /* renamed from: j */
    static final Object f163j = new Object();

    /* renamed from: A */
    int f164A;

    /* renamed from: B */
    C0085l f165B;

    /* renamed from: C */
    C0081j f166C;

    /* renamed from: D */
    C0085l f167D;

    /* renamed from: E */
    C0102m f168E;

    /* renamed from: F */
    C0043p f169F;

    /* renamed from: G */
    C0068f f170G;

    /* renamed from: H */
    int f171H;

    /* renamed from: I */
    int f172I;

    /* renamed from: J */
    String f173J;

    /* renamed from: K */
    boolean f174K;

    /* renamed from: L */
    boolean f175L;

    /* renamed from: M */
    boolean f176M;

    /* renamed from: N */
    boolean f177N;

    /* renamed from: O */
    boolean f178O;

    /* renamed from: P */
    boolean f179P = true;

    /* renamed from: Q */
    boolean f180Q;

    /* renamed from: R */
    ViewGroup f181R;

    /* renamed from: S */
    View f182S;

    /* renamed from: T */
    View f183T;

    /* renamed from: U */
    boolean f184U;

    /* renamed from: V */
    boolean f185V = true;

    /* renamed from: W */
    C0072a f186W;

    /* renamed from: X */
    boolean f187X;

    /* renamed from: Y */
    boolean f188Y;

    /* renamed from: Z */
    float f189Z;

    /* renamed from: aa */
    LayoutInflater f190aa;

    /* renamed from: ab */
    boolean f191ab;

    /* renamed from: ac */
    C0029f f192ac = new C0029f(this);

    /* renamed from: ad */
    C0029f f193ad;

    /* renamed from: ae */
    C0028e f194ae;

    /* renamed from: af */
    C0035j<C0028e> f195af = new C0035j<>();

    /* renamed from: k */
    int f196k = 0;

    /* renamed from: l */
    Bundle f197l;

    /* renamed from: m */
    SparseArray<Parcelable> f198m;

    /* renamed from: n */
    Boolean f199n;

    /* renamed from: o */
    int f200o = -1;

    /* renamed from: p */
    String f201p;

    /* renamed from: q */
    Bundle f202q;

    /* renamed from: r */
    C0068f f203r;

    /* renamed from: s */
    int f204s = -1;

    /* renamed from: t */
    int f205t;

    /* renamed from: u */
    boolean f206u;

    /* renamed from: v */
    boolean f207v;

    /* renamed from: w */
    boolean f208w;

    /* renamed from: x */
    boolean f209x;

    /* renamed from: y */
    boolean f210y;

    /* renamed from: z */
    boolean f211z;

    /* renamed from: android.support.v4.app.f$a */
    static class C0072a {

        /* renamed from: a */
        View f215a;

        /* renamed from: b */
        Animator f216b;

        /* renamed from: c */
        int f217c;

        /* renamed from: d */
        int f218d;

        /* renamed from: e */
        int f219e;

        /* renamed from: f */
        int f220f;

        /* renamed from: g */
        Object f221g = null;

        /* renamed from: h */
        Object f222h = C0068f.f163j;

        /* renamed from: i */
        Object f223i = null;

        /* renamed from: j */
        Object f224j = C0068f.f163j;

        /* renamed from: k */
        Object f225k = null;

        /* renamed from: l */
        Object f226l = C0068f.f163j;

        /* renamed from: m */
        Boolean f227m;

        /* renamed from: n */
        Boolean f228n;

        /* renamed from: o */
        C0142y f229o = null;

        /* renamed from: p */
        C0142y f230p = null;

        /* renamed from: q */
        boolean f231q;

        /* renamed from: r */
        C0074c f232r;

        /* renamed from: s */
        boolean f233s;

        C0072a() {
        }
    }

    /* renamed from: android.support.v4.app.f$b */
    public static class C0073b extends RuntimeException {
        public C0073b(String str, Exception exc) {
            super(str, exc);
        }
    }

    /* renamed from: android.support.v4.app.f$c */
    interface C0074c {
        /* renamed from: a */
        void mo278a();

        /* renamed from: b */
        void mo279b();
    }

    /* renamed from: a */
    public static C0068f m216a(Context context, String str, Bundle bundle) {
        try {
            Class cls = (Class) f162a.get(str);
            if (cls == null) {
                cls = context.getClassLoader().loadClass(str);
                f162a.put(str, cls);
            }
            C0068f fVar = (C0068f) cls.getConstructor(new Class[0]).newInstance(new Object[0]);
            if (bundle != null) {
                bundle.setClassLoader(fVar.getClass().getClassLoader());
                fVar.mo241g(bundle);
            }
            return fVar;
        } catch (ClassNotFoundException e) {
            StringBuilder sb = new StringBuilder();
            sb.append("Unable to instantiate fragment ");
            sb.append(str);
            sb.append(": make sure class name exists, is public, and has an");
            sb.append(" empty constructor that is public");
            throw new C0073b(sb.toString(), e);
        } catch (InstantiationException e2) {
            StringBuilder sb2 = new StringBuilder();
            sb2.append("Unable to instantiate fragment ");
            sb2.append(str);
            sb2.append(": make sure class name exists, is public, and has an");
            sb2.append(" empty constructor that is public");
            throw new C0073b(sb2.toString(), e2);
        } catch (IllegalAccessException e3) {
            StringBuilder sb3 = new StringBuilder();
            sb3.append("Unable to instantiate fragment ");
            sb3.append(str);
            sb3.append(": make sure class name exists, is public, and has an");
            sb3.append(" empty constructor that is public");
            throw new C0073b(sb3.toString(), e3);
        } catch (NoSuchMethodException e4) {
            StringBuilder sb4 = new StringBuilder();
            sb4.append("Unable to instantiate fragment ");
            sb4.append(str);
            sb4.append(": could not find Fragment constructor");
            throw new C0073b(sb4.toString(), e4);
        } catch (InvocationTargetException e5) {
            StringBuilder sb5 = new StringBuilder();
            sb5.append("Unable to instantiate fragment ");
            sb5.append(str);
            sb5.append(": calling Fragment constructor caused an exception");
            throw new C0073b(sb5.toString(), e5);
        }
    }

    /* renamed from: a */
    static boolean m217a(Context context, String str) {
        try {
            Class cls = (Class) f162a.get(str);
            if (cls == null) {
                cls = context.getClassLoader().loadClass(str);
                f162a.put(str, cls);
            }
            return C0068f.class.isAssignableFrom(cls);
        } catch (ClassNotFoundException unused) {
            return false;
        }
    }

    /* renamed from: c */
    private C0072a mo167c() {
        if (this.f186W == null) {
            this.f186W = new C0072a();
        }
        return this.f186W;
    }

    /* renamed from: A */
    public Object mo177A() {
        C0072a aVar = this.f186W;
        if (aVar == null) {
            return null;
        }
        return aVar.f225k;
    }

    /* renamed from: B */
    public Object mo178B() {
        C0072a aVar = this.f186W;
        if (aVar == null) {
            return null;
        }
        return aVar.f226l == f163j ? mo177A() : this.f186W.f226l;
    }

    /* renamed from: C */
    public boolean mo179C() {
        C0072a aVar = this.f186W;
        if (aVar == null || aVar.f228n == null) {
            return true;
        }
        return this.f186W.f228n.booleanValue();
    }

    /* renamed from: D */
    public boolean mo180D() {
        C0072a aVar = this.f186W;
        if (aVar == null || aVar.f227m == null) {
            return true;
        }
        return this.f186W.f227m.booleanValue();
    }

    /* renamed from: E */
    public void mo181E() {
        C0085l lVar = this.f165B;
        if (lVar == null || lVar.f279m == null) {
            mo167c().f231q = false;
        } else if (Looper.myLooper() != this.f165B.f279m.mo348h().getLooper()) {
            this.f165B.f279m.mo348h().postAtFrontOfQueue(new Runnable() {
                public void run() {
                    C0068f.this.mo182F();
                }
            });
        } else {
            mo182F();
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: F */
    public void mo182F() {
        C0074c cVar;
        C0072a aVar = this.f186W;
        if (aVar == null) {
            cVar = null;
        } else {
            aVar.f231q = false;
            cVar = aVar.f232r;
            this.f186W.f232r = null;
        }
        if (cVar != null) {
            cVar.mo278a();
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: G */
    public void mo183G() {
        if (this.f166C != null) {
            this.f167D = new C0085l();
            this.f167D.mo387a(this.f166C, (C0079h) new C0079h() {
                /* renamed from: a */
                public C0068f mo275a(Context context, String str, Bundle bundle) {
                    return C0068f.this.f166C.mo275a(context, str, bundle);
                }

                /* renamed from: a */
                public View mo276a(int i) {
                    if (C0068f.this.f182S != null) {
                        return C0068f.this.f182S.findViewById(i);
                    }
                    throw new IllegalStateException("Fragment does not have a view");
                }

                /* renamed from: a */
                public boolean mo277a() {
                    return C0068f.this.f182S != null;
                }
            }, this);
            return;
        }
        throw new IllegalStateException("Fragment has not been attached yet.");
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: H */
    public void mo184H() {
        C0085l lVar = this.f167D;
        if (lVar != null) {
            lVar.mo432m();
            this.f167D.mo420g();
        }
        this.f196k = 3;
        this.f180Q = false;
        mo171e();
        if (this.f180Q) {
            C0085l lVar2 = this.f167D;
            if (lVar2 != null) {
                lVar2.mo440p();
            }
            this.f192ac.mo66a(C0025a.ON_START);
            if (this.f182S != null) {
                this.f193ad.mo66a(C0025a.ON_START);
                return;
            }
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Fragment ");
        sb.append(this);
        sb.append(" did not call through to super.onStart()");
        throw new C0143z(sb.toString());
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: I */
    public void mo185I() {
        C0085l lVar = this.f167D;
        if (lVar != null) {
            lVar.mo432m();
            this.f167D.mo420g();
        }
        this.f196k = 4;
        this.f180Q = false;
        mo264r();
        if (this.f180Q) {
            C0085l lVar2 = this.f167D;
            if (lVar2 != null) {
                lVar2.mo441q();
                this.f167D.mo420g();
            }
            this.f192ac.mo66a(C0025a.ON_RESUME);
            if (this.f182S != null) {
                this.f193ad.mo66a(C0025a.ON_RESUME);
                return;
            }
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Fragment ");
        sb.append(this);
        sb.append(" did not call through to super.onResume()");
        throw new C0143z(sb.toString());
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: J */
    public void mo186J() {
        C0085l lVar = this.f167D;
        if (lVar != null) {
            lVar.mo432m();
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: K */
    public void mo187K() {
        onLowMemory();
        C0085l lVar = this.f167D;
        if (lVar != null) {
            lVar.mo447v();
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: L */
    public void mo188L() {
        if (this.f182S != null) {
            this.f193ad.mo66a(C0025a.ON_PAUSE);
        }
        this.f192ac.mo66a(C0025a.ON_PAUSE);
        C0085l lVar = this.f167D;
        if (lVar != null) {
            lVar.mo442r();
        }
        this.f196k = 3;
        this.f180Q = false;
        mo265s();
        if (!this.f180Q) {
            StringBuilder sb = new StringBuilder();
            sb.append("Fragment ");
            sb.append(this);
            sb.append(" did not call through to super.onPause()");
            throw new C0143z(sb.toString());
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: M */
    public void mo189M() {
        if (this.f182S != null) {
            this.f193ad.mo66a(C0025a.ON_STOP);
        }
        this.f192ac.mo66a(C0025a.ON_STOP);
        C0085l lVar = this.f167D;
        if (lVar != null) {
            lVar.mo443s();
        }
        this.f196k = 2;
        this.f180Q = false;
        mo173f();
        if (!this.f180Q) {
            StringBuilder sb = new StringBuilder();
            sb.append("Fragment ");
            sb.append(this);
            sb.append(" did not call through to super.onStop()");
            throw new C0143z(sb.toString());
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: N */
    public void mo190N() {
        if (this.f182S != null) {
            this.f193ad.mo66a(C0025a.ON_DESTROY);
        }
        C0085l lVar = this.f167D;
        if (lVar != null) {
            lVar.mo444t();
        }
        this.f196k = 1;
        this.f180Q = false;
        mo174g();
        if (this.f180Q) {
            C0133u.m647a(this).mo109a();
            this.f211z = false;
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Fragment ");
        sb.append(this);
        sb.append(" did not call through to super.onDestroyView()");
        throw new C0143z(sb.toString());
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: O */
    public void mo191O() {
        this.f192ac.mo66a(C0025a.ON_DESTROY);
        C0085l lVar = this.f167D;
        if (lVar != null) {
            lVar.mo446u();
        }
        this.f196k = 0;
        this.f180Q = false;
        this.f191ab = false;
        mo266t();
        if (this.f180Q) {
            this.f167D = null;
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Fragment ");
        sb.append(this);
        sb.append(" did not call through to super.onDestroy()");
        throw new C0143z(sb.toString());
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: P */
    public void mo192P() {
        this.f180Q = false;
        mo169d();
        this.f190aa = null;
        if (this.f180Q) {
            C0085l lVar = this.f167D;
            if (lVar == null) {
                return;
            }
            if (this.f177N) {
                lVar.mo446u();
                this.f167D = null;
                return;
            }
            StringBuilder sb = new StringBuilder();
            sb.append("Child FragmentManager of ");
            sb.append(this);
            sb.append(" was not ");
            sb.append(" destroyed and this fragment is not retaining instance");
            throw new IllegalStateException(sb.toString());
        }
        StringBuilder sb2 = new StringBuilder();
        sb2.append("Fragment ");
        sb2.append(this);
        sb2.append(" did not call through to super.onDetach()");
        throw new C0143z(sb2.toString());
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: Q */
    public int mo193Q() {
        C0072a aVar = this.f186W;
        if (aVar == null) {
            return 0;
        }
        return aVar.f218d;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: R */
    public int mo194R() {
        C0072a aVar = this.f186W;
        if (aVar == null) {
            return 0;
        }
        return aVar.f219e;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: S */
    public int mo195S() {
        C0072a aVar = this.f186W;
        if (aVar == null) {
            return 0;
        }
        return aVar.f220f;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: T */
    public C0142y mo196T() {
        C0072a aVar = this.f186W;
        if (aVar == null) {
            return null;
        }
        return aVar.f229o;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: U */
    public C0142y mo197U() {
        C0072a aVar = this.f186W;
        if (aVar == null) {
            return null;
        }
        return aVar.f230p;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: V */
    public View mo198V() {
        C0072a aVar = this.f186W;
        if (aVar == null) {
            return null;
        }
        return aVar.f215a;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: W */
    public Animator mo199W() {
        C0072a aVar = this.f186W;
        if (aVar == null) {
            return null;
        }
        return aVar.f216b;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: X */
    public int mo200X() {
        C0072a aVar = this.f186W;
        if (aVar == null) {
            return 0;
        }
        return aVar.f217c;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: Y */
    public boolean mo201Y() {
        C0072a aVar = this.f186W;
        if (aVar == null) {
            return false;
        }
        return aVar.f231q;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: Z */
    public boolean mo202Z() {
        C0072a aVar = this.f186W;
        if (aVar == null) {
            return false;
        }
        return aVar.f233s;
    }

    /* renamed from: a */
    public C0024c mo65a() {
        return this.f192ac;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public C0068f mo203a(String str) {
        if (str.equals(this.f201p)) {
            return this;
        }
        C0085l lVar = this.f167D;
        if (lVar != null) {
            return lVar.mo396b(str);
        }
        return null;
    }

    /* renamed from: a */
    public View mo204a(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return null;
    }

    /* renamed from: a */
    public Animation mo205a(int i, boolean z, int i2) {
        return null;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo206a(int i) {
        if (this.f186W != null || i != 0) {
            mo167c().f218d = i;
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo207a(int i, int i2) {
        if (this.f186W != null || i != 0 || i2 != 0) {
            mo167c();
            C0072a aVar = this.f186W;
            aVar.f219e = i;
            aVar.f220f = i2;
        }
    }

    /* renamed from: a */
    public void mo208a(int i, int i2, Intent intent) {
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public final void mo209a(int i, C0068f fVar) {
        String str;
        StringBuilder sb;
        this.f200o = i;
        if (fVar != null) {
            sb = new StringBuilder();
            sb.append(fVar.f201p);
            str = ":";
        } else {
            sb = new StringBuilder();
            str = "android:fragment:";
        }
        sb.append(str);
        sb.append(this.f200o);
        this.f201p = sb.toString();
    }

    /* renamed from: a */
    public void mo210a(int i, String[] strArr, int[] iArr) {
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo211a(Animator animator) {
        mo167c().f216b = animator;
    }

    @Deprecated
    /* renamed from: a */
    public void mo212a(Activity activity) {
        this.f180Q = true;
    }

    @Deprecated
    /* renamed from: a */
    public void mo213a(Activity activity, AttributeSet attributeSet, Bundle bundle) {
        this.f180Q = true;
    }

    /* renamed from: a */
    public void mo162a(Context context) {
        this.f180Q = true;
        C0081j jVar = this.f166C;
        Activity f = jVar == null ? null : jVar.mo346f();
        if (f != null) {
            this.f180Q = false;
            mo212a(f);
        }
    }

    /* renamed from: a */
    public void mo214a(Context context, AttributeSet attributeSet, Bundle bundle) {
        this.f180Q = true;
        C0081j jVar = this.f166C;
        Activity f = jVar == null ? null : jVar.mo346f();
        if (f != null) {
            this.f180Q = false;
            mo213a(f, attributeSet, bundle);
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo215a(Configuration configuration) {
        onConfigurationChanged(configuration);
        C0085l lVar = this.f167D;
        if (lVar != null) {
            lVar.mo377a(configuration);
        }
    }

    /* renamed from: a */
    public void mo163a(Bundle bundle) {
        this.f180Q = true;
        mo249j(bundle);
        C0085l lVar = this.f167D;
        if (lVar != null && !lVar.mo390a(1)) {
            this.f167D.mo435n();
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo216a(C0074c cVar) {
        mo167c();
        if (cVar != this.f186W.f232r) {
            if (cVar == null || this.f186W.f232r == null) {
                if (this.f186W.f231q) {
                    this.f186W.f232r = cVar;
                }
                if (cVar != null) {
                    cVar.mo279b();
                }
                return;
            }
            StringBuilder sb = new StringBuilder();
            sb.append("Trying to set a replacement startPostponedEnterTransition on ");
            sb.append(this);
            throw new IllegalStateException(sb.toString());
        }
    }

    /* renamed from: a */
    public void mo217a(C0068f fVar) {
    }

    /* renamed from: a */
    public void mo218a(Menu menu) {
    }

    /* renamed from: a */
    public void mo219a(Menu menu, MenuInflater menuInflater) {
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo220a(View view) {
        mo167c().f215a = view;
    }

    /* renamed from: a */
    public void mo221a(View view, Bundle bundle) {
    }

    /* renamed from: a */
    public void mo222a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        printWriter.print(str);
        printWriter.print("mFragmentId=#");
        printWriter.print(Integer.toHexString(this.f171H));
        printWriter.print(" mContainerId=#");
        printWriter.print(Integer.toHexString(this.f172I));
        printWriter.print(" mTag=");
        printWriter.println(this.f173J);
        printWriter.print(str);
        printWriter.print("mState=");
        printWriter.print(this.f196k);
        printWriter.print(" mIndex=");
        printWriter.print(this.f200o);
        printWriter.print(" mWho=");
        printWriter.print(this.f201p);
        printWriter.print(" mBackStackNesting=");
        printWriter.println(this.f164A);
        printWriter.print(str);
        printWriter.print("mAdded=");
        printWriter.print(this.f206u);
        printWriter.print(" mRemoving=");
        printWriter.print(this.f207v);
        printWriter.print(" mFromLayout=");
        printWriter.print(this.f208w);
        printWriter.print(" mInLayout=");
        printWriter.println(this.f209x);
        printWriter.print(str);
        printWriter.print("mHidden=");
        printWriter.print(this.f174K);
        printWriter.print(" mDetached=");
        printWriter.print(this.f175L);
        printWriter.print(" mMenuVisible=");
        printWriter.print(this.f179P);
        printWriter.print(" mHasMenu=");
        printWriter.println(this.f178O);
        printWriter.print(str);
        printWriter.print("mRetainInstance=");
        printWriter.print(this.f176M);
        printWriter.print(" mRetaining=");
        printWriter.print(this.f177N);
        printWriter.print(" mUserVisibleHint=");
        printWriter.println(this.f185V);
        if (this.f165B != null) {
            printWriter.print(str);
            printWriter.print("mFragmentManager=");
            printWriter.println(this.f165B);
        }
        if (this.f166C != null) {
            printWriter.print(str);
            printWriter.print("mHost=");
            printWriter.println(this.f166C);
        }
        if (this.f170G != null) {
            printWriter.print(str);
            printWriter.print("mParentFragment=");
            printWriter.println(this.f170G);
        }
        if (this.f202q != null) {
            printWriter.print(str);
            printWriter.print("mArguments=");
            printWriter.println(this.f202q);
        }
        if (this.f197l != null) {
            printWriter.print(str);
            printWriter.print("mSavedFragmentState=");
            printWriter.println(this.f197l);
        }
        if (this.f198m != null) {
            printWriter.print(str);
            printWriter.print("mSavedViewState=");
            printWriter.println(this.f198m);
        }
        if (this.f203r != null) {
            printWriter.print(str);
            printWriter.print("mTarget=");
            printWriter.print(this.f203r);
            printWriter.print(" mTargetRequestCode=");
            printWriter.println(this.f205t);
        }
        if (mo193Q() != 0) {
            printWriter.print(str);
            printWriter.print("mNextAnim=");
            printWriter.println(mo193Q());
        }
        if (this.f181R != null) {
            printWriter.print(str);
            printWriter.print("mContainer=");
            printWriter.println(this.f181R);
        }
        if (this.f182S != null) {
            printWriter.print(str);
            printWriter.print("mView=");
            printWriter.println(this.f182S);
        }
        if (this.f183T != null) {
            printWriter.print(str);
            printWriter.print("mInnerView=");
            printWriter.println(this.f182S);
        }
        if (mo198V() != null) {
            printWriter.print(str);
            printWriter.print("mAnimatingAway=");
            printWriter.println(mo198V());
            printWriter.print(str);
            printWriter.print("mStateAfterAnimating=");
            printWriter.println(mo200X());
        }
        if (mo248j() != null) {
            C0133u.m647a(this).mo110a(str, fileDescriptor, printWriter, strArr);
        }
        if (this.f167D != null) {
            printWriter.print(str);
            StringBuilder sb = new StringBuilder();
            sb.append("Child ");
            sb.append(this.f167D);
            sb.append(":");
            printWriter.println(sb.toString());
            C0085l lVar = this.f167D;
            StringBuilder sb2 = new StringBuilder();
            sb2.append(str);
            sb2.append("  ");
            lVar.mo352a(sb2.toString(), fileDescriptor, printWriter, strArr);
        }
    }

    /* renamed from: a */
    public boolean mo223a(MenuItem menuItem) {
        return false;
    }

    /* renamed from: b */
    public Animator mo224b(int i, boolean z, int i2) {
        return null;
    }

    /* renamed from: b */
    public C0043p mo88b() {
        if (mo248j() != null) {
            if (this.f169F == null) {
                this.f169F = new C0043p();
            }
            return this.f169F;
        }
        throw new IllegalStateException("Can't access ViewModels from detached fragment");
    }

    /* renamed from: b */
    public LayoutInflater mo166b(Bundle bundle) {
        return mo246i(bundle);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public void mo225b(int i) {
        mo167c().f217c = i;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public void mo226b(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        C0085l lVar = this.f167D;
        if (lVar != null) {
            lVar.mo432m();
        }
        this.f211z = true;
        this.f194ae = new C0028e() {
            /* renamed from: a */
            public C0024c mo65a() {
                if (C0068f.this.f193ad == null) {
                    C0068f fVar = C0068f.this;
                    fVar.f193ad = new C0029f(fVar.f194ae);
                }
                return C0068f.this.f193ad;
            }
        };
        this.f193ad = null;
        this.f182S = mo204a(layoutInflater, viewGroup, bundle);
        if (this.f182S != null) {
            this.f194ae.mo65a();
            this.f195af.mo45a(this.f194ae);
        } else if (this.f193ad == null) {
            this.f194ae = null;
        } else {
            throw new IllegalStateException("Called getViewLifecycleOwner() but onCreateView() returned null");
        }
    }

    /* renamed from: b */
    public void mo227b(Menu menu) {
    }

    /* renamed from: b */
    public void mo228b(boolean z) {
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public boolean mo229b(Menu menu, MenuInflater menuInflater) {
        boolean z = false;
        if (this.f174K) {
            return false;
        }
        if (this.f178O && this.f179P) {
            mo219a(menu, menuInflater);
            z = true;
        }
        C0085l lVar = this.f167D;
        return lVar != null ? z | lVar.mo392a(menu, menuInflater) : z;
    }

    /* renamed from: b */
    public boolean mo230b(MenuItem menuItem) {
        return false;
    }

    /* renamed from: c */
    public void mo231c(boolean z) {
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public boolean mo232c(Menu menu) {
        boolean z = false;
        if (this.f174K) {
            return false;
        }
        if (this.f178O && this.f179P) {
            mo218a(menu);
            z = true;
        }
        C0085l lVar = this.f167D;
        return lVar != null ? z | lVar.mo391a(menu) : z;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public boolean mo233c(MenuItem menuItem) {
        if (!this.f174K) {
            if (this.f178O && this.f179P && mo223a(menuItem)) {
                return true;
            }
            C0085l lVar = this.f167D;
            if (lVar != null && lVar.mo393a(menuItem)) {
                return true;
            }
        }
        return false;
    }

    /* renamed from: d */
    public void mo169d() {
        this.f180Q = true;
    }

    /* renamed from: d */
    public void mo170d(Bundle bundle) {
        this.f180Q = true;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: d */
    public void mo234d(Menu menu) {
        if (!this.f174K) {
            if (this.f178O && this.f179P) {
                mo227b(menu);
            }
            C0085l lVar = this.f167D;
            if (lVar != null) {
                lVar.mo402b(menu);
            }
        }
    }

    /* renamed from: d */
    public void mo235d(boolean z) {
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: d */
    public boolean mo236d(MenuItem menuItem) {
        if (!this.f174K) {
            if (mo230b(menuItem)) {
                return true;
            }
            C0085l lVar = this.f167D;
            if (lVar != null && lVar.mo404b(menuItem)) {
                return true;
            }
        }
        return false;
    }

    /* renamed from: e */
    public void mo171e() {
        this.f180Q = true;
    }

    /* renamed from: e */
    public void mo172e(Bundle bundle) {
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: e */
    public void mo237e(boolean z) {
        mo231c(z);
        C0085l lVar = this.f167D;
        if (lVar != null) {
            lVar.mo389a(z);
        }
    }

    public final boolean equals(Object obj) {
        return super.equals(obj);
    }

    /* renamed from: f */
    public void mo173f() {
        this.f180Q = true;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: f */
    public final void mo239f(Bundle bundle) {
        SparseArray<Parcelable> sparseArray = this.f198m;
        if (sparseArray != null) {
            this.f183T.restoreHierarchyState(sparseArray);
            this.f198m = null;
        }
        this.f180Q = false;
        mo251k(bundle);
        if (!this.f180Q) {
            StringBuilder sb = new StringBuilder();
            sb.append("Fragment ");
            sb.append(this);
            sb.append(" did not call through to super.onViewStateRestored()");
            throw new C0143z(sb.toString());
        } else if (this.f182S != null) {
            this.f193ad.mo66a(C0025a.ON_CREATE);
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: f */
    public void mo240f(boolean z) {
        mo235d(z);
        C0085l lVar = this.f167D;
        if (lVar != null) {
            lVar.mo403b(z);
        }
    }

    /* renamed from: g */
    public void mo174g() {
        this.f180Q = true;
    }

    /* renamed from: g */
    public void mo241g(Bundle bundle) {
        if (this.f200o < 0 || !mo247i()) {
            this.f202q = bundle;
            return;
        }
        throw new IllegalStateException("Fragment already active and state has been saved");
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: g */
    public void mo242g(boolean z) {
        mo167c().f233s = z;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: h */
    public LayoutInflater mo243h(Bundle bundle) {
        this.f190aa = mo166b(bundle);
        return this.f190aa;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: h */
    public final boolean mo244h() {
        return this.f164A > 0;
    }

    public final int hashCode() {
        return super.hashCode();
    }

    @Deprecated
    /* renamed from: i */
    public LayoutInflater mo246i(Bundle bundle) {
        C0081j jVar = this.f166C;
        if (jVar != null) {
            LayoutInflater b = jVar.mo316b();
            mo258o();
            C0169b.m763a(b, this.f167D.mo449x());
            return b;
        }
        throw new IllegalStateException("onGetLayoutInflater() cannot be executed until the Fragment is attached to the FragmentManager.");
    }

    /* renamed from: i */
    public final boolean mo247i() {
        C0085l lVar = this.f165B;
        if (lVar == null) {
            return false;
        }
        return lVar.mo355d();
    }

    /* renamed from: j */
    public Context mo248j() {
        C0081j jVar = this.f166C;
        if (jVar == null) {
            return null;
        }
        return jVar.mo347g();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: j */
    public void mo249j(Bundle bundle) {
        if (bundle != null) {
            Parcelable parcelable = bundle.getParcelable("android:support:fragments");
            if (parcelable != null) {
                if (this.f167D == null) {
                    mo183G();
                }
                this.f167D.mo379a(parcelable, this.f168E);
                this.f168E = null;
                this.f167D.mo435n();
            }
        }
    }

    /* renamed from: k */
    public final Context mo250k() {
        Context j = mo248j();
        if (j != null) {
            return j;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Fragment ");
        sb.append(this);
        sb.append(" not attached to a context.");
        throw new IllegalStateException(sb.toString());
    }

    /* renamed from: k */
    public void mo251k(Bundle bundle) {
        this.f180Q = true;
    }

    /* renamed from: l */
    public final C0075g mo252l() {
        C0081j jVar = this.f166C;
        if (jVar == null) {
            return null;
        }
        return (C0075g) jVar.mo346f();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: l */
    public void mo253l(Bundle bundle) {
        C0085l lVar = this.f167D;
        if (lVar != null) {
            lVar.mo432m();
        }
        this.f196k = 1;
        this.f180Q = false;
        mo163a(bundle);
        this.f191ab = true;
        if (this.f180Q) {
            this.f192ac.mo66a(C0025a.ON_CREATE);
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Fragment ");
        sb.append(this);
        sb.append(" did not call through to super.onCreate()");
        throw new C0143z(sb.toString());
    }

    /* renamed from: m */
    public final Resources mo254m() {
        return mo250k().getResources();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: m */
    public void mo255m(Bundle bundle) {
        C0085l lVar = this.f167D;
        if (lVar != null) {
            lVar.mo432m();
        }
        this.f196k = 2;
        this.f180Q = false;
        mo170d(bundle);
        if (this.f180Q) {
            C0085l lVar2 = this.f167D;
            if (lVar2 != null) {
                lVar2.mo436o();
                return;
            }
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Fragment ");
        sb.append(this);
        sb.append(" did not call through to super.onActivityCreated()");
        throw new C0143z(sb.toString());
    }

    /* renamed from: n */
    public final C0082k mo256n() {
        return this.f165B;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: n */
    public void mo257n(Bundle bundle) {
        mo172e(bundle);
        C0085l lVar = this.f167D;
        if (lVar != null) {
            Parcelable l = lVar.mo430l();
            if (l != null) {
                bundle.putParcelable("android:support:fragments", l);
            }
        }
    }

    /* renamed from: o */
    public final C0082k mo258o() {
        if (this.f167D == null) {
            mo183G();
            int i = this.f196k;
            if (i >= 4) {
                this.f167D.mo441q();
            } else if (i >= 3) {
                this.f167D.mo440p();
            } else if (i >= 2) {
                this.f167D.mo436o();
            } else if (i >= 1) {
                this.f167D.mo435n();
            }
        }
        return this.f167D;
    }

    public void onConfigurationChanged(Configuration configuration) {
        this.f180Q = true;
    }

    public void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenuInfo contextMenuInfo) {
        mo252l().onCreateContextMenu(contextMenu, view, contextMenuInfo);
    }

    public void onLowMemory() {
        this.f180Q = true;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: p */
    public C0082k mo262p() {
        return this.f167D;
    }

    /* renamed from: q */
    public View mo263q() {
        return this.f182S;
    }

    /* renamed from: r */
    public void mo264r() {
        this.f180Q = true;
    }

    /* renamed from: s */
    public void mo265s() {
        this.f180Q = true;
    }

    /* renamed from: t */
    public void mo266t() {
        boolean z = true;
        this.f180Q = true;
        C0075g l = mo252l();
        if (l == null || !l.isChangingConfigurations()) {
            z = false;
        }
        C0043p pVar = this.f169F;
        if (pVar != null && !z) {
            pVar.mo86a();
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        C0156d.m710a(this, sb);
        if (this.f200o >= 0) {
            sb.append(" #");
            sb.append(this.f200o);
        }
        if (this.f171H != 0) {
            sb.append(" id=0x");
            sb.append(Integer.toHexString(this.f171H));
        }
        if (this.f173J != null) {
            sb.append(" ");
            sb.append(this.f173J);
        }
        sb.append('}');
        return sb.toString();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: u */
    public void mo268u() {
        this.f200o = -1;
        this.f201p = null;
        this.f206u = false;
        this.f207v = false;
        this.f208w = false;
        this.f209x = false;
        this.f210y = false;
        this.f164A = 0;
        this.f165B = null;
        this.f167D = null;
        this.f166C = null;
        this.f171H = 0;
        this.f172I = 0;
        this.f173J = null;
        this.f174K = false;
        this.f175L = false;
        this.f177N = false;
    }

    /* renamed from: v */
    public void mo269v() {
    }

    /* renamed from: w */
    public Object mo270w() {
        C0072a aVar = this.f186W;
        if (aVar == null) {
            return null;
        }
        return aVar.f221g;
    }

    /* renamed from: x */
    public Object mo271x() {
        C0072a aVar = this.f186W;
        if (aVar == null) {
            return null;
        }
        return aVar.f222h == f163j ? mo270w() : this.f186W.f222h;
    }

    /* renamed from: y */
    public Object mo272y() {
        C0072a aVar = this.f186W;
        if (aVar == null) {
            return null;
        }
        return aVar.f223i;
    }

    /* renamed from: z */
    public Object mo273z() {
        C0072a aVar = this.f186W;
        if (aVar == null) {
            return null;
        }
        return aVar.f224j == f163j ? mo272y() : this.f186W.f224j;
    }
}
