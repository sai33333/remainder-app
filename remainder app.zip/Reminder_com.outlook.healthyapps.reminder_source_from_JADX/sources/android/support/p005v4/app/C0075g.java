package android.support.p005v4.app;

import android.arch.lifecycle.C0024c;
import android.arch.lifecycle.C0024c.C0026b;
import android.arch.lifecycle.C0043p;
import android.arch.lifecycle.C0044q;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Parcelable;
import android.support.p005v4.app.C0055a.C0057a;
import android.support.p005v4.app.C0055a.C0058b;
import android.support.p005v4.app.C0055a.C0059c;
import android.support.p005v4.p008c.C0166i;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import java.io.FileDescriptor;
import java.io.PrintWriter;

/* renamed from: android.support.v4.app.g */
public class C0075g extends C0060aa implements C0044q, C0057a, C0059c {

    /* renamed from: a */
    final Handler f234a = new Handler() {
        public void handleMessage(Message message) {
            if (message.what != 2) {
                super.handleMessage(message);
                return;
            }
            C0075g.this.mo283c();
            C0075g.this.f235b.mo345m();
        }
    };

    /* renamed from: b */
    final C0080i f235b = C0080i.m352a((C0081j<?>) new C0077a<Object>());

    /* renamed from: c */
    boolean f236c;

    /* renamed from: d */
    boolean f237d;

    /* renamed from: e */
    boolean f238e = true;

    /* renamed from: f */
    boolean f239f;

    /* renamed from: g */
    boolean f240g;

    /* renamed from: h */
    boolean f241h;

    /* renamed from: i */
    int f242i;

    /* renamed from: j */
    C0166i<String> f243j;

    /* renamed from: k */
    private C0043p f244k;

    /* renamed from: android.support.v4.app.g$a */
    class C0077a extends C0081j<C0075g> {
        public C0077a() {
            super(C0075g.this);
        }

        /* renamed from: a */
        public View mo276a(int i) {
            return C0075g.this.findViewById(i);
        }

        /* renamed from: a */
        public void mo314a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
            C0075g.this.dump(str, fileDescriptor, printWriter, strArr);
        }

        /* renamed from: a */
        public boolean mo277a() {
            Window window = C0075g.this.getWindow();
            return (window == null || window.peekDecorView() == null) ? false : true;
        }

        /* renamed from: a */
        public boolean mo315a(C0068f fVar) {
            return !C0075g.this.isFinishing();
        }

        /* renamed from: b */
        public LayoutInflater mo316b() {
            return C0075g.this.getLayoutInflater().cloneInContext(C0075g.this);
        }

        /* renamed from: b */
        public void mo317b(C0068f fVar) {
            C0075g.this.mo281a(fVar);
        }

        /* renamed from: c */
        public void mo318c() {
            C0075g.this.mo286e();
        }

        /* renamed from: d */
        public boolean mo319d() {
            return C0075g.this.getWindow() != null;
        }

        /* renamed from: e */
        public int mo320e() {
            Window window = C0075g.this.getWindow();
            if (window == null) {
                return 0;
            }
            return window.getAttributes().windowAnimations;
        }
    }

    /* renamed from: android.support.v4.app.g$b */
    static final class C0078b {

        /* renamed from: a */
        Object f247a;

        /* renamed from: b */
        C0043p f248b;

        /* renamed from: c */
        C0102m f249c;

        C0078b() {
        }
    }

    /* renamed from: a */
    private static boolean m327a(C0082k kVar, C0026b bVar) {
        boolean z = false;
        for (C0068f fVar : kVar.mo354c()) {
            if (fVar != null) {
                if (fVar.mo65a().mo61a().mo64a(C0026b.STARTED)) {
                    fVar.f192ac.mo67a(bVar);
                    z = true;
                }
                C0082k p = fVar.mo262p();
                if (p != null) {
                    z |= m327a(p, bVar);
                }
            }
        }
        return z;
    }

    /* renamed from: b */
    static void m328b(int i) {
        if ((i & -65536) != 0) {
            throw new IllegalArgumentException("Can only use lower 16 bits for requestCode");
        }
    }

    /* renamed from: g */
    private void mo972g() {
        do {
        } while (m327a(mo287f(), C0026b.CREATED));
    }

    /* renamed from: a */
    public C0024c mo65a() {
        return super.mo65a();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public final View mo280a(View view, String str, Context context, AttributeSet attributeSet) {
        return this.f235b.mo323a(view, str, context, attributeSet);
    }

    /* renamed from: a */
    public final void mo127a(int i) {
        if (!this.f239f && i != -1) {
            m328b(i);
        }
    }

    /* renamed from: a */
    public void mo281a(C0068f fVar) {
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public boolean mo282a(View view, Menu menu) {
        return super.onPreparePanel(0, view, menu);
    }

    /* renamed from: b */
    public C0043p mo88b() {
        if (getApplication() != null) {
            if (this.f244k == null) {
                C0078b bVar = (C0078b) getLastNonConfigurationInstance();
                if (bVar != null) {
                    this.f244k = bVar.f248b;
                }
                if (this.f244k == null) {
                    this.f244k = new C0043p();
                }
            }
            return this.f244k;
        }
        throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
    }

    /* access modifiers changed from: protected */
    /* renamed from: c */
    public void mo283c() {
        this.f235b.mo340h();
    }

    /* renamed from: d */
    public Object mo284d() {
        return null;
    }

    public void dump(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        super.dump(str, fileDescriptor, printWriter, strArr);
        printWriter.print(str);
        printWriter.print("Local FragmentActivity ");
        printWriter.print(Integer.toHexString(System.identityHashCode(this)));
        printWriter.println(" State:");
        StringBuilder sb = new StringBuilder();
        sb.append(str);
        sb.append("  ");
        String sb2 = sb.toString();
        printWriter.print(sb2);
        printWriter.print("mCreated=");
        printWriter.print(this.f236c);
        printWriter.print(" mResumed=");
        printWriter.print(this.f237d);
        printWriter.print(" mStopped=");
        printWriter.print(this.f238e);
        if (getApplication() != null) {
            C0133u.m647a(this).mo110a(sb2, fileDescriptor, printWriter, strArr);
        }
        this.f235b.mo322a().mo352a(str, fileDescriptor, printWriter, strArr);
    }

    @Deprecated
    /* renamed from: e */
    public void mo286e() {
        invalidateOptionsMenu();
    }

    /* renamed from: f */
    public C0082k mo287f() {
        return this.f235b.mo322a();
    }

    /* access modifiers changed from: protected */
    public void onActivityResult(int i, int i2, Intent intent) {
        this.f235b.mo331b();
        int i3 = i >> 16;
        if (i3 != 0) {
            int i4 = i3 - 1;
            String str = (String) this.f243j.mo703a(i4);
            this.f243j.mo709c(i4);
            if (str == null) {
                Log.w("FragmentActivity", "Activity result delivered for unknown Fragment.");
                return;
            }
            C0068f a = this.f235b.mo321a(str);
            if (a == null) {
                StringBuilder sb = new StringBuilder();
                sb.append("Activity result no fragment exists for who: ");
                sb.append(str);
                Log.w("FragmentActivity", sb.toString());
            } else {
                a.mo208a(i & 65535, i2, intent);
            }
            return;
        }
        C0058b a2 = C0055a.m167a();
        if (a2 == null || !a2.mo125a(this, i, i2, intent)) {
            super.onActivityResult(i, i2, intent);
        }
    }

    public void onBackPressed() {
        C0082k a = this.f235b.mo322a();
        boolean d = a.mo355d();
        if (!d || VERSION.SDK_INT > 25) {
            if (d || !a.mo353b()) {
                super.onBackPressed();
            }
        }
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.f235b.mo331b();
        this.f235b.mo324a(configuration);
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        C0102m mVar = null;
        this.f235b.mo326a((C0068f) null);
        super.onCreate(bundle);
        C0078b bVar = (C0078b) getLastNonConfigurationInstance();
        if (!(bVar == null || bVar.f248b == null || this.f244k != null)) {
            this.f244k = bVar.f248b;
        }
        if (bundle != null) {
            Parcelable parcelable = bundle.getParcelable("android:support:fragments");
            C0080i iVar = this.f235b;
            if (bVar != null) {
                mVar = bVar.f249c;
            }
            iVar.mo325a(parcelable, mVar);
            if (bundle.containsKey("android:support:next_request_index")) {
                this.f242i = bundle.getInt("android:support:next_request_index");
                int[] intArray = bundle.getIntArray("android:support:request_indicies");
                String[] stringArray = bundle.getStringArray("android:support:request_fragment_who");
                if (intArray == null || stringArray == null || intArray.length != stringArray.length) {
                    Log.w("FragmentActivity", "Invalid requestCode mapping in savedInstanceState.");
                } else {
                    this.f243j = new C0166i<>(intArray.length);
                    for (int i = 0; i < intArray.length; i++) {
                        this.f243j.mo707b(intArray[i], stringArray[i]);
                    }
                }
            }
        }
        if (this.f243j == null) {
            this.f243j = new C0166i<>();
            this.f242i = 0;
        }
        this.f235b.mo337e();
    }

    public boolean onCreatePanelMenu(int i, Menu menu) {
        return i == 0 ? super.onCreatePanelMenu(i, menu) | this.f235b.mo329a(menu, getMenuInflater()) : super.onCreatePanelMenu(i, menu);
    }

    public View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        View a = mo280a(view, str, context, attributeSet);
        return a == null ? super.onCreateView(view, str, context, attributeSet) : a;
    }

    public View onCreateView(String str, Context context, AttributeSet attributeSet) {
        View a = mo280a(null, str, context, attributeSet);
        return a == null ? super.onCreateView(str, context, attributeSet) : a;
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        super.onDestroy();
        if (this.f244k != null && !isChangingConfigurations()) {
            this.f244k.mo86a();
        }
        this.f235b.mo343k();
    }

    public void onLowMemory() {
        super.onLowMemory();
        this.f235b.mo344l();
    }

    public boolean onMenuItemSelected(int i, MenuItem menuItem) {
        if (super.onMenuItemSelected(i, menuItem)) {
            return true;
        }
        if (i == 0) {
            return this.f235b.mo330a(menuItem);
        }
        if (i != 6) {
            return false;
        }
        return this.f235b.mo334b(menuItem);
    }

    public void onMultiWindowModeChanged(boolean z) {
        this.f235b.mo327a(z);
    }

    /* access modifiers changed from: protected */
    public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        this.f235b.mo331b();
    }

    public void onPanelClosed(int i, Menu menu) {
        if (i == 0) {
            this.f235b.mo332b(menu);
        }
        super.onPanelClosed(i, menu);
    }

    /* access modifiers changed from: protected */
    public void onPause() {
        super.onPause();
        this.f237d = false;
        if (this.f234a.hasMessages(2)) {
            this.f234a.removeMessages(2);
            mo283c();
        }
        this.f235b.mo341i();
    }

    public void onPictureInPictureModeChanged(boolean z) {
        this.f235b.mo333b(z);
    }

    /* access modifiers changed from: protected */
    public void onPostResume() {
        super.onPostResume();
        this.f234a.removeMessages(2);
        mo283c();
        this.f235b.mo345m();
    }

    public boolean onPreparePanel(int i, View view, Menu menu) {
        return (i != 0 || menu == null) ? super.onPreparePanel(i, view, menu) : mo282a(view, menu) | this.f235b.mo328a(menu);
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        this.f235b.mo331b();
        int i2 = (i >> 16) & 65535;
        if (i2 != 0) {
            int i3 = i2 - 1;
            String str = (String) this.f243j.mo703a(i3);
            this.f243j.mo709c(i3);
            if (str == null) {
                Log.w("FragmentActivity", "Activity result delivered for unknown Fragment.");
                return;
            }
            C0068f a = this.f235b.mo321a(str);
            if (a == null) {
                StringBuilder sb = new StringBuilder();
                sb.append("Activity result no fragment exists for who: ");
                sb.append(str);
                Log.w("FragmentActivity", sb.toString());
            } else {
                a.mo210a(i & 65535, strArr, iArr);
            }
        }
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        super.onResume();
        this.f234a.sendEmptyMessage(2);
        this.f237d = true;
        this.f235b.mo345m();
    }

    public final Object onRetainNonConfigurationInstance() {
        Object d = mo284d();
        C0102m d2 = this.f235b.mo336d();
        if (d2 == null && this.f244k == null && d == null) {
            return null;
        }
        C0078b bVar = new C0078b();
        bVar.f247a = d;
        bVar.f248b = this.f244k;
        bVar.f249c = d2;
        return bVar;
    }

    /* access modifiers changed from: protected */
    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        mo972g();
        Parcelable c = this.f235b.mo335c();
        if (c != null) {
            bundle.putParcelable("android:support:fragments", c);
        }
        if (this.f243j.mo705b() > 0) {
            bundle.putInt("android:support:next_request_index", this.f242i);
            int[] iArr = new int[this.f243j.mo705b()];
            String[] strArr = new String[this.f243j.mo705b()];
            for (int i = 0; i < this.f243j.mo705b(); i++) {
                iArr[i] = this.f243j.mo711d(i);
                strArr[i] = (String) this.f243j.mo712e(i);
            }
            bundle.putIntArray("android:support:request_indicies", iArr);
            bundle.putStringArray("android:support:request_fragment_who", strArr);
        }
    }

    /* access modifiers changed from: protected */
    public void onStart() {
        super.onStart();
        this.f238e = false;
        if (!this.f236c) {
            this.f236c = true;
            this.f235b.mo338f();
        }
        this.f235b.mo331b();
        this.f235b.mo345m();
        this.f235b.mo339g();
    }

    public void onStateNotSaved() {
        this.f235b.mo331b();
    }

    /* access modifiers changed from: protected */
    public void onStop() {
        super.onStop();
        this.f238e = true;
        mo972g();
        this.f235b.mo342j();
    }

    public void startActivityForResult(Intent intent, int i) {
        if (!this.f241h && i != -1) {
            m328b(i);
        }
        super.startActivityForResult(intent, i);
    }

    public void startActivityForResult(Intent intent, int i, Bundle bundle) {
        if (!this.f241h && i != -1) {
            m328b(i);
        }
        super.startActivityForResult(intent, i, bundle);
    }

    public void startIntentSenderForResult(IntentSender intentSender, int i, Intent intent, int i2, int i3, int i4) {
        if (!this.f240g && i != -1) {
            m328b(i);
        }
        super.startIntentSenderForResult(intentSender, i, intent, i2, i3, i4);
    }

    public void startIntentSenderForResult(IntentSender intentSender, int i, Intent intent, int i2, int i3, int i4, Bundle bundle) {
        if (!this.f240g && i != -1) {
            m328b(i);
        }
        super.startIntentSenderForResult(intentSender, i, intent, i2, i3, i4, bundle);
    }
}
