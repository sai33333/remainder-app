package android.support.p005v4.app;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

/* renamed from: android.support.v4.app.i */
public class C0080i {

    /* renamed from: a */
    private final C0081j<?> f250a;

    private C0080i(C0081j<?> jVar) {
        this.f250a = jVar;
    }

    /* renamed from: a */
    public static C0080i m352a(C0081j<?> jVar) {
        return new C0080i(jVar);
    }

    /* renamed from: a */
    public C0068f mo321a(String str) {
        return this.f250a.f252b.mo396b(str);
    }

    /* renamed from: a */
    public C0082k mo322a() {
        return this.f250a.mo349i();
    }

    /* renamed from: a */
    public View mo323a(View view, String str, Context context, AttributeSet attributeSet) {
        return this.f250a.f252b.onCreateView(view, str, context, attributeSet);
    }

    /* renamed from: a */
    public void mo324a(Configuration configuration) {
        this.f250a.f252b.mo377a(configuration);
    }

    /* renamed from: a */
    public void mo325a(Parcelable parcelable, C0102m mVar) {
        this.f250a.f252b.mo379a(parcelable, mVar);
    }

    /* renamed from: a */
    public void mo326a(C0068f fVar) {
        C0085l lVar = this.f250a.f252b;
        C0081j<?> jVar = this.f250a;
        lVar.mo387a((C0081j) jVar, (C0079h) jVar, fVar);
    }

    /* renamed from: a */
    public void mo327a(boolean z) {
        this.f250a.f252b.mo389a(z);
    }

    /* renamed from: a */
    public boolean mo328a(Menu menu) {
        return this.f250a.f252b.mo391a(menu);
    }

    /* renamed from: a */
    public boolean mo329a(Menu menu, MenuInflater menuInflater) {
        return this.f250a.f252b.mo392a(menu, menuInflater);
    }

    /* renamed from: a */
    public boolean mo330a(MenuItem menuItem) {
        return this.f250a.f252b.mo393a(menuItem);
    }

    /* renamed from: b */
    public void mo331b() {
        this.f250a.f252b.mo432m();
    }

    /* renamed from: b */
    public void mo332b(Menu menu) {
        this.f250a.f252b.mo402b(menu);
    }

    /* renamed from: b */
    public void mo333b(boolean z) {
        this.f250a.f252b.mo403b(z);
    }

    /* renamed from: b */
    public boolean mo334b(MenuItem menuItem) {
        return this.f250a.f252b.mo404b(menuItem);
    }

    /* renamed from: c */
    public Parcelable mo335c() {
        return this.f250a.f252b.mo430l();
    }

    /* renamed from: d */
    public C0102m mo336d() {
        return this.f250a.f252b.mo426j();
    }

    /* renamed from: e */
    public void mo337e() {
        this.f250a.f252b.mo435n();
    }

    /* renamed from: f */
    public void mo338f() {
        this.f250a.f252b.mo436o();
    }

    /* renamed from: g */
    public void mo339g() {
        this.f250a.f252b.mo440p();
    }

    /* renamed from: h */
    public void mo340h() {
        this.f250a.f252b.mo441q();
    }

    /* renamed from: i */
    public void mo341i() {
        this.f250a.f252b.mo442r();
    }

    /* renamed from: j */
    public void mo342j() {
        this.f250a.f252b.mo443s();
    }

    /* renamed from: k */
    public void mo343k() {
        this.f250a.f252b.mo446u();
    }

    /* renamed from: l */
    public void mo344l() {
        this.f250a.f252b.mo447v();
    }

    /* renamed from: m */
    public boolean mo345m() {
        return this.f250a.f252b.mo420g();
    }
}
