package android.support.p005v4.app;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.support.p005v4.p008c.C0164g;
import android.view.LayoutInflater;
import android.view.View;
import java.io.FileDescriptor;
import java.io.PrintWriter;

/* renamed from: android.support.v4.app.j */
public abstract class C0081j<E> extends C0079h {

    /* renamed from: a */
    private final Activity f251a;

    /* renamed from: b */
    final C0085l f252b;

    /* renamed from: c */
    private final Context f253c;

    /* renamed from: d */
    private final Handler f254d;

    /* renamed from: e */
    private final int f255e;

    C0081j(Activity activity, Context context, Handler handler, int i) {
        this.f252b = new C0085l();
        this.f251a = activity;
        this.f253c = (Context) C0164g.m732a(context, "context == null");
        this.f254d = (Handler) C0164g.m732a(handler, "handler == null");
        this.f255e = i;
    }

    C0081j(C0075g gVar) {
        this(gVar, gVar, gVar.f234a, 0);
    }

    /* renamed from: a */
    public View mo276a(int i) {
        return null;
    }

    /* renamed from: a */
    public void mo314a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
    }

    /* renamed from: a */
    public boolean mo277a() {
        return true;
    }

    /* renamed from: a */
    public boolean mo315a(C0068f fVar) {
        return true;
    }

    /* renamed from: b */
    public LayoutInflater mo316b() {
        return LayoutInflater.from(this.f253c);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public void mo317b(C0068f fVar) {
    }

    /* renamed from: c */
    public void mo318c() {
    }

    /* renamed from: d */
    public boolean mo319d() {
        return true;
    }

    /* renamed from: e */
    public int mo320e() {
        return this.f255e;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: f */
    public Activity mo346f() {
        return this.f251a;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: g */
    public Context mo347g() {
        return this.f253c;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: h */
    public Handler mo348h() {
        return this.f254d;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: i */
    public C0085l mo349i() {
        return this.f252b;
    }
}
