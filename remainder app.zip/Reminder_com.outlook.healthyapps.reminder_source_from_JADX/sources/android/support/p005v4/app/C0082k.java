package android.support.p005v4.app;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.List;

/* renamed from: android.support.v4.app.k */
public abstract class C0082k {

    /* renamed from: android.support.v4.app.k$a */
    public static abstract class C0083a {
        /* renamed from: a */
        public void mo356a(C0082k kVar, C0068f fVar) {
        }

        /* renamed from: a */
        public void mo357a(C0082k kVar, C0068f fVar, Context context) {
        }

        /* renamed from: a */
        public void mo358a(C0082k kVar, C0068f fVar, Bundle bundle) {
        }

        /* renamed from: a */
        public void mo359a(C0082k kVar, C0068f fVar, View view, Bundle bundle) {
        }

        /* renamed from: b */
        public void mo360b(C0082k kVar, C0068f fVar) {
        }

        /* renamed from: b */
        public void mo361b(C0082k kVar, C0068f fVar, Context context) {
        }

        /* renamed from: b */
        public void mo362b(C0082k kVar, C0068f fVar, Bundle bundle) {
        }

        /* renamed from: c */
        public void mo363c(C0082k kVar, C0068f fVar) {
        }

        /* renamed from: c */
        public void mo364c(C0082k kVar, C0068f fVar, Bundle bundle) {
        }

        /* renamed from: d */
        public void mo365d(C0082k kVar, C0068f fVar) {
        }

        /* renamed from: d */
        public void mo366d(C0082k kVar, C0068f fVar, Bundle bundle) {
        }

        /* renamed from: e */
        public void mo367e(C0082k kVar, C0068f fVar) {
        }

        /* renamed from: f */
        public void mo368f(C0082k kVar, C0068f fVar) {
        }

        /* renamed from: g */
        public void mo369g(C0082k kVar, C0068f fVar) {
        }
    }

    /* renamed from: android.support.v4.app.k$b */
    public interface C0084b {
        /* renamed from: a */
        void mo370a();
    }

    /* renamed from: a */
    public abstract C0107p mo350a();

    /* renamed from: a */
    public abstract void mo351a(int i, int i2);

    /* renamed from: a */
    public abstract void mo352a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr);

    /* renamed from: b */
    public abstract boolean mo353b();

    /* renamed from: c */
    public abstract List<C0068f> mo354c();

    /* renamed from: d */
    public abstract boolean mo355d();
}
