package android.support.p005v4.app;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.arch.lifecycle.C0043p;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources.NotFoundException;
import android.content.res.TypedArray;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcelable;
import android.support.p005v4.app.C0082k.C0083a;
import android.support.p005v4.app.C0082k.C0084b;
import android.support.p005v4.p008c.C0153b;
import android.support.p005v4.p008c.C0156d;
import android.support.p005v4.p008c.C0157e;
import android.support.p005v4.p009d.C0170c;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater.Factory2;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.ScaleAnimation;
import android.view.animation.Transformation;
import com.google.android.gms.internal.C1217ty;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/* renamed from: android.support.v4.app.l */
final class C0085l extends C0082k implements Factory2 {

    /* renamed from: F */
    static final Interpolator f256F = new DecelerateInterpolator(2.5f);

    /* renamed from: G */
    static final Interpolator f257G = new DecelerateInterpolator(1.5f);

    /* renamed from: H */
    static final Interpolator f258H = new AccelerateInterpolator(2.5f);

    /* renamed from: I */
    static final Interpolator f259I = new AccelerateInterpolator(1.5f);

    /* renamed from: a */
    static boolean f260a = false;

    /* renamed from: q */
    static Field f261q;

    /* renamed from: A */
    Bundle f262A = null;

    /* renamed from: B */
    SparseArray<Parcelable> f263B = null;

    /* renamed from: C */
    ArrayList<C0101j> f264C;

    /* renamed from: D */
    C0102m f265D;

    /* renamed from: E */
    Runnable f266E = new Runnable() {
        public void run() {
            C0085l.this.mo420g();
        }
    };

    /* renamed from: J */
    private final CopyOnWriteArrayList<C0097f> f267J = new CopyOnWriteArrayList<>();

    /* renamed from: b */
    ArrayList<C0099h> f268b;

    /* renamed from: c */
    boolean f269c;

    /* renamed from: d */
    int f270d = 0;

    /* renamed from: e */
    final ArrayList<C0068f> f271e = new ArrayList<>();

    /* renamed from: f */
    SparseArray<C0068f> f272f;

    /* renamed from: g */
    ArrayList<C0061b> f273g;

    /* renamed from: h */
    ArrayList<C0068f> f274h;

    /* renamed from: i */
    ArrayList<C0061b> f275i;

    /* renamed from: j */
    ArrayList<Integer> f276j;

    /* renamed from: k */
    ArrayList<C0084b> f277k;

    /* renamed from: l */
    int f278l = 0;

    /* renamed from: m */
    C0081j f279m;

    /* renamed from: n */
    C0079h f280n;

    /* renamed from: o */
    C0068f f281o;

    /* renamed from: p */
    C0068f f282p;

    /* renamed from: r */
    boolean f283r;

    /* renamed from: s */
    boolean f284s;

    /* renamed from: t */
    boolean f285t;

    /* renamed from: u */
    boolean f286u;

    /* renamed from: v */
    String f287v;

    /* renamed from: w */
    boolean f288w;

    /* renamed from: x */
    ArrayList<C0061b> f289x;

    /* renamed from: y */
    ArrayList<Boolean> f290y;

    /* renamed from: z */
    ArrayList<C0068f> f291z;

    /* renamed from: android.support.v4.app.l$a */
    private static class C0091a extends C0093b {

        /* renamed from: a */
        View f305a;

        C0091a(View view, AnimationListener animationListener) {
            super(animationListener);
            this.f305a = view;
        }

        public void onAnimationEnd(Animation animation) {
            if (C0170c.m770c(this.f305a) || VERSION.SDK_INT >= 24) {
                this.f305a.post(new Runnable() {
                    public void run() {
                        C0091a.this.f305a.setLayerType(0, null);
                    }
                });
            } else {
                this.f305a.setLayerType(0, null);
            }
            super.onAnimationEnd(animation);
        }
    }

    /* renamed from: android.support.v4.app.l$b */
    private static class C0093b implements AnimationListener {

        /* renamed from: a */
        private final AnimationListener f307a;

        C0093b(AnimationListener animationListener) {
            this.f307a = animationListener;
        }

        public void onAnimationEnd(Animation animation) {
            AnimationListener animationListener = this.f307a;
            if (animationListener != null) {
                animationListener.onAnimationEnd(animation);
            }
        }

        public void onAnimationRepeat(Animation animation) {
            AnimationListener animationListener = this.f307a;
            if (animationListener != null) {
                animationListener.onAnimationRepeat(animation);
            }
        }

        public void onAnimationStart(Animation animation) {
            AnimationListener animationListener = this.f307a;
            if (animationListener != null) {
                animationListener.onAnimationStart(animation);
            }
        }
    }

    /* renamed from: android.support.v4.app.l$c */
    private static class C0094c {

        /* renamed from: a */
        public final Animation f308a;

        /* renamed from: b */
        public final Animator f309b;

        C0094c(Animator animator) {
            this.f308a = null;
            this.f309b = animator;
            if (animator == null) {
                throw new IllegalStateException("Animator cannot be null");
            }
        }

        C0094c(Animation animation) {
            this.f308a = animation;
            this.f309b = null;
            if (animation == null) {
                throw new IllegalStateException("Animation cannot be null");
            }
        }
    }

    /* renamed from: android.support.v4.app.l$d */
    private static class C0095d extends AnimatorListenerAdapter {

        /* renamed from: a */
        View f310a;

        C0095d(View view) {
            this.f310a = view;
        }

        public void onAnimationEnd(Animator animator) {
            this.f310a.setLayerType(0, null);
            animator.removeListener(this);
        }

        public void onAnimationStart(Animator animator) {
            this.f310a.setLayerType(2, null);
        }
    }

    /* renamed from: android.support.v4.app.l$e */
    private static class C0096e extends AnimationSet implements Runnable {

        /* renamed from: a */
        private final ViewGroup f311a;

        /* renamed from: b */
        private final View f312b;

        /* renamed from: c */
        private boolean f313c;

        /* renamed from: d */
        private boolean f314d;

        /* renamed from: e */
        private boolean f315e = true;

        C0096e(Animation animation, ViewGroup viewGroup, View view) {
            super(false);
            this.f311a = viewGroup;
            this.f312b = view;
            addAnimation(animation);
            this.f311a.post(this);
        }

        public boolean getTransformation(long j, Transformation transformation) {
            this.f315e = true;
            if (this.f313c) {
                return !this.f314d;
            }
            if (!super.getTransformation(j, transformation)) {
                this.f313c = true;
                C0140w.m665a(this.f311a, this);
            }
            return true;
        }

        public boolean getTransformation(long j, Transformation transformation, float f) {
            this.f315e = true;
            if (this.f313c) {
                return !this.f314d;
            }
            if (!super.getTransformation(j, transformation, f)) {
                this.f313c = true;
                C0140w.m665a(this.f311a, this);
            }
            return true;
        }

        public void run() {
            if (this.f313c || !this.f315e) {
                this.f311a.endViewTransition(this.f312b);
                this.f314d = true;
                return;
            }
            this.f315e = false;
            this.f311a.post(this);
        }
    }

    /* renamed from: android.support.v4.app.l$f */
    private static final class C0097f {

        /* renamed from: a */
        final C0083a f316a;

        /* renamed from: b */
        final boolean f317b;
    }

    /* renamed from: android.support.v4.app.l$g */
    static class C0098g {

        /* renamed from: a */
        public static final int[] f318a = {16842755, 16842960, 16842961};
    }

    /* renamed from: android.support.v4.app.l$h */
    interface C0099h {
        /* renamed from: a */
        boolean mo144a(ArrayList<C0061b> arrayList, ArrayList<Boolean> arrayList2);
    }

    /* renamed from: android.support.v4.app.l$i */
    private class C0100i implements C0099h {

        /* renamed from: a */
        final String f319a;

        /* renamed from: b */
        final int f320b;

        /* renamed from: c */
        final int f321c;

        C0100i(String str, int i, int i2) {
            this.f319a = str;
            this.f320b = i;
            this.f321c = i2;
        }

        /* renamed from: a */
        public boolean mo144a(ArrayList<C0061b> arrayList, ArrayList<Boolean> arrayList2) {
            if (C0085l.this.f282p != null && this.f320b < 0 && this.f319a == null) {
                C0082k p = C0085l.this.f282p.mo262p();
                if (p != null && p.mo353b()) {
                    return false;
                }
            }
            return C0085l.this.mo394a(arrayList, arrayList2, this.f319a, this.f320b, this.f321c);
        }
    }

    /* renamed from: android.support.v4.app.l$j */
    static class C0101j implements C0074c {

        /* renamed from: a */
        final boolean f323a;

        /* renamed from: b */
        final C0061b f324b;

        /* renamed from: c */
        private int f325c;

        C0101j(C0061b bVar, boolean z) {
            this.f323a = z;
            this.f324b = bVar;
        }

        /* renamed from: a */
        public void mo278a() {
            this.f325c--;
            if (this.f325c == 0) {
                this.f324b.f112a.mo415f();
            }
        }

        /* renamed from: b */
        public void mo279b() {
            this.f325c++;
        }

        /* renamed from: c */
        public boolean mo463c() {
            return this.f325c == 0;
        }

        /* renamed from: d */
        public void mo464d() {
            boolean z = this.f325c > 0;
            C0085l lVar = this.f324b.f112a;
            int size = lVar.f271e.size();
            for (int i = 0; i < size; i++) {
                C0068f fVar = (C0068f) lVar.f271e.get(i);
                fVar.mo216a((C0074c) null);
                if (z && fVar.mo201Y()) {
                    fVar.mo181E();
                }
            }
            this.f324b.f112a.mo380a(this.f324b, this.f323a, !z, true);
        }

        /* renamed from: e */
        public void mo465e() {
            this.f324b.f112a.mo380a(this.f324b, this.f323a, false, false);
        }
    }

    C0085l() {
    }

    /* renamed from: A */
    private void m412A() {
        if (this.f264C != null) {
            while (!this.f264C.isEmpty()) {
                ((C0101j) this.f264C.remove(0)).mo464d();
            }
        }
    }

    /* renamed from: B */
    private void m413B() {
        SparseArray<C0068f> sparseArray = this.f272f;
        int size = sparseArray == null ? 0 : sparseArray.size();
        for (int i = 0; i < size; i++) {
            C0068f fVar = (C0068f) this.f272f.valueAt(i);
            if (fVar != null) {
                if (fVar.mo198V() != null) {
                    int X = fVar.mo200X();
                    View V = fVar.mo198V();
                    Animation animation = V.getAnimation();
                    if (animation != null) {
                        animation.cancel();
                        V.clearAnimation();
                    }
                    fVar.mo220a((View) null);
                    mo382a(fVar, X, 0, 0, false);
                } else if (fVar.mo199W() != null) {
                    fVar.mo199W().end();
                }
            }
        }
    }

    /* renamed from: C */
    private void m414C() {
        SparseArray<C0068f> sparseArray = this.f272f;
        if (sparseArray != null) {
            for (int size = sparseArray.size() - 1; size >= 0; size--) {
                if (this.f272f.valueAt(size) == null) {
                    SparseArray<C0068f> sparseArray2 = this.f272f;
                    sparseArray2.delete(sparseArray2.keyAt(size));
                }
            }
        }
    }

    /* renamed from: a */
    private int m415a(ArrayList<C0061b> arrayList, ArrayList<Boolean> arrayList2, int i, int i2, C0153b<C0068f> bVar) {
        int i3 = i2;
        for (int i4 = i2 - 1; i4 >= i; i4--) {
            C0061b bVar2 = (C0061b) arrayList.get(i4);
            boolean booleanValue = ((Boolean) arrayList2.get(i4)).booleanValue();
            if (bVar2.mo151e() && !bVar2.mo143a(arrayList, i4 + 1, i2)) {
                if (this.f264C == null) {
                    this.f264C = new ArrayList<>();
                }
                C0101j jVar = new C0101j(bVar2, booleanValue);
                this.f264C.add(jVar);
                bVar2.mo140a((C0074c) jVar);
                if (booleanValue) {
                    bVar2.mo150d();
                } else {
                    bVar2.mo147b(false);
                }
                i3--;
                if (i4 != i3) {
                    arrayList.remove(i4);
                    arrayList.add(i3, bVar2);
                }
                m430b(bVar);
            }
        }
        return i3;
    }

    /* renamed from: a */
    static C0094c m416a(Context context, float f, float f2) {
        AlphaAnimation alphaAnimation = new AlphaAnimation(f, f2);
        alphaAnimation.setInterpolator(f257G);
        alphaAnimation.setDuration(220);
        return new C0094c((Animation) alphaAnimation);
    }

    /* renamed from: a */
    static C0094c m417a(Context context, float f, float f2, float f3, float f4) {
        AnimationSet animationSet = new AnimationSet(false);
        ScaleAnimation scaleAnimation = new ScaleAnimation(f, f2, f, f2, 1, 0.5f, 1, 0.5f);
        scaleAnimation.setInterpolator(f256F);
        scaleAnimation.setDuration(220);
        animationSet.addAnimation(scaleAnimation);
        AlphaAnimation alphaAnimation = new AlphaAnimation(f3, f4);
        alphaAnimation.setInterpolator(f257G);
        alphaAnimation.setDuration(220);
        animationSet.addAnimation(alphaAnimation);
        return new C0094c((Animation) animationSet);
    }

    /* renamed from: a */
    private static AnimationListener m418a(Animation animation) {
        String str;
        String str2;
        try {
            if (f261q == null) {
                f261q = Animation.class.getDeclaredField("mListener");
                f261q.setAccessible(true);
            }
            return (AnimationListener) f261q.get(animation);
        } catch (NoSuchFieldException e) {
            e = e;
            str2 = "FragmentManager";
            str = "No field with the name mListener is found in Animation class";
            Log.e(str2, str, e);
            return null;
        } catch (IllegalAccessException e2) {
            e = e2;
            str2 = "FragmentManager";
            str = "Cannot access Animation's mListener field";
            Log.e(str2, str, e);
            return null;
        }
    }

    /* renamed from: a */
    private void m419a(final C0068f fVar, C0094c cVar, int i) {
        final View view = fVar.f182S;
        final ViewGroup viewGroup = fVar.f181R;
        viewGroup.startViewTransition(view);
        fVar.mo225b(i);
        if (cVar.f308a != null) {
            C0096e eVar = new C0096e(cVar.f308a, viewGroup, view);
            fVar.mo220a(fVar.f182S);
            eVar.setAnimationListener(new C0093b(m418a((Animation) eVar)) {
                public void onAnimationEnd(Animation animation) {
                    super.onAnimationEnd(animation);
                    viewGroup.post(new Runnable() {
                        public void run() {
                            if (fVar.mo198V() != null) {
                                fVar.mo220a((View) null);
                                C0085l.this.mo382a(fVar, fVar.mo200X(), 0, 0, false);
                            }
                        }
                    });
                }
            });
            m431b(view, cVar);
            fVar.f182S.startAnimation(eVar);
            return;
        }
        Animator animator = cVar.f309b;
        fVar.mo211a(cVar.f309b);
        animator.addListener(new AnimatorListenerAdapter() {
            public void onAnimationEnd(Animator animator) {
                viewGroup.endViewTransition(view);
                Animator W = fVar.mo199W();
                fVar.mo211a((Animator) null);
                if (W != null && viewGroup.indexOfChild(view) < 0) {
                    C0085l lVar = C0085l.this;
                    C0068f fVar = fVar;
                    lVar.mo382a(fVar, fVar.mo200X(), 0, 0, false);
                }
            }
        });
        animator.setTarget(fVar.f182S);
        m431b(fVar.f182S, cVar);
        animator.start();
    }

    /* renamed from: a */
    private static void m420a(C0102m mVar) {
        if (mVar != null) {
            List<C0068f> a = mVar.mo466a();
            if (a != null) {
                for (C0068f fVar : a) {
                    fVar.f177N = true;
                }
            }
            List<C0102m> b = mVar.mo467b();
            if (b != null) {
                for (C0102m a2 : b) {
                    m420a(a2);
                }
            }
        }
    }

    /* renamed from: a */
    private void m421a(C0153b<C0068f> bVar) {
        int size = bVar.size();
        for (int i = 0; i < size; i++) {
            C0068f fVar = (C0068f) bVar.mo601b(i);
            if (!fVar.f206u) {
                View q = fVar.mo263q();
                fVar.f189Z = q.getAlpha();
                q.setAlpha(0.0f);
            }
        }
    }

    /* renamed from: a */
    private void m422a(RuntimeException runtimeException) {
        Log.e("FragmentManager", runtimeException.getMessage());
        Log.e("FragmentManager", "Activity state:");
        PrintWriter printWriter = new PrintWriter(new C0157e("FragmentManager"));
        C0081j jVar = this.f279m;
        if (jVar != null) {
            try {
                jVar.mo314a("  ", null, printWriter, new String[0]);
            } catch (Exception e) {
                Log.e("FragmentManager", "Failed dumping state", e);
            }
        } else {
            mo352a("  ", (FileDescriptor) null, printWriter, new String[0]);
        }
        throw runtimeException;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:13:0x0030, code lost:
        if (((java.lang.Boolean) r9.get(r5)).booleanValue() != false) goto L_0x0032;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:14:0x0032, code lost:
        r3.mo465e();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:27:0x006b, code lost:
        if (((java.lang.Boolean) r9.get(r5)).booleanValue() != false) goto L_0x0032;
     */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void m423a(java.util.ArrayList<android.support.p005v4.app.C0061b> r8, java.util.ArrayList<java.lang.Boolean> r9) {
        /*
            r7 = this;
            java.util.ArrayList<android.support.v4.app.l$j> r0 = r7.f264C
            r1 = 0
            if (r0 != 0) goto L_0x0007
            r0 = r1
            goto L_0x000b
        L_0x0007:
            int r0 = r0.size()
        L_0x000b:
            r2 = r0
            r0 = r1
        L_0x000d:
            if (r0 >= r2) goto L_0x0074
            java.util.ArrayList<android.support.v4.app.l$j> r3 = r7.f264C
            java.lang.Object r3 = r3.get(r0)
            android.support.v4.app.l$j r3 = (android.support.p005v4.app.C0085l.C0101j) r3
            r4 = -1
            if (r8 == 0) goto L_0x0036
            boolean r5 = r3.f323a
            if (r5 != 0) goto L_0x0036
            android.support.v4.app.b r5 = r3.f324b
            int r5 = r8.indexOf(r5)
            if (r5 == r4) goto L_0x0036
            java.lang.Object r5 = r9.get(r5)
            java.lang.Boolean r5 = (java.lang.Boolean) r5
            boolean r5 = r5.booleanValue()
            if (r5 == 0) goto L_0x0036
        L_0x0032:
            r3.mo465e()
            goto L_0x0071
        L_0x0036:
            boolean r5 = r3.mo463c()
            if (r5 != 0) goto L_0x004a
            if (r8 == 0) goto L_0x0071
            android.support.v4.app.b r5 = r3.f324b
            int r6 = r8.size()
            boolean r5 = r5.mo143a(r8, r1, r6)
            if (r5 == 0) goto L_0x0071
        L_0x004a:
            java.util.ArrayList<android.support.v4.app.l$j> r5 = r7.f264C
            r5.remove(r0)
            int r0 = r0 + -1
            int r2 = r2 + -1
            if (r8 == 0) goto L_0x006e
            boolean r5 = r3.f323a
            if (r5 != 0) goto L_0x006e
            android.support.v4.app.b r5 = r3.f324b
            int r5 = r8.indexOf(r5)
            if (r5 == r4) goto L_0x006e
            java.lang.Object r4 = r9.get(r5)
            java.lang.Boolean r4 = (java.lang.Boolean) r4
            boolean r4 = r4.booleanValue()
            if (r4 == 0) goto L_0x006e
            goto L_0x0032
        L_0x006e:
            r3.mo464d()
        L_0x0071:
            int r0 = r0 + 1
            goto L_0x000d
        L_0x0074:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p005v4.app.C0085l.m423a(java.util.ArrayList, java.util.ArrayList):void");
    }

    /* renamed from: a */
    private void m424a(ArrayList<C0061b> arrayList, ArrayList<Boolean> arrayList2, int i, int i2) {
        int i3;
        ArrayList<C0061b> arrayList3 = arrayList;
        ArrayList<Boolean> arrayList4 = arrayList2;
        int i4 = i;
        int i5 = i2;
        boolean z = ((C0061b) arrayList3.get(i4)).f131t;
        ArrayList<C0068f> arrayList5 = this.f291z;
        if (arrayList5 == null) {
            this.f291z = new ArrayList<>();
        } else {
            arrayList5.clear();
        }
        this.f291z.addAll(this.f271e);
        C0068f w = mo448w();
        boolean z2 = false;
        for (int i6 = i4; i6 < i5; i6++) {
            C0061b bVar = (C0061b) arrayList3.get(i6);
            w = !((Boolean) arrayList4.get(i6)).booleanValue() ? bVar.mo134a(this.f291z, w) : bVar.mo146b(this.f291z, w);
            z2 = z2 || bVar.f120i;
        }
        this.f291z.clear();
        if (!z) {
            C0108q.m558a(this, arrayList, arrayList2, i, i2, false);
        }
        m433b(arrayList, arrayList2, i, i2);
        if (z) {
            C0153b bVar2 = new C0153b();
            m430b(bVar2);
            int a = m415a(arrayList, arrayList2, i, i2, bVar2);
            m421a(bVar2);
            i3 = a;
        } else {
            i3 = i5;
        }
        if (i3 != i4 && z) {
            C0108q.m558a(this, arrayList, arrayList2, i, i3, true);
            mo376a(this.f278l, true);
        }
        while (i4 < i5) {
            C0061b bVar3 = (C0061b) arrayList3.get(i4);
            if (((Boolean) arrayList4.get(i4)).booleanValue() && bVar3.f124m >= 0) {
                mo405c(bVar3.f124m);
                bVar3.f124m = -1;
            }
            bVar3.mo137a();
            i4++;
        }
        if (z2) {
            mo424i();
        }
    }

    /* renamed from: a */
    static boolean m425a(Animator animator) {
        if (animator == null) {
            return false;
        }
        if (animator instanceof ValueAnimator) {
            PropertyValuesHolder[] values = ((ValueAnimator) animator).getValues();
            for (PropertyValuesHolder propertyName : values) {
                if ("alpha".equals(propertyName.getPropertyName())) {
                    return true;
                }
            }
        } else if (animator instanceof AnimatorSet) {
            ArrayList childAnimations = ((AnimatorSet) animator).getChildAnimations();
            for (int i = 0; i < childAnimations.size(); i++) {
                if (m425a((Animator) childAnimations.get(i))) {
                    return true;
                }
            }
        }
        return false;
    }

    /* renamed from: a */
    static boolean m426a(C0094c cVar) {
        if (cVar.f308a instanceof AlphaAnimation) {
            return true;
        }
        if (!(cVar.f308a instanceof AnimationSet)) {
            return m425a(cVar.f309b);
        }
        List animations = ((AnimationSet) cVar.f308a).getAnimations();
        for (int i = 0; i < animations.size(); i++) {
            if (animations.get(i) instanceof AlphaAnimation) {
                return true;
            }
        }
        return false;
    }

    /* renamed from: a */
    static boolean m427a(View view, C0094c cVar) {
        return view != null && cVar != null && VERSION.SDK_INT >= 19 && view.getLayerType() == 0 && C0170c.m768b(view) && m426a(cVar);
    }

    /* renamed from: a */
    private boolean m428a(String str, int i, int i2) {
        mo420g();
        m434c(true);
        C0068f fVar = this.f282p;
        if (fVar != null && i < 0 && str == null) {
            C0082k p = fVar.mo262p();
            if (p != null && p.mo353b()) {
                return true;
            }
        }
        boolean a = mo394a(this.f289x, this.f290y, str, i, i2);
        if (a) {
            this.f269c = true;
            try {
                m432b(this.f289x, this.f290y);
            } finally {
                m440z();
            }
        }
        mo421h();
        m414C();
        return a;
    }

    /* renamed from: b */
    public static int m429b(int i, boolean z) {
        if (i == 4097) {
            return z ? 1 : 2;
        }
        if (i == 4099) {
            return z ? 5 : 6;
        }
        if (i != 8194) {
            return -1;
        }
        return z ? 3 : 4;
    }

    /* renamed from: b */
    private void m430b(C0153b<C0068f> bVar) {
        int i = this.f278l;
        if (i >= 1) {
            int min = Math.min(i, 3);
            int size = this.f271e.size();
            for (int i2 = 0; i2 < size; i2++) {
                C0068f fVar = (C0068f) this.f271e.get(i2);
                if (fVar.f196k < min) {
                    mo382a(fVar, min, fVar.mo193Q(), fVar.mo194R(), false);
                    if (fVar.f182S != null && !fVar.f174K && fVar.f187X) {
                        bVar.add(fVar);
                    }
                }
            }
        }
    }

    /* renamed from: b */
    private static void m431b(View view, C0094c cVar) {
        if (view != null && cVar != null && m427a(view, cVar)) {
            if (cVar.f309b != null) {
                cVar.f309b.addListener(new C0095d(view));
                return;
            }
            AnimationListener a = m418a(cVar.f308a);
            view.setLayerType(2, null);
            cVar.f308a.setAnimationListener(new C0091a(view, a));
        }
    }

    /* renamed from: b */
    private void m432b(ArrayList<C0061b> arrayList, ArrayList<Boolean> arrayList2) {
        if (arrayList != null && !arrayList.isEmpty()) {
            if (arrayList2 == null || arrayList.size() != arrayList2.size()) {
                throw new IllegalStateException("Internal error with the back stack records");
            }
            m423a(arrayList, arrayList2);
            int size = arrayList.size();
            int i = 0;
            int i2 = 0;
            while (i < size) {
                if (!((C0061b) arrayList.get(i)).f131t) {
                    if (i2 != i) {
                        m424a(arrayList, arrayList2, i2, i);
                    }
                    i2 = i + 1;
                    if (((Boolean) arrayList2.get(i)).booleanValue()) {
                        while (i2 < size && ((Boolean) arrayList2.get(i2)).booleanValue() && !((C0061b) arrayList.get(i2)).f131t) {
                            i2++;
                        }
                    }
                    m424a(arrayList, arrayList2, i, i2);
                    i = i2 - 1;
                }
                i++;
            }
            if (i2 != size) {
                m424a(arrayList, arrayList2, i2, size);
            }
        }
    }

    /* renamed from: b */
    private static void m433b(ArrayList<C0061b> arrayList, ArrayList<Boolean> arrayList2, int i, int i2) {
        while (i < i2) {
            C0061b bVar = (C0061b) arrayList.get(i);
            boolean z = true;
            if (((Boolean) arrayList2.get(i)).booleanValue()) {
                bVar.mo138a(-1);
                if (i != i2 - 1) {
                    z = false;
                }
                bVar.mo147b(z);
            } else {
                bVar.mo138a(1);
                bVar.mo150d();
            }
            i++;
        }
    }

    /* renamed from: c */
    private void m434c(boolean z) {
        if (this.f269c) {
            throw new IllegalStateException("FragmentManager is already executing transactions");
        } else if (this.f279m == null) {
            throw new IllegalStateException("Fragment host has been destroyed");
        } else if (Looper.myLooper() == this.f279m.mo348h().getLooper()) {
            if (!z) {
                m439y();
            }
            if (this.f289x == null) {
                this.f289x = new ArrayList<>();
                this.f290y = new ArrayList<>();
            }
            this.f269c = true;
            try {
                m423a(null, null);
            } finally {
                this.f269c = false;
            }
        } else {
            throw new IllegalStateException("Must be called from main thread of fragment host");
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:14:0x003b, code lost:
        return false;
     */
    /* renamed from: c */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private boolean m435c(java.util.ArrayList<android.support.p005v4.app.C0061b> r5, java.util.ArrayList<java.lang.Boolean> r6) {
        /*
            r4 = this;
            monitor-enter(r4)
            java.util.ArrayList<android.support.v4.app.l$h> r0 = r4.f268b     // Catch:{ all -> 0x003c }
            r1 = 0
            if (r0 == 0) goto L_0x003a
            java.util.ArrayList<android.support.v4.app.l$h> r0 = r4.f268b     // Catch:{ all -> 0x003c }
            int r0 = r0.size()     // Catch:{ all -> 0x003c }
            if (r0 != 0) goto L_0x000f
            goto L_0x003a
        L_0x000f:
            java.util.ArrayList<android.support.v4.app.l$h> r0 = r4.f268b     // Catch:{ all -> 0x003c }
            int r0 = r0.size()     // Catch:{ all -> 0x003c }
            r2 = r1
        L_0x0016:
            if (r1 >= r0) goto L_0x0028
            java.util.ArrayList<android.support.v4.app.l$h> r3 = r4.f268b     // Catch:{ all -> 0x003c }
            java.lang.Object r3 = r3.get(r1)     // Catch:{ all -> 0x003c }
            android.support.v4.app.l$h r3 = (android.support.p005v4.app.C0085l.C0099h) r3     // Catch:{ all -> 0x003c }
            boolean r3 = r3.mo144a(r5, r6)     // Catch:{ all -> 0x003c }
            r2 = r2 | r3
            int r1 = r1 + 1
            goto L_0x0016
        L_0x0028:
            java.util.ArrayList<android.support.v4.app.l$h> r5 = r4.f268b     // Catch:{ all -> 0x003c }
            r5.clear()     // Catch:{ all -> 0x003c }
            android.support.v4.app.j r5 = r4.f279m     // Catch:{ all -> 0x003c }
            android.os.Handler r5 = r5.mo348h()     // Catch:{ all -> 0x003c }
            java.lang.Runnable r6 = r4.f266E     // Catch:{ all -> 0x003c }
            r5.removeCallbacks(r6)     // Catch:{ all -> 0x003c }
            monitor-exit(r4)     // Catch:{ all -> 0x003c }
            return r2
        L_0x003a:
            monitor-exit(r4)     // Catch:{ all -> 0x003c }
            return r1
        L_0x003c:
            r5 = move-exception
            monitor-exit(r4)     // Catch:{ all -> 0x003c }
            throw r5
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p005v4.app.C0085l.m435c(java.util.ArrayList, java.util.ArrayList):boolean");
    }

    /* renamed from: d */
    public static int m436d(int i) {
        if (i == 4097) {
            return 8194;
        }
        if (i != 4099) {
            return i != 8194 ? 0 : 4097;
        }
        return 4099;
    }

    /* JADX INFO: finally extract failed */
    /* renamed from: e */
    private void m437e(int i) {
        try {
            this.f269c = true;
            mo376a(i, false);
            this.f269c = false;
            mo420g();
        } catch (Throwable th) {
            this.f269c = false;
            throw th;
        }
    }

    /* renamed from: p */
    private C0068f m438p(C0068f fVar) {
        ViewGroup viewGroup = fVar.f181R;
        View view = fVar.f182S;
        if (!(viewGroup == null || view == null)) {
            for (int indexOf = this.f271e.indexOf(fVar) - 1; indexOf >= 0; indexOf--) {
                C0068f fVar2 = (C0068f) this.f271e.get(indexOf);
                if (fVar2.f181R == viewGroup && fVar2.f182S != null) {
                    return fVar2;
                }
            }
        }
        return null;
    }

    /* renamed from: y */
    private void m439y() {
        if (mo355d()) {
            throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
        } else if (this.f287v != null) {
            StringBuilder sb = new StringBuilder();
            sb.append("Can not perform this action inside of ");
            sb.append(this.f287v);
            throw new IllegalStateException(sb.toString());
        }
    }

    /* renamed from: z */
    private void m440z() {
        this.f269c = false;
        this.f290y.clear();
        this.f289x.clear();
    }

    /* renamed from: a */
    public int mo371a(C0061b bVar) {
        synchronized (this) {
            if (this.f276j != null) {
                if (this.f276j.size() > 0) {
                    int intValue = ((Integer) this.f276j.remove(this.f276j.size() - 1)).intValue();
                    if (f260a) {
                        StringBuilder sb = new StringBuilder();
                        sb.append("Adding back stack index ");
                        sb.append(intValue);
                        sb.append(" with ");
                        sb.append(bVar);
                        Log.v("FragmentManager", sb.toString());
                    }
                    this.f275i.set(intValue, bVar);
                    return intValue;
                }
            }
            if (this.f275i == null) {
                this.f275i = new ArrayList<>();
            }
            int size = this.f275i.size();
            if (f260a) {
                StringBuilder sb2 = new StringBuilder();
                sb2.append("Setting back stack index ");
                sb2.append(size);
                sb2.append(" to ");
                sb2.append(bVar);
                Log.v("FragmentManager", sb2.toString());
            }
            this.f275i.add(bVar);
            return size;
        }
    }

    /* renamed from: a */
    public C0068f mo372a(Bundle bundle, String str) {
        int i = bundle.getInt(str, -1);
        if (i == -1) {
            return null;
        }
        C0068f fVar = (C0068f) this.f272f.get(i);
        if (fVar == null) {
            StringBuilder sb = new StringBuilder();
            sb.append("Fragment no longer exists for key ");
            sb.append(str);
            sb.append(": index ");
            sb.append(i);
            m422a((RuntimeException) new IllegalStateException(sb.toString()));
        }
        return fVar;
    }

    /* renamed from: a */
    public C0068f mo373a(String str) {
        if (str != null) {
            for (int size = this.f271e.size() - 1; size >= 0; size--) {
                C0068f fVar = (C0068f) this.f271e.get(size);
                if (fVar != null && str.equals(fVar.f173J)) {
                    return fVar;
                }
            }
        }
        SparseArray<C0068f> sparseArray = this.f272f;
        if (!(sparseArray == null || str == null)) {
            for (int size2 = sparseArray.size() - 1; size2 >= 0; size2--) {
                C0068f fVar2 = (C0068f) this.f272f.valueAt(size2);
                if (fVar2 != null && str.equals(fVar2.f173J)) {
                    return fVar2;
                }
            }
        }
        return null;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public C0094c mo374a(C0068f fVar, int i, boolean z, int i2) {
        int Q = fVar.mo193Q();
        Animation a = fVar.mo205a(i, z, Q);
        if (a != null) {
            return new C0094c(a);
        }
        Animator b = fVar.mo224b(i, z, Q);
        if (b != null) {
            return new C0094c(b);
        }
        if (Q != 0) {
            boolean equals = "anim".equals(this.f279m.mo347g().getResources().getResourceTypeName(Q));
            boolean z2 = false;
            if (equals) {
                try {
                    Animation loadAnimation = AnimationUtils.loadAnimation(this.f279m.mo347g(), Q);
                    if (loadAnimation != null) {
                        return new C0094c(loadAnimation);
                    }
                    z2 = true;
                } catch (NotFoundException e) {
                    throw e;
                } catch (RuntimeException unused) {
                }
            }
            if (!z2) {
                try {
                    Animator loadAnimator = AnimatorInflater.loadAnimator(this.f279m.mo347g(), Q);
                    if (loadAnimator != null) {
                        return new C0094c(loadAnimator);
                    }
                } catch (RuntimeException e2) {
                    if (!equals) {
                        Animation loadAnimation2 = AnimationUtils.loadAnimation(this.f279m.mo347g(), Q);
                        if (loadAnimation2 != null) {
                            return new C0094c(loadAnimation2);
                        }
                    } else {
                        throw e2;
                    }
                }
            }
        }
        if (i == 0) {
            return null;
        }
        int b2 = m429b(i, z);
        if (b2 < 0) {
            return null;
        }
        switch (b2) {
            case 1:
                return m417a(this.f279m.mo347g(), 1.125f, 1.0f, 0.0f, 1.0f);
            case 2:
                return m417a(this.f279m.mo347g(), 1.0f, 0.975f, 1.0f, 0.0f);
            case 3:
                return m417a(this.f279m.mo347g(), 0.975f, 1.0f, 0.0f, 1.0f);
            case C1217ty.f4597d /*4*/:
                return m417a(this.f279m.mo347g(), 1.0f, 1.075f, 1.0f, 0.0f);
            case C1217ty.f4598e /*5*/:
                return m416a(this.f279m.mo347g(), 0.0f, 1.0f);
            case C1217ty.f4599f /*6*/:
                return m416a(this.f279m.mo347g(), 1.0f, 0.0f);
            default:
                if (i2 == 0 && this.f279m.mo319d()) {
                    i2 = this.f279m.mo320e();
                }
                if (i2 == 0) {
                }
                return null;
        }
    }

    /* renamed from: a */
    public C0107p mo350a() {
        return new C0061b(this);
    }

    /* renamed from: a */
    public void mo351a(int i, int i2) {
        if (i >= 0) {
            mo388a((C0099h) new C0100i(null, i, i2), false);
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Bad id: ");
        sb.append(i);
        throw new IllegalArgumentException(sb.toString());
    }

    /* renamed from: a */
    public void mo375a(int i, C0061b bVar) {
        synchronized (this) {
            if (this.f275i == null) {
                this.f275i = new ArrayList<>();
            }
            int size = this.f275i.size();
            if (i < size) {
                if (f260a) {
                    StringBuilder sb = new StringBuilder();
                    sb.append("Setting back stack index ");
                    sb.append(i);
                    sb.append(" to ");
                    sb.append(bVar);
                    Log.v("FragmentManager", sb.toString());
                }
                this.f275i.set(i, bVar);
            } else {
                while (size < i) {
                    this.f275i.add(null);
                    if (this.f276j == null) {
                        this.f276j = new ArrayList<>();
                    }
                    if (f260a) {
                        StringBuilder sb2 = new StringBuilder();
                        sb2.append("Adding available back stack index ");
                        sb2.append(size);
                        Log.v("FragmentManager", sb2.toString());
                    }
                    this.f276j.add(Integer.valueOf(size));
                    size++;
                }
                if (f260a) {
                    StringBuilder sb3 = new StringBuilder();
                    sb3.append("Adding back stack index ");
                    sb3.append(i);
                    sb3.append(" with ");
                    sb3.append(bVar);
                    Log.v("FragmentManager", sb3.toString());
                }
                this.f275i.add(bVar);
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo376a(int i, boolean z) {
        if (this.f279m == null && i != 0) {
            throw new IllegalStateException("No activity");
        } else if (z || i != this.f278l) {
            this.f278l = i;
            if (this.f272f != null) {
                int size = this.f271e.size();
                for (int i2 = 0; i2 < size; i2++) {
                    mo413e((C0068f) this.f271e.get(i2));
                }
                int size2 = this.f272f.size();
                for (int i3 = 0; i3 < size2; i3++) {
                    C0068f fVar = (C0068f) this.f272f.valueAt(i3);
                    if (fVar != null && ((fVar.f207v || fVar.f175L) && !fVar.f187X)) {
                        mo413e(fVar);
                    }
                }
                mo412e();
                if (this.f283r) {
                    C0081j jVar = this.f279m;
                    if (jVar != null && this.f278l == 4) {
                        jVar.mo318c();
                        this.f283r = false;
                    }
                }
            }
        }
    }

    /* renamed from: a */
    public void mo377a(Configuration configuration) {
        for (int i = 0; i < this.f271e.size(); i++) {
            C0068f fVar = (C0068f) this.f271e.get(i);
            if (fVar != null) {
                fVar.mo215a(configuration);
            }
        }
    }

    /* renamed from: a */
    public void mo378a(Bundle bundle, String str, C0068f fVar) {
        if (fVar.f200o < 0) {
            StringBuilder sb = new StringBuilder();
            sb.append("Fragment ");
            sb.append(fVar);
            sb.append(" is not currently in the FragmentManager");
            m422a((RuntimeException) new IllegalStateException(sb.toString()));
        }
        bundle.putInt(str, fVar.f200o);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo379a(Parcelable parcelable, C0102m mVar) {
        List list;
        List list2;
        if (parcelable != null) {
            C0103n nVar = (C0103n) parcelable;
            if (nVar.f329a != null) {
                if (mVar != null) {
                    List a = mVar.mo466a();
                    list2 = mVar.mo467b();
                    list = mVar.mo468c();
                    int size = a != null ? a.size() : 0;
                    for (int i = 0; i < size; i++) {
                        C0068f fVar = (C0068f) a.get(i);
                        if (f260a) {
                            StringBuilder sb = new StringBuilder();
                            sb.append("restoreAllState: re-attaching retained ");
                            sb.append(fVar);
                            Log.v("FragmentManager", sb.toString());
                        }
                        int i2 = 0;
                        while (i2 < nVar.f329a.length && nVar.f329a[i2].f335b != fVar.f200o) {
                            i2++;
                        }
                        if (i2 == nVar.f329a.length) {
                            StringBuilder sb2 = new StringBuilder();
                            sb2.append("Could not find active fragment with index ");
                            sb2.append(fVar.f200o);
                            m422a((RuntimeException) new IllegalStateException(sb2.toString()));
                        }
                        C0105o oVar = nVar.f329a[i2];
                        oVar.f345l = fVar;
                        fVar.f198m = null;
                        fVar.f164A = 0;
                        fVar.f209x = false;
                        fVar.f206u = false;
                        fVar.f203r = null;
                        if (oVar.f344k != null) {
                            oVar.f344k.setClassLoader(this.f279m.mo347g().getClassLoader());
                            fVar.f198m = oVar.f344k.getSparseParcelableArray("android:view_state");
                            fVar.f197l = oVar.f344k;
                        }
                    }
                } else {
                    list2 = null;
                    list = null;
                }
                this.f272f = new SparseArray<>(nVar.f329a.length);
                int i3 = 0;
                while (i3 < nVar.f329a.length) {
                    C0105o oVar2 = nVar.f329a[i3];
                    if (oVar2 != null) {
                        C0068f a2 = oVar2.mo475a(this.f279m, this.f280n, this.f281o, (list2 == null || i3 >= list2.size()) ? null : (C0102m) list2.get(i3), (list == null || i3 >= list.size()) ? null : (C0043p) list.get(i3));
                        if (f260a) {
                            StringBuilder sb3 = new StringBuilder();
                            sb3.append("restoreAllState: active #");
                            sb3.append(i3);
                            sb3.append(": ");
                            sb3.append(a2);
                            Log.v("FragmentManager", sb3.toString());
                        }
                        this.f272f.put(a2.f200o, a2);
                        oVar2.f345l = null;
                    }
                    i3++;
                }
                if (mVar != null) {
                    List a3 = mVar.mo466a();
                    int size2 = a3 != null ? a3.size() : 0;
                    for (int i4 = 0; i4 < size2; i4++) {
                        C0068f fVar2 = (C0068f) a3.get(i4);
                        if (fVar2.f204s >= 0) {
                            fVar2.f203r = (C0068f) this.f272f.get(fVar2.f204s);
                            if (fVar2.f203r == null) {
                                StringBuilder sb4 = new StringBuilder();
                                sb4.append("Re-attaching retained fragment ");
                                sb4.append(fVar2);
                                sb4.append(" target no longer exists: ");
                                sb4.append(fVar2.f204s);
                                Log.w("FragmentManager", sb4.toString());
                            }
                        }
                    }
                }
                this.f271e.clear();
                if (nVar.f330b != null) {
                    int i5 = 0;
                    while (i5 < nVar.f330b.length) {
                        C0068f fVar3 = (C0068f) this.f272f.get(nVar.f330b[i5]);
                        if (fVar3 == null) {
                            StringBuilder sb5 = new StringBuilder();
                            sb5.append("No instantiated fragment for index #");
                            sb5.append(nVar.f330b[i5]);
                            m422a((RuntimeException) new IllegalStateException(sb5.toString()));
                        }
                        fVar3.f206u = true;
                        if (f260a) {
                            StringBuilder sb6 = new StringBuilder();
                            sb6.append("restoreAllState: added #");
                            sb6.append(i5);
                            sb6.append(": ");
                            sb6.append(fVar3);
                            Log.v("FragmentManager", sb6.toString());
                        }
                        if (!this.f271e.contains(fVar3)) {
                            synchronized (this.f271e) {
                                this.f271e.add(fVar3);
                            }
                            i5++;
                        } else {
                            throw new IllegalStateException("Already added!");
                        }
                    }
                }
                if (nVar.f331c != null) {
                    this.f273g = new ArrayList<>(nVar.f331c.length);
                    for (int i6 = 0; i6 < nVar.f331c.length; i6++) {
                        C0061b a4 = nVar.f331c[i6].mo154a(this);
                        if (f260a) {
                            StringBuilder sb7 = new StringBuilder();
                            sb7.append("restoreAllState: back stack #");
                            sb7.append(i6);
                            sb7.append(" (index ");
                            sb7.append(a4.f124m);
                            sb7.append("): ");
                            sb7.append(a4);
                            Log.v("FragmentManager", sb7.toString());
                            PrintWriter printWriter = new PrintWriter(new C0157e("FragmentManager"));
                            a4.mo142a("  ", printWriter, false);
                            printWriter.close();
                        }
                        this.f273g.add(a4);
                        if (a4.f124m >= 0) {
                            mo375a(a4.f124m, a4);
                        }
                    }
                } else {
                    this.f273g = null;
                }
                if (nVar.f332d >= 0) {
                    this.f282p = (C0068f) this.f272f.get(nVar.f332d);
                }
                this.f270d = nVar.f333e;
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo380a(C0061b bVar, boolean z, boolean z2, boolean z3) {
        if (z) {
            bVar.mo147b(z3);
        } else {
            bVar.mo150d();
        }
        ArrayList arrayList = new ArrayList(1);
        ArrayList arrayList2 = new ArrayList(1);
        arrayList.add(bVar);
        arrayList2.add(Boolean.valueOf(z));
        if (z2) {
            C0108q.m558a(this, arrayList, arrayList2, 0, 1, true);
        }
        if (z3) {
            mo376a(this.f278l, true);
        }
        SparseArray<C0068f> sparseArray = this.f272f;
        if (sparseArray != null) {
            int size = sparseArray.size();
            for (int i = 0; i < size; i++) {
                C0068f fVar = (C0068f) this.f272f.valueAt(i);
                if (fVar != null && fVar.f182S != null && fVar.f187X && bVar.mo148b(fVar.f172I)) {
                    if (fVar.f189Z > 0.0f) {
                        fVar.f182S.setAlpha(fVar.f189Z);
                    }
                    if (z3) {
                        fVar.f189Z = 0.0f;
                    } else {
                        fVar.f189Z = -1.0f;
                        fVar.f187X = false;
                    }
                }
            }
        }
    }

    /* renamed from: a */
    public void mo381a(C0068f fVar) {
        if (fVar.f184U) {
            if (this.f269c) {
                this.f288w = true;
                return;
            }
            fVar.f184U = false;
            mo382a(fVar, this.f278l, 0, 0, false);
        }
    }

    /* JADX WARNING: type inference failed for: r8v0 */
    /* JADX WARNING: type inference failed for: r8v1, types: [int] */
    /* JADX WARNING: type inference failed for: r11v1 */
    /* JADX WARNING: type inference failed for: r8v2 */
    /* JADX WARNING: type inference failed for: r11v2 */
    /* JADX WARNING: type inference failed for: r11v3 */
    /* JADX WARNING: type inference failed for: r11v4 */
    /* JADX WARNING: type inference failed for: r8v3, types: [boolean] */
    /* JADX WARNING: type inference failed for: r8v4 */
    /* JADX WARNING: type inference failed for: r11v5 */
    /* JADX WARNING: type inference failed for: r11v6 */
    /* JADX WARNING: type inference failed for: r8v5 */
    /* JADX WARNING: type inference failed for: r11v9 */
    /* JADX INFO: used method not loaded: android.support.v4.app.j.a(android.support.v4.app.f):null, types can be incorrect */
    /* access modifiers changed from: 0000 */
    /* JADX WARNING: Code restructure failed: missing block: B:100:?, code lost:
        r1 = r15.mo254m().getResourceName(r7.f172I);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:101:0x020b, code lost:
        r1 = "unknown";
     */
    /* JADX WARNING: Code restructure failed: missing block: B:104:0x023d, code lost:
        r0 = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:144:0x0318, code lost:
        if (r11 >= 3) goto L_0x033a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:146:0x031c, code lost:
        if (f260a == false) goto L_0x0334;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:147:0x031e, code lost:
        r1 = new java.lang.StringBuilder();
        r1.append("movefrom STARTED: ");
        r1.append(r15);
        android.util.Log.v("FragmentManager", r1.toString());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:148:0x0334, code lost:
        r15.mo189M();
        mo414e(r15, false);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:149:0x033a, code lost:
        if (r11 >= 2) goto L_0x03c1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:151:0x033e, code lost:
        if (f260a == false) goto L_0x0356;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:152:0x0340, code lost:
        r1 = new java.lang.StringBuilder();
        r1.append("movefrom ACTIVITY_CREATED: ");
        r1.append(r15);
        android.util.Log.v("FragmentManager", r1.toString());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:154:0x0358, code lost:
        if (r7.f182S == null) goto L_0x0369;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:156:0x0360, code lost:
        if (r6.f279m.mo315a(r15) == false) goto L_0x0369;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:158:0x0364, code lost:
        if (r7.f198m != null) goto L_0x0369;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:159:0x0366, code lost:
        mo433m(r15);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:160:0x0369, code lost:
        r15.mo190N();
        mo417f(r15, false);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:161:0x0371, code lost:
        if (r7.f182S == null) goto L_0x03b2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:163:0x0375, code lost:
        if (r7.f181R == null) goto L_0x03b2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:164:0x0377, code lost:
        r7.f181R.endViewTransition(r7.f182S);
        r7.f182S.clearAnimation();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:165:0x0386, code lost:
        if (r6.f278l <= 0) goto L_0x03a3;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:167:0x038a, code lost:
        if (r6.f286u != false) goto L_0x03a3;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:169:0x0392, code lost:
        if (r7.f182S.getVisibility() != 0) goto L_0x03a3;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:171:0x0398, code lost:
        if (r7.f189Z < 0.0f) goto L_0x03a3;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:172:0x039a, code lost:
        r0 = mo374a(r15, r17, false, r18);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:173:0x03a3, code lost:
        r0 = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:174:0x03a4, code lost:
        r7.f189Z = 0.0f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:175:0x03a6, code lost:
        if (r0 == null) goto L_0x03ab;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:176:0x03a8, code lost:
        m419a(r15, r0, r11);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:177:0x03ab, code lost:
        r7.f181R.removeView(r7.f182S);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:178:0x03b2, code lost:
        r7.f181R = null;
        r7.f182S = null;
        r7.f194ae = null;
        r7.f195af.mo45a(null);
        r7.f183T = null;
        r7.f209x = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:179:0x03c1, code lost:
        if (r11 >= 1) goto L_0x0437;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:181:0x03c5, code lost:
        if (r6.f286u == false) goto L_0x03e8;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:183:0x03cb, code lost:
        if (r15.mo198V() == null) goto L_0x03d8;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:184:0x03cd, code lost:
        r0 = r15.mo198V();
        r15.mo220a((android.view.View) null);
        r0.clearAnimation();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:186:0x03dc, code lost:
        if (r15.mo199W() == null) goto L_0x03e8;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:187:0x03de, code lost:
        r0 = r15.mo199W();
        r15.mo211a((android.animation.Animator) null);
        r0.cancel();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:189:0x03ec, code lost:
        if (r15.mo198V() != null) goto L_0x0433;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:191:0x03f2, code lost:
        if (r15.mo199W() == null) goto L_0x03f5;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:193:0x03f7, code lost:
        if (f260a == false) goto L_0x040f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:194:0x03f9, code lost:
        r1 = new java.lang.StringBuilder();
        r1.append("movefrom CREATED: ");
        r1.append(r15);
        android.util.Log.v("FragmentManager", r1.toString());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:196:0x0411, code lost:
        if (r7.f177N != false) goto L_0x041a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:197:0x0413, code lost:
        r15.mo191O();
        mo419g(r15, false);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:198:0x041a, code lost:
        r7.f196k = 0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:199:0x041c, code lost:
        r15.mo192P();
        mo423h(r15, false);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:200:0x0422, code lost:
        if (r19 != false) goto L_0x0437;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:202:0x0426, code lost:
        if (r7.f177N != false) goto L_0x042c;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:203:0x0428, code lost:
        mo418g(r15);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:204:0x042c, code lost:
        r7.f166C = null;
        r7.f170G = null;
        r7.f165B = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:205:0x0433, code lost:
        r15.mo225b(r11);
        r8 = r8;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:83:0x01a6, code lost:
        mo406c(r15);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:84:0x01a9, code lost:
        if (r11 <= 1) goto L_0x02a0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:86:0x01ad, code lost:
        if (f260a == false) goto L_0x01c5;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:87:0x01af, code lost:
        r1 = new java.lang.StringBuilder();
        r1.append("moveto ACTIVITY_CREATED: ");
        r1.append(r15);
        android.util.Log.v("FragmentManager", r1.toString());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:89:0x01c7, code lost:
        if (r7.f208w != false) goto L_0x028b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:91:0x01cb, code lost:
        if (r7.f172I == 0) goto L_0x023d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:93:0x01d0, code lost:
        if (r7.f172I != -1) goto L_0x01f0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:94:0x01d2, code lost:
        r1 = new java.lang.StringBuilder();
        r1.append("Cannot create fragment ");
        r1.append(r15);
        r1.append(" for a container view with no id");
        m422a((java.lang.RuntimeException) new java.lang.IllegalArgumentException(r1.toString()));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:95:0x01f0, code lost:
        r0 = (android.view.ViewGroup) r6.f280n.mo276a(r7.f172I);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:96:0x01fa, code lost:
        if (r0 != null) goto L_0x023e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:98:0x01fe, code lost:
        if (r7.f210y != false) goto L_0x023e;
     */
    /* JADX WARNING: Multi-variable type inference failed. Error: jadx.core.utils.exceptions.JadxRuntimeException: No candidate types for var: r11v5
      assigns: []
      uses: []
      mth insns count: 436
    	at jadx.core.dex.visitors.typeinference.TypeSearch.fillTypeCandidates(TypeSearch.java:237)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1540)
    	at jadx.core.dex.visitors.typeinference.TypeSearch.run(TypeSearch.java:53)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runMultiVariableSearch(TypeInferenceVisitor.java:99)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:92)
    	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:27)
    	at jadx.core.dex.visitors.DepthTraversal.lambda$visit$1(DepthTraversal.java:14)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1540)
    	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
    	at jadx.core.ProcessClass.process(ProcessClass.java:30)
    	at jadx.core.ProcessClass.lambda$processDependencies$0(ProcessClass.java:49)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1540)
    	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:49)
    	at jadx.core.ProcessClass.process(ProcessClass.java:35)
    	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:311)
    	at jadx.api.JavaClass.decompile(JavaClass.java:62)
    	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:217)
     */
    /* JADX WARNING: Removed duplicated region for block: B:209:0x043c  */
    /* JADX WARNING: Unknown variable types count: 3 */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo382a(android.support.p005v4.app.C0068f r15, int r16, int r17, int r18, boolean r19) {
        /*
            r14 = this;
            r6 = r14
            r7 = r15
            boolean r0 = r7.f206u
            r8 = 1
            if (r0 == 0) goto L_0x000f
            boolean r0 = r7.f175L
            if (r0 == 0) goto L_0x000c
            goto L_0x000f
        L_0x000c:
            r0 = r16
            goto L_0x0014
        L_0x000f:
            r0 = r16
            if (r0 <= r8) goto L_0x0014
            r0 = r8
        L_0x0014:
            boolean r1 = r7.f207v
            if (r1 == 0) goto L_0x002a
            int r1 = r7.f196k
            if (r0 <= r1) goto L_0x002a
            int r0 = r7.f196k
            if (r0 != 0) goto L_0x0028
            boolean r0 = r15.mo244h()
            if (r0 == 0) goto L_0x0028
            r0 = r8
            goto L_0x002a
        L_0x0028:
            int r0 = r7.f196k
        L_0x002a:
            boolean r1 = r7.f184U
            r9 = 3
            r10 = 2
            if (r1 == 0) goto L_0x0038
            int r1 = r7.f196k
            if (r1 >= r9) goto L_0x0038
            if (r0 <= r10) goto L_0x0038
            r11 = r10
            goto L_0x0039
        L_0x0038:
            r11 = r0
        L_0x0039:
            int r0 = r7.f196k
            r12 = 0
            r13 = 0
            if (r0 > r11) goto L_0x02ea
            boolean r0 = r7.f208w
            if (r0 == 0) goto L_0x0048
            boolean r0 = r7.f209x
            if (r0 != 0) goto L_0x0048
            return
        L_0x0048:
            android.view.View r0 = r15.mo198V()
            if (r0 != 0) goto L_0x0054
            android.animation.Animator r0 = r15.mo199W()
            if (r0 == 0) goto L_0x0066
        L_0x0054:
            r15.mo220a(r12)
            r15.mo211a(r12)
            int r2 = r15.mo200X()
            r3 = 0
            r4 = 0
            r5 = 1
            r0 = r14
            r1 = r15
            r0.mo382a(r1, r2, r3, r4, r5)
        L_0x0066:
            int r0 = r7.f196k
            switch(r0) {
                case 0: goto L_0x006d;
                case 1: goto L_0x01a6;
                case 2: goto L_0x02a0;
                case 3: goto L_0x02c2;
                default: goto L_0x006b;
            }
        L_0x006b:
            goto L_0x0437
        L_0x006d:
            if (r11 <= 0) goto L_0x01a6
            boolean r0 = f260a
            if (r0 == 0) goto L_0x0089
            java.lang.String r0 = "FragmentManager"
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "moveto CREATED: "
            r1.append(r2)
            r1.append(r15)
            java.lang.String r1 = r1.toString()
            android.util.Log.v(r0, r1)
        L_0x0089:
            android.os.Bundle r0 = r7.f197l
            if (r0 == 0) goto L_0x00e0
            android.os.Bundle r0 = r7.f197l
            android.support.v4.app.j r1 = r6.f279m
            android.content.Context r1 = r1.mo347g()
            java.lang.ClassLoader r1 = r1.getClassLoader()
            r0.setClassLoader(r1)
            android.os.Bundle r0 = r7.f197l
            java.lang.String r1 = "android:view_state"
            android.util.SparseArray r0 = r0.getSparseParcelableArray(r1)
            r7.f198m = r0
            android.os.Bundle r0 = r7.f197l
            java.lang.String r1 = "android:target_state"
            android.support.v4.app.f r0 = r14.mo372a(r0, r1)
            r7.f203r = r0
            android.support.v4.app.f r0 = r7.f203r
            if (r0 == 0) goto L_0x00be
            android.os.Bundle r0 = r7.f197l
            java.lang.String r1 = "android:target_req_state"
            int r0 = r0.getInt(r1, r13)
            r7.f205t = r0
        L_0x00be:
            java.lang.Boolean r0 = r7.f199n
            if (r0 == 0) goto L_0x00cd
            java.lang.Boolean r0 = r7.f199n
            boolean r0 = r0.booleanValue()
            r7.f185V = r0
            r7.f199n = r12
            goto L_0x00d7
        L_0x00cd:
            android.os.Bundle r0 = r7.f197l
            java.lang.String r1 = "android:user_visible_hint"
            boolean r0 = r0.getBoolean(r1, r8)
            r7.f185V = r0
        L_0x00d7:
            boolean r0 = r7.f185V
            if (r0 != 0) goto L_0x00e0
            r7.f184U = r8
            if (r11 <= r10) goto L_0x00e0
            r11 = r10
        L_0x00e0:
            android.support.v4.app.j r0 = r6.f279m
            r7.f166C = r0
            android.support.v4.app.f r1 = r6.f281o
            r7.f170G = r1
            if (r1 == 0) goto L_0x00ed
            android.support.v4.app.l r0 = r1.f167D
            goto L_0x00f1
        L_0x00ed:
            android.support.v4.app.l r0 = r0.mo349i()
        L_0x00f1:
            r7.f165B = r0
            android.support.v4.app.f r0 = r7.f203r
            if (r0 == 0) goto L_0x013c
            android.util.SparseArray<android.support.v4.app.f> r0 = r6.f272f
            android.support.v4.app.f r1 = r7.f203r
            int r1 = r1.f200o
            java.lang.Object r0 = r0.get(r1)
            android.support.v4.app.f r1 = r7.f203r
            if (r0 != r1) goto L_0x0116
            android.support.v4.app.f r0 = r7.f203r
            int r0 = r0.f196k
            if (r0 >= r8) goto L_0x013c
            android.support.v4.app.f r1 = r7.f203r
            r2 = 1
            r3 = 0
            r4 = 0
            r5 = 1
            r0 = r14
            r0.mo382a(r1, r2, r3, r4, r5)
            goto L_0x013c
        L_0x0116:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "Fragment "
            r1.append(r2)
            r1.append(r15)
            java.lang.String r2 = " declared target fragment "
            r1.append(r2)
            android.support.v4.app.f r2 = r7.f203r
            r1.append(r2)
            java.lang.String r2 = " that does not belong to this FragmentManager!"
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        L_0x013c:
            android.support.v4.app.j r0 = r6.f279m
            android.content.Context r0 = r0.mo347g()
            r14.mo383a(r15, r0, r13)
            r7.f180Q = r13
            android.support.v4.app.j r0 = r6.f279m
            android.content.Context r0 = r0.mo347g()
            r15.mo162a(r0)
            boolean r0 = r7.f180Q
            if (r0 == 0) goto L_0x018a
            android.support.v4.app.f r0 = r7.f170G
            if (r0 != 0) goto L_0x015e
            android.support.v4.app.j r0 = r6.f279m
            r0.mo317b(r15)
            goto L_0x0163
        L_0x015e:
            android.support.v4.app.f r0 = r7.f170G
            r0.mo217a(r15)
        L_0x0163:
            android.support.v4.app.j r0 = r6.f279m
            android.content.Context r0 = r0.mo347g()
            r14.mo399b(r15, r0, r13)
            boolean r0 = r7.f191ab
            if (r0 != 0) goto L_0x0180
            android.os.Bundle r0 = r7.f197l
            r14.mo384a(r15, r0, r13)
            android.os.Bundle r0 = r7.f197l
            r15.mo253l(r0)
            android.os.Bundle r0 = r7.f197l
            r14.mo400b(r15, r0, r13)
            goto L_0x0187
        L_0x0180:
            android.os.Bundle r0 = r7.f197l
            r15.mo249j(r0)
            r7.f196k = r8
        L_0x0187:
            r7.f177N = r13
            goto L_0x01a6
        L_0x018a:
            android.support.v4.app.z r0 = new android.support.v4.app.z
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "Fragment "
            r1.append(r2)
            r1.append(r15)
            java.lang.String r2 = " did not call through to super.onAttach()"
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        L_0x01a6:
            r14.mo406c(r15)
            if (r11 <= r8) goto L_0x02a0
            boolean r0 = f260a
            if (r0 == 0) goto L_0x01c5
            java.lang.String r0 = "FragmentManager"
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "moveto ACTIVITY_CREATED: "
            r1.append(r2)
            r1.append(r15)
            java.lang.String r1 = r1.toString()
            android.util.Log.v(r0, r1)
        L_0x01c5:
            boolean r0 = r7.f208w
            if (r0 != 0) goto L_0x028b
            int r0 = r7.f172I
            if (r0 == 0) goto L_0x023d
            int r0 = r7.f172I
            r1 = -1
            if (r0 != r1) goto L_0x01f0
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "Cannot create fragment "
            r1.append(r2)
            r1.append(r15)
            java.lang.String r2 = " for a container view with no id"
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            r14.m422a(r0)
        L_0x01f0:
            android.support.v4.app.h r0 = r6.f280n
            int r1 = r7.f172I
            android.view.View r0 = r0.mo276a(r1)
            android.view.ViewGroup r0 = (android.view.ViewGroup) r0
            if (r0 != 0) goto L_0x023e
            boolean r1 = r7.f210y
            if (r1 != 0) goto L_0x023e
            android.content.res.Resources r1 = r15.mo254m()     // Catch:{ NotFoundException -> 0x020b }
            int r2 = r7.f172I     // Catch:{ NotFoundException -> 0x020b }
            java.lang.String r1 = r1.getResourceName(r2)     // Catch:{ NotFoundException -> 0x020b }
            goto L_0x020d
        L_0x020b:
            java.lang.String r1 = "unknown"
        L_0x020d:
            java.lang.IllegalArgumentException r2 = new java.lang.IllegalArgumentException
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            java.lang.String r4 = "No view found for id 0x"
            r3.append(r4)
            int r4 = r7.f172I
            java.lang.String r4 = java.lang.Integer.toHexString(r4)
            r3.append(r4)
            java.lang.String r4 = " ("
            r3.append(r4)
            r3.append(r1)
            java.lang.String r1 = ") for fragment "
            r3.append(r1)
            r3.append(r15)
            java.lang.String r1 = r3.toString()
            r2.<init>(r1)
            r14.m422a(r2)
            goto L_0x023e
        L_0x023d:
            r0 = r12
        L_0x023e:
            r7.f181R = r0
            android.os.Bundle r1 = r7.f197l
            android.view.LayoutInflater r1 = r15.mo243h(r1)
            android.os.Bundle r2 = r7.f197l
            r15.mo226b(r1, r0, r2)
            android.view.View r1 = r7.f182S
            if (r1 == 0) goto L_0x0289
            android.view.View r1 = r7.f182S
            r7.f183T = r1
            android.view.View r1 = r7.f182S
            r1.setSaveFromParentEnabled(r13)
            if (r0 == 0) goto L_0x025f
            android.view.View r1 = r7.f182S
            r0.addView(r1)
        L_0x025f:
            boolean r0 = r7.f174K
            if (r0 == 0) goto L_0x026a
            android.view.View r0 = r7.f182S
            r1 = 8
            r0.setVisibility(r1)
        L_0x026a:
            android.view.View r0 = r7.f182S
            android.os.Bundle r1 = r7.f197l
            r15.mo221a(r0, r1)
            android.view.View r0 = r7.f182S
            android.os.Bundle r1 = r7.f197l
            r14.mo385a(r15, r0, r1, r13)
            android.view.View r0 = r7.f182S
            int r0 = r0.getVisibility()
            if (r0 != 0) goto L_0x0285
            android.view.ViewGroup r0 = r7.f181R
            if (r0 == 0) goto L_0x0285
            goto L_0x0286
        L_0x0285:
            r8 = r13
        L_0x0286:
            r7.f187X = r8
            goto L_0x028b
        L_0x0289:
            r7.f183T = r12
        L_0x028b:
            android.os.Bundle r0 = r7.f197l
            r15.mo255m(r0)
            android.os.Bundle r0 = r7.f197l
            r14.mo407c(r15, r0, r13)
            android.view.View r0 = r7.f182S
            if (r0 == 0) goto L_0x029e
            android.os.Bundle r0 = r7.f197l
            r15.mo239f(r0)
        L_0x029e:
            r7.f197l = r12
        L_0x02a0:
            if (r11 <= r10) goto L_0x02c2
            boolean r0 = f260a
            if (r0 == 0) goto L_0x02bc
            java.lang.String r0 = "FragmentManager"
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "moveto STARTED: "
            r1.append(r2)
            r1.append(r15)
            java.lang.String r1 = r1.toString()
            android.util.Log.v(r0, r1)
        L_0x02bc:
            r15.mo184H()
            r14.mo401b(r15, r13)
        L_0x02c2:
            if (r11 <= r9) goto L_0x0437
            boolean r0 = f260a
            if (r0 == 0) goto L_0x02de
            java.lang.String r0 = "FragmentManager"
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "moveto RESUMED: "
            r1.append(r2)
            r1.append(r15)
            java.lang.String r1 = r1.toString()
            android.util.Log.v(r0, r1)
        L_0x02de:
            r15.mo185I()
            r14.mo408c(r15, r13)
            r7.f197l = r12
            r7.f198m = r12
            goto L_0x0437
        L_0x02ea:
            int r0 = r7.f196k
            if (r0 <= r11) goto L_0x0437
            int r0 = r7.f196k
            switch(r0) {
                case 1: goto L_0x03c1;
                case 2: goto L_0x033a;
                case 3: goto L_0x0318;
                case 4: goto L_0x02f5;
                default: goto L_0x02f3;
            }
        L_0x02f3:
            goto L_0x0437
        L_0x02f5:
            r0 = 4
            if (r11 >= r0) goto L_0x0318
            boolean r0 = f260a
            if (r0 == 0) goto L_0x0312
            java.lang.String r0 = "FragmentManager"
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "movefrom RESUMED: "
            r1.append(r2)
            r1.append(r15)
            java.lang.String r1 = r1.toString()
            android.util.Log.v(r0, r1)
        L_0x0312:
            r15.mo188L()
            r14.mo411d(r15, r13)
        L_0x0318:
            if (r11 >= r9) goto L_0x033a
            boolean r0 = f260a
            if (r0 == 0) goto L_0x0334
            java.lang.String r0 = "FragmentManager"
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "movefrom STARTED: "
            r1.append(r2)
            r1.append(r15)
            java.lang.String r1 = r1.toString()
            android.util.Log.v(r0, r1)
        L_0x0334:
            r15.mo189M()
            r14.mo414e(r15, r13)
        L_0x033a:
            if (r11 >= r10) goto L_0x03c1
            boolean r0 = f260a
            if (r0 == 0) goto L_0x0356
            java.lang.String r0 = "FragmentManager"
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "movefrom ACTIVITY_CREATED: "
            r1.append(r2)
            r1.append(r15)
            java.lang.String r1 = r1.toString()
            android.util.Log.v(r0, r1)
        L_0x0356:
            android.view.View r0 = r7.f182S
            if (r0 == 0) goto L_0x0369
            android.support.v4.app.j r0 = r6.f279m
            boolean r0 = r0.mo315a(r15)
            if (r0 == 0) goto L_0x0369
            android.util.SparseArray<android.os.Parcelable> r0 = r7.f198m
            if (r0 != 0) goto L_0x0369
            r14.mo433m(r15)
        L_0x0369:
            r15.mo190N()
            r14.mo417f(r15, r13)
            android.view.View r0 = r7.f182S
            if (r0 == 0) goto L_0x03b2
            android.view.ViewGroup r0 = r7.f181R
            if (r0 == 0) goto L_0x03b2
            android.view.ViewGroup r0 = r7.f181R
            android.view.View r1 = r7.f182S
            r0.endViewTransition(r1)
            android.view.View r0 = r7.f182S
            r0.clearAnimation()
            int r0 = r6.f278l
            r1 = 0
            if (r0 <= 0) goto L_0x03a3
            boolean r0 = r6.f286u
            if (r0 != 0) goto L_0x03a3
            android.view.View r0 = r7.f182S
            int r0 = r0.getVisibility()
            if (r0 != 0) goto L_0x03a3
            float r0 = r7.f189Z
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L_0x03a3
            r0 = r17
            r2 = r18
            android.support.v4.app.l$c r0 = r14.mo374a(r15, r0, r13, r2)
            goto L_0x03a4
        L_0x03a3:
            r0 = r12
        L_0x03a4:
            r7.f189Z = r1
            if (r0 == 0) goto L_0x03ab
            r14.m419a(r15, r0, r11)
        L_0x03ab:
            android.view.ViewGroup r0 = r7.f181R
            android.view.View r1 = r7.f182S
            r0.removeView(r1)
        L_0x03b2:
            r7.f181R = r12
            r7.f182S = r12
            r7.f194ae = r12
            android.arch.lifecycle.j<android.arch.lifecycle.e> r0 = r7.f195af
            r0.mo45a(r12)
            r7.f183T = r12
            r7.f209x = r13
        L_0x03c1:
            if (r11 >= r8) goto L_0x0437
            boolean r0 = r6.f286u
            if (r0 == 0) goto L_0x03e8
            android.view.View r0 = r15.mo198V()
            if (r0 == 0) goto L_0x03d8
            android.view.View r0 = r15.mo198V()
            r15.mo220a(r12)
            r0.clearAnimation()
            goto L_0x03e8
        L_0x03d8:
            android.animation.Animator r0 = r15.mo199W()
            if (r0 == 0) goto L_0x03e8
            android.animation.Animator r0 = r15.mo199W()
            r15.mo211a(r12)
            r0.cancel()
        L_0x03e8:
            android.view.View r0 = r15.mo198V()
            if (r0 != 0) goto L_0x0433
            android.animation.Animator r0 = r15.mo199W()
            if (r0 == 0) goto L_0x03f5
            goto L_0x0433
        L_0x03f5:
            boolean r0 = f260a
            if (r0 == 0) goto L_0x040f
            java.lang.String r0 = "FragmentManager"
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "movefrom CREATED: "
            r1.append(r2)
            r1.append(r15)
            java.lang.String r1 = r1.toString()
            android.util.Log.v(r0, r1)
        L_0x040f:
            boolean r0 = r7.f177N
            if (r0 != 0) goto L_0x041a
            r15.mo191O()
            r14.mo419g(r15, r13)
            goto L_0x041c
        L_0x041a:
            r7.f196k = r13
        L_0x041c:
            r15.mo192P()
            r14.mo423h(r15, r13)
            if (r19 != 0) goto L_0x0437
            boolean r0 = r7.f177N
            if (r0 != 0) goto L_0x042c
            r14.mo418g(r15)
            goto L_0x0437
        L_0x042c:
            r7.f166C = r12
            r7.f170G = r12
            r7.f165B = r12
            goto L_0x0437
        L_0x0433:
            r15.mo225b(r11)
            goto L_0x0438
        L_0x0437:
            r8 = r11
        L_0x0438:
            int r0 = r7.f196k
            if (r0 == r8) goto L_0x046b
            java.lang.String r0 = "FragmentManager"
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "moveToState: Fragment state for "
            r1.append(r2)
            r1.append(r15)
            java.lang.String r2 = " not updated inline; "
            r1.append(r2)
            java.lang.String r2 = "expected state "
            r1.append(r2)
            r1.append(r8)
            java.lang.String r2 = " found "
            r1.append(r2)
            int r2 = r7.f196k
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            android.util.Log.w(r0, r1)
            r7.f196k = r8
        L_0x046b:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p005v4.app.C0085l.mo382a(android.support.v4.app.f, int, int, int, boolean):void");
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo383a(C0068f fVar, Context context, boolean z) {
        C0068f fVar2 = this.f281o;
        if (fVar2 != null) {
            C0082k n = fVar2.mo256n();
            if (n instanceof C0085l) {
                ((C0085l) n).mo383a(fVar, context, true);
            }
        }
        Iterator it = this.f267J.iterator();
        while (it.hasNext()) {
            C0097f fVar3 = (C0097f) it.next();
            if (!z || fVar3.f317b) {
                fVar3.f316a.mo357a((C0082k) this, fVar, context);
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo384a(C0068f fVar, Bundle bundle, boolean z) {
        C0068f fVar2 = this.f281o;
        if (fVar2 != null) {
            C0082k n = fVar2.mo256n();
            if (n instanceof C0085l) {
                ((C0085l) n).mo384a(fVar, bundle, true);
            }
        }
        Iterator it = this.f267J.iterator();
        while (it.hasNext()) {
            C0097f fVar3 = (C0097f) it.next();
            if (!z || fVar3.f317b) {
                fVar3.f316a.mo358a((C0082k) this, fVar, bundle);
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo385a(C0068f fVar, View view, Bundle bundle, boolean z) {
        C0068f fVar2 = this.f281o;
        if (fVar2 != null) {
            C0082k n = fVar2.mo256n();
            if (n instanceof C0085l) {
                ((C0085l) n).mo385a(fVar, view, bundle, true);
            }
        }
        Iterator it = this.f267J.iterator();
        while (it.hasNext()) {
            C0097f fVar3 = (C0097f) it.next();
            if (!z || fVar3.f317b) {
                fVar3.f316a.mo359a(this, fVar, view, bundle);
            }
        }
    }

    /* renamed from: a */
    public void mo386a(C0068f fVar, boolean z) {
        if (f260a) {
            StringBuilder sb = new StringBuilder();
            sb.append("add: ");
            sb.append(fVar);
            Log.v("FragmentManager", sb.toString());
        }
        mo416f(fVar);
        if (fVar.f175L) {
            return;
        }
        if (!this.f271e.contains(fVar)) {
            synchronized (this.f271e) {
                this.f271e.add(fVar);
            }
            fVar.f206u = true;
            fVar.f207v = false;
            if (fVar.f182S == null) {
                fVar.f188Y = false;
            }
            if (fVar.f178O && fVar.f179P) {
                this.f283r = true;
            }
            if (z) {
                mo398b(fVar);
                return;
            }
            return;
        }
        StringBuilder sb2 = new StringBuilder();
        sb2.append("Fragment already added: ");
        sb2.append(fVar);
        throw new IllegalStateException(sb2.toString());
    }

    /* renamed from: a */
    public void mo387a(C0081j jVar, C0079h hVar, C0068f fVar) {
        if (this.f279m == null) {
            this.f279m = jVar;
            this.f280n = hVar;
            this.f281o = fVar;
            return;
        }
        throw new IllegalStateException("Already attached");
    }

    /* renamed from: a */
    public void mo388a(C0099h hVar, boolean z) {
        if (!z) {
            m439y();
        }
        synchronized (this) {
            if (!this.f286u) {
                if (this.f279m != null) {
                    if (this.f268b == null) {
                        this.f268b = new ArrayList<>();
                    }
                    this.f268b.add(hVar);
                    mo415f();
                    return;
                }
            }
            if (!z) {
                throw new IllegalStateException("Activity has been destroyed");
            }
        }
    }

    /* renamed from: a */
    public void mo352a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        StringBuilder sb = new StringBuilder();
        sb.append(str);
        sb.append("    ");
        String sb2 = sb.toString();
        SparseArray<C0068f> sparseArray = this.f272f;
        if (sparseArray != null) {
            int size = sparseArray.size();
            if (size > 0) {
                printWriter.print(str);
                printWriter.print("Active Fragments in ");
                printWriter.print(Integer.toHexString(System.identityHashCode(this)));
                printWriter.println(":");
                for (int i = 0; i < size; i++) {
                    C0068f fVar = (C0068f) this.f272f.valueAt(i);
                    printWriter.print(str);
                    printWriter.print("  #");
                    printWriter.print(i);
                    printWriter.print(": ");
                    printWriter.println(fVar);
                    if (fVar != null) {
                        fVar.mo222a(sb2, fileDescriptor, printWriter, strArr);
                    }
                }
            }
        }
        int size2 = this.f271e.size();
        if (size2 > 0) {
            printWriter.print(str);
            printWriter.println("Added Fragments:");
            for (int i2 = 0; i2 < size2; i2++) {
                C0068f fVar2 = (C0068f) this.f271e.get(i2);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i2);
                printWriter.print(": ");
                printWriter.println(fVar2.toString());
            }
        }
        ArrayList<C0068f> arrayList = this.f274h;
        if (arrayList != null) {
            int size3 = arrayList.size();
            if (size3 > 0) {
                printWriter.print(str);
                printWriter.println("Fragments Created Menus:");
                for (int i3 = 0; i3 < size3; i3++) {
                    C0068f fVar3 = (C0068f) this.f274h.get(i3);
                    printWriter.print(str);
                    printWriter.print("  #");
                    printWriter.print(i3);
                    printWriter.print(": ");
                    printWriter.println(fVar3.toString());
                }
            }
        }
        ArrayList<C0061b> arrayList2 = this.f273g;
        if (arrayList2 != null) {
            int size4 = arrayList2.size();
            if (size4 > 0) {
                printWriter.print(str);
                printWriter.println("Back Stack:");
                for (int i4 = 0; i4 < size4; i4++) {
                    C0061b bVar = (C0061b) this.f273g.get(i4);
                    printWriter.print(str);
                    printWriter.print("  #");
                    printWriter.print(i4);
                    printWriter.print(": ");
                    printWriter.println(bVar.toString());
                    bVar.mo141a(sb2, fileDescriptor, printWriter, strArr);
                }
            }
        }
        synchronized (this) {
            if (this.f275i != null) {
                int size5 = this.f275i.size();
                if (size5 > 0) {
                    printWriter.print(str);
                    printWriter.println("Back Stack Indices:");
                    for (int i5 = 0; i5 < size5; i5++) {
                        C0061b bVar2 = (C0061b) this.f275i.get(i5);
                        printWriter.print(str);
                        printWriter.print("  #");
                        printWriter.print(i5);
                        printWriter.print(": ");
                        printWriter.println(bVar2);
                    }
                }
            }
            if (this.f276j != null && this.f276j.size() > 0) {
                printWriter.print(str);
                printWriter.print("mAvailBackStackIndices: ");
                printWriter.println(Arrays.toString(this.f276j.toArray()));
            }
        }
        ArrayList<C0099h> arrayList3 = this.f268b;
        if (arrayList3 != null) {
            int size6 = arrayList3.size();
            if (size6 > 0) {
                printWriter.print(str);
                printWriter.println("Pending Actions:");
                for (int i6 = 0; i6 < size6; i6++) {
                    C0099h hVar = (C0099h) this.f268b.get(i6);
                    printWriter.print(str);
                    printWriter.print("  #");
                    printWriter.print(i6);
                    printWriter.print(": ");
                    printWriter.println(hVar);
                }
            }
        }
        printWriter.print(str);
        printWriter.println("FragmentManager misc state:");
        printWriter.print(str);
        printWriter.print("  mHost=");
        printWriter.println(this.f279m);
        printWriter.print(str);
        printWriter.print("  mContainer=");
        printWriter.println(this.f280n);
        if (this.f281o != null) {
            printWriter.print(str);
            printWriter.print("  mParent=");
            printWriter.println(this.f281o);
        }
        printWriter.print(str);
        printWriter.print("  mCurState=");
        printWriter.print(this.f278l);
        printWriter.print(" mStateSaved=");
        printWriter.print(this.f284s);
        printWriter.print(" mStopped=");
        printWriter.print(this.f285t);
        printWriter.print(" mDestroyed=");
        printWriter.println(this.f286u);
        if (this.f283r) {
            printWriter.print(str);
            printWriter.print("  mNeedMenuInvalidate=");
            printWriter.println(this.f283r);
        }
        if (this.f287v != null) {
            printWriter.print(str);
            printWriter.print("  mNoTransactionsBecause=");
            printWriter.println(this.f287v);
        }
    }

    /* renamed from: a */
    public void mo389a(boolean z) {
        for (int size = this.f271e.size() - 1; size >= 0; size--) {
            C0068f fVar = (C0068f) this.f271e.get(size);
            if (fVar != null) {
                fVar.mo237e(z);
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public boolean mo390a(int i) {
        return this.f278l >= i;
    }

    /* renamed from: a */
    public boolean mo391a(Menu menu) {
        if (this.f278l < 1) {
            return false;
        }
        boolean z = false;
        for (int i = 0; i < this.f271e.size(); i++) {
            C0068f fVar = (C0068f) this.f271e.get(i);
            if (fVar != null && fVar.mo232c(menu)) {
                z = true;
            }
        }
        return z;
    }

    /* renamed from: a */
    public boolean mo392a(Menu menu, MenuInflater menuInflater) {
        if (this.f278l < 1) {
            return false;
        }
        ArrayList<C0068f> arrayList = null;
        boolean z = false;
        for (int i = 0; i < this.f271e.size(); i++) {
            C0068f fVar = (C0068f) this.f271e.get(i);
            if (fVar != null && fVar.mo229b(menu, menuInflater)) {
                if (arrayList == null) {
                    arrayList = new ArrayList<>();
                }
                arrayList.add(fVar);
                z = true;
            }
        }
        if (this.f274h != null) {
            for (int i2 = 0; i2 < this.f274h.size(); i2++) {
                C0068f fVar2 = (C0068f) this.f274h.get(i2);
                if (arrayList == null || !arrayList.contains(fVar2)) {
                    fVar2.mo269v();
                }
            }
        }
        this.f274h = arrayList;
        return z;
    }

    /* renamed from: a */
    public boolean mo393a(MenuItem menuItem) {
        if (this.f278l < 1) {
            return false;
        }
        for (int i = 0; i < this.f271e.size(); i++) {
            C0068f fVar = (C0068f) this.f271e.get(i);
            if (fVar != null && fVar.mo233c(menuItem)) {
                return true;
            }
        }
        return false;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public boolean mo394a(ArrayList<C0061b> arrayList, ArrayList<Boolean> arrayList2, String str, int i, int i2) {
        int i3;
        ArrayList<C0061b> arrayList3 = this.f273g;
        if (arrayList3 == null) {
            return false;
        }
        if (str == null && i < 0 && (i2 & 1) == 0) {
            int size = arrayList3.size() - 1;
            if (size < 0) {
                return false;
            }
            arrayList.add(this.f273g.remove(size));
            arrayList2.add(Boolean.valueOf(true));
        } else {
            if (str != null || i >= 0) {
                i3 = this.f273g.size() - 1;
                while (i3 >= 0) {
                    C0061b bVar = (C0061b) this.f273g.get(i3);
                    if ((str != null && str.equals(bVar.mo152f())) || (i >= 0 && i == bVar.f124m)) {
                        break;
                    }
                    i3--;
                }
                if (i3 < 0) {
                    return false;
                }
                if ((i2 & 1) != 0) {
                    while (true) {
                        i3--;
                        if (i3 < 0) {
                            break;
                        }
                        C0061b bVar2 = (C0061b) this.f273g.get(i3);
                        if ((str == null || !str.equals(bVar2.mo152f())) && (i < 0 || i != bVar2.f124m)) {
                            break;
                        }
                    }
                }
            } else {
                i3 = -1;
            }
            if (i3 == this.f273g.size() - 1) {
                return false;
            }
            for (int size2 = this.f273g.size() - 1; size2 > i3; size2--) {
                arrayList.add(this.f273g.remove(size2));
                arrayList2.add(Boolean.valueOf(true));
            }
        }
        return true;
    }

    /* renamed from: b */
    public C0068f mo395b(int i) {
        for (int size = this.f271e.size() - 1; size >= 0; size--) {
            C0068f fVar = (C0068f) this.f271e.get(size);
            if (fVar != null && fVar.f171H == i) {
                return fVar;
            }
        }
        SparseArray<C0068f> sparseArray = this.f272f;
        if (sparseArray != null) {
            for (int size2 = sparseArray.size() - 1; size2 >= 0; size2--) {
                C0068f fVar2 = (C0068f) this.f272f.valueAt(size2);
                if (fVar2 != null && fVar2.f171H == i) {
                    return fVar2;
                }
            }
        }
        return null;
    }

    /* renamed from: b */
    public C0068f mo396b(String str) {
        SparseArray<C0068f> sparseArray = this.f272f;
        if (!(sparseArray == null || str == null)) {
            for (int size = sparseArray.size() - 1; size >= 0; size--) {
                C0068f fVar = (C0068f) this.f272f.valueAt(size);
                if (fVar != null) {
                    C0068f a = fVar.mo203a(str);
                    if (a != null) {
                        return a;
                    }
                }
            }
        }
        return null;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public void mo397b(C0061b bVar) {
        if (this.f273g == null) {
            this.f273g = new ArrayList<>();
        }
        this.f273g.add(bVar);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public void mo398b(C0068f fVar) {
        mo382a(fVar, this.f278l, 0, 0, false);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public void mo399b(C0068f fVar, Context context, boolean z) {
        C0068f fVar2 = this.f281o;
        if (fVar2 != null) {
            C0082k n = fVar2.mo256n();
            if (n instanceof C0085l) {
                ((C0085l) n).mo399b(fVar, context, true);
            }
        }
        Iterator it = this.f267J.iterator();
        while (it.hasNext()) {
            C0097f fVar3 = (C0097f) it.next();
            if (!z || fVar3.f317b) {
                fVar3.f316a.mo361b((C0082k) this, fVar, context);
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public void mo400b(C0068f fVar, Bundle bundle, boolean z) {
        C0068f fVar2 = this.f281o;
        if (fVar2 != null) {
            C0082k n = fVar2.mo256n();
            if (n instanceof C0085l) {
                ((C0085l) n).mo400b(fVar, bundle, true);
            }
        }
        Iterator it = this.f267J.iterator();
        while (it.hasNext()) {
            C0097f fVar3 = (C0097f) it.next();
            if (!z || fVar3.f317b) {
                fVar3.f316a.mo362b((C0082k) this, fVar, bundle);
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public void mo401b(C0068f fVar, boolean z) {
        C0068f fVar2 = this.f281o;
        if (fVar2 != null) {
            C0082k n = fVar2.mo256n();
            if (n instanceof C0085l) {
                ((C0085l) n).mo401b(fVar, true);
            }
        }
        Iterator it = this.f267J.iterator();
        while (it.hasNext()) {
            C0097f fVar3 = (C0097f) it.next();
            if (!z || fVar3.f317b) {
                fVar3.f316a.mo356a(this, fVar);
            }
        }
    }

    /* renamed from: b */
    public void mo402b(Menu menu) {
        if (this.f278l >= 1) {
            for (int i = 0; i < this.f271e.size(); i++) {
                C0068f fVar = (C0068f) this.f271e.get(i);
                if (fVar != null) {
                    fVar.mo234d(menu);
                }
            }
        }
    }

    /* renamed from: b */
    public void mo403b(boolean z) {
        for (int size = this.f271e.size() - 1; size >= 0; size--) {
            C0068f fVar = (C0068f) this.f271e.get(size);
            if (fVar != null) {
                fVar.mo240f(z);
            }
        }
    }

    /* renamed from: b */
    public boolean mo353b() {
        m439y();
        return m428a((String) null, -1, 0);
    }

    /* renamed from: b */
    public boolean mo404b(MenuItem menuItem) {
        if (this.f278l < 1) {
            return false;
        }
        for (int i = 0; i < this.f271e.size(); i++) {
            C0068f fVar = (C0068f) this.f271e.get(i);
            if (fVar != null && fVar.mo236d(menuItem)) {
                return true;
            }
        }
        return false;
    }

    /* renamed from: c */
    public List<C0068f> mo354c() {
        List<C0068f> list;
        if (this.f271e.isEmpty()) {
            return Collections.emptyList();
        }
        synchronized (this.f271e) {
            list = (List) this.f271e.clone();
        }
        return list;
    }

    /* renamed from: c */
    public void mo405c(int i) {
        synchronized (this) {
            this.f275i.set(i, null);
            if (this.f276j == null) {
                this.f276j = new ArrayList<>();
            }
            if (f260a) {
                StringBuilder sb = new StringBuilder();
                sb.append("Freeing back stack index ");
                sb.append(i);
                Log.v("FragmentManager", sb.toString());
            }
            this.f276j.add(Integer.valueOf(i));
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public void mo406c(C0068f fVar) {
        if (fVar.f208w && !fVar.f211z) {
            fVar.mo226b(fVar.mo243h(fVar.f197l), (ViewGroup) null, fVar.f197l);
            if (fVar.f182S != null) {
                fVar.f183T = fVar.f182S;
                fVar.f182S.setSaveFromParentEnabled(false);
                if (fVar.f174K) {
                    fVar.f182S.setVisibility(8);
                }
                fVar.mo221a(fVar.f182S, fVar.f197l);
                mo385a(fVar, fVar.f182S, fVar.f197l, false);
                return;
            }
            fVar.f183T = null;
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public void mo407c(C0068f fVar, Bundle bundle, boolean z) {
        C0068f fVar2 = this.f281o;
        if (fVar2 != null) {
            C0082k n = fVar2.mo256n();
            if (n instanceof C0085l) {
                ((C0085l) n).mo407c(fVar, bundle, true);
            }
        }
        Iterator it = this.f267J.iterator();
        while (it.hasNext()) {
            C0097f fVar3 = (C0097f) it.next();
            if (!z || fVar3.f317b) {
                fVar3.f316a.mo364c(this, fVar, bundle);
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public void mo408c(C0068f fVar, boolean z) {
        C0068f fVar2 = this.f281o;
        if (fVar2 != null) {
            C0082k n = fVar2.mo256n();
            if (n instanceof C0085l) {
                ((C0085l) n).mo408c(fVar, true);
            }
        }
        Iterator it = this.f267J.iterator();
        while (it.hasNext()) {
            C0097f fVar3 = (C0097f) it.next();
            if (!z || fVar3.f317b) {
                fVar3.f316a.mo360b(this, fVar);
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: d */
    public void mo409d(final C0068f fVar) {
        if (fVar.f182S != null) {
            C0094c a = mo374a(fVar, fVar.mo194R(), !fVar.f174K, fVar.mo195S());
            if (a == null || a.f309b == null) {
                if (a != null) {
                    m431b(fVar.f182S, a);
                    fVar.f182S.startAnimation(a.f308a);
                    a.f308a.start();
                }
                fVar.f182S.setVisibility((!fVar.f174K || fVar.mo202Z()) ? 0 : 8);
                if (fVar.mo202Z()) {
                    fVar.mo242g(false);
                }
            } else {
                a.f309b.setTarget(fVar.f182S);
                if (!fVar.f174K) {
                    fVar.f182S.setVisibility(0);
                } else if (fVar.mo202Z()) {
                    fVar.mo242g(false);
                } else {
                    final ViewGroup viewGroup = fVar.f181R;
                    final View view = fVar.f182S;
                    viewGroup.startViewTransition(view);
                    a.f309b.addListener(new AnimatorListenerAdapter() {
                        public void onAnimationEnd(Animator animator) {
                            viewGroup.endViewTransition(view);
                            animator.removeListener(this);
                            if (fVar.f182S != null) {
                                fVar.f182S.setVisibility(8);
                            }
                        }
                    });
                }
                m431b(fVar.f182S, a);
                a.f309b.start();
            }
        }
        if (fVar.f206u && fVar.f178O && fVar.f179P) {
            this.f283r = true;
        }
        fVar.f188Y = false;
        fVar.mo228b(fVar.f174K);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: d */
    public void mo410d(C0068f fVar, Bundle bundle, boolean z) {
        C0068f fVar2 = this.f281o;
        if (fVar2 != null) {
            C0082k n = fVar2.mo256n();
            if (n instanceof C0085l) {
                ((C0085l) n).mo410d(fVar, bundle, true);
            }
        }
        Iterator it = this.f267J.iterator();
        while (it.hasNext()) {
            C0097f fVar3 = (C0097f) it.next();
            if (!z || fVar3.f317b) {
                fVar3.f316a.mo366d(this, fVar, bundle);
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: d */
    public void mo411d(C0068f fVar, boolean z) {
        C0068f fVar2 = this.f281o;
        if (fVar2 != null) {
            C0082k n = fVar2.mo256n();
            if (n instanceof C0085l) {
                ((C0085l) n).mo411d(fVar, true);
            }
        }
        Iterator it = this.f267J.iterator();
        while (it.hasNext()) {
            C0097f fVar3 = (C0097f) it.next();
            if (!z || fVar3.f317b) {
                fVar3.f316a.mo363c(this, fVar);
            }
        }
    }

    /* renamed from: d */
    public boolean mo355d() {
        return this.f284s || this.f285t;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: e */
    public void mo412e() {
        if (this.f272f != null) {
            for (int i = 0; i < this.f272f.size(); i++) {
                C0068f fVar = (C0068f) this.f272f.valueAt(i);
                if (fVar != null) {
                    mo381a(fVar);
                }
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: e */
    public void mo413e(C0068f fVar) {
        if (fVar != null) {
            int i = this.f278l;
            if (fVar.f207v) {
                i = fVar.mo244h() ? Math.min(i, 1) : Math.min(i, 0);
            }
            mo382a(fVar, i, fVar.mo194R(), fVar.mo195S(), false);
            if (fVar.f182S != null) {
                C0068f p = m438p(fVar);
                if (p != null) {
                    View view = p.f182S;
                    ViewGroup viewGroup = fVar.f181R;
                    int indexOfChild = viewGroup.indexOfChild(view);
                    int indexOfChild2 = viewGroup.indexOfChild(fVar.f182S);
                    if (indexOfChild2 < indexOfChild) {
                        viewGroup.removeViewAt(indexOfChild2);
                        viewGroup.addView(fVar.f182S, indexOfChild);
                    }
                }
                if (fVar.f187X && fVar.f181R != null) {
                    if (fVar.f189Z > 0.0f) {
                        fVar.f182S.setAlpha(fVar.f189Z);
                    }
                    fVar.f189Z = 0.0f;
                    fVar.f187X = false;
                    C0094c a = mo374a(fVar, fVar.mo194R(), true, fVar.mo195S());
                    if (a != null) {
                        m431b(fVar.f182S, a);
                        if (a.f308a != null) {
                            fVar.f182S.startAnimation(a.f308a);
                        } else {
                            a.f309b.setTarget(fVar.f182S);
                            a.f309b.start();
                        }
                    }
                }
            }
            if (fVar.f188Y) {
                mo409d(fVar);
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: e */
    public void mo414e(C0068f fVar, boolean z) {
        C0068f fVar2 = this.f281o;
        if (fVar2 != null) {
            C0082k n = fVar2.mo256n();
            if (n instanceof C0085l) {
                ((C0085l) n).mo414e(fVar, true);
            }
        }
        Iterator it = this.f267J.iterator();
        while (it.hasNext()) {
            C0097f fVar3 = (C0097f) it.next();
            if (!z || fVar3.f317b) {
                fVar3.f316a.mo365d(this, fVar);
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: f */
    public void mo415f() {
        synchronized (this) {
            boolean z = false;
            boolean z2 = this.f264C != null && !this.f264C.isEmpty();
            if (this.f268b != null && this.f268b.size() == 1) {
                z = true;
            }
            if (z2 || z) {
                this.f279m.mo348h().removeCallbacks(this.f266E);
                this.f279m.mo348h().post(this.f266E);
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: f */
    public void mo416f(C0068f fVar) {
        if (fVar.f200o < 0) {
            int i = this.f270d;
            this.f270d = i + 1;
            fVar.mo209a(i, this.f281o);
            if (this.f272f == null) {
                this.f272f = new SparseArray<>();
            }
            this.f272f.put(fVar.f200o, fVar);
            if (f260a) {
                StringBuilder sb = new StringBuilder();
                sb.append("Allocated fragment index ");
                sb.append(fVar);
                Log.v("FragmentManager", sb.toString());
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: f */
    public void mo417f(C0068f fVar, boolean z) {
        C0068f fVar2 = this.f281o;
        if (fVar2 != null) {
            C0082k n = fVar2.mo256n();
            if (n instanceof C0085l) {
                ((C0085l) n).mo417f(fVar, true);
            }
        }
        Iterator it = this.f267J.iterator();
        while (it.hasNext()) {
            C0097f fVar3 = (C0097f) it.next();
            if (!z || fVar3.f317b) {
                fVar3.f316a.mo367e(this, fVar);
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: g */
    public void mo418g(C0068f fVar) {
        if (fVar.f200o >= 0) {
            if (f260a) {
                StringBuilder sb = new StringBuilder();
                sb.append("Freeing fragment index ");
                sb.append(fVar);
                Log.v("FragmentManager", sb.toString());
            }
            this.f272f.put(fVar.f200o, null);
            fVar.mo268u();
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: g */
    public void mo419g(C0068f fVar, boolean z) {
        C0068f fVar2 = this.f281o;
        if (fVar2 != null) {
            C0082k n = fVar2.mo256n();
            if (n instanceof C0085l) {
                ((C0085l) n).mo419g(fVar, true);
            }
        }
        Iterator it = this.f267J.iterator();
        while (it.hasNext()) {
            C0097f fVar3 = (C0097f) it.next();
            if (!z || fVar3.f317b) {
                fVar3.f316a.mo368f(this, fVar);
            }
        }
    }

    /* JADX INFO: finally extract failed */
    /* renamed from: g */
    public boolean mo420g() {
        m434c(true);
        boolean z = false;
        while (m435c(this.f289x, this.f290y)) {
            this.f269c = true;
            try {
                m432b(this.f289x, this.f290y);
                m440z();
                z = true;
            } catch (Throwable th) {
                m440z();
                throw th;
            }
        }
        mo421h();
        m414C();
        return z;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: h */
    public void mo421h() {
        if (this.f288w) {
            this.f288w = false;
            mo412e();
        }
    }

    /* renamed from: h */
    public void mo422h(C0068f fVar) {
        if (f260a) {
            StringBuilder sb = new StringBuilder();
            sb.append("remove: ");
            sb.append(fVar);
            sb.append(" nesting=");
            sb.append(fVar.f164A);
            Log.v("FragmentManager", sb.toString());
        }
        boolean z = !fVar.mo244h();
        if (!fVar.f175L || z) {
            synchronized (this.f271e) {
                this.f271e.remove(fVar);
            }
            if (fVar.f178O && fVar.f179P) {
                this.f283r = true;
            }
            fVar.f206u = false;
            fVar.f207v = true;
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: h */
    public void mo423h(C0068f fVar, boolean z) {
        C0068f fVar2 = this.f281o;
        if (fVar2 != null) {
            C0082k n = fVar2.mo256n();
            if (n instanceof C0085l) {
                ((C0085l) n).mo423h(fVar, true);
            }
        }
        Iterator it = this.f267J.iterator();
        while (it.hasNext()) {
            C0097f fVar3 = (C0097f) it.next();
            if (!z || fVar3.f317b) {
                fVar3.f316a.mo369g(this, fVar);
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: i */
    public void mo424i() {
        if (this.f277k != null) {
            for (int i = 0; i < this.f277k.size(); i++) {
                ((C0084b) this.f277k.get(i)).mo370a();
            }
        }
    }

    /* renamed from: i */
    public void mo425i(C0068f fVar) {
        if (f260a) {
            StringBuilder sb = new StringBuilder();
            sb.append("hide: ");
            sb.append(fVar);
            Log.v("FragmentManager", sb.toString());
        }
        if (!fVar.f174K) {
            fVar.f174K = true;
            fVar.f188Y = true ^ fVar.f188Y;
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: j */
    public C0102m mo426j() {
        m420a(this.f265D);
        return this.f265D;
    }

    /* renamed from: j */
    public void mo427j(C0068f fVar) {
        if (f260a) {
            StringBuilder sb = new StringBuilder();
            sb.append("show: ");
            sb.append(fVar);
            Log.v("FragmentManager", sb.toString());
        }
        if (fVar.f174K) {
            fVar.f174K = false;
            fVar.f188Y = !fVar.f188Y;
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: k */
    public void mo428k() {
        ArrayList arrayList;
        ArrayList arrayList2;
        ArrayList arrayList3;
        C0102m mVar;
        if (this.f272f != null) {
            arrayList3 = null;
            arrayList2 = null;
            arrayList = null;
            for (int i = 0; i < this.f272f.size(); i++) {
                C0068f fVar = (C0068f) this.f272f.valueAt(i);
                if (fVar != null) {
                    if (fVar.f176M) {
                        if (arrayList3 == null) {
                            arrayList3 = new ArrayList();
                        }
                        arrayList3.add(fVar);
                        fVar.f204s = fVar.f203r != null ? fVar.f203r.f200o : -1;
                        if (f260a) {
                            StringBuilder sb = new StringBuilder();
                            sb.append("retainNonConfig: keeping retained ");
                            sb.append(fVar);
                            Log.v("FragmentManager", sb.toString());
                        }
                    }
                    if (fVar.f167D != null) {
                        fVar.f167D.mo428k();
                        mVar = fVar.f167D.f265D;
                    } else {
                        mVar = fVar.f168E;
                    }
                    if (arrayList2 == null && mVar != null) {
                        arrayList2 = new ArrayList(this.f272f.size());
                        for (int i2 = 0; i2 < i; i2++) {
                            arrayList2.add(null);
                        }
                    }
                    if (arrayList2 != null) {
                        arrayList2.add(mVar);
                    }
                    if (arrayList == null && fVar.f169F != null) {
                        arrayList = new ArrayList(this.f272f.size());
                        for (int i3 = 0; i3 < i; i3++) {
                            arrayList.add(null);
                        }
                    }
                    if (arrayList != null) {
                        arrayList.add(fVar.f169F);
                    }
                }
            }
        } else {
            arrayList3 = null;
            arrayList2 = null;
            arrayList = null;
        }
        if (arrayList3 == null && arrayList2 == null && arrayList == null) {
            this.f265D = null;
        } else {
            this.f265D = new C0102m(arrayList3, arrayList2, arrayList);
        }
    }

    /* renamed from: k */
    public void mo429k(C0068f fVar) {
        if (f260a) {
            StringBuilder sb = new StringBuilder();
            sb.append("detach: ");
            sb.append(fVar);
            Log.v("FragmentManager", sb.toString());
        }
        if (!fVar.f175L) {
            fVar.f175L = true;
            if (fVar.f206u) {
                if (f260a) {
                    StringBuilder sb2 = new StringBuilder();
                    sb2.append("remove from detach: ");
                    sb2.append(fVar);
                    Log.v("FragmentManager", sb2.toString());
                }
                synchronized (this.f271e) {
                    this.f271e.remove(fVar);
                }
                if (fVar.f178O && fVar.f179P) {
                    this.f283r = true;
                }
                fVar.f206u = false;
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: l */
    public Parcelable mo430l() {
        int[] iArr;
        m412A();
        m413B();
        mo420g();
        this.f284s = true;
        C0063c[] cVarArr = null;
        this.f265D = null;
        SparseArray<C0068f> sparseArray = this.f272f;
        if (sparseArray == null || sparseArray.size() <= 0) {
            return null;
        }
        int size = this.f272f.size();
        C0105o[] oVarArr = new C0105o[size];
        boolean z = false;
        for (int i = 0; i < size; i++) {
            C0068f fVar = (C0068f) this.f272f.valueAt(i);
            if (fVar != null) {
                if (fVar.f200o < 0) {
                    StringBuilder sb = new StringBuilder();
                    sb.append("Failure saving state: active ");
                    sb.append(fVar);
                    sb.append(" has cleared index: ");
                    sb.append(fVar.f200o);
                    m422a((RuntimeException) new IllegalStateException(sb.toString()));
                }
                C0105o oVar = new C0105o(fVar);
                oVarArr[i] = oVar;
                if (fVar.f196k <= 0 || oVar.f344k != null) {
                    oVar.f344k = fVar.f197l;
                } else {
                    oVar.f344k = mo434n(fVar);
                    if (fVar.f203r != null) {
                        if (fVar.f203r.f200o < 0) {
                            StringBuilder sb2 = new StringBuilder();
                            sb2.append("Failure saving state: ");
                            sb2.append(fVar);
                            sb2.append(" has target not in fragment manager: ");
                            sb2.append(fVar.f203r);
                            m422a((RuntimeException) new IllegalStateException(sb2.toString()));
                        }
                        if (oVar.f344k == null) {
                            oVar.f344k = new Bundle();
                        }
                        mo378a(oVar.f344k, "android:target_state", fVar.f203r);
                        if (fVar.f205t != 0) {
                            oVar.f344k.putInt("android:target_req_state", fVar.f205t);
                        }
                    }
                }
                if (f260a) {
                    StringBuilder sb3 = new StringBuilder();
                    sb3.append("Saved state of ");
                    sb3.append(fVar);
                    sb3.append(": ");
                    sb3.append(oVar.f344k);
                    Log.v("FragmentManager", sb3.toString());
                }
                z = true;
            }
        }
        if (!z) {
            if (f260a) {
                Log.v("FragmentManager", "saveAllState: no fragments!");
            }
            return null;
        }
        int size2 = this.f271e.size();
        if (size2 > 0) {
            iArr = new int[size2];
            for (int i2 = 0; i2 < size2; i2++) {
                iArr[i2] = ((C0068f) this.f271e.get(i2)).f200o;
                if (iArr[i2] < 0) {
                    StringBuilder sb4 = new StringBuilder();
                    sb4.append("Failure saving state: active ");
                    sb4.append(this.f271e.get(i2));
                    sb4.append(" has cleared index: ");
                    sb4.append(iArr[i2]);
                    m422a((RuntimeException) new IllegalStateException(sb4.toString()));
                }
                if (f260a) {
                    StringBuilder sb5 = new StringBuilder();
                    sb5.append("saveAllState: adding fragment #");
                    sb5.append(i2);
                    sb5.append(": ");
                    sb5.append(this.f271e.get(i2));
                    Log.v("FragmentManager", sb5.toString());
                }
            }
        } else {
            iArr = null;
        }
        ArrayList<C0061b> arrayList = this.f273g;
        if (arrayList != null) {
            int size3 = arrayList.size();
            if (size3 > 0) {
                cVarArr = new C0063c[size3];
                for (int i3 = 0; i3 < size3; i3++) {
                    cVarArr[i3] = new C0063c((C0061b) this.f273g.get(i3));
                    if (f260a) {
                        StringBuilder sb6 = new StringBuilder();
                        sb6.append("saveAllState: adding back stack #");
                        sb6.append(i3);
                        sb6.append(": ");
                        sb6.append(this.f273g.get(i3));
                        Log.v("FragmentManager", sb6.toString());
                    }
                }
            }
        }
        C0103n nVar = new C0103n();
        nVar.f329a = oVarArr;
        nVar.f330b = iArr;
        nVar.f331c = cVarArr;
        C0068f fVar2 = this.f282p;
        if (fVar2 != null) {
            nVar.f332d = fVar2.f200o;
        }
        nVar.f333e = this.f270d;
        mo428k();
        return nVar;
    }

    /* renamed from: l */
    public void mo431l(C0068f fVar) {
        if (f260a) {
            StringBuilder sb = new StringBuilder();
            sb.append("attach: ");
            sb.append(fVar);
            Log.v("FragmentManager", sb.toString());
        }
        if (fVar.f175L) {
            fVar.f175L = false;
            if (fVar.f206u) {
                return;
            }
            if (!this.f271e.contains(fVar)) {
                if (f260a) {
                    StringBuilder sb2 = new StringBuilder();
                    sb2.append("add from attach: ");
                    sb2.append(fVar);
                    Log.v("FragmentManager", sb2.toString());
                }
                synchronized (this.f271e) {
                    this.f271e.add(fVar);
                }
                fVar.f206u = true;
                if (fVar.f178O && fVar.f179P) {
                    this.f283r = true;
                    return;
                }
                return;
            }
            StringBuilder sb3 = new StringBuilder();
            sb3.append("Fragment already added: ");
            sb3.append(fVar);
            throw new IllegalStateException(sb3.toString());
        }
    }

    /* renamed from: m */
    public void mo432m() {
        this.f265D = null;
        this.f284s = false;
        this.f285t = false;
        int size = this.f271e.size();
        for (int i = 0; i < size; i++) {
            C0068f fVar = (C0068f) this.f271e.get(i);
            if (fVar != null) {
                fVar.mo186J();
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: m */
    public void mo433m(C0068f fVar) {
        if (fVar.f183T != null) {
            SparseArray<Parcelable> sparseArray = this.f263B;
            if (sparseArray == null) {
                this.f263B = new SparseArray<>();
            } else {
                sparseArray.clear();
            }
            fVar.f183T.saveHierarchyState(this.f263B);
            if (this.f263B.size() > 0) {
                fVar.f198m = this.f263B;
                this.f263B = null;
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: n */
    public Bundle mo434n(C0068f fVar) {
        Bundle bundle;
        if (this.f262A == null) {
            this.f262A = new Bundle();
        }
        fVar.mo257n(this.f262A);
        mo410d(fVar, this.f262A, false);
        if (!this.f262A.isEmpty()) {
            bundle = this.f262A;
            this.f262A = null;
        } else {
            bundle = null;
        }
        if (fVar.f182S != null) {
            mo433m(fVar);
        }
        if (fVar.f198m != null) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            bundle.putSparseParcelableArray("android:view_state", fVar.f198m);
        }
        if (!fVar.f185V) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            bundle.putBoolean("android:user_visible_hint", fVar.f185V);
        }
        return bundle;
    }

    /* renamed from: n */
    public void mo435n() {
        this.f284s = false;
        this.f285t = false;
        m437e(1);
    }

    /* renamed from: o */
    public void mo436o() {
        this.f284s = false;
        this.f285t = false;
        m437e(2);
    }

    /* renamed from: o */
    public void mo437o(C0068f fVar) {
        if (fVar == null || (this.f272f.get(fVar.f200o) == fVar && (fVar.f166C == null || fVar.mo256n() == this))) {
            this.f282p = fVar;
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Fragment ");
        sb.append(fVar);
        sb.append(" is not an active fragment of FragmentManager ");
        sb.append(this);
        throw new IllegalArgumentException(sb.toString());
    }

    public View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        C0068f fVar;
        Context context2 = context;
        AttributeSet attributeSet2 = attributeSet;
        String str2 = str;
        if (!"fragment".equals(str)) {
            return null;
        }
        String attributeValue = attributeSet2.getAttributeValue(null, "class");
        TypedArray obtainStyledAttributes = context2.obtainStyledAttributes(attributeSet2, C0098g.f318a);
        int i = 0;
        if (attributeValue == null) {
            attributeValue = obtainStyledAttributes.getString(0);
        }
        String str3 = attributeValue;
        int resourceId = obtainStyledAttributes.getResourceId(1, -1);
        String string = obtainStyledAttributes.getString(2);
        obtainStyledAttributes.recycle();
        if (!C0068f.m217a(this.f279m.mo347g(), str3)) {
            return null;
        }
        if (view != null) {
            i = view.getId();
        }
        if (i == -1 && resourceId == -1 && string == null) {
            StringBuilder sb = new StringBuilder();
            sb.append(attributeSet.getPositionDescription());
            sb.append(": Must specify unique android:id, android:tag, or have a parent with an id for ");
            sb.append(str3);
            throw new IllegalArgumentException(sb.toString());
        }
        C0068f b = resourceId != -1 ? mo395b(resourceId) : null;
        if (b == null && string != null) {
            b = mo373a(string);
        }
        if (b == null && i != -1) {
            b = mo395b(i);
        }
        if (f260a) {
            StringBuilder sb2 = new StringBuilder();
            sb2.append("onCreateView: id=0x");
            sb2.append(Integer.toHexString(resourceId));
            sb2.append(" fname=");
            sb2.append(str3);
            sb2.append(" existing=");
            sb2.append(b);
            Log.v("FragmentManager", sb2.toString());
        }
        if (b == null) {
            C0068f a = this.f280n.mo275a(context2, str3, null);
            a.f208w = true;
            a.f171H = resourceId != 0 ? resourceId : i;
            a.f172I = i;
            a.f173J = string;
            a.f209x = true;
            a.f165B = this;
            C0081j jVar = this.f279m;
            a.f166C = jVar;
            a.mo214a(jVar.mo347g(), attributeSet2, a.f197l);
            mo386a(a, true);
            fVar = a;
        } else if (!b.f209x) {
            b.f209x = true;
            b.f166C = this.f279m;
            if (!b.f177N) {
                b.mo214a(this.f279m.mo347g(), attributeSet2, b.f197l);
            }
            fVar = b;
        } else {
            StringBuilder sb3 = new StringBuilder();
            sb3.append(attributeSet.getPositionDescription());
            sb3.append(": Duplicate id 0x");
            sb3.append(Integer.toHexString(resourceId));
            sb3.append(", tag ");
            sb3.append(string);
            sb3.append(", or parent id 0x");
            sb3.append(Integer.toHexString(i));
            sb3.append(" with another fragment for ");
            sb3.append(str3);
            throw new IllegalArgumentException(sb3.toString());
        }
        if (this.f278l >= 1 || !fVar.f208w) {
            mo398b(fVar);
        } else {
            mo382a(fVar, 1, 0, 0, false);
        }
        if (fVar.f182S != null) {
            if (resourceId != 0) {
                fVar.f182S.setId(resourceId);
            }
            if (fVar.f182S.getTag() == null) {
                fVar.f182S.setTag(string);
            }
            return fVar.f182S;
        }
        StringBuilder sb4 = new StringBuilder();
        sb4.append("Fragment ");
        sb4.append(str3);
        sb4.append(" did not create a view.");
        throw new IllegalStateException(sb4.toString());
    }

    public View onCreateView(String str, Context context, AttributeSet attributeSet) {
        return onCreateView(null, str, context, attributeSet);
    }

    /* renamed from: p */
    public void mo440p() {
        this.f284s = false;
        this.f285t = false;
        m437e(3);
    }

    /* renamed from: q */
    public void mo441q() {
        this.f284s = false;
        this.f285t = false;
        m437e(4);
    }

    /* renamed from: r */
    public void mo442r() {
        m437e(3);
    }

    /* renamed from: s */
    public void mo443s() {
        this.f285t = true;
        m437e(2);
    }

    /* renamed from: t */
    public void mo444t() {
        m437e(1);
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("FragmentManager{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append(" in ");
        Object obj = this.f281o;
        if (obj == null) {
            obj = this.f279m;
        }
        C0156d.m710a(obj, sb);
        sb.append("}}");
        return sb.toString();
    }

    /* renamed from: u */
    public void mo446u() {
        this.f286u = true;
        mo420g();
        m437e(0);
        this.f279m = null;
        this.f280n = null;
        this.f281o = null;
    }

    /* renamed from: v */
    public void mo447v() {
        for (int i = 0; i < this.f271e.size(); i++) {
            C0068f fVar = (C0068f) this.f271e.get(i);
            if (fVar != null) {
                fVar.mo187K();
            }
        }
    }

    /* renamed from: w */
    public C0068f mo448w() {
        return this.f282p;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: x */
    public Factory2 mo449x() {
        return this;
    }
}
