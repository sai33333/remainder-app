package android.support.p005v4.app;

import android.arch.lifecycle.C0043p;
import java.util.List;

/* renamed from: android.support.v4.app.m */
public class C0102m {

    /* renamed from: a */
    private final List<C0068f> f326a;

    /* renamed from: b */
    private final List<C0102m> f327b;

    /* renamed from: c */
    private final List<C0043p> f328c;

    C0102m(List<C0068f> list, List<C0102m> list2, List<C0043p> list3) {
        this.f326a = list;
        this.f327b = list2;
        this.f328c = list3;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public List<C0068f> mo466a() {
        return this.f326a;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public List<C0102m> mo467b() {
        return this.f327b;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public List<C0043p> mo468c() {
        return this.f328c;
    }
}
