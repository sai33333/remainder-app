package android.support.p005v4.app;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

/* renamed from: android.support.v4.app.n */
final class C0103n implements Parcelable {
    public static final Creator<C0103n> CREATOR = new Creator<C0103n>() {
        /* renamed from: a */
        public C0103n createFromParcel(Parcel parcel) {
            return new C0103n(parcel);
        }

        /* renamed from: a */
        public C0103n[] newArray(int i) {
            return new C0103n[i];
        }
    };

    /* renamed from: a */
    C0105o[] f329a;

    /* renamed from: b */
    int[] f330b;

    /* renamed from: c */
    C0063c[] f331c;

    /* renamed from: d */
    int f332d = -1;

    /* renamed from: e */
    int f333e;

    public C0103n() {
    }

    public C0103n(Parcel parcel) {
        this.f329a = (C0105o[]) parcel.createTypedArray(C0105o.CREATOR);
        this.f330b = parcel.createIntArray();
        this.f331c = (C0063c[]) parcel.createTypedArray(C0063c.CREATOR);
        this.f332d = parcel.readInt();
        this.f333e = parcel.readInt();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeTypedArray(this.f329a, i);
        parcel.writeIntArray(this.f330b);
        parcel.writeTypedArray(this.f331c, i);
        parcel.writeInt(this.f332d);
        parcel.writeInt(this.f333e);
    }
}
