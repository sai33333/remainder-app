package android.support.p005v4.app;

import android.arch.lifecycle.C0043p;
import android.content.Context;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.util.Log;

/* renamed from: android.support.v4.app.o */
final class C0105o implements Parcelable {
    public static final Creator<C0105o> CREATOR = new Creator<C0105o>() {
        /* renamed from: a */
        public C0105o createFromParcel(Parcel parcel) {
            return new C0105o(parcel);
        }

        /* renamed from: a */
        public C0105o[] newArray(int i) {
            return new C0105o[i];
        }
    };

    /* renamed from: a */
    final String f334a;

    /* renamed from: b */
    final int f335b;

    /* renamed from: c */
    final boolean f336c;

    /* renamed from: d */
    final int f337d;

    /* renamed from: e */
    final int f338e;

    /* renamed from: f */
    final String f339f;

    /* renamed from: g */
    final boolean f340g;

    /* renamed from: h */
    final boolean f341h;

    /* renamed from: i */
    final Bundle f342i;

    /* renamed from: j */
    final boolean f343j;

    /* renamed from: k */
    Bundle f344k;

    /* renamed from: l */
    C0068f f345l;

    C0105o(Parcel parcel) {
        this.f334a = parcel.readString();
        this.f335b = parcel.readInt();
        boolean z = true;
        this.f336c = parcel.readInt() != 0;
        this.f337d = parcel.readInt();
        this.f338e = parcel.readInt();
        this.f339f = parcel.readString();
        this.f340g = parcel.readInt() != 0;
        this.f341h = parcel.readInt() != 0;
        this.f342i = parcel.readBundle();
        if (parcel.readInt() == 0) {
            z = false;
        }
        this.f343j = z;
        this.f344k = parcel.readBundle();
    }

    C0105o(C0068f fVar) {
        this.f334a = fVar.getClass().getName();
        this.f335b = fVar.f200o;
        this.f336c = fVar.f208w;
        this.f337d = fVar.f171H;
        this.f338e = fVar.f172I;
        this.f339f = fVar.f173J;
        this.f340g = fVar.f176M;
        this.f341h = fVar.f175L;
        this.f342i = fVar.f202q;
        this.f343j = fVar.f174K;
    }

    /* renamed from: a */
    public C0068f mo475a(C0081j jVar, C0079h hVar, C0068f fVar, C0102m mVar, C0043p pVar) {
        if (this.f345l == null) {
            Context g = jVar.mo347g();
            Bundle bundle = this.f342i;
            if (bundle != null) {
                bundle.setClassLoader(g.getClassLoader());
            }
            this.f345l = hVar != null ? hVar.mo275a(g, this.f334a, this.f342i) : C0068f.m216a(g, this.f334a, this.f342i);
            Bundle bundle2 = this.f344k;
            if (bundle2 != null) {
                bundle2.setClassLoader(g.getClassLoader());
                this.f345l.f197l = this.f344k;
            }
            this.f345l.mo209a(this.f335b, fVar);
            C0068f fVar2 = this.f345l;
            fVar2.f208w = this.f336c;
            fVar2.f210y = true;
            fVar2.f171H = this.f337d;
            fVar2.f172I = this.f338e;
            fVar2.f173J = this.f339f;
            fVar2.f176M = this.f340g;
            fVar2.f175L = this.f341h;
            fVar2.f174K = this.f343j;
            fVar2.f165B = jVar.f252b;
            if (C0085l.f260a) {
                StringBuilder sb = new StringBuilder();
                sb.append("Instantiated fragment ");
                sb.append(this.f345l);
                Log.v("FragmentManager", sb.toString());
            }
        }
        C0068f fVar3 = this.f345l;
        fVar3.f168E = mVar;
        fVar3.f169F = pVar;
        return fVar3;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.f334a);
        parcel.writeInt(this.f335b);
        parcel.writeInt(this.f336c ? 1 : 0);
        parcel.writeInt(this.f337d);
        parcel.writeInt(this.f338e);
        parcel.writeString(this.f339f);
        parcel.writeInt(this.f340g ? 1 : 0);
        parcel.writeInt(this.f341h ? 1 : 0);
        parcel.writeBundle(this.f342i);
        parcel.writeInt(this.f343j ? 1 : 0);
        parcel.writeBundle(this.f344k);
    }
}
