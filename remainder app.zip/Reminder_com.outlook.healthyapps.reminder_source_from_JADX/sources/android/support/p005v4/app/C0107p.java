package android.support.p005v4.app;

/* renamed from: android.support.v4.app.p */
public abstract class C0107p {
    /* renamed from: a */
    public abstract C0107p mo135a(C0068f fVar);

    /* renamed from: a */
    public abstract C0107p mo136a(C0068f fVar, String str);

    /* renamed from: b */
    public abstract int mo145b();

    /* renamed from: c */
    public abstract int mo149c();
}
