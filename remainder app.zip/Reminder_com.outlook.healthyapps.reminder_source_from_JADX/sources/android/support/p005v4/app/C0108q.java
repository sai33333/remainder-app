package android.support.p005v4.app;

import android.graphics.Rect;
import android.os.Build.VERSION;
import android.support.p005v4.p008c.C0151a;
import android.support.p005v4.p009d.C0170c;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

/* renamed from: android.support.v4.app.q */
class C0108q {

    /* renamed from: a */
    private static final int[] f346a = {0, 3, 0, 1, 5, 4, 7, 6, 9, 8};

    /* renamed from: b */
    private static final C0119s f347b = (VERSION.SDK_INT >= 21 ? new C0114r() : null);

    /* renamed from: c */
    private static final C0119s f348c = m543a();

    /* renamed from: android.support.v4.app.q$a */
    static class C0113a {

        /* renamed from: a */
        public C0068f f377a;

        /* renamed from: b */
        public boolean f378b;

        /* renamed from: c */
        public C0061b f379c;

        /* renamed from: d */
        public C0068f f380d;

        /* renamed from: e */
        public boolean f381e;

        /* renamed from: f */
        public C0061b f382f;

        C0113a() {
        }
    }

    /* renamed from: a */
    private static C0113a m542a(C0113a aVar, SparseArray<C0113a> sparseArray, int i) {
        if (aVar != null) {
            return aVar;
        }
        C0113a aVar2 = new C0113a();
        sparseArray.put(i, aVar2);
        return aVar2;
    }

    /* renamed from: a */
    private static C0119s m543a() {
        try {
            return (C0119s) Class.forName("android.support.transition.FragmentTransitionSupport").getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
        } catch (Exception unused) {
            return null;
        }
    }

    /* renamed from: a */
    private static C0119s m544a(C0068f fVar, C0068f fVar2) {
        ArrayList arrayList = new ArrayList();
        if (fVar != null) {
            Object y = fVar.mo272y();
            if (y != null) {
                arrayList.add(y);
            }
            Object x = fVar.mo271x();
            if (x != null) {
                arrayList.add(x);
            }
            Object B = fVar.mo178B();
            if (B != null) {
                arrayList.add(B);
            }
        }
        if (fVar2 != null) {
            Object w = fVar2.mo270w();
            if (w != null) {
                arrayList.add(w);
            }
            Object z = fVar2.mo273z();
            if (z != null) {
                arrayList.add(z);
            }
            Object A = fVar2.mo177A();
            if (A != null) {
                arrayList.add(A);
            }
        }
        if (arrayList.isEmpty()) {
            return null;
        }
        C0119s sVar = f347b;
        if (sVar != null && m565a(sVar, (List<Object>) arrayList)) {
            return f347b;
        }
        C0119s sVar2 = f348c;
        if (sVar2 != null && m565a(sVar2, (List<Object>) arrayList)) {
            return f348c;
        }
        if (f347b == null && f348c == null) {
            return null;
        }
        throw new IllegalArgumentException("Invalid Transition types");
    }

    /* renamed from: a */
    private static C0151a<String, String> m545a(int i, ArrayList<C0061b> arrayList, ArrayList<Boolean> arrayList2, int i2, int i3) {
        ArrayList<String> arrayList3;
        ArrayList arrayList4;
        C0151a<String, String> aVar = new C0151a<>();
        for (int i4 = i3 - 1; i4 >= i2; i4--) {
            C0061b bVar = (C0061b) arrayList.get(i4);
            if (bVar.mo148b(i)) {
                boolean booleanValue = ((Boolean) arrayList2.get(i4)).booleanValue();
                if (bVar.f129r != null) {
                    int size = bVar.f129r.size();
                    if (booleanValue) {
                        arrayList3 = bVar.f129r;
                        arrayList4 = bVar.f130s;
                    } else {
                        ArrayList arrayList5 = bVar.f129r;
                        arrayList3 = bVar.f130s;
                        arrayList4 = arrayList5;
                    }
                    for (int i5 = 0; i5 < size; i5++) {
                        String str = (String) arrayList4.get(i5);
                        String str2 = (String) arrayList3.get(i5);
                        String str3 = (String) aVar.remove(str2);
                        if (str3 != null) {
                            aVar.put(str, str3);
                        } else {
                            aVar.put(str, str2);
                        }
                    }
                }
            }
        }
        return aVar;
    }

    /* renamed from: a */
    static C0151a<String, View> m546a(C0119s sVar, C0151a<String, String> aVar, Object obj, C0113a aVar2) {
        C0142y yVar;
        ArrayList<String> arrayList;
        C0068f fVar = aVar2.f377a;
        View q = fVar.mo263q();
        if (aVar.isEmpty() || obj == null || q == null) {
            aVar.clear();
            return null;
        }
        C0151a<String, View> aVar3 = new C0151a<>();
        sVar.mo520a((Map<String, View>) aVar3, q);
        C0061b bVar = aVar2.f379c;
        if (aVar2.f378b) {
            yVar = fVar.mo197U();
            arrayList = bVar.f129r;
        } else {
            yVar = fVar.mo196T();
            arrayList = bVar.f130s;
        }
        if (arrayList != null) {
            aVar3.mo583a(arrayList);
            aVar3.mo583a(aVar.values());
        }
        if (yVar != null) {
            yVar.mo569a(arrayList, aVar3);
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                String str = (String) arrayList.get(size);
                View view = (View) aVar3.get(str);
                if (view == null) {
                    String a = m552a(aVar, str);
                    if (a != null) {
                        aVar.remove(a);
                    }
                } else if (!str.equals(C0170c.m765a(view))) {
                    String a2 = m552a(aVar, str);
                    if (a2 != null) {
                        aVar.put(a2, C0170c.m765a(view));
                    }
                }
            }
        } else {
            m562a(aVar, aVar3);
        }
        return aVar3;
    }

    /* renamed from: a */
    static View m547a(C0151a<String, View> aVar, C0113a aVar2, Object obj, boolean z) {
        C0061b bVar = aVar2.f379c;
        if (obj == null || aVar == null || bVar.f129r == null || bVar.f129r.isEmpty()) {
            return null;
        }
        return (View) aVar.get((String) (z ? bVar.f129r : bVar.f130s).get(0));
    }

    /* renamed from: a */
    private static Object m548a(C0119s sVar, C0068f fVar, C0068f fVar2, boolean z) {
        if (fVar == null || fVar2 == null) {
            return null;
        }
        return sVar.mo500c(sVar.mo495b(z ? fVar2.mo178B() : fVar.mo177A()));
    }

    /* renamed from: a */
    private static Object m549a(C0119s sVar, C0068f fVar, boolean z) {
        if (fVar == null) {
            return null;
        }
        return sVar.mo495b(z ? fVar.mo273z() : fVar.mo270w());
    }

    /* renamed from: a */
    private static Object m550a(C0119s sVar, ViewGroup viewGroup, View view, C0151a<String, String> aVar, C0113a aVar2, ArrayList<View> arrayList, ArrayList<View> arrayList2, Object obj, Object obj2) {
        Object obj3;
        final Rect rect;
        final View view2;
        C0119s sVar2 = sVar;
        View view3 = view;
        C0151a<String, String> aVar3 = aVar;
        C0113a aVar4 = aVar2;
        ArrayList<View> arrayList3 = arrayList;
        ArrayList<View> arrayList4 = arrayList2;
        Object obj4 = obj;
        C0068f fVar = aVar4.f377a;
        C0068f fVar2 = aVar4.f380d;
        if (fVar != null) {
            fVar.mo263q().setVisibility(0);
        }
        if (fVar == null || fVar2 == null) {
            return null;
        }
        boolean z = aVar4.f378b;
        Object a = aVar.isEmpty() ? null : m548a(sVar, fVar, fVar2, z);
        C0151a b = m566b(sVar, aVar3, a, aVar4);
        C0151a a2 = m546a(sVar, aVar3, a, aVar4);
        if (aVar.isEmpty()) {
            if (b != null) {
                b.clear();
            }
            if (a2 != null) {
                a2.clear();
            }
            obj3 = null;
        } else {
            m564a(arrayList3, b, (Collection<String>) aVar.keySet());
            m564a(arrayList4, a2, aVar.values());
            obj3 = a;
        }
        if (obj4 == null && obj2 == null && obj3 == null) {
            return null;
        }
        m556a(fVar, fVar2, z, b, true);
        if (obj3 != null) {
            arrayList4.add(view3);
            sVar.mo490a(obj3, view3, arrayList3);
            m561a(sVar, obj3, obj2, b, aVar4.f381e, aVar4.f382f);
            Rect rect2 = new Rect();
            View a3 = m547a(a2, aVar4, obj4, z);
            if (a3 != null) {
                sVar.mo488a(obj4, rect2);
            }
            rect = rect2;
            view2 = a3;
        } else {
            view2 = null;
            rect = null;
        }
        final C0068f fVar3 = fVar;
        final C0068f fVar4 = fVar2;
        final boolean z2 = z;
        final C0151a aVar5 = a2;
        final C0119s sVar3 = sVar;
        C01113 r0 = new Runnable() {
            public void run() {
                C0108q.m556a(fVar3, fVar4, z2, aVar5, false);
                View view = view2;
                if (view != null) {
                    sVar3.mo515a(view, rect);
                }
            }
        };
        C0140w.m665a(viewGroup, r0);
        return obj3;
    }

    /* renamed from: a */
    private static Object m551a(C0119s sVar, Object obj, Object obj2, Object obj3, C0068f fVar, boolean z) {
        boolean z2 = (obj == null || obj2 == null || fVar == null) ? true : z ? fVar.mo180D() : fVar.mo179C();
        return z2 ? sVar.mo486a(obj2, obj, obj3) : sVar.mo496b(obj2, obj, obj3);
    }

    /* renamed from: a */
    private static String m552a(C0151a<String, String> aVar, String str) {
        int size = aVar.size();
        for (int i = 0; i < size; i++) {
            if (str.equals(aVar.mo689c(i))) {
                return (String) aVar.mo688b(i);
            }
        }
        return null;
    }

    /* renamed from: a */
    static ArrayList<View> m553a(C0119s sVar, Object obj, C0068f fVar, ArrayList<View> arrayList, View view) {
        if (obj == null) {
            return null;
        }
        ArrayList<View> arrayList2 = new ArrayList<>();
        View q = fVar.mo263q();
        if (q != null) {
            sVar.mo519a(arrayList2, q);
        }
        if (arrayList != null) {
            arrayList2.removeAll(arrayList);
        }
        if (arrayList2.isEmpty()) {
            return arrayList2;
        }
        arrayList2.add(view);
        sVar.mo492a(obj, arrayList2);
        return arrayList2;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:19:0x0035, code lost:
        if (r10.f206u != false) goto L_0x008b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:41:0x006d, code lost:
        r1 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:42:0x006f, code lost:
        r1 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:47:0x007a, code lost:
        r13 = r1;
        r1 = false;
        r12 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:53:0x0089, code lost:
        if (r10.f174K == false) goto L_0x008b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:54:0x008b, code lost:
        r1 = true;
     */
    /* JADX WARNING: Removed duplicated region for block: B:59:0x009a  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static void m554a(android.support.p005v4.app.C0061b r16, android.support.p005v4.app.C0061b.C0062a r17, android.util.SparseArray<android.support.p005v4.app.C0108q.C0113a> r18, boolean r19, boolean r20) {
        /*
            r0 = r16
            r1 = r17
            r2 = r18
            r3 = r19
            android.support.v4.app.f r10 = r1.f134b
            if (r10 != 0) goto L_0x000d
            return
        L_0x000d:
            int r11 = r10.f172I
            if (r11 != 0) goto L_0x0012
            return
        L_0x0012:
            if (r3 == 0) goto L_0x001b
            int[] r4 = f346a
            int r1 = r1.f133a
            r1 = r4[r1]
            goto L_0x001d
        L_0x001b:
            int r1 = r1.f133a
        L_0x001d:
            r4 = 0
            r5 = 1
            if (r1 == r5) goto L_0x007e
            switch(r1) {
                case 3: goto L_0x0054;
                case 4: goto L_0x003c;
                case 5: goto L_0x0029;
                case 6: goto L_0x0054;
                case 7: goto L_0x007e;
                default: goto L_0x0024;
            }
        L_0x0024:
            r1 = r4
            r12 = r1
            r13 = r12
            goto L_0x0092
        L_0x0029:
            if (r20 == 0) goto L_0x0038
            boolean r1 = r10.f188Y
            if (r1 == 0) goto L_0x008d
            boolean r1 = r10.f174K
            if (r1 != 0) goto L_0x008d
            boolean r1 = r10.f206u
            if (r1 == 0) goto L_0x008d
            goto L_0x008b
        L_0x0038:
            boolean r1 = r10.f174K
            goto L_0x008e
        L_0x003c:
            if (r20 == 0) goto L_0x004b
            boolean r1 = r10.f188Y
            if (r1 == 0) goto L_0x006f
            boolean r1 = r10.f206u
            if (r1 == 0) goto L_0x006f
            boolean r1 = r10.f174K
            if (r1 == 0) goto L_0x006f
        L_0x004a:
            goto L_0x006d
        L_0x004b:
            boolean r1 = r10.f206u
            if (r1 == 0) goto L_0x006f
            boolean r1 = r10.f174K
            if (r1 != 0) goto L_0x006f
            goto L_0x004a
        L_0x0054:
            if (r20 == 0) goto L_0x0071
            boolean r1 = r10.f206u
            if (r1 != 0) goto L_0x006f
            android.view.View r1 = r10.f182S
            if (r1 == 0) goto L_0x006f
            android.view.View r1 = r10.f182S
            int r1 = r1.getVisibility()
            if (r1 != 0) goto L_0x006f
            float r1 = r10.f189Z
            r6 = 0
            int r1 = (r1 > r6 ? 1 : (r1 == r6 ? 0 : -1))
            if (r1 < 0) goto L_0x006f
        L_0x006d:
            r1 = r5
            goto L_0x007a
        L_0x006f:
            r1 = r4
            goto L_0x007a
        L_0x0071:
            boolean r1 = r10.f206u
            if (r1 == 0) goto L_0x006f
            boolean r1 = r10.f174K
            if (r1 != 0) goto L_0x006f
            goto L_0x006d
        L_0x007a:
            r13 = r1
            r1 = r4
            r12 = r5
            goto L_0x0092
        L_0x007e:
            if (r20 == 0) goto L_0x0083
            boolean r1 = r10.f187X
            goto L_0x008e
        L_0x0083:
            boolean r1 = r10.f206u
            if (r1 != 0) goto L_0x008d
            boolean r1 = r10.f174K
            if (r1 != 0) goto L_0x008d
        L_0x008b:
            r1 = r5
            goto L_0x008e
        L_0x008d:
            r1 = r4
        L_0x008e:
            r12 = r4
            r13 = r12
            r4 = r1
            r1 = r5
        L_0x0092:
            java.lang.Object r6 = r2.get(r11)
            android.support.v4.app.q$a r6 = (android.support.p005v4.app.C0108q.C0113a) r6
            if (r4 == 0) goto L_0x00a4
            android.support.v4.app.q$a r6 = m542a(r6, r2, r11)
            r6.f377a = r10
            r6.f378b = r3
            r6.f379c = r0
        L_0x00a4:
            r14 = r6
            r15 = 0
            if (r20 != 0) goto L_0x00cb
            if (r1 == 0) goto L_0x00cb
            if (r14 == 0) goto L_0x00b2
            android.support.v4.app.f r1 = r14.f380d
            if (r1 != r10) goto L_0x00b2
            r14.f380d = r15
        L_0x00b2:
            android.support.v4.app.l r4 = r0.f112a
            int r1 = r10.f196k
            if (r1 >= r5) goto L_0x00cb
            int r1 = r4.f278l
            if (r1 < r5) goto L_0x00cb
            boolean r1 = r0.f131t
            if (r1 != 0) goto L_0x00cb
            r4.mo416f(r10)
            r6 = 1
            r7 = 0
            r8 = 0
            r9 = 0
            r5 = r10
            r4.mo382a(r5, r6, r7, r8, r9)
        L_0x00cb:
            if (r13 == 0) goto L_0x00dd
            if (r14 == 0) goto L_0x00d3
            android.support.v4.app.f r1 = r14.f380d
            if (r1 != 0) goto L_0x00dd
        L_0x00d3:
            android.support.v4.app.q$a r14 = m542a(r14, r2, r11)
            r14.f380d = r10
            r14.f381e = r3
            r14.f382f = r0
        L_0x00dd:
            if (r20 != 0) goto L_0x00e9
            if (r12 == 0) goto L_0x00e9
            if (r14 == 0) goto L_0x00e9
            android.support.v4.app.f r0 = r14.f377a
            if (r0 != r10) goto L_0x00e9
            r14.f377a = r15
        L_0x00e9:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p005v4.app.C0108q.m554a(android.support.v4.app.b, android.support.v4.app.b$a, android.util.SparseArray, boolean, boolean):void");
    }

    /* renamed from: a */
    public static void m555a(C0061b bVar, SparseArray<C0113a> sparseArray, boolean z) {
        int size = bVar.f113b.size();
        for (int i = 0; i < size; i++) {
            m554a(bVar, (C0062a) bVar.f113b.get(i), sparseArray, false, z);
        }
    }

    /* renamed from: a */
    static void m556a(C0068f fVar, C0068f fVar2, boolean z, C0151a<String, View> aVar, boolean z2) {
        C0142y T = z ? fVar2.mo196T() : fVar.mo196T();
        if (T != null) {
            ArrayList arrayList = new ArrayList();
            ArrayList arrayList2 = new ArrayList();
            int size = aVar == null ? 0 : aVar.size();
            for (int i = 0; i < size; i++) {
                arrayList2.add(aVar.mo688b(i));
                arrayList.add(aVar.mo689c(i));
            }
            if (z2) {
                T.mo568a(arrayList2, arrayList, null);
            } else {
                T.mo570b(arrayList2, arrayList, null);
            }
        }
    }

    /* renamed from: a */
    private static void m557a(C0085l lVar, int i, C0113a aVar, View view, C0151a<String, String> aVar2) {
        Object obj;
        C0085l lVar2 = lVar;
        C0113a aVar3 = aVar;
        View view2 = view;
        ViewGroup viewGroup = lVar2.f280n.mo277a() ? (ViewGroup) lVar2.f280n.mo276a(i) : null;
        if (viewGroup != null) {
            C0068f fVar = aVar3.f377a;
            C0068f fVar2 = aVar3.f380d;
            C0119s a = m544a(fVar2, fVar);
            if (a != null) {
                boolean z = aVar3.f378b;
                boolean z2 = aVar3.f381e;
                ArrayList arrayList = new ArrayList();
                ArrayList arrayList2 = new ArrayList();
                Object a2 = m549a(a, fVar, z);
                Object b = m567b(a, fVar2, z2);
                Object obj2 = a2;
                ViewGroup viewGroup2 = viewGroup;
                ArrayList arrayList3 = arrayList2;
                Object a3 = m550a(a, viewGroup, view, aVar2, aVar, arrayList2, arrayList, a2, b);
                Object obj3 = obj2;
                if (obj3 == null && a3 == null) {
                    obj = b;
                    if (obj == null) {
                        return;
                    }
                } else {
                    obj = b;
                }
                ArrayList a4 = m553a(a, obj, fVar2, arrayList3, view2);
                ArrayList a5 = m553a(a, obj3, fVar, arrayList, view2);
                m563a(a5, 4);
                C0068f fVar3 = fVar;
                ArrayList arrayList4 = a4;
                Object a6 = m551a(a, obj3, obj, a3, fVar3, z);
                if (a6 != null) {
                    m560a(a, obj, fVar2, arrayList4);
                    ArrayList a7 = a.mo514a(arrayList);
                    a.mo491a(a6, obj3, a5, obj, arrayList4, a3, arrayList);
                    ViewGroup viewGroup3 = viewGroup2;
                    a.mo487a(viewGroup3, a6);
                    a.mo516a(viewGroup3, arrayList3, arrayList, a7, aVar2);
                    m563a(a5, 0);
                    a.mo493a(a3, arrayList3, arrayList);
                }
            }
        }
    }

    /* renamed from: a */
    static void m558a(C0085l lVar, ArrayList<C0061b> arrayList, ArrayList<Boolean> arrayList2, int i, int i2, boolean z) {
        if (lVar.f278l >= 1) {
            SparseArray sparseArray = new SparseArray();
            for (int i3 = i; i3 < i2; i3++) {
                C0061b bVar = (C0061b) arrayList.get(i3);
                if (((Boolean) arrayList2.get(i3)).booleanValue()) {
                    m569b(bVar, sparseArray, z);
                } else {
                    m555a(bVar, sparseArray, z);
                }
            }
            if (sparseArray.size() != 0) {
                View view = new View(lVar.f279m.mo347g());
                int size = sparseArray.size();
                for (int i4 = 0; i4 < size; i4++) {
                    int keyAt = sparseArray.keyAt(i4);
                    C0151a a = m545a(keyAt, arrayList, arrayList2, i, i2);
                    C0113a aVar = (C0113a) sparseArray.valueAt(i4);
                    if (z) {
                        m557a(lVar, keyAt, aVar, view, a);
                    } else {
                        m570b(lVar, keyAt, aVar, view, a);
                    }
                }
            }
        }
    }

    /* renamed from: a */
    private static void m559a(C0119s sVar, ViewGroup viewGroup, C0068f fVar, View view, ArrayList<View> arrayList, Object obj, ArrayList<View> arrayList2, Object obj2, ArrayList<View> arrayList3) {
        final Object obj3 = obj;
        final C0119s sVar2 = sVar;
        final View view2 = view;
        final C0068f fVar2 = fVar;
        final ArrayList<View> arrayList4 = arrayList;
        final ArrayList<View> arrayList5 = arrayList2;
        final ArrayList<View> arrayList6 = arrayList3;
        final Object obj4 = obj2;
        C01102 r0 = new Runnable() {
            public void run() {
                Object obj = obj3;
                if (obj != null) {
                    sVar2.mo501c(obj, view2);
                    arrayList5.addAll(C0108q.m553a(sVar2, obj3, fVar2, arrayList4, view2));
                }
                if (arrayList6 != null) {
                    if (obj4 != null) {
                        ArrayList arrayList = new ArrayList();
                        arrayList.add(view2);
                        sVar2.mo499b(obj4, arrayList6, arrayList);
                    }
                    arrayList6.clear();
                    arrayList6.add(view2);
                }
            }
        };
        ViewGroup viewGroup2 = viewGroup;
        C0140w.m665a(viewGroup, r0);
    }

    /* renamed from: a */
    private static void m560a(C0119s sVar, Object obj, C0068f fVar, final ArrayList<View> arrayList) {
        if (fVar != null && obj != null && fVar.f206u && fVar.f174K && fVar.f188Y) {
            fVar.mo242g(true);
            sVar.mo498b(obj, fVar.mo263q(), arrayList);
            C0140w.m665a(fVar.f181R, new Runnable() {
                public void run() {
                    C0108q.m563a(arrayList, 4);
                }
            });
        }
    }

    /* renamed from: a */
    private static void m561a(C0119s sVar, Object obj, Object obj2, C0151a<String, View> aVar, boolean z, C0061b bVar) {
        if (bVar.f129r != null && !bVar.f129r.isEmpty()) {
            View view = (View) aVar.get((String) (z ? bVar.f130s : bVar.f129r).get(0));
            sVar.mo489a(obj, view);
            if (obj2 != null) {
                sVar.mo489a(obj2, view);
            }
        }
    }

    /* renamed from: a */
    private static void m562a(C0151a<String, String> aVar, C0151a<String, View> aVar2) {
        for (int size = aVar.size() - 1; size >= 0; size--) {
            if (!aVar2.containsKey((String) aVar.mo689c(size))) {
                aVar.mo693d(size);
            }
        }
    }

    /* renamed from: a */
    static void m563a(ArrayList<View> arrayList, int i) {
        if (arrayList != null) {
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                ((View) arrayList.get(size)).setVisibility(i);
            }
        }
    }

    /* renamed from: a */
    private static void m564a(ArrayList<View> arrayList, C0151a<String, View> aVar, Collection<String> collection) {
        for (int size = aVar.size() - 1; size >= 0; size--) {
            View view = (View) aVar.mo689c(size);
            if (collection.contains(C0170c.m765a(view))) {
                arrayList.add(view);
            }
        }
    }

    /* renamed from: a */
    private static boolean m565a(C0119s sVar, List<Object> list) {
        int size = list.size();
        for (int i = 0; i < size; i++) {
            if (!sVar.mo494a(list.get(i))) {
                return false;
            }
        }
        return true;
    }

    /* renamed from: b */
    private static C0151a<String, View> m566b(C0119s sVar, C0151a<String, String> aVar, Object obj, C0113a aVar2) {
        C0142y yVar;
        ArrayList<String> arrayList;
        if (aVar.isEmpty() || obj == null) {
            aVar.clear();
            return null;
        }
        C0068f fVar = aVar2.f380d;
        C0151a<String, View> aVar3 = new C0151a<>();
        sVar.mo520a((Map<String, View>) aVar3, fVar.mo263q());
        C0061b bVar = aVar2.f382f;
        if (aVar2.f381e) {
            yVar = fVar.mo196T();
            arrayList = bVar.f130s;
        } else {
            yVar = fVar.mo197U();
            arrayList = bVar.f129r;
        }
        aVar3.mo583a(arrayList);
        if (yVar != null) {
            yVar.mo569a(arrayList, aVar3);
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                String str = (String) arrayList.get(size);
                View view = (View) aVar3.get(str);
                if (view == null) {
                    aVar.remove(str);
                } else if (!str.equals(C0170c.m765a(view))) {
                    aVar.put(C0170c.m765a(view), (String) aVar.remove(str));
                }
            }
        } else {
            aVar.mo583a(aVar3.keySet());
        }
        return aVar3;
    }

    /* renamed from: b */
    private static Object m567b(C0119s sVar, C0068f fVar, boolean z) {
        if (fVar == null) {
            return null;
        }
        return sVar.mo495b(z ? fVar.mo271x() : fVar.mo272y());
    }

    /* renamed from: b */
    private static Object m568b(C0119s sVar, ViewGroup viewGroup, View view, C0151a<String, String> aVar, C0113a aVar2, ArrayList<View> arrayList, ArrayList<View> arrayList2, Object obj, Object obj2) {
        C0151a<String, String> aVar3;
        Object obj3;
        Object obj4;
        Rect rect;
        C0119s sVar2 = sVar;
        C0113a aVar4 = aVar2;
        ArrayList<View> arrayList3 = arrayList;
        Object obj5 = obj;
        C0068f fVar = aVar4.f377a;
        C0068f fVar2 = aVar4.f380d;
        if (fVar == null || fVar2 == null) {
            return null;
        }
        boolean z = aVar4.f378b;
        if (aVar.isEmpty()) {
            aVar3 = aVar;
            obj3 = null;
        } else {
            obj3 = m548a(sVar2, fVar, fVar2, z);
            aVar3 = aVar;
        }
        C0151a b = m566b(sVar2, aVar3, obj3, aVar4);
        if (aVar.isEmpty()) {
            obj4 = null;
        } else {
            arrayList3.addAll(b.values());
            obj4 = obj3;
        }
        if (obj5 == null && obj2 == null && obj4 == null) {
            return null;
        }
        m556a(fVar, fVar2, z, b, true);
        if (obj4 != null) {
            rect = new Rect();
            sVar2.mo490a(obj4, view, arrayList3);
            m561a(sVar, obj4, obj2, b, aVar4.f381e, aVar4.f382f);
            if (obj5 != null) {
                sVar2.mo488a(obj5, rect);
            }
        } else {
            rect = null;
        }
        final C0119s sVar3 = sVar;
        final C0151a<String, String> aVar5 = aVar;
        final Object obj6 = obj4;
        final C0113a aVar6 = aVar2;
        C01124 r13 = r0;
        final ArrayList<View> arrayList4 = arrayList2;
        final View view2 = view;
        final C0068f fVar3 = fVar;
        final C0068f fVar4 = fVar2;
        final boolean z2 = z;
        final ArrayList<View> arrayList5 = arrayList;
        final Object obj7 = obj;
        final Rect rect2 = rect;
        C01124 r0 = new Runnable() {
            public void run() {
                C0151a a = C0108q.m546a(sVar3, aVar5, obj6, aVar6);
                if (a != null) {
                    arrayList4.addAll(a.values());
                    arrayList4.add(view2);
                }
                C0108q.m556a(fVar3, fVar4, z2, a, false);
                Object obj = obj6;
                if (obj != null) {
                    sVar3.mo493a(obj, arrayList5, arrayList4);
                    View a2 = C0108q.m547a(a, aVar6, obj7, z2);
                    if (a2 != null) {
                        sVar3.mo515a(a2, rect2);
                    }
                }
            }
        };
        C0140w.m665a(viewGroup, r13);
        return obj4;
    }

    /* renamed from: b */
    public static void m569b(C0061b bVar, SparseArray<C0113a> sparseArray, boolean z) {
        if (bVar.f112a.f280n.mo277a()) {
            for (int size = bVar.f113b.size() - 1; size >= 0; size--) {
                m554a(bVar, (C0062a) bVar.f113b.get(size), sparseArray, true, z);
            }
        }
    }

    /* renamed from: b */
    private static void m570b(C0085l lVar, int i, C0113a aVar, View view, C0151a<String, String> aVar2) {
        Object obj;
        C0085l lVar2 = lVar;
        C0113a aVar3 = aVar;
        View view2 = view;
        C0151a<String, String> aVar4 = aVar2;
        ViewGroup viewGroup = lVar2.f280n.mo277a() ? (ViewGroup) lVar2.f280n.mo276a(i) : null;
        if (viewGroup != null) {
            C0068f fVar = aVar3.f377a;
            C0068f fVar2 = aVar3.f380d;
            C0119s a = m544a(fVar2, fVar);
            if (a != null) {
                boolean z = aVar3.f378b;
                boolean z2 = aVar3.f381e;
                Object a2 = m549a(a, fVar, z);
                Object b = m567b(a, fVar2, z2);
                ArrayList arrayList = new ArrayList();
                ArrayList arrayList2 = new ArrayList();
                ArrayList arrayList3 = arrayList;
                Object obj2 = b;
                Object obj3 = a2;
                C0119s sVar = a;
                Object b2 = m568b(a, viewGroup, view, aVar2, aVar, arrayList, arrayList2, a2, obj2);
                Object obj4 = obj3;
                if (obj4 == null && b2 == null) {
                    obj = obj2;
                    if (obj == null) {
                        return;
                    }
                } else {
                    obj = obj2;
                }
                ArrayList a3 = m553a(sVar, obj, fVar2, arrayList3, view2);
                Object obj5 = (a3 == null || a3.isEmpty()) ? null : obj;
                sVar.mo497b(obj4, view2);
                Object a4 = m551a(sVar, obj4, obj5, b2, fVar, aVar3.f378b);
                if (a4 != null) {
                    ArrayList arrayList4 = new ArrayList();
                    C0119s sVar2 = sVar;
                    sVar2.mo491a(a4, obj4, arrayList4, obj5, a3, b2, arrayList2);
                    m559a(sVar2, viewGroup, fVar, view, arrayList2, obj4, arrayList4, obj5, a3);
                    ArrayList arrayList5 = arrayList2;
                    sVar.mo517a((View) viewGroup, arrayList5, (Map<String, String>) aVar4);
                    sVar.mo487a(viewGroup, a4);
                    sVar.mo518a(viewGroup, arrayList5, (Map<String, String>) aVar4);
                }
            }
        }
    }
}
