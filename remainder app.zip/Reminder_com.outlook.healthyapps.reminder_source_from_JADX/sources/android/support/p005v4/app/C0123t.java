package android.support.p005v4.app;

import android.app.Service;
import android.app.job.JobInfo;
import android.app.job.JobInfo.Builder;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobServiceEngine;
import android.app.job.JobWorkItem;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build.VERSION;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import java.util.ArrayList;
import java.util.HashMap;

/* renamed from: android.support.v4.app.t */
public abstract class C0123t extends Service {

    /* renamed from: h */
    static final Object f409h = new Object();

    /* renamed from: i */
    static final HashMap<ComponentName, C0132h> f410i = new HashMap<>();

    /* renamed from: a */
    C0125b f411a;

    /* renamed from: b */
    C0132h f412b;

    /* renamed from: c */
    C0124a f413c;

    /* renamed from: d */
    boolean f414d = false;

    /* renamed from: e */
    boolean f415e = false;

    /* renamed from: f */
    boolean f416f = false;

    /* renamed from: g */
    final ArrayList<C0127d> f417g;

    /* renamed from: android.support.v4.app.t$a */
    final class C0124a extends AsyncTask<Void, Void, Void> {
        C0124a() {
        }

        /* access modifiers changed from: protected */
        /* renamed from: a */
        public Void doInBackground(Void... voidArr) {
            while (true) {
                C0128e d = C0123t.this.mo529d();
                if (d == null) {
                    return null;
                }
                C0123t.this.mo524a(d.mo546a());
                d.mo547b();
            }
        }

        /* access modifiers changed from: protected */
        /* renamed from: a */
        public void onCancelled(Void voidR) {
            C0123t.this.mo528c();
        }

        /* access modifiers changed from: protected */
        /* renamed from: b */
        public void onPostExecute(Void voidR) {
            C0123t.this.mo528c();
        }
    }

    /* renamed from: android.support.v4.app.t$b */
    interface C0125b {
        /* renamed from: a */
        IBinder mo540a();

        /* renamed from: b */
        C0128e mo541b();
    }

    /* renamed from: android.support.v4.app.t$c */
    static final class C0126c extends C0132h {

        /* renamed from: a */
        boolean f419a;

        /* renamed from: b */
        boolean f420b;

        /* renamed from: f */
        private final Context f421f;

        /* renamed from: g */
        private final WakeLock f422g;

        /* renamed from: h */
        private final WakeLock f423h;

        C0126c(Context context, ComponentName componentName) {
            super(context, componentName);
            this.f421f = context.getApplicationContext();
            PowerManager powerManager = (PowerManager) context.getSystemService("power");
            StringBuilder sb = new StringBuilder();
            sb.append(componentName.getClassName());
            sb.append(":launch");
            this.f422g = powerManager.newWakeLock(1, sb.toString());
            this.f422g.setReferenceCounted(false);
            StringBuilder sb2 = new StringBuilder();
            sb2.append(componentName.getClassName());
            sb2.append(":run");
            this.f423h = powerManager.newWakeLock(1, sb2.toString());
            this.f423h.setReferenceCounted(false);
        }

        /* renamed from: a */
        public void mo542a() {
            synchronized (this) {
                this.f419a = false;
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo543a(Intent intent) {
            Intent intent2 = new Intent(intent);
            intent2.setComponent(this.f434c);
            if (this.f421f.startService(intent2) != null) {
                synchronized (this) {
                    if (!this.f419a) {
                        this.f419a = true;
                        if (!this.f420b) {
                            this.f422g.acquire(60000);
                        }
                    }
                }
            }
        }

        /* renamed from: b */
        public void mo544b() {
            synchronized (this) {
                if (!this.f420b) {
                    this.f420b = true;
                    this.f423h.acquire(600000);
                    this.f422g.release();
                }
            }
        }

        /* renamed from: c */
        public void mo545c() {
            synchronized (this) {
                if (this.f420b) {
                    if (this.f419a) {
                        this.f422g.acquire(60000);
                    }
                    this.f420b = false;
                    this.f423h.release();
                }
            }
        }
    }

    /* renamed from: android.support.v4.app.t$d */
    final class C0127d implements C0128e {

        /* renamed from: a */
        final Intent f424a;

        /* renamed from: b */
        final int f425b;

        C0127d(Intent intent, int i) {
            this.f424a = intent;
            this.f425b = i;
        }

        /* renamed from: a */
        public Intent mo546a() {
            return this.f424a;
        }

        /* renamed from: b */
        public void mo547b() {
            C0123t.this.stopSelf(this.f425b);
        }
    }

    /* renamed from: android.support.v4.app.t$e */
    interface C0128e {
        /* renamed from: a */
        Intent mo546a();

        /* renamed from: b */
        void mo547b();
    }

    /* renamed from: android.support.v4.app.t$f */
    static final class C0129f extends JobServiceEngine implements C0125b {

        /* renamed from: a */
        final C0123t f427a;

        /* renamed from: b */
        final Object f428b = new Object();

        /* renamed from: c */
        JobParameters f429c;

        /* renamed from: android.support.v4.app.t$f$a */
        final class C0130a implements C0128e {

            /* renamed from: a */
            final JobWorkItem f430a;

            C0130a(JobWorkItem jobWorkItem) {
                this.f430a = jobWorkItem;
            }

            /* renamed from: a */
            public Intent mo546a() {
                return this.f430a.getIntent();
            }

            /* renamed from: b */
            public void mo547b() {
                synchronized (C0129f.this.f428b) {
                    if (C0129f.this.f429c != null) {
                        C0129f.this.f429c.completeWork(this.f430a);
                    }
                }
            }
        }

        C0129f(C0123t tVar) {
            super(tVar);
            this.f427a = tVar;
        }

        /* renamed from: a */
        public IBinder mo540a() {
            return getBinder();
        }

        /* JADX WARNING: Code restructure failed: missing block: B:10:0x0013, code lost:
            r1.getIntent().setExtrasClassLoader(r3.f427a.getClassLoader());
         */
        /* JADX WARNING: Code restructure failed: missing block: B:11:0x0025, code lost:
            return new android.support.p005v4.app.C0123t.C0129f.C0130a(r3, r1);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:12:0x0026, code lost:
            return null;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:9:0x0011, code lost:
            if (r1 == null) goto L_0x0026;
         */
        /* renamed from: b */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public android.support.p005v4.app.C0123t.C0128e mo541b() {
            /*
                r3 = this;
                java.lang.Object r0 = r3.f428b
                monitor-enter(r0)
                android.app.job.JobParameters r1 = r3.f429c     // Catch:{ all -> 0x0027 }
                r2 = 0
                if (r1 != 0) goto L_0x000a
                monitor-exit(r0)     // Catch:{ all -> 0x0027 }
                return r2
            L_0x000a:
                android.app.job.JobParameters r1 = r3.f429c     // Catch:{ all -> 0x0027 }
                android.app.job.JobWorkItem r1 = r1.dequeueWork()     // Catch:{ all -> 0x0027 }
                monitor-exit(r0)     // Catch:{ all -> 0x0027 }
                if (r1 == 0) goto L_0x0026
                android.content.Intent r0 = r1.getIntent()
                android.support.v4.app.t r2 = r3.f427a
                java.lang.ClassLoader r2 = r2.getClassLoader()
                r0.setExtrasClassLoader(r2)
                android.support.v4.app.t$f$a r0 = new android.support.v4.app.t$f$a
                r0.<init>(r1)
                return r0
            L_0x0026:
                return r2
            L_0x0027:
                r1 = move-exception
                monitor-exit(r0)     // Catch:{ all -> 0x0027 }
                throw r1
            */
            throw new UnsupportedOperationException("Method not decompiled: android.support.p005v4.app.C0123t.C0129f.mo541b():android.support.v4.app.t$e");
        }

        public boolean onStartJob(JobParameters jobParameters) {
            this.f429c = jobParameters;
            this.f427a.mo525a(false);
            return true;
        }

        public boolean onStopJob(JobParameters jobParameters) {
            boolean b = this.f427a.mo527b();
            synchronized (this.f428b) {
                this.f429c = null;
            }
            return b;
        }
    }

    /* renamed from: android.support.v4.app.t$g */
    static final class C0131g extends C0132h {

        /* renamed from: a */
        private final JobInfo f432a;

        /* renamed from: b */
        private final JobScheduler f433b;

        C0131g(Context context, ComponentName componentName, int i) {
            super(context, componentName);
            mo550a(i);
            this.f432a = new Builder(i, this.f434c).setOverrideDeadline(0).build();
            this.f433b = (JobScheduler) context.getApplicationContext().getSystemService("jobscheduler");
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo543a(Intent intent) {
            this.f433b.enqueue(this.f432a, new JobWorkItem(intent));
        }
    }

    /* renamed from: android.support.v4.app.t$h */
    static abstract class C0132h {

        /* renamed from: c */
        final ComponentName f434c;

        /* renamed from: d */
        boolean f435d;

        /* renamed from: e */
        int f436e;

        C0132h(Context context, ComponentName componentName) {
            this.f434c = componentName;
        }

        /* renamed from: a */
        public void mo542a() {
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo550a(int i) {
            if (!this.f435d) {
                this.f435d = true;
                this.f436e = i;
            } else if (this.f436e != i) {
                StringBuilder sb = new StringBuilder();
                sb.append("Given job ID ");
                sb.append(i);
                sb.append(" is different than previous ");
                sb.append(this.f436e);
                throw new IllegalArgumentException(sb.toString());
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public abstract void mo543a(Intent intent);

        /* renamed from: b */
        public void mo544b() {
        }

        /* renamed from: c */
        public void mo545c() {
        }
    }

    public C0123t() {
        this.f417g = VERSION.SDK_INT >= 26 ? null : new ArrayList<>();
    }

    /* renamed from: a */
    static C0132h m615a(Context context, ComponentName componentName, boolean z, int i) {
        C0132h hVar;
        C0132h hVar2 = (C0132h) f410i.get(componentName);
        if (hVar2 != null) {
            return hVar2;
        }
        if (VERSION.SDK_INT < 26) {
            hVar = new C0126c(context, componentName);
        } else if (z) {
            hVar = new C0131g(context, componentName, i);
        } else {
            throw new IllegalArgumentException("Can't be here without a job id");
        }
        C0132h hVar3 = hVar;
        f410i.put(componentName, hVar3);
        return hVar3;
    }

    /* renamed from: a */
    public static void m616a(Context context, ComponentName componentName, int i, Intent intent) {
        if (intent != null) {
            synchronized (f409h) {
                C0132h a = m615a(context, componentName, true, i);
                a.mo550a(i);
                a.mo543a(intent);
            }
            return;
        }
        throw new IllegalArgumentException("work must not be null");
    }

    /* renamed from: a */
    public static void m617a(Context context, Class cls, int i, Intent intent) {
        m616a(context, new ComponentName(context, cls), i, intent);
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public abstract void mo524a(Intent intent);

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo525a(boolean z) {
        if (this.f413c == null) {
            this.f413c = new C0124a();
            C0132h hVar = this.f412b;
            if (hVar != null && z) {
                hVar.mo544b();
            }
            this.f413c.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Void[0]);
        }
    }

    /* renamed from: a */
    public boolean mo526a() {
        return true;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public boolean mo527b() {
        C0124a aVar = this.f413c;
        if (aVar != null) {
            aVar.cancel(this.f414d);
        }
        this.f415e = true;
        return mo526a();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public void mo528c() {
        ArrayList<C0127d> arrayList = this.f417g;
        if (arrayList != null) {
            synchronized (arrayList) {
                this.f413c = null;
                if (this.f417g != null && this.f417g.size() > 0) {
                    mo525a(false);
                } else if (!this.f416f) {
                    this.f412b.mo545c();
                }
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: d */
    public C0128e mo529d() {
        C0125b bVar = this.f411a;
        if (bVar != null) {
            return bVar.mo541b();
        }
        synchronized (this.f417g) {
            if (this.f417g.size() <= 0) {
                return null;
            }
            C0128e eVar = (C0128e) this.f417g.remove(0);
            return eVar;
        }
    }

    public IBinder onBind(Intent intent) {
        C0125b bVar = this.f411a;
        if (bVar != null) {
            return bVar.mo540a();
        }
        return null;
    }

    public void onCreate() {
        super.onCreate();
        if (VERSION.SDK_INT >= 26) {
            this.f411a = new C0129f(this);
            this.f412b = null;
            return;
        }
        this.f411a = null;
        this.f412b = m615a((Context) this, new ComponentName(this, getClass()), false, 0);
    }

    public void onDestroy() {
        super.onDestroy();
        ArrayList<C0127d> arrayList = this.f417g;
        if (arrayList != null) {
            synchronized (arrayList) {
                this.f416f = true;
                this.f412b.mo545c();
            }
        }
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        if (this.f417g == null) {
            return 2;
        }
        this.f412b.mo542a();
        synchronized (this.f417g) {
            ArrayList<C0127d> arrayList = this.f417g;
            if (intent == null) {
                intent = new Intent();
            }
            arrayList.add(new C0127d(intent, i2));
            mo525a(true);
        }
        return 3;
    }
}
