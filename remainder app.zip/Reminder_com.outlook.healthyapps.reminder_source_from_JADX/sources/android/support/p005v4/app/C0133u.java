package android.support.p005v4.app;

import android.arch.lifecycle.C0028e;
import android.arch.lifecycle.C0044q;
import android.support.p005v4.p006a.C0049b;
import java.io.FileDescriptor;
import java.io.PrintWriter;

/* renamed from: android.support.v4.app.u */
public abstract class C0133u {

    /* renamed from: android.support.v4.app.u$a */
    public interface C0134a<D> {
        /* renamed from: a */
        void mo551a(C0049b<D> bVar);

        /* renamed from: a */
        void mo552a(C0049b<D> bVar, D d);
    }

    /* renamed from: a */
    public static <T extends C0028e & C0044q> C0133u m647a(T t) {
        return new LoaderManagerImpl(t, ((C0044q) t).mo88b());
    }

    /* renamed from: a */
    public abstract void mo109a();

    @Deprecated
    /* renamed from: a */
    public abstract void mo110a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr);
}
