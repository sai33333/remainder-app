package android.support.p005v4.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.p004a.C0045a.C0046a;
import java.util.ArrayList;

/* renamed from: android.support.v4.app.v */
public class C0135v {

    /* renamed from: android.support.v4.app.v$a */
    public static class C0136a {

        /* renamed from: a */
        final Bundle f437a;

        /* renamed from: b */
        boolean f438b;

        /* renamed from: c */
        public int f439c;

        /* renamed from: d */
        public CharSequence f440d;

        /* renamed from: e */
        public PendingIntent f441e;

        /* renamed from: f */
        private final C0141x[] f442f;

        /* renamed from: g */
        private final C0141x[] f443g;

        /* renamed from: h */
        private boolean f444h;

        /* renamed from: i */
        private final int f445i;

        public C0136a(int i, CharSequence charSequence, PendingIntent pendingIntent) {
            this(i, charSequence, pendingIntent, new Bundle(), null, null, true, 0, true);
        }

        C0136a(int i, CharSequence charSequence, PendingIntent pendingIntent, Bundle bundle, C0141x[] xVarArr, C0141x[] xVarArr2, boolean z, int i2, boolean z2) {
            this.f438b = true;
            this.f439c = i;
            this.f440d = C0138c.m654d(charSequence);
            this.f441e = pendingIntent;
            if (bundle == null) {
                bundle = new Bundle();
            }
            this.f437a = bundle;
            this.f442f = xVarArr;
            this.f443g = xVarArr2;
            this.f444h = z;
            this.f445i = i2;
            this.f438b = z2;
        }
    }

    /* renamed from: android.support.v4.app.v$b */
    public static class C0137b extends C0139d {

        /* renamed from: c */
        private CharSequence f446c;

        /* renamed from: a */
        public C0137b mo553a(CharSequence charSequence) {
            this.f446c = C0138c.m654d(charSequence);
            return this;
        }
    }

    /* renamed from: android.support.v4.app.v$c */
    public static class C0138c {

        /* renamed from: a */
        public Context f447a;

        /* renamed from: b */
        public ArrayList<C0136a> f448b;

        /* renamed from: c */
        ArrayList<C0136a> f449c;

        /* renamed from: d */
        CharSequence f450d;

        /* renamed from: e */
        CharSequence f451e;

        /* renamed from: f */
        PendingIntent f452f;

        /* renamed from: g */
        Bitmap f453g;

        /* renamed from: h */
        int f454h;

        /* renamed from: i */
        boolean f455i;

        /* renamed from: j */
        C0139d f456j;

        /* renamed from: k */
        boolean f457k;

        /* renamed from: l */
        int f458l;

        /* renamed from: m */
        int f459m;

        /* renamed from: n */
        String f460n;

        /* renamed from: o */
        int f461o;

        /* renamed from: p */
        int f462p;

        /* renamed from: q */
        Notification f463q;
        @Deprecated

        /* renamed from: r */
        public ArrayList<String> f464r;

        @Deprecated
        public C0138c(Context context) {
            this(context, null);
        }

        public C0138c(Context context, String str) {
            this.f448b = new ArrayList<>();
            this.f449c = new ArrayList<>();
            this.f455i = true;
            this.f457k = false;
            this.f458l = 0;
            this.f459m = 0;
            this.f461o = 0;
            this.f462p = 0;
            this.f463q = new Notification();
            this.f447a = context;
            this.f460n = str;
            this.f463q.when = System.currentTimeMillis();
            this.f463q.audioStreamType = -1;
            this.f454h = 0;
            this.f464r = new ArrayList<>();
        }

        /* renamed from: b */
        private Bitmap m653b(Bitmap bitmap) {
            if (bitmap != null && VERSION.SDK_INT < 27) {
                Resources resources = this.f447a.getResources();
                int dimensionPixelSize = resources.getDimensionPixelSize(C0046a.compat_notification_large_icon_max_width);
                int dimensionPixelSize2 = resources.getDimensionPixelSize(C0046a.compat_notification_large_icon_max_height);
                if (bitmap.getWidth() <= dimensionPixelSize && bitmap.getHeight() <= dimensionPixelSize2) {
                    return bitmap;
                }
                double min = Math.min(((double) dimensionPixelSize) / ((double) Math.max(1, bitmap.getWidth())), ((double) dimensionPixelSize2) / ((double) Math.max(1, bitmap.getHeight())));
                bitmap = Bitmap.createScaledBitmap(bitmap, (int) Math.ceil(((double) bitmap.getWidth()) * min), (int) Math.ceil(((double) bitmap.getHeight()) * min), true);
            }
            return bitmap;
        }

        /* renamed from: d */
        protected static CharSequence m654d(CharSequence charSequence) {
            if (charSequence == null) {
                return charSequence;
            }
            if (charSequence.length() > 5120) {
                charSequence = charSequence.subSequence(0, 5120);
            }
            return charSequence;
        }

        /* renamed from: a */
        public C0138c mo554a(int i) {
            this.f463q.icon = i;
            return this;
        }

        /* renamed from: a */
        public C0138c mo555a(int i, CharSequence charSequence, PendingIntent pendingIntent) {
            this.f448b.add(new C0136a(i, charSequence, pendingIntent));
            return this;
        }

        /* renamed from: a */
        public C0138c mo556a(PendingIntent pendingIntent) {
            this.f452f = pendingIntent;
            return this;
        }

        /* renamed from: a */
        public C0138c mo557a(Bitmap bitmap) {
            this.f453g = m653b(bitmap);
            return this;
        }

        /* renamed from: a */
        public C0138c mo558a(C0139d dVar) {
            if (this.f456j != dVar) {
                this.f456j = dVar;
                C0139d dVar2 = this.f456j;
                if (dVar2 != null) {
                    dVar2.mo563a(this);
                }
            }
            return this;
        }

        /* renamed from: a */
        public C0138c mo559a(CharSequence charSequence) {
            this.f450d = m654d(charSequence);
            return this;
        }

        /* renamed from: b */
        public C0138c mo560b(int i) {
            this.f454h = i;
            return this;
        }

        /* renamed from: b */
        public C0138c mo561b(CharSequence charSequence) {
            this.f451e = m654d(charSequence);
            return this;
        }

        /* renamed from: c */
        public C0138c mo562c(CharSequence charSequence) {
            this.f463q.tickerText = m654d(charSequence);
            return this;
        }
    }

    /* renamed from: android.support.v4.app.v$d */
    public static abstract class C0139d {

        /* renamed from: a */
        protected C0138c f465a;

        /* renamed from: b */
        boolean f466b = false;

        /* renamed from: a */
        public void mo563a(C0138c cVar) {
            if (this.f465a != cVar) {
                this.f465a = cVar;
                C0138c cVar2 = this.f465a;
                if (cVar2 != null) {
                    cVar2.mo558a(this);
                }
            }
        }
    }
}
