package android.support.p005v4.app;

import android.view.View;
import android.view.View.OnAttachStateChangeListener;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnPreDrawListener;

/* renamed from: android.support.v4.app.w */
class C0140w implements OnAttachStateChangeListener, OnPreDrawListener {

    /* renamed from: a */
    private final View f467a;

    /* renamed from: b */
    private ViewTreeObserver f468b;

    /* renamed from: c */
    private final Runnable f469c;

    private C0140w(View view, Runnable runnable) {
        this.f467a = view;
        this.f468b = view.getViewTreeObserver();
        this.f469c = runnable;
    }

    /* renamed from: a */
    public static C0140w m665a(View view, Runnable runnable) {
        C0140w wVar = new C0140w(view, runnable);
        view.getViewTreeObserver().addOnPreDrawListener(wVar);
        view.addOnAttachStateChangeListener(wVar);
        return wVar;
    }

    /* renamed from: a */
    public void mo564a() {
        (this.f468b.isAlive() ? this.f468b : this.f467a.getViewTreeObserver()).removeOnPreDrawListener(this);
        this.f467a.removeOnAttachStateChangeListener(this);
    }

    public boolean onPreDraw() {
        mo564a();
        this.f469c.run();
        return true;
    }

    public void onViewAttachedToWindow(View view) {
        this.f468b = view.getViewTreeObserver();
    }

    public void onViewDetachedFromWindow(View view) {
        mo564a();
    }
}
