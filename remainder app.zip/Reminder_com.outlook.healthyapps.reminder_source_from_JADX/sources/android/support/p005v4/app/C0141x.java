package android.support.p005v4.app;

/* renamed from: android.support.v4.app.x */
public final class C0141x {
}
