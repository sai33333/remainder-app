package android.support.p005v4.app;

import android.view.View;
import java.util.List;
import java.util.Map;

/* renamed from: android.support.v4.app.y */
public abstract class C0142y {
    /* renamed from: a */
    public void mo568a(List<String> list, List<View> list2, List<View> list3) {
    }

    /* renamed from: a */
    public void mo569a(List<String> list, Map<String, View> map) {
    }

    /* renamed from: b */
    public void mo570b(List<String> list, List<View> list2, List<View> list3) {
    }
}
