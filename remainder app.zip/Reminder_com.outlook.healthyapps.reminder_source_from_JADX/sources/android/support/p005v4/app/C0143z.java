package android.support.p005v4.app;

import android.util.AndroidRuntimeException;

/* renamed from: android.support.v4.app.z */
final class C0143z extends AndroidRuntimeException {
    public C0143z(String str) {
        super(str);
    }
}
