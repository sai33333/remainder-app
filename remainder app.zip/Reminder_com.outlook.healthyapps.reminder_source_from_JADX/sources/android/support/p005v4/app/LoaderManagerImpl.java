package android.support.p005v4.app;

import android.arch.lifecycle.C0028e;
import android.arch.lifecycle.C0035j;
import android.arch.lifecycle.C0036k;
import android.arch.lifecycle.C0040n;
import android.arch.lifecycle.C0041o;
import android.arch.lifecycle.C0041o.C0042a;
import android.arch.lifecycle.C0043p;
import android.os.Bundle;
import android.support.p005v4.app.C0133u.C0134a;
import android.support.p005v4.p006a.C0049b;
import android.support.p005v4.p006a.C0049b.C0050a;
import android.support.p005v4.p008c.C0156d;
import android.support.p005v4.p008c.C0166i;
import android.util.Log;
import java.io.FileDescriptor;
import java.io.PrintWriter;

/* renamed from: android.support.v4.app.LoaderManagerImpl */
class LoaderManagerImpl extends C0133u {

    /* renamed from: a */
    static boolean f91a = false;

    /* renamed from: b */
    private final C0028e f92b;

    /* renamed from: c */
    private final LoaderViewModel f93c;

    /* renamed from: android.support.v4.app.LoaderManagerImpl$LoaderViewModel */
    static class LoaderViewModel extends C0040n {

        /* renamed from: a */
        private static final C0042a f94a = new C0042a() {
            /* renamed from: a */
            public <T extends C0040n> T mo84a(Class<T> cls) {
                return new LoaderViewModel();
            }
        };

        /* renamed from: b */
        private C0166i<C0053a> f95b = new C0166i<>();

        /* renamed from: c */
        private boolean f96c = false;

        LoaderViewModel() {
        }

        /* renamed from: a */
        static LoaderViewModel m150a(C0043p pVar) {
            return (LoaderViewModel) new C0041o(pVar, f94a).mo82a(LoaderViewModel.class);
        }

        /* access modifiers changed from: protected */
        /* renamed from: a */
        public void mo81a() {
            super.mo81a();
            int b = this.f95b.mo705b();
            for (int i = 0; i < b; i++) {
                ((C0053a) this.f95b.mo712e(i)).mo114a(true);
            }
            this.f95b.mo708c();
        }

        /* renamed from: a */
        public void mo112a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
            if (this.f95b.mo705b() > 0) {
                printWriter.print(str);
                printWriter.println("Loaders:");
                StringBuilder sb = new StringBuilder();
                sb.append(str);
                sb.append("    ");
                String sb2 = sb.toString();
                for (int i = 0; i < this.f95b.mo705b(); i++) {
                    C0053a aVar = (C0053a) this.f95b.mo712e(i);
                    printWriter.print(str);
                    printWriter.print("  #");
                    printWriter.print(this.f95b.mo711d(i));
                    printWriter.print(": ");
                    printWriter.println(aVar.toString());
                    aVar.mo115a(sb2, fileDescriptor, printWriter, strArr);
                }
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public void mo113b() {
            int b = this.f95b.mo705b();
            for (int i = 0; i < b; i++) {
                ((C0053a) this.f95b.mo712e(i)).mo117g();
            }
        }
    }

    /* renamed from: android.support.v4.app.LoaderManagerImpl$a */
    public static class C0053a<D> extends C0035j<D> implements C0050a<D> {

        /* renamed from: a */
        private final int f97a;

        /* renamed from: b */
        private final Bundle f98b;

        /* renamed from: c */
        private final C0049b<D> f99c;

        /* renamed from: d */
        private C0028e f100d;

        /* renamed from: e */
        private C0054b<D> f101e;

        /* renamed from: f */
        private C0049b<D> f102f;

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public C0049b<D> mo114a(boolean z) {
            if (LoaderManagerImpl.f91a) {
                StringBuilder sb = new StringBuilder();
                sb.append("  Destroying: ");
                sb.append(this);
                Log.v("LoaderManager", sb.toString());
            }
            this.f99c.mo94c();
            this.f99c.mo98g();
            C0054b<D> bVar = this.f101e;
            if (bVar != null) {
                mo44a((C0036k<? super D>) bVar);
                if (z) {
                    bVar.mo121b();
                }
            }
            this.f99c.mo91a((C0050a<D>) this);
            if ((bVar == null || bVar.mo120a()) && !z) {
                return this.f99c;
            }
            this.f99c.mo100i();
            return this.f102f;
        }

        /* renamed from: a */
        public void mo44a(C0036k<? super D> kVar) {
            super.mo44a(kVar);
            this.f100d = null;
            this.f101e = null;
        }

        /* renamed from: a */
        public void mo45a(D d) {
            super.mo45a(d);
            C0049b<D> bVar = this.f102f;
            if (bVar != null) {
                bVar.mo100i();
                this.f102f = null;
            }
        }

        /* renamed from: a */
        public void mo115a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
            printWriter.print(str);
            printWriter.print("mId=");
            printWriter.print(this.f97a);
            printWriter.print(" mArgs=");
            printWriter.println(this.f98b);
            printWriter.print(str);
            printWriter.print("mLoader=");
            printWriter.println(this.f99c);
            C0049b<D> bVar = this.f99c;
            StringBuilder sb = new StringBuilder();
            sb.append(str);
            sb.append("  ");
            bVar.mo92a(sb.toString(), fileDescriptor, printWriter, strArr);
            if (this.f101e != null) {
                printWriter.print(str);
                printWriter.print("mCallbacks=");
                printWriter.println(this.f101e);
                C0054b<D> bVar2 = this.f101e;
                StringBuilder sb2 = new StringBuilder();
                sb2.append(str);
                sb2.append("  ");
                bVar2.mo119a(sb2.toString(), printWriter);
            }
            printWriter.print(str);
            printWriter.print("mData=");
            printWriter.println(mo116f().mo89a(mo42a()));
            printWriter.print(str);
            printWriter.print("mStarted=");
            printWriter.println(mo48d());
        }

        /* access modifiers changed from: protected */
        /* renamed from: b */
        public void mo46b() {
            if (LoaderManagerImpl.f91a) {
                StringBuilder sb = new StringBuilder();
                sb.append("  Starting: ");
                sb.append(this);
                Log.v("LoaderManager", sb.toString());
            }
            this.f99c.mo90a();
        }

        /* access modifiers changed from: protected */
        /* renamed from: c */
        public void mo47c() {
            if (LoaderManagerImpl.f91a) {
                StringBuilder sb = new StringBuilder();
                sb.append("  Stopping: ");
                sb.append(this);
                Log.v("LoaderManager", sb.toString());
            }
            this.f99c.mo96e();
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: f */
        public C0049b<D> mo116f() {
            return this.f99c;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: g */
        public void mo117g() {
            C0028e eVar = this.f100d;
            C0054b<D> bVar = this.f101e;
            if (eVar != null && bVar != null) {
                super.mo44a((C0036k<T>) bVar);
                mo43a(eVar, (C0036k<T>) bVar);
            }
        }

        public String toString() {
            StringBuilder sb = new StringBuilder(64);
            sb.append("LoaderInfo{");
            sb.append(Integer.toHexString(System.identityHashCode(this)));
            sb.append(" #");
            sb.append(this.f97a);
            sb.append(" : ");
            C0156d.m710a(this.f99c, sb);
            sb.append("}}");
            return sb.toString();
        }
    }

    /* renamed from: android.support.v4.app.LoaderManagerImpl$b */
    static class C0054b<D> implements C0036k<D> {

        /* renamed from: a */
        private final C0049b<D> f103a;

        /* renamed from: b */
        private final C0134a<D> f104b;

        /* renamed from: c */
        private boolean f105c;

        /* renamed from: a */
        public void mo70a(D d) {
            if (LoaderManagerImpl.f91a) {
                StringBuilder sb = new StringBuilder();
                sb.append("  onLoadFinished in ");
                sb.append(this.f103a);
                sb.append(": ");
                sb.append(this.f103a.mo89a(d));
                Log.v("LoaderManager", sb.toString());
            }
            this.f104b.mo552a(this.f103a, d);
            this.f105c = true;
        }

        /* renamed from: a */
        public void mo119a(String str, PrintWriter printWriter) {
            printWriter.print(str);
            printWriter.print("mDeliveredData=");
            printWriter.println(this.f105c);
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public boolean mo120a() {
            return this.f105c;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public void mo121b() {
            if (this.f105c) {
                if (LoaderManagerImpl.f91a) {
                    StringBuilder sb = new StringBuilder();
                    sb.append("  Resetting: ");
                    sb.append(this.f103a);
                    Log.v("LoaderManager", sb.toString());
                }
                this.f104b.mo551a(this.f103a);
            }
        }

        public String toString() {
            return this.f104b.toString();
        }
    }

    LoaderManagerImpl(C0028e eVar, C0043p pVar) {
        this.f92b = eVar;
        this.f93c = LoaderViewModel.m150a(pVar);
    }

    /* renamed from: a */
    public void mo109a() {
        this.f93c.mo113b();
    }

    @Deprecated
    /* renamed from: a */
    public void mo110a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        this.f93c.mo112a(str, fileDescriptor, printWriter, strArr);
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("LoaderManager{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append(" in ");
        C0156d.m710a(this.f92b, sb);
        sb.append("}}");
        return sb.toString();
    }
}
