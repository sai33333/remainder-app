package android.support.p005v4.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Icon;
import android.os.Build.VERSION;
import android.os.Parcelable;
import android.util.Log;
import androidx.versionedparcelable.CustomVersionedParcelable;
import com.google.android.gms.internal.C1217ty;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.Charset;

/* renamed from: android.support.v4.graphics.drawable.IconCompat */
public class IconCompat extends CustomVersionedParcelable {

    /* renamed from: h */
    static final Mode f537h = Mode.SRC_IN;

    /* renamed from: a */
    public int f538a;

    /* renamed from: b */
    Object f539b;

    /* renamed from: c */
    public byte[] f540c;

    /* renamed from: d */
    public Parcelable f541d;

    /* renamed from: e */
    public int f542e;

    /* renamed from: f */
    public int f543f;

    /* renamed from: g */
    public ColorStateList f544g = null;

    /* renamed from: i */
    Mode f545i = f537h;

    /* renamed from: j */
    public String f546j;

    /* renamed from: a */
    private static String m780a(int i) {
        switch (i) {
            case 1:
                return "BITMAP";
            case 2:
                return "RESOURCE";
            case 3:
                return "DATA";
            case C1217ty.f4597d /*4*/:
                return "URI";
            case C1217ty.f4598e /*5*/:
                return "BITMAP_MASKABLE";
            default:
                return "UNKNOWN";
        }
    }

    /* renamed from: a */
    private static String m781a(Icon icon) {
        if (VERSION.SDK_INT >= 28) {
            return icon.getResPackage();
        }
        try {
            return (String) icon.getClass().getMethod("getResPackage", new Class[0]).invoke(icon, new Object[0]);
        } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException e) {
            Log.e("IconCompat", "Unable to get icon package", e);
            return null;
        }
    }

    /* renamed from: b */
    private static int m782b(Icon icon) {
        if (VERSION.SDK_INT >= 28) {
            return icon.getResId();
        }
        try {
            return ((Integer) icon.getClass().getMethod("getResId", new Class[0]).invoke(icon, new Object[0])).intValue();
        } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException e) {
            Log.e("IconCompat", "Unable to get icon resource", e);
            return 0;
        }
    }

    /* renamed from: a */
    public String mo717a() {
        if (this.f538a == -1 && VERSION.SDK_INT >= 23) {
            return m781a((Icon) this.f539b);
        }
        if (this.f538a == 2) {
            return ((String) this.f539b).split(":", -1)[0];
        }
        StringBuilder sb = new StringBuilder();
        sb.append("called getResPackage() on ");
        sb.append(this);
        throw new IllegalStateException(sb.toString());
    }

    /* JADX WARNING: Code restructure failed: missing block: B:15:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:6:0x0021, code lost:
        r4 = r4.getBytes(java.nio.charset.Charset.forName("UTF-16"));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:7:0x002b, code lost:
        r3.f540c = r4;
     */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo718a(boolean r4) {
        /*
            r3 = this;
            android.graphics.PorterDuff$Mode r0 = r3.f545i
            java.lang.String r0 = r0.name()
            r3.f546j = r0
            int r0 = r3.f538a
            r1 = -1
            if (r0 == r1) goto L_0x0045
            switch(r0) {
                case 1: goto L_0x002e;
                case 2: goto L_0x001d;
                case 3: goto L_0x0018;
                case 4: goto L_0x0011;
                case 5: goto L_0x002e;
                default: goto L_0x0010;
            }
        L_0x0010:
            goto L_0x004d
        L_0x0011:
            java.lang.Object r4 = r3.f539b
            java.lang.String r4 = r4.toString()
            goto L_0x0021
        L_0x0018:
            java.lang.Object r4 = r3.f539b
            byte[] r4 = (byte[]) r4
            goto L_0x002b
        L_0x001d:
            java.lang.Object r4 = r3.f539b
            java.lang.String r4 = (java.lang.String) r4
        L_0x0021:
            java.lang.String r0 = "UTF-16"
            java.nio.charset.Charset r0 = java.nio.charset.Charset.forName(r0)
            byte[] r4 = r4.getBytes(r0)
        L_0x002b:
            r3.f540c = r4
            goto L_0x004d
        L_0x002e:
            if (r4 == 0) goto L_0x0047
            java.lang.Object r4 = r3.f539b
            android.graphics.Bitmap r4 = (android.graphics.Bitmap) r4
            java.io.ByteArrayOutputStream r0 = new java.io.ByteArrayOutputStream
            r0.<init>()
            android.graphics.Bitmap$CompressFormat r1 = android.graphics.Bitmap.CompressFormat.PNG
            r2 = 90
            r4.compress(r1, r2, r0)
            byte[] r4 = r0.toByteArray()
            goto L_0x002b
        L_0x0045:
            if (r4 != 0) goto L_0x004e
        L_0x0047:
            java.lang.Object r4 = r3.f539b
            android.os.Parcelable r4 = (android.os.Parcelable) r4
            r3.f541d = r4
        L_0x004d:
            return
        L_0x004e:
            java.lang.IllegalArgumentException r4 = new java.lang.IllegalArgumentException
            java.lang.String r0 = "Can't serialize Icon created with IconCompat#createFromIcon"
            r4.<init>(r0)
            throw r4
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p005v4.graphics.drawable.IconCompat.mo718a(boolean):void");
    }

    /* renamed from: b */
    public int mo719b() {
        if (this.f538a == -1 && VERSION.SDK_INT >= 23) {
            return m782b((Icon) this.f539b);
        }
        if (this.f538a == 2) {
            return this.f542e;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("called getResId() on ");
        sb.append(this);
        throw new IllegalStateException(sb.toString());
    }

    /* renamed from: c */
    public void mo720c() {
        Object obj;
        this.f545i = Mode.valueOf(this.f546j);
        int i = this.f538a;
        if (i != -1) {
            switch (i) {
                case 1:
                case C1217ty.f4598e /*5*/:
                    obj = this.f541d;
                    if (obj == null) {
                        byte[] bArr = this.f540c;
                        this.f539b = bArr;
                        this.f538a = 3;
                        this.f542e = 0;
                        this.f543f = bArr.length;
                        return;
                    }
                    break;
                case 2:
                case C1217ty.f4597d /*4*/:
                    obj = new String(this.f540c, Charset.forName("UTF-16"));
                    break;
                case 3:
                    obj = this.f540c;
                    break;
                default:
                    return;
            }
        } else {
            obj = this.f541d;
            if (obj == null) {
                throw new IllegalArgumentException("Invalid icon");
            }
        }
        this.f539b = obj;
    }

    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.lang.String toString() {
        /*
            r5 = this;
            int r0 = r5.f538a
            r1 = -1
            if (r0 != r1) goto L_0x000c
            java.lang.Object r0 = r5.f539b
            java.lang.String r0 = java.lang.String.valueOf(r0)
            return r0
        L_0x000c:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r1 = "Icon(typ="
            r0.<init>(r1)
            int r1 = r5.f538a
            java.lang.String r1 = m780a(r1)
            r0.append(r1)
            int r1 = r5.f538a
            switch(r1) {
                case 1: goto L_0x006c;
                case 2: goto L_0x0043;
                case 3: goto L_0x002d;
                case 4: goto L_0x0022;
                case 5: goto L_0x006c;
                default: goto L_0x0021;
            }
        L_0x0021:
            goto L_0x008c
        L_0x0022:
            java.lang.String r1 = " uri="
            r0.append(r1)
            java.lang.Object r1 = r5.f539b
            r0.append(r1)
            goto L_0x008c
        L_0x002d:
            java.lang.String r1 = " len="
            r0.append(r1)
            int r1 = r5.f542e
            r0.append(r1)
            int r1 = r5.f543f
            if (r1 == 0) goto L_0x008c
            java.lang.String r1 = " off="
            r0.append(r1)
            int r1 = r5.f543f
            goto L_0x0089
        L_0x0043:
            java.lang.String r1 = " pkg="
            r0.append(r1)
            java.lang.String r1 = r5.mo717a()
            r0.append(r1)
            java.lang.String r1 = " id="
            r0.append(r1)
            java.lang.String r1 = "0x%08x"
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = 0
            int r4 = r5.mo719b()
            java.lang.Integer r4 = java.lang.Integer.valueOf(r4)
            r2[r3] = r4
            java.lang.String r1 = java.lang.String.format(r1, r2)
            r0.append(r1)
            goto L_0x008c
        L_0x006c:
            java.lang.String r1 = " size="
            r0.append(r1)
            java.lang.Object r1 = r5.f539b
            android.graphics.Bitmap r1 = (android.graphics.Bitmap) r1
            int r1 = r1.getWidth()
            r0.append(r1)
            java.lang.String r1 = "x"
            r0.append(r1)
            java.lang.Object r1 = r5.f539b
            android.graphics.Bitmap r1 = (android.graphics.Bitmap) r1
            int r1 = r1.getHeight()
        L_0x0089:
            r0.append(r1)
        L_0x008c:
            android.content.res.ColorStateList r1 = r5.f544g
            if (r1 == 0) goto L_0x009a
            java.lang.String r1 = " tint="
            r0.append(r1)
            android.content.res.ColorStateList r1 = r5.f544g
            r0.append(r1)
        L_0x009a:
            android.graphics.PorterDuff$Mode r1 = r5.f545i
            android.graphics.PorterDuff$Mode r2 = f537h
            if (r1 == r2) goto L_0x00aa
            java.lang.String r1 = " mode="
            r0.append(r1)
            android.graphics.PorterDuff$Mode r1 = r5.f545i
            r0.append(r1)
        L_0x00aa:
            java.lang.String r1 = ")"
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p005v4.graphics.drawable.IconCompat.toString():java.lang.String");
    }
}
