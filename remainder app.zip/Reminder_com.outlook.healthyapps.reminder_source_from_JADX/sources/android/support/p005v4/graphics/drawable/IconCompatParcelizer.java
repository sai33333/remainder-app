package android.support.p005v4.graphics.drawable;

import androidx.versionedparcelable.C0218a;

/* renamed from: android.support.v4.graphics.drawable.IconCompatParcelizer */
public final class IconCompatParcelizer extends androidx.core.graphics.drawable.IconCompatParcelizer {
    public static IconCompat read(C0218a aVar) {
        return androidx.core.graphics.drawable.IconCompatParcelizer.read(aVar);
    }

    public static void write(IconCompat iconCompat, C0218a aVar) {
        androidx.core.graphics.drawable.IconCompatParcelizer.write(iconCompat, aVar);
    }
}
