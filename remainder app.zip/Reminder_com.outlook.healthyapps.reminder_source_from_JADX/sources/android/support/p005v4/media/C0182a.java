package android.support.p005v4.media;

import androidx.versionedparcelable.C0220c;

/* renamed from: android.support.v4.media.a */
interface C0182a extends C0220c {
}
