package android.support.p005v4.media;

import android.annotation.TargetApi;
import android.media.AudioAttributes;

@TargetApi(21)
/* renamed from: android.support.v4.media.b */
class C0183b implements C0182a {

    /* renamed from: a */
    AudioAttributes f586a;

    /* renamed from: b */
    int f587b = -1;

    C0183b() {
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof C0183b)) {
            return false;
        }
        return this.f586a.equals(((C0183b) obj).f586a);
    }

    public int hashCode() {
        return this.f586a.hashCode();
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("AudioAttributesCompat: audioattributes=");
        sb.append(this.f586a);
        return sb.toString();
    }
}
