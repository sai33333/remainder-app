package android.support.p005v4.media;

import java.util.Arrays;

/* renamed from: android.support.v4.media.c */
class C0184c implements C0182a {

    /* renamed from: a */
    int f588a = 0;

    /* renamed from: b */
    int f589b = 0;

    /* renamed from: c */
    int f590c = 0;

    /* renamed from: d */
    int f591d = -1;

    C0184c() {
    }

    /* renamed from: a */
    public int mo772a() {
        int i = this.f591d;
        return i != -1 ? i : AudioAttributesCompat.m787a(false, this.f590c, this.f588a);
    }

    /* renamed from: b */
    public int mo773b() {
        return this.f589b;
    }

    /* renamed from: c */
    public int mo774c() {
        return this.f588a;
    }

    /* renamed from: d */
    public int mo775d() {
        int i = this.f590c;
        int a = mo772a();
        if (a == 6) {
            i |= 4;
        } else if (a == 7) {
            i |= 1;
        }
        return i & 273;
    }

    public boolean equals(Object obj) {
        boolean z = false;
        if (!(obj instanceof C0184c)) {
            return false;
        }
        C0184c cVar = (C0184c) obj;
        if (this.f589b == cVar.mo773b() && this.f590c == cVar.mo775d() && this.f588a == cVar.mo774c() && this.f591d == cVar.f591d) {
            z = true;
        }
        return z;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(this.f589b), Integer.valueOf(this.f590c), Integer.valueOf(this.f588a), Integer.valueOf(this.f591d)});
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("AudioAttributesCompat:");
        if (this.f591d != -1) {
            sb.append(" stream=");
            sb.append(this.f591d);
            sb.append(" derived");
        }
        sb.append(" usage=");
        sb.append(AudioAttributesCompat.m788a(this.f588a));
        sb.append(" content=");
        sb.append(this.f589b);
        sb.append(" flags=0x");
        sb.append(Integer.toHexString(this.f590c).toUpperCase());
        return sb.toString();
    }
}
