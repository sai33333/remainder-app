package android.support.p005v4.media;

import android.media.MediaDescription;
import android.media.MediaDescription.Builder;
import android.net.Uri;

/* renamed from: android.support.v4.media.e */
class C0187e {

    /* renamed from: android.support.v4.media.e$a */
    static class C0188a {
        /* renamed from: a */
        public static void m842a(Object obj, Uri uri) {
            ((Builder) obj).setMediaUri(uri);
        }
    }

    /* renamed from: a */
    public static Uri m841a(Object obj) {
        return ((MediaDescription) obj).getMediaUri();
    }
}
