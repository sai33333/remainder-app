package android.support.p005v4.media;

import android.media.MediaMetadata;
import android.os.Parcel;

/* renamed from: android.support.v4.media.f */
class C0189f {
    /* renamed from: a */
    public static void m843a(Object obj, Parcel parcel, int i) {
        ((MediaMetadata) obj).writeToParcel(parcel, i);
    }
}
