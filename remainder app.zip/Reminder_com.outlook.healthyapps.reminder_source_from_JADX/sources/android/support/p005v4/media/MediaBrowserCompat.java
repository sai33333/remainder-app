package android.support.p005v4.media;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.p005v4.media.session.MediaSessionCompat;
import android.support.p005v4.p007b.C0147b;
import android.util.Log;
import com.google.android.gms.C0276a.C0278b;
import java.util.ArrayList;
import java.util.List;

/* renamed from: android.support.v4.media.MediaBrowserCompat */
public final class MediaBrowserCompat {

    /* renamed from: a */
    static final boolean f550a = Log.isLoggable("MediaBrowserCompat", 3);

    /* renamed from: android.support.v4.media.MediaBrowserCompat$CustomActionResultReceiver */
    private static class CustomActionResultReceiver extends C0147b {

        /* renamed from: d */
        private final String f551d;

        /* renamed from: e */
        private final Bundle f552e;

        /* renamed from: f */
        private final C0175a f553f;

        /* access modifiers changed from: protected */
        /* renamed from: a */
        public void mo575a(int i, Bundle bundle) {
            if (this.f553f != null) {
                MediaSessionCompat.m885a(bundle);
                switch (i) {
                    case -1:
                        this.f553f.mo734c(this.f551d, this.f552e, bundle);
                        break;
                    case C0278b.AdsAttrs_adSize /*0*/:
                        this.f553f.mo733b(this.f551d, this.f552e, bundle);
                        break;
                    case 1:
                        this.f553f.mo732a(this.f551d, this.f552e, bundle);
                        break;
                    default:
                        StringBuilder sb = new StringBuilder();
                        sb.append("Unknown result code: ");
                        sb.append(i);
                        sb.append(" (extras=");
                        sb.append(this.f552e);
                        sb.append(", resultData=");
                        sb.append(bundle);
                        sb.append(")");
                        Log.w("MediaBrowserCompat", sb.toString());
                        break;
                }
            }
        }
    }

    /* renamed from: android.support.v4.media.MediaBrowserCompat$ItemReceiver */
    private static class ItemReceiver extends C0147b {

        /* renamed from: d */
        private final String f554d;

        /* renamed from: e */
        private final C0176b f555e;

        /* access modifiers changed from: protected */
        /* renamed from: a */
        public void mo575a(int i, Bundle bundle) {
            MediaSessionCompat.m885a(bundle);
            if (i != 0 || bundle == null || !bundle.containsKey("media_item")) {
                this.f555e.mo736a(this.f554d);
                return;
            }
            Parcelable parcelable = bundle.getParcelable("media_item");
            if (parcelable == null || (parcelable instanceof MediaItem)) {
                this.f555e.mo735a((MediaItem) parcelable);
            } else {
                this.f555e.mo736a(this.f554d);
            }
        }
    }

    /* renamed from: android.support.v4.media.MediaBrowserCompat$MediaItem */
    public static class MediaItem implements Parcelable {
        public static final Creator<MediaItem> CREATOR = new Creator<MediaItem>() {
            /* renamed from: a */
            public MediaItem createFromParcel(Parcel parcel) {
                return new MediaItem(parcel);
            }

            /* renamed from: a */
            public MediaItem[] newArray(int i) {
                return new MediaItem[i];
            }
        };

        /* renamed from: a */
        private final int f556a;

        /* renamed from: b */
        private final MediaDescriptionCompat f557b;

        MediaItem(Parcel parcel) {
            this.f556a = parcel.readInt();
            this.f557b = (MediaDescriptionCompat) MediaDescriptionCompat.CREATOR.createFromParcel(parcel);
        }

        public int describeContents() {
            return 0;
        }

        public String toString() {
            StringBuilder sb = new StringBuilder("MediaItem{");
            sb.append("mFlags=");
            sb.append(this.f556a);
            sb.append(", mDescription=");
            sb.append(this.f557b);
            sb.append('}');
            return sb.toString();
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeInt(this.f556a);
            this.f557b.writeToParcel(parcel, i);
        }
    }

    /* renamed from: android.support.v4.media.MediaBrowserCompat$SearchResultReceiver */
    private static class SearchResultReceiver extends C0147b {

        /* renamed from: d */
        private final String f558d;

        /* renamed from: e */
        private final Bundle f559e;

        /* renamed from: f */
        private final C0177c f560f;

        /* access modifiers changed from: protected */
        /* renamed from: a */
        public void mo575a(int i, Bundle bundle) {
            MediaSessionCompat.m885a(bundle);
            if (i != 0 || bundle == null || !bundle.containsKey("search_results")) {
                this.f560f.mo737a(this.f558d, this.f559e);
                return;
            }
            Parcelable[] parcelableArray = bundle.getParcelableArray("search_results");
            ArrayList arrayList = null;
            if (parcelableArray != null) {
                arrayList = new ArrayList();
                for (Parcelable parcelable : parcelableArray) {
                    arrayList.add((MediaItem) parcelable);
                }
            }
            this.f560f.mo738a(this.f558d, this.f559e, arrayList);
        }
    }

    /* renamed from: android.support.v4.media.MediaBrowserCompat$a */
    public static abstract class C0175a {
        /* renamed from: a */
        public void mo732a(String str, Bundle bundle, Bundle bundle2) {
        }

        /* renamed from: b */
        public void mo733b(String str, Bundle bundle, Bundle bundle2) {
        }

        /* renamed from: c */
        public void mo734c(String str, Bundle bundle, Bundle bundle2) {
        }
    }

    /* renamed from: android.support.v4.media.MediaBrowserCompat$b */
    public static abstract class C0176b {
        /* renamed from: a */
        public void mo735a(MediaItem mediaItem) {
        }

        /* renamed from: a */
        public void mo736a(String str) {
        }
    }

    /* renamed from: android.support.v4.media.MediaBrowserCompat$c */
    public static abstract class C0177c {
        /* renamed from: a */
        public void mo737a(String str, Bundle bundle) {
        }

        /* renamed from: a */
        public void mo738a(String str, Bundle bundle, List<MediaItem> list) {
        }
    }
}
