package android.support.p005v4.media;

import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.text.TextUtils;

/* renamed from: android.support.v4.media.MediaDescriptionCompat */
public final class MediaDescriptionCompat implements Parcelable {
    public static final Creator<MediaDescriptionCompat> CREATOR = new Creator<MediaDescriptionCompat>() {
        /* renamed from: a */
        public MediaDescriptionCompat createFromParcel(Parcel parcel) {
            return VERSION.SDK_INT < 21 ? new MediaDescriptionCompat(parcel) : MediaDescriptionCompat.m801a(C0185d.m823a(parcel));
        }

        /* renamed from: a */
        public MediaDescriptionCompat[] newArray(int i) {
            return new MediaDescriptionCompat[i];
        }
    };

    /* renamed from: a */
    private final String f561a;

    /* renamed from: b */
    private final CharSequence f562b;

    /* renamed from: c */
    private final CharSequence f563c;

    /* renamed from: d */
    private final CharSequence f564d;

    /* renamed from: e */
    private final Bitmap f565e;

    /* renamed from: f */
    private final Uri f566f;

    /* renamed from: g */
    private final Bundle f567g;

    /* renamed from: h */
    private final Uri f568h;

    /* renamed from: i */
    private Object f569i;

    /* renamed from: android.support.v4.media.MediaDescriptionCompat$a */
    public static final class C0179a {

        /* renamed from: a */
        private String f570a;

        /* renamed from: b */
        private CharSequence f571b;

        /* renamed from: c */
        private CharSequence f572c;

        /* renamed from: d */
        private CharSequence f573d;

        /* renamed from: e */
        private Bitmap f574e;

        /* renamed from: f */
        private Uri f575f;

        /* renamed from: g */
        private Bundle f576g;

        /* renamed from: h */
        private Uri f577h;

        /* renamed from: a */
        public C0179a mo747a(Bitmap bitmap) {
            this.f574e = bitmap;
            return this;
        }

        /* renamed from: a */
        public C0179a mo748a(Uri uri) {
            this.f575f = uri;
            return this;
        }

        /* renamed from: a */
        public C0179a mo749a(Bundle bundle) {
            this.f576g = bundle;
            return this;
        }

        /* renamed from: a */
        public C0179a mo750a(CharSequence charSequence) {
            this.f571b = charSequence;
            return this;
        }

        /* renamed from: a */
        public C0179a mo751a(String str) {
            this.f570a = str;
            return this;
        }

        /* renamed from: a */
        public MediaDescriptionCompat mo752a() {
            MediaDescriptionCompat mediaDescriptionCompat = new MediaDescriptionCompat(this.f570a, this.f571b, this.f572c, this.f573d, this.f574e, this.f575f, this.f576g, this.f577h);
            return mediaDescriptionCompat;
        }

        /* renamed from: b */
        public C0179a mo753b(Uri uri) {
            this.f577h = uri;
            return this;
        }

        /* renamed from: b */
        public C0179a mo754b(CharSequence charSequence) {
            this.f572c = charSequence;
            return this;
        }

        /* renamed from: c */
        public C0179a mo755c(CharSequence charSequence) {
            this.f573d = charSequence;
            return this;
        }
    }

    MediaDescriptionCompat(Parcel parcel) {
        this.f561a = parcel.readString();
        this.f562b = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.f563c = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.f564d = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        ClassLoader classLoader = getClass().getClassLoader();
        this.f565e = (Bitmap) parcel.readParcelable(classLoader);
        this.f566f = (Uri) parcel.readParcelable(classLoader);
        this.f567g = parcel.readBundle(classLoader);
        this.f568h = (Uri) parcel.readParcelable(classLoader);
    }

    MediaDescriptionCompat(String str, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, Bitmap bitmap, Uri uri, Bundle bundle, Uri uri2) {
        this.f561a = str;
        this.f562b = charSequence;
        this.f563c = charSequence2;
        this.f564d = charSequence3;
        this.f565e = bitmap;
        this.f566f = uri;
        this.f567g = bundle;
        this.f568h = uri2;
    }

    /* JADX WARNING: Removed duplicated region for block: B:17:0x006d  */
    /* JADX WARNING: Removed duplicated region for block: B:18:0x0071  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static android.support.p005v4.media.MediaDescriptionCompat m801a(java.lang.Object r6) {
        /*
            r0 = 0
            if (r6 == 0) goto L_0x0084
            int r1 = android.os.Build.VERSION.SDK_INT
            r2 = 21
            if (r1 < r2) goto L_0x0084
            android.support.v4.media.MediaDescriptionCompat$a r1 = new android.support.v4.media.MediaDescriptionCompat$a
            r1.<init>()
            java.lang.String r2 = android.support.p005v4.media.C0185d.m824a(r6)
            r1.mo751a(r2)
            java.lang.CharSequence r2 = android.support.p005v4.media.C0185d.m826b(r6)
            r1.mo750a(r2)
            java.lang.CharSequence r2 = android.support.p005v4.media.C0185d.m827c(r6)
            r1.mo754b(r2)
            java.lang.CharSequence r2 = android.support.p005v4.media.C0185d.m828d(r6)
            r1.mo755c(r2)
            android.graphics.Bitmap r2 = android.support.p005v4.media.C0185d.m829e(r6)
            r1.mo747a(r2)
            android.net.Uri r2 = android.support.p005v4.media.C0185d.m830f(r6)
            r1.mo748a(r2)
            android.os.Bundle r2 = android.support.p005v4.media.C0185d.m831g(r6)
            if (r2 == 0) goto L_0x004a
            android.support.p005v4.media.session.MediaSessionCompat.m885a(r2)
            java.lang.String r3 = "android.support.v4.media.description.MEDIA_URI"
            android.os.Parcelable r3 = r2.getParcelable(r3)
            android.net.Uri r3 = (android.net.Uri) r3
            goto L_0x004b
        L_0x004a:
            r3 = r0
        L_0x004b:
            if (r3 == 0) goto L_0x0067
            java.lang.String r4 = "android.support.v4.media.description.NULL_BUNDLE_FLAG"
            boolean r4 = r2.containsKey(r4)
            if (r4 == 0) goto L_0x005d
            int r4 = r2.size()
            r5 = 2
            if (r4 != r5) goto L_0x005d
            goto L_0x0068
        L_0x005d:
            java.lang.String r0 = "android.support.v4.media.description.MEDIA_URI"
            r2.remove(r0)
            java.lang.String r0 = "android.support.v4.media.description.NULL_BUNDLE_FLAG"
            r2.remove(r0)
        L_0x0067:
            r0 = r2
        L_0x0068:
            r1.mo749a(r0)
            if (r3 == 0) goto L_0x0071
            r1.mo753b(r3)
            goto L_0x007e
        L_0x0071:
            int r0 = android.os.Build.VERSION.SDK_INT
            r2 = 23
            if (r0 < r2) goto L_0x007e
            android.net.Uri r0 = android.support.p005v4.media.C0187e.m841a(r6)
            r1.mo753b(r0)
        L_0x007e:
            android.support.v4.media.MediaDescriptionCompat r0 = r1.mo752a()
            r0.f569i = r6
        L_0x0084:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p005v4.media.MediaDescriptionCompat.m801a(java.lang.Object):android.support.v4.media.MediaDescriptionCompat");
    }

    /* renamed from: a */
    public Object mo739a() {
        if (this.f569i != null || VERSION.SDK_INT < 21) {
            return this.f569i;
        }
        Object a = C0186a.m832a();
        C0186a.m838a(a, this.f561a);
        C0186a.m837a(a, this.f562b);
        C0186a.m839b(a, this.f563c);
        C0186a.m840c(a, this.f564d);
        C0186a.m834a(a, this.f565e);
        C0186a.m835a(a, this.f566f);
        Bundle bundle = this.f567g;
        if (VERSION.SDK_INT < 23 && this.f568h != null) {
            if (bundle == null) {
                bundle = new Bundle();
                bundle.putBoolean("android.support.v4.media.description.NULL_BUNDLE_FLAG", true);
            }
            bundle.putParcelable("android.support.v4.media.description.MEDIA_URI", this.f568h);
        }
        C0186a.m836a(a, bundle);
        if (VERSION.SDK_INT >= 23) {
            C0188a.m842a(a, this.f568h);
        }
        this.f569i = C0186a.m833a(a);
        return this.f569i;
    }

    public int describeContents() {
        return 0;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(this.f562b);
        sb.append(", ");
        sb.append(this.f563c);
        sb.append(", ");
        sb.append(this.f564d);
        return sb.toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        if (VERSION.SDK_INT < 21) {
            parcel.writeString(this.f561a);
            TextUtils.writeToParcel(this.f562b, parcel, i);
            TextUtils.writeToParcel(this.f563c, parcel, i);
            TextUtils.writeToParcel(this.f564d, parcel, i);
            parcel.writeParcelable(this.f565e, i);
            parcel.writeParcelable(this.f566f, i);
            parcel.writeBundle(this.f567g);
            parcel.writeParcelable(this.f568h, i);
            return;
        }
        C0185d.m825a(mo739a(), parcel, i);
    }
}
