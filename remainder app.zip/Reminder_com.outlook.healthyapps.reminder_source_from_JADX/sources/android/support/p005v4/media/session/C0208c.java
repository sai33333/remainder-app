package android.support.p005v4.media.session;

import android.media.AudioAttributes;
import android.media.MediaMetadata;
import android.media.session.MediaController.Callback;
import android.media.session.MediaController.PlaybackInfo;
import android.media.session.MediaSession.QueueItem;
import android.media.session.PlaybackState;
import android.os.Bundle;
import com.google.android.gms.internal.C1217ty;
import java.util.List;

/* renamed from: android.support.v4.media.session.c */
class C0208c {

    /* renamed from: android.support.v4.media.session.c$a */
    public interface C0209a {
        /* renamed from: a */
        void mo801a();

        /* renamed from: a */
        void mo802a(int i, int i2, int i3, int i4, int i5);

        /* renamed from: a */
        void mo803a(Bundle bundle);

        /* renamed from: a */
        void mo804a(CharSequence charSequence);

        /* renamed from: a */
        void mo805a(Object obj);

        /* renamed from: a */
        void mo806a(String str, Bundle bundle);

        /* renamed from: a */
        void mo807a(List<?> list);

        /* renamed from: b */
        void mo808b(Object obj);
    }

    /* renamed from: android.support.v4.media.session.c$b */
    static class C0210b<T extends C0209a> extends Callback {

        /* renamed from: a */
        protected final T f640a;

        public C0210b(T t) {
            this.f640a = t;
        }

        public void onAudioInfoChanged(PlaybackInfo playbackInfo) {
            this.f640a.mo802a(playbackInfo.getPlaybackType(), C0211c.m1042b(playbackInfo), playbackInfo.getVolumeControl(), playbackInfo.getMaxVolume(), playbackInfo.getCurrentVolume());
        }

        public void onExtrasChanged(Bundle bundle) {
            MediaSessionCompat.m885a(bundle);
            this.f640a.mo803a(bundle);
        }

        public void onMetadataChanged(MediaMetadata mediaMetadata) {
            this.f640a.mo808b(mediaMetadata);
        }

        public void onPlaybackStateChanged(PlaybackState playbackState) {
            this.f640a.mo805a((Object) playbackState);
        }

        public void onQueueChanged(List<QueueItem> list) {
            this.f640a.mo807a(list);
        }

        public void onQueueTitleChanged(CharSequence charSequence) {
            this.f640a.mo804a(charSequence);
        }

        public void onSessionDestroyed() {
            this.f640a.mo801a();
        }

        public void onSessionEvent(String str, Bundle bundle) {
            MediaSessionCompat.m885a(bundle);
            this.f640a.mo806a(str, bundle);
        }
    }

    /* renamed from: android.support.v4.media.session.c$c */
    public static class C0211c {
        /* renamed from: a */
        private static int m1040a(AudioAttributes audioAttributes) {
            if ((audioAttributes.getFlags() & 1) == 1) {
                return 7;
            }
            if ((audioAttributes.getFlags() & 4) == 4) {
                return 6;
            }
            switch (audioAttributes.getUsage()) {
                case 1:
                case 11:
                case 12:
                case 14:
                    return 3;
                case 2:
                    return 0;
                case 3:
                    return 8;
                case C1217ty.f4597d /*4*/:
                    return 4;
                case C1217ty.f4598e /*5*/:
                case C1217ty.f4600g /*7*/:
                case C1217ty.f4601h /*8*/:
                case 9:
                case 10:
                    return 5;
                case C1217ty.f4599f /*6*/:
                    return 2;
                case 13:
                    return 1;
                default:
                    return 3;
            }
        }

        /* renamed from: a */
        public static AudioAttributes m1041a(Object obj) {
            return ((PlaybackInfo) obj).getAudioAttributes();
        }

        /* renamed from: b */
        public static int m1042b(Object obj) {
            return m1040a(m1041a(obj));
        }
    }

    /* renamed from: a */
    public static Object m1031a(C0209a aVar) {
        return new C0210b(aVar);
    }
}
