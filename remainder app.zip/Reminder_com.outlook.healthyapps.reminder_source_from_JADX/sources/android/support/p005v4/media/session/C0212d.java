package android.support.p005v4.media.session;

import android.media.session.MediaSession.QueueItem;

/* renamed from: android.support.v4.media.session.d */
class C0212d {

    /* renamed from: android.support.v4.media.session.d$a */
    static class C0213a {
        /* renamed from: a */
        public static Object m1043a(Object obj) {
            return ((QueueItem) obj).getDescription();
        }

        /* renamed from: b */
        public static long m1044b(Object obj) {
            return ((QueueItem) obj).getQueueId();
        }
    }
}
