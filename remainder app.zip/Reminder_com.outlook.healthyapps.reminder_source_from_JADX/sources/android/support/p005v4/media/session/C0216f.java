package android.support.p005v4.media.session;

import android.media.session.PlaybackState;
import android.os.Bundle;

/* renamed from: android.support.v4.media.session.f */
class C0216f {
    /* renamed from: a */
    public static Bundle m1058a(Object obj) {
        return ((PlaybackState) obj).getExtras();
    }
}
