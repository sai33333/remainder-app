package android.support.p005v4.media.session;

import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder.DeathRecipient;
import android.os.Message;
import android.os.RemoteException;
import android.os.ResultReceiver;
import android.support.p005v4.app.C0065d;
import android.support.p005v4.media.MediaMetadataCompat;
import android.support.p005v4.media.session.C0202a.C0203a;
import android.support.p005v4.media.session.C0205b.C0206a;
import android.support.p005v4.media.session.C0208c.C0209a;
import android.support.p005v4.media.session.MediaSessionCompat.QueueItem;
import android.support.p005v4.media.session.MediaSessionCompat.Token;
import android.util.Log;
import com.google.android.gms.internal.C1217ty;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.List;

/* renamed from: android.support.v4.media.session.MediaControllerCompat */
public final class MediaControllerCompat {

    /* renamed from: android.support.v4.media.session.MediaControllerCompat$MediaControllerImplApi21 */
    static class MediaControllerImplApi21 {

        /* renamed from: a */
        final Object f592a;

        /* renamed from: b */
        final Token f593b;

        /* renamed from: c */
        private final List<C0191a> f594c;

        /* renamed from: d */
        private HashMap<C0191a, C0190a> f595d;

        /* renamed from: android.support.v4.media.session.MediaControllerCompat$MediaControllerImplApi21$ExtraBinderRequestResultReceiver */
        private static class ExtraBinderRequestResultReceiver extends ResultReceiver {

            /* renamed from: a */
            private WeakReference<MediaControllerImplApi21> f596a;

            /* access modifiers changed from: protected */
            public void onReceiveResult(int i, Bundle bundle) {
                MediaControllerImplApi21 mediaControllerImplApi21 = (MediaControllerImplApi21) this.f596a.get();
                if (mediaControllerImplApi21 != null && bundle != null) {
                    synchronized (mediaControllerImplApi21.f592a) {
                        mediaControllerImplApi21.f593b.mo831a(C0206a.m981a(C0065d.m200a(bundle, "android.support.v4.media.session.EXTRA_BINDER")));
                        mediaControllerImplApi21.f593b.mo830a(bundle.getBundle("android.support.v4.media.session.SESSION_TOKEN2_BUNDLE"));
                        mediaControllerImplApi21.mo779a();
                    }
                }
            }
        }

        /* renamed from: android.support.v4.media.session.MediaControllerCompat$MediaControllerImplApi21$a */
        private static class C0190a extends C0194c {
            C0190a(C0191a aVar) {
                super(aVar);
            }

            /* renamed from: a */
            public void mo781a() {
                throw new AssertionError();
            }

            /* renamed from: a */
            public void mo782a(Bundle bundle) {
                throw new AssertionError();
            }

            /* renamed from: a */
            public void mo783a(MediaMetadataCompat mediaMetadataCompat) {
                throw new AssertionError();
            }

            /* renamed from: a */
            public void mo784a(ParcelableVolumeInfo parcelableVolumeInfo) {
                throw new AssertionError();
            }

            /* renamed from: a */
            public void mo785a(CharSequence charSequence) {
                throw new AssertionError();
            }

            /* renamed from: a */
            public void mo786a(List<QueueItem> list) {
                throw new AssertionError();
            }
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo779a() {
            if (this.f593b.mo829a() != null) {
                for (C0191a aVar : this.f594c) {
                    C0190a aVar2 = new C0190a(aVar);
                    this.f595d.put(aVar, aVar2);
                    aVar.f599c = aVar2;
                    try {
                        this.f593b.mo829a().mo871a((C0202a) aVar2);
                        aVar.mo789a(13, null, null);
                    } catch (RemoteException e) {
                        Log.e("MediaControllerCompat", "Dead object in registerCallback.", e);
                    }
                }
                this.f594c.clear();
            }
        }
    }

    /* renamed from: android.support.v4.media.session.MediaControllerCompat$a */
    public static abstract class C0191a implements DeathRecipient {

        /* renamed from: a */
        final Object f597a;

        /* renamed from: b */
        C0192a f598b;

        /* renamed from: c */
        C0202a f599c;

        /* renamed from: android.support.v4.media.session.MediaControllerCompat$a$a */
        private class C0192a extends Handler {

            /* renamed from: a */
            boolean f600a;

            /* renamed from: b */
            final /* synthetic */ C0191a f601b;

            public void handleMessage(Message message) {
                if (this.f600a) {
                    switch (message.what) {
                        case 1:
                            Bundle data = message.getData();
                            MediaSessionCompat.m885a(data);
                            this.f601b.mo795a((String) message.obj, data);
                            break;
                        case 2:
                            this.f601b.mo793a((PlaybackStateCompat) message.obj);
                            break;
                        case 3:
                            this.f601b.mo791a((MediaMetadataCompat) message.obj);
                            break;
                        case C1217ty.f4597d /*4*/:
                            this.f601b.mo792a((C0195b) message.obj);
                            break;
                        case C1217ty.f4598e /*5*/:
                            this.f601b.mo796a((List) message.obj);
                            break;
                        case C1217ty.f4599f /*6*/:
                            this.f601b.mo794a((CharSequence) message.obj);
                            break;
                        case C1217ty.f4600g /*7*/:
                            Bundle bundle = (Bundle) message.obj;
                            MediaSessionCompat.m885a(bundle);
                            this.f601b.mo790a(bundle);
                            break;
                        case C1217ty.f4601h /*8*/:
                            this.f601b.mo798b();
                            break;
                        case 9:
                            this.f601b.mo788a(((Integer) message.obj).intValue());
                            break;
                        case 11:
                            this.f601b.mo797a(((Boolean) message.obj).booleanValue());
                            break;
                        case 12:
                            this.f601b.mo799b(((Integer) message.obj).intValue());
                            break;
                        case 13:
                            this.f601b.mo787a();
                            break;
                    }
                }
            }
        }

        /* renamed from: android.support.v4.media.session.MediaControllerCompat$a$b */
        private static class C0193b implements C0209a {

            /* renamed from: a */
            private final WeakReference<C0191a> f602a;

            C0193b(C0191a aVar) {
                this.f602a = new WeakReference<>(aVar);
            }

            /* renamed from: a */
            public void mo801a() {
                C0191a aVar = (C0191a) this.f602a.get();
                if (aVar != null) {
                    aVar.mo798b();
                }
            }

            /* renamed from: a */
            public void mo802a(int i, int i2, int i3, int i4, int i5) {
                C0191a aVar = (C0191a) this.f602a.get();
                if (aVar != null) {
                    C0195b bVar = new C0195b(i, i2, i3, i4, i5);
                    aVar.mo792a(bVar);
                }
            }

            /* renamed from: a */
            public void mo803a(Bundle bundle) {
                C0191a aVar = (C0191a) this.f602a.get();
                if (aVar != null) {
                    aVar.mo790a(bundle);
                }
            }

            /* renamed from: a */
            public void mo804a(CharSequence charSequence) {
                C0191a aVar = (C0191a) this.f602a.get();
                if (aVar != null) {
                    aVar.mo794a(charSequence);
                }
            }

            /* renamed from: a */
            public void mo805a(Object obj) {
                C0191a aVar = (C0191a) this.f602a.get();
                if (aVar != null && aVar.f599c == null) {
                    aVar.mo793a(PlaybackStateCompat.m899a(obj));
                }
            }

            /* renamed from: a */
            public void mo806a(String str, Bundle bundle) {
                C0191a aVar = (C0191a) this.f602a.get();
                if (aVar == null) {
                    return;
                }
                if (aVar.f599c == null || VERSION.SDK_INT >= 23) {
                    aVar.mo795a(str, bundle);
                }
            }

            /* renamed from: a */
            public void mo807a(List<?> list) {
                C0191a aVar = (C0191a) this.f602a.get();
                if (aVar != null) {
                    aVar.mo796a(QueueItem.m887a(list));
                }
            }

            /* renamed from: b */
            public void mo808b(Object obj) {
                C0191a aVar = (C0191a) this.f602a.get();
                if (aVar != null) {
                    aVar.mo791a(MediaMetadataCompat.m814a(obj));
                }
            }
        }

        /* renamed from: android.support.v4.media.session.MediaControllerCompat$a$c */
        private static class C0194c extends C0203a {

            /* renamed from: a */
            private final WeakReference<C0191a> f603a;

            C0194c(C0191a aVar) {
                this.f603a = new WeakReference<>(aVar);
            }

            /* renamed from: a */
            public void mo781a() {
                C0191a aVar = (C0191a) this.f603a.get();
                if (aVar != null) {
                    aVar.mo789a(8, null, null);
                }
            }

            /* renamed from: a */
            public void mo809a(int i) {
                C0191a aVar = (C0191a) this.f603a.get();
                if (aVar != null) {
                    aVar.mo789a(9, Integer.valueOf(i), null);
                }
            }

            /* renamed from: a */
            public void mo782a(Bundle bundle) {
                C0191a aVar = (C0191a) this.f603a.get();
                if (aVar != null) {
                    aVar.mo789a(7, bundle, null);
                }
            }

            /* renamed from: a */
            public void mo783a(MediaMetadataCompat mediaMetadataCompat) {
                C0191a aVar = (C0191a) this.f603a.get();
                if (aVar != null) {
                    aVar.mo789a(3, mediaMetadataCompat, null);
                }
            }

            /* renamed from: a */
            public void mo784a(ParcelableVolumeInfo parcelableVolumeInfo) {
                C0191a aVar = (C0191a) this.f603a.get();
                if (aVar != null) {
                    aVar.mo789a(4, parcelableVolumeInfo != null ? new C0195b(parcelableVolumeInfo.f616a, parcelableVolumeInfo.f617b, parcelableVolumeInfo.f618c, parcelableVolumeInfo.f619d, parcelableVolumeInfo.f620e) : null, null);
                }
            }

            /* renamed from: a */
            public void mo810a(PlaybackStateCompat playbackStateCompat) {
                C0191a aVar = (C0191a) this.f603a.get();
                if (aVar != null) {
                    aVar.mo789a(2, playbackStateCompat, null);
                }
            }

            /* renamed from: a */
            public void mo785a(CharSequence charSequence) {
                C0191a aVar = (C0191a) this.f603a.get();
                if (aVar != null) {
                    aVar.mo789a(6, charSequence, null);
                }
            }

            /* renamed from: a */
            public void mo811a(String str, Bundle bundle) {
                C0191a aVar = (C0191a) this.f603a.get();
                if (aVar != null) {
                    aVar.mo789a(1, str, bundle);
                }
            }

            /* renamed from: a */
            public void mo786a(List<QueueItem> list) {
                C0191a aVar = (C0191a) this.f603a.get();
                if (aVar != null) {
                    aVar.mo789a(5, list, null);
                }
            }

            /* renamed from: a */
            public void mo812a(boolean z) {
            }

            /* renamed from: b */
            public void mo813b() {
                C0191a aVar = (C0191a) this.f603a.get();
                if (aVar != null) {
                    aVar.mo789a(13, null, null);
                }
            }

            /* renamed from: b */
            public void mo814b(int i) {
                C0191a aVar = (C0191a) this.f603a.get();
                if (aVar != null) {
                    aVar.mo789a(12, Integer.valueOf(i), null);
                }
            }

            /* renamed from: b */
            public void mo815b(boolean z) {
                C0191a aVar = (C0191a) this.f603a.get();
                if (aVar != null) {
                    aVar.mo789a(11, Boolean.valueOf(z), null);
                }
            }
        }

        public C0191a() {
            Object obj;
            if (VERSION.SDK_INT >= 21) {
                obj = C0208c.m1031a(new C0193b(this));
            } else {
                C0202a cVar = new C0194c(this);
                this.f599c = cVar;
                obj = cVar;
            }
            this.f597a = obj;
        }

        /* renamed from: a */
        public void mo787a() {
        }

        /* renamed from: a */
        public void mo788a(int i) {
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public void mo789a(int i, Object obj, Bundle bundle) {
            C0192a aVar = this.f598b;
            if (aVar != null) {
                Message obtainMessage = aVar.obtainMessage(i, obj);
                obtainMessage.setData(bundle);
                obtainMessage.sendToTarget();
            }
        }

        /* renamed from: a */
        public void mo790a(Bundle bundle) {
        }

        /* renamed from: a */
        public void mo791a(MediaMetadataCompat mediaMetadataCompat) {
        }

        /* renamed from: a */
        public void mo792a(C0195b bVar) {
        }

        /* renamed from: a */
        public void mo793a(PlaybackStateCompat playbackStateCompat) {
        }

        /* renamed from: a */
        public void mo794a(CharSequence charSequence) {
        }

        /* renamed from: a */
        public void mo795a(String str, Bundle bundle) {
        }

        /* renamed from: a */
        public void mo796a(List<QueueItem> list) {
        }

        /* renamed from: a */
        public void mo797a(boolean z) {
        }

        /* renamed from: b */
        public void mo798b() {
        }

        /* renamed from: b */
        public void mo799b(int i) {
        }
    }

    /* renamed from: android.support.v4.media.session.MediaControllerCompat$b */
    public static final class C0195b {

        /* renamed from: a */
        private final int f604a;

        /* renamed from: b */
        private final int f605b;

        /* renamed from: c */
        private final int f606c;

        /* renamed from: d */
        private final int f607d;

        /* renamed from: e */
        private final int f608e;

        C0195b(int i, int i2, int i3, int i4, int i5) {
            this.f604a = i;
            this.f605b = i2;
            this.f606c = i3;
            this.f607d = i4;
            this.f608e = i5;
        }
    }
}
