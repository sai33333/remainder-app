package android.support.p005v4.media.session;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

/* renamed from: android.support.v4.media.session.ParcelableVolumeInfo */
public class ParcelableVolumeInfo implements Parcelable {
    public static final Creator<ParcelableVolumeInfo> CREATOR = new Creator<ParcelableVolumeInfo>() {
        /* renamed from: a */
        public ParcelableVolumeInfo createFromParcel(Parcel parcel) {
            return new ParcelableVolumeInfo(parcel);
        }

        /* renamed from: a */
        public ParcelableVolumeInfo[] newArray(int i) {
            return new ParcelableVolumeInfo[i];
        }
    };

    /* renamed from: a */
    public int f616a;

    /* renamed from: b */
    public int f617b;

    /* renamed from: c */
    public int f618c;

    /* renamed from: d */
    public int f619d;

    /* renamed from: e */
    public int f620e;

    public ParcelableVolumeInfo(Parcel parcel) {
        this.f616a = parcel.readInt();
        this.f618c = parcel.readInt();
        this.f619d = parcel.readInt();
        this.f620e = parcel.readInt();
        this.f617b = parcel.readInt();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.f616a);
        parcel.writeInt(this.f618c);
        parcel.writeInt(this.f619d);
        parcel.writeInt(this.f620e);
        parcel.writeInt(this.f617b);
    }
}
