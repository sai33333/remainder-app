package android.support.p005v4.media.session;

import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import java.util.ArrayList;
import java.util.List;

/* renamed from: android.support.v4.media.session.PlaybackStateCompat */
public final class PlaybackStateCompat implements Parcelable {
    public static final Creator<PlaybackStateCompat> CREATOR = new Creator<PlaybackStateCompat>() {
        /* renamed from: a */
        public PlaybackStateCompat createFromParcel(Parcel parcel) {
            return new PlaybackStateCompat(parcel);
        }

        /* renamed from: a */
        public PlaybackStateCompat[] newArray(int i) {
            return new PlaybackStateCompat[i];
        }
    };

    /* renamed from: a */
    final int f621a;

    /* renamed from: b */
    final long f622b;

    /* renamed from: c */
    final long f623c;

    /* renamed from: d */
    final float f624d;

    /* renamed from: e */
    final long f625e;

    /* renamed from: f */
    final int f626f;

    /* renamed from: g */
    final CharSequence f627g;

    /* renamed from: h */
    final long f628h;

    /* renamed from: i */
    List<CustomAction> f629i;

    /* renamed from: j */
    final long f630j;

    /* renamed from: k */
    final Bundle f631k;

    /* renamed from: l */
    private Object f632l;

    /* renamed from: android.support.v4.media.session.PlaybackStateCompat$CustomAction */
    public static final class CustomAction implements Parcelable {
        public static final Creator<CustomAction> CREATOR = new Creator<CustomAction>() {
            /* renamed from: a */
            public CustomAction createFromParcel(Parcel parcel) {
                return new CustomAction(parcel);
            }

            /* renamed from: a */
            public CustomAction[] newArray(int i) {
                return new CustomAction[i];
            }
        };

        /* renamed from: a */
        private final String f633a;

        /* renamed from: b */
        private final CharSequence f634b;

        /* renamed from: c */
        private final int f635c;

        /* renamed from: d */
        private final Bundle f636d;

        /* renamed from: e */
        private Object f637e;

        CustomAction(Parcel parcel) {
            this.f633a = parcel.readString();
            this.f634b = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
            this.f635c = parcel.readInt();
            this.f636d = parcel.readBundle(MediaSessionCompat.class.getClassLoader());
        }

        CustomAction(String str, CharSequence charSequence, int i, Bundle bundle) {
            this.f633a = str;
            this.f634b = charSequence;
            this.f635c = i;
            this.f636d = bundle;
        }

        /* renamed from: a */
        public static CustomAction m902a(Object obj) {
            if (obj == null || VERSION.SDK_INT < 21) {
                return null;
            }
            CustomAction customAction = new CustomAction(C0215a.m1054a(obj), C0215a.m1055b(obj), C0215a.m1056c(obj), C0215a.m1057d(obj));
            customAction.f637e = obj;
            return customAction;
        }

        public int describeContents() {
            return 0;
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("Action:mName='");
            sb.append(this.f634b);
            sb.append(", mIcon=");
            sb.append(this.f635c);
            sb.append(", mExtras=");
            sb.append(this.f636d);
            return sb.toString();
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeString(this.f633a);
            TextUtils.writeToParcel(this.f634b, parcel, i);
            parcel.writeInt(this.f635c);
            parcel.writeBundle(this.f636d);
        }
    }

    PlaybackStateCompat(int i, long j, long j2, float f, long j3, int i2, CharSequence charSequence, long j4, List<CustomAction> list, long j5, Bundle bundle) {
        this.f621a = i;
        this.f622b = j;
        this.f623c = j2;
        this.f624d = f;
        this.f625e = j3;
        this.f626f = i2;
        this.f627g = charSequence;
        this.f628h = j4;
        this.f629i = new ArrayList(list);
        this.f630j = j5;
        this.f631k = bundle;
    }

    PlaybackStateCompat(Parcel parcel) {
        this.f621a = parcel.readInt();
        this.f622b = parcel.readLong();
        this.f624d = parcel.readFloat();
        this.f628h = parcel.readLong();
        this.f623c = parcel.readLong();
        this.f625e = parcel.readLong();
        this.f627g = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.f629i = parcel.createTypedArrayList(CustomAction.CREATOR);
        this.f630j = parcel.readLong();
        this.f631k = parcel.readBundle(MediaSessionCompat.class.getClassLoader());
        this.f626f = parcel.readInt();
    }

    /* renamed from: a */
    public static PlaybackStateCompat m899a(Object obj) {
        List list;
        Object obj2 = obj;
        Bundle bundle = null;
        if (obj2 == null || VERSION.SDK_INT < 21) {
            return null;
        }
        List<Object> h = C0214e.m1052h(obj);
        if (h != null) {
            ArrayList arrayList = new ArrayList(h.size());
            for (Object a : h) {
                arrayList.add(CustomAction.m902a(a));
            }
            list = arrayList;
        } else {
            list = null;
        }
        if (VERSION.SDK_INT >= 22) {
            bundle = C0216f.m1058a(obj);
        }
        PlaybackStateCompat playbackStateCompat = new PlaybackStateCompat(C0214e.m1045a(obj), C0214e.m1046b(obj), C0214e.m1047c(obj), C0214e.m1048d(obj), C0214e.m1049e(obj), 0, C0214e.m1050f(obj), C0214e.m1051g(obj), list, C0214e.m1053i(obj), bundle);
        playbackStateCompat.f632l = obj2;
        return playbackStateCompat;
    }

    public int describeContents() {
        return 0;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("PlaybackState {");
        sb.append("state=");
        sb.append(this.f621a);
        sb.append(", position=");
        sb.append(this.f622b);
        sb.append(", buffered position=");
        sb.append(this.f623c);
        sb.append(", speed=");
        sb.append(this.f624d);
        sb.append(", updated=");
        sb.append(this.f628h);
        sb.append(", actions=");
        sb.append(this.f625e);
        sb.append(", error code=");
        sb.append(this.f626f);
        sb.append(", error message=");
        sb.append(this.f627g);
        sb.append(", custom actions=");
        sb.append(this.f629i);
        sb.append(", active item id=");
        sb.append(this.f630j);
        sb.append("}");
        return sb.toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.f621a);
        parcel.writeLong(this.f622b);
        parcel.writeFloat(this.f624d);
        parcel.writeLong(this.f628h);
        parcel.writeLong(this.f623c);
        parcel.writeLong(this.f625e);
        TextUtils.writeToParcel(this.f627g, parcel, i);
        parcel.writeTypedList(this.f629i);
        parcel.writeLong(this.f630j);
        parcel.writeBundle(this.f631k);
        parcel.writeInt(this.f626f);
    }
}
