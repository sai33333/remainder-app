package android.support.p005v4.p006a;

import android.content.Context;
import android.os.Process;

/* renamed from: android.support.v4.a.a */
public class C0048a {

    /* renamed from: a */
    private static final Object f83a = new Object();

    /* renamed from: a */
    public static int m132a(Context context, String str) {
        if (str != null) {
            return context.checkPermission(str, Process.myPid(), Process.myUid());
        }
        throw new IllegalArgumentException("permission is null");
    }
}
