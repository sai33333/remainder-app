package android.support.p005v4.p007b;

import android.os.Bundle;
import android.os.Handler;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.p005v4.p007b.C0144a.C0145a;

/* renamed from: android.support.v4.b.b */
public class C0147b implements Parcelable {
    public static final Creator<C0147b> CREATOR = new Creator<C0147b>() {
        /* renamed from: a */
        public C0147b createFromParcel(Parcel parcel) {
            return new C0147b(parcel);
        }

        /* renamed from: a */
        public C0147b[] newArray(int i) {
            return new C0147b[i];
        }
    };

    /* renamed from: a */
    final boolean f471a = false;

    /* renamed from: b */
    final Handler f472b = null;

    /* renamed from: c */
    C0144a f473c;

    /* renamed from: android.support.v4.b.b$a */
    class C0149a extends C0145a {
        C0149a() {
        }

        /* renamed from: a */
        public void mo571a(int i, Bundle bundle) {
            if (C0147b.this.f472b != null) {
                C0147b.this.f472b.post(new C0150b(i, bundle));
            } else {
                C0147b.this.mo575a(i, bundle);
            }
        }
    }

    /* renamed from: android.support.v4.b.b$b */
    class C0150b implements Runnable {

        /* renamed from: a */
        final int f475a;

        /* renamed from: b */
        final Bundle f476b;

        C0150b(int i, Bundle bundle) {
            this.f475a = i;
            this.f476b = bundle;
        }

        public void run() {
            C0147b.this.mo575a(this.f475a, this.f476b);
        }
    }

    C0147b(Parcel parcel) {
        this.f473c = C0145a.m671a(parcel.readStrongBinder());
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public void mo575a(int i, Bundle bundle) {
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        synchronized (this) {
            if (this.f473c == null) {
                this.f473c = new C0149a();
            }
            parcel.writeStrongBinder(this.f473c.asBinder());
        }
    }
}
