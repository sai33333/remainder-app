package android.support.p005v4.p008c;

import java.util.Collection;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

/* renamed from: android.support.v4.c.a */
public class C0151a<K, V> extends C0165h<K, V> implements Map<K, V> {

    /* renamed from: a */
    C0158f<K, V> f478a;

    public C0151a() {
    }

    public C0151a(int i) {
        super(i);
    }

    /* renamed from: b */
    private C0158f<K, V> m677b() {
        if (this.f478a == null) {
            this.f478a = new C0158f<K, V>() {
                /* access modifiers changed from: protected */
                /* renamed from: a */
                public int mo588a() {
                    return C0151a.this.f517h;
                }

                /* access modifiers changed from: protected */
                /* renamed from: a */
                public int mo589a(Object obj) {
                    return C0151a.this.mo683a(obj);
                }

                /* access modifiers changed from: protected */
                /* renamed from: a */
                public Object mo590a(int i, int i2) {
                    return C0151a.this.f516g[(i << 1) + i2];
                }

                /* access modifiers changed from: protected */
                /* renamed from: a */
                public V mo591a(int i, V v) {
                    return C0151a.this.mo685a(i, v);
                }

                /* access modifiers changed from: protected */
                /* renamed from: a */
                public void mo592a(int i) {
                    C0151a.this.mo693d(i);
                }

                /* access modifiers changed from: protected */
                /* renamed from: a */
                public void mo593a(K k, V v) {
                    C0151a.this.put(k, v);
                }

                /* access modifiers changed from: protected */
                /* renamed from: b */
                public int mo594b(Object obj) {
                    return C0151a.this.mo687b(obj);
                }

                /* access modifiers changed from: protected */
                /* renamed from: b */
                public Map<K, V> mo595b() {
                    return C0151a.this;
                }

                /* access modifiers changed from: protected */
                /* renamed from: c */
                public void mo596c() {
                    C0151a.this.clear();
                }
            };
        }
        return this.f478a;
    }

    /* renamed from: a */
    public boolean mo583a(Collection<?> collection) {
        return C0158f.m715c(this, collection);
    }

    public Set<Entry<K, V>> entrySet() {
        return m677b().mo622d();
    }

    public Set<K> keySet() {
        return m677b().mo623e();
    }

    public void putAll(Map<? extends K, ? extends V> map) {
        mo686a(this.f517h + map.size());
        for (Entry entry : map.entrySet()) {
            put(entry.getKey(), entry.getValue());
        }
    }

    public Collection<V> values() {
        return m677b().mo624f();
    }
}
