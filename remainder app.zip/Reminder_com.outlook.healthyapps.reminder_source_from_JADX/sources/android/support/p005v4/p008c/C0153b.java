package android.support.p005v4.p008c;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/* renamed from: android.support.v4.c.b */
public final class C0153b<E> implements Collection<E>, Set<E> {

    /* renamed from: c */
    private static final int[] f480c = new int[0];

    /* renamed from: d */
    private static final Object[] f481d = new Object[0];

    /* renamed from: e */
    private static Object[] f482e;

    /* renamed from: f */
    private static int f483f;

    /* renamed from: g */
    private static Object[] f484g;

    /* renamed from: h */
    private static int f485h;

    /* renamed from: a */
    Object[] f486a;

    /* renamed from: b */
    int f487b;

    /* renamed from: i */
    private int[] f488i;

    /* renamed from: j */
    private C0158f<E, E> f489j;

    public C0153b() {
        this(0);
    }

    public C0153b(int i) {
        if (i == 0) {
            this.f488i = f480c;
            this.f486a = f481d;
        } else {
            m692d(i);
        }
        this.f487b = 0;
    }

    /* renamed from: a */
    private int m688a() {
        int i = this.f487b;
        if (i == 0) {
            return -1;
        }
        int a = C0155c.m707a(this.f488i, i, 0);
        if (a < 0 || this.f486a[a] == null) {
            return a;
        }
        int i2 = a + 1;
        while (i2 < i && this.f488i[i2] == 0) {
            if (this.f486a[i2] == null) {
                return i2;
            }
            i2++;
        }
        int i3 = a - 1;
        while (i3 >= 0 && this.f488i[i3] == 0) {
            if (this.f486a[i3] == null) {
                return i3;
            }
            i3--;
        }
        return ~i2;
    }

    /* renamed from: a */
    private int m689a(Object obj, int i) {
        int i2 = this.f487b;
        if (i2 == 0) {
            return -1;
        }
        int a = C0155c.m707a(this.f488i, i2, i);
        if (a < 0 || obj.equals(this.f486a[a])) {
            return a;
        }
        int i3 = a + 1;
        while (i3 < i2 && this.f488i[i3] == i) {
            if (obj.equals(this.f486a[i3])) {
                return i3;
            }
            i3++;
        }
        int i4 = a - 1;
        while (i4 >= 0 && this.f488i[i4] == i) {
            if (obj.equals(this.f486a[i4])) {
                return i4;
            }
            i4--;
        }
        return ~i3;
    }

    /* renamed from: a */
    private static void m690a(int[] iArr, Object[] objArr, int i) {
        if (iArr.length == 8) {
            synchronized (C0153b.class) {
                if (f485h < 10) {
                    objArr[0] = f484g;
                    objArr[1] = iArr;
                    for (int i2 = i - 1; i2 >= 2; i2--) {
                        objArr[i2] = null;
                    }
                    f484g = objArr;
                    f485h++;
                }
            }
        } else if (iArr.length == 4) {
            synchronized (C0153b.class) {
                if (f483f < 10) {
                    objArr[0] = f482e;
                    objArr[1] = iArr;
                    for (int i3 = i - 1; i3 >= 2; i3--) {
                        objArr[i3] = null;
                    }
                    f482e = objArr;
                    f483f++;
                }
            }
        }
    }

    /* renamed from: b */
    private C0158f<E, E> m691b() {
        if (this.f489j == null) {
            this.f489j = new C0158f<E, E>() {
                /* access modifiers changed from: protected */
                /* renamed from: a */
                public int mo588a() {
                    return C0153b.this.f487b;
                }

                /* access modifiers changed from: protected */
                /* renamed from: a */
                public int mo589a(Object obj) {
                    return C0153b.this.mo597a(obj);
                }

                /* access modifiers changed from: protected */
                /* renamed from: a */
                public Object mo590a(int i, int i2) {
                    return C0153b.this.f486a[i];
                }

                /* access modifiers changed from: protected */
                /* renamed from: a */
                public E mo591a(int i, E e) {
                    throw new UnsupportedOperationException("not a map");
                }

                /* access modifiers changed from: protected */
                /* renamed from: a */
                public void mo592a(int i) {
                    C0153b.this.mo602c(i);
                }

                /* access modifiers changed from: protected */
                /* renamed from: a */
                public void mo593a(E e, E e2) {
                    C0153b.this.add(e);
                }

                /* access modifiers changed from: protected */
                /* renamed from: b */
                public int mo594b(Object obj) {
                    return C0153b.this.mo597a(obj);
                }

                /* access modifiers changed from: protected */
                /* renamed from: b */
                public Map<E, E> mo595b() {
                    throw new UnsupportedOperationException("not a map");
                }

                /* access modifiers changed from: protected */
                /* renamed from: c */
                public void mo596c() {
                    C0153b.this.clear();
                }
            };
        }
        return this.f489j;
    }

    /* renamed from: d */
    private void m692d(int i) {
        if (i == 8) {
            synchronized (C0153b.class) {
                if (f484g != null) {
                    Object[] objArr = f484g;
                    this.f486a = objArr;
                    f484g = (Object[]) objArr[0];
                    this.f488i = (int[]) objArr[1];
                    objArr[1] = null;
                    objArr[0] = null;
                    f485h--;
                    return;
                }
            }
        } else if (i == 4) {
            synchronized (C0153b.class) {
                if (f482e != null) {
                    Object[] objArr2 = f482e;
                    this.f486a = objArr2;
                    f482e = (Object[]) objArr2[0];
                    this.f488i = (int[]) objArr2[1];
                    objArr2[1] = null;
                    objArr2[0] = null;
                    f483f--;
                    return;
                }
            }
        }
        this.f488i = new int[i];
        this.f486a = new Object[i];
    }

    /* renamed from: a */
    public int mo597a(Object obj) {
        return obj == null ? m688a() : m689a(obj, obj.hashCode());
    }

    /* renamed from: a */
    public void mo598a(int i) {
        int[] iArr = this.f488i;
        if (iArr.length < i) {
            Object[] objArr = this.f486a;
            m692d(i);
            int i2 = this.f487b;
            if (i2 > 0) {
                System.arraycopy(iArr, 0, this.f488i, 0, i2);
                System.arraycopy(objArr, 0, this.f486a, 0, this.f487b);
            }
            m690a(iArr, objArr, this.f487b);
        }
    }

    public boolean add(E e) {
        int i;
        int i2;
        if (e == null) {
            i2 = m688a();
            i = 0;
        } else {
            int hashCode = e.hashCode();
            i = hashCode;
            i2 = m689a(e, hashCode);
        }
        if (i2 >= 0) {
            return false;
        }
        int i3 = ~i2;
        int i4 = this.f487b;
        if (i4 >= this.f488i.length) {
            int i5 = 4;
            if (i4 >= 8) {
                i5 = (i4 >> 1) + i4;
            } else if (i4 >= 4) {
                i5 = 8;
            }
            int[] iArr = this.f488i;
            Object[] objArr = this.f486a;
            m692d(i5);
            int[] iArr2 = this.f488i;
            if (iArr2.length > 0) {
                System.arraycopy(iArr, 0, iArr2, 0, iArr.length);
                System.arraycopy(objArr, 0, this.f486a, 0, objArr.length);
            }
            m690a(iArr, objArr, this.f487b);
        }
        int i6 = this.f487b;
        if (i3 < i6) {
            int[] iArr3 = this.f488i;
            int i7 = i3 + 1;
            System.arraycopy(iArr3, i3, iArr3, i7, i6 - i3);
            Object[] objArr2 = this.f486a;
            System.arraycopy(objArr2, i3, objArr2, i7, this.f487b - i3);
        }
        this.f488i[i3] = i;
        this.f486a[i3] = e;
        this.f487b++;
        return true;
    }

    public boolean addAll(Collection<? extends E> collection) {
        mo598a(this.f487b + collection.size());
        boolean z = false;
        for (Object add : collection) {
            z |= add(add);
        }
        return z;
    }

    /* renamed from: b */
    public E mo601b(int i) {
        return this.f486a[i];
    }

    /* renamed from: c */
    public E mo602c(int i) {
        E[] eArr = this.f486a;
        E e = eArr[i];
        int i2 = this.f487b;
        if (i2 <= 1) {
            m690a(this.f488i, eArr, i2);
            this.f488i = f480c;
            this.f486a = f481d;
            this.f487b = 0;
        } else {
            int[] iArr = this.f488i;
            int i3 = 8;
            if (iArr.length <= 8 || i2 >= iArr.length / 3) {
                this.f487b--;
                int i4 = this.f487b;
                if (i < i4) {
                    int[] iArr2 = this.f488i;
                    int i5 = i + 1;
                    System.arraycopy(iArr2, i5, iArr2, i, i4 - i);
                    Object[] objArr = this.f486a;
                    System.arraycopy(objArr, i5, objArr, i, this.f487b - i);
                }
                this.f486a[this.f487b] = null;
            } else {
                if (i2 > 8) {
                    i3 = i2 + (i2 >> 1);
                }
                int[] iArr3 = this.f488i;
                Object[] objArr2 = this.f486a;
                m692d(i3);
                this.f487b--;
                if (i > 0) {
                    System.arraycopy(iArr3, 0, this.f488i, 0, i);
                    System.arraycopy(objArr2, 0, this.f486a, 0, i);
                }
                int i6 = this.f487b;
                if (i < i6) {
                    int i7 = i + 1;
                    System.arraycopy(iArr3, i7, this.f488i, i, i6 - i);
                    System.arraycopy(objArr2, i7, this.f486a, i, this.f487b - i);
                }
            }
        }
        return e;
    }

    public void clear() {
        int i = this.f487b;
        if (i != 0) {
            m690a(this.f488i, this.f486a, i);
            this.f488i = f480c;
            this.f486a = f481d;
            this.f487b = 0;
        }
    }

    public boolean contains(Object obj) {
        return mo597a(obj) >= 0;
    }

    public boolean containsAll(Collection<?> collection) {
        for (Object contains : collection) {
            if (!contains(contains)) {
                return false;
            }
        }
        return true;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof Set) {
            Set set = (Set) obj;
            if (size() != set.size()) {
                return false;
            }
            int i = 0;
            while (i < this.f487b) {
                try {
                    if (!set.contains(mo601b(i))) {
                        return false;
                    }
                    i++;
                } catch (ClassCastException | NullPointerException unused) {
                }
            }
            return true;
        }
        return false;
    }

    public int hashCode() {
        int[] iArr = this.f488i;
        int i = 0;
        for (int i2 = 0; i2 < this.f487b; i2++) {
            i += iArr[i2];
        }
        return i;
    }

    public boolean isEmpty() {
        return this.f487b <= 0;
    }

    public Iterator<E> iterator() {
        return m691b().mo623e().iterator();
    }

    public boolean remove(Object obj) {
        int a = mo597a(obj);
        if (a < 0) {
            return false;
        }
        mo602c(a);
        return true;
    }

    public boolean removeAll(Collection<?> collection) {
        boolean z = false;
        for (Object remove : collection) {
            z |= remove(remove);
        }
        return z;
    }

    public boolean retainAll(Collection<?> collection) {
        boolean z = false;
        for (int i = this.f487b - 1; i >= 0; i--) {
            if (!collection.contains(this.f486a[i])) {
                mo602c(i);
                z = true;
            }
        }
        return z;
    }

    public int size() {
        return this.f487b;
    }

    public Object[] toArray() {
        int i = this.f487b;
        Object[] objArr = new Object[i];
        System.arraycopy(this.f486a, 0, objArr, 0, i);
        return objArr;
    }

    public <T> T[] toArray(T[] tArr) {
        if (tArr.length < this.f487b) {
            tArr = (Object[]) Array.newInstance(tArr.getClass().getComponentType(), this.f487b);
        }
        System.arraycopy(this.f486a, 0, tArr, 0, this.f487b);
        int length = tArr.length;
        int i = this.f487b;
        if (length > i) {
            tArr[i] = null;
        }
        return tArr;
    }

    public String toString() {
        if (isEmpty()) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder(this.f487b * 14);
        sb.append('{');
        for (int i = 0; i < this.f487b; i++) {
            if (i > 0) {
                sb.append(", ");
            }
            Object b = mo601b(i);
            if (b != this) {
                sb.append(b);
            } else {
                sb.append("(this Set)");
            }
        }
        sb.append('}');
        return sb.toString();
    }
}
