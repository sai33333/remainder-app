package android.support.p005v4.p008c;

/* renamed from: android.support.v4.c.c */
class C0155c {

    /* renamed from: a */
    static final int[] f491a = new int[0];

    /* renamed from: b */
    static final long[] f492b = new long[0];

    /* renamed from: c */
    static final Object[] f493c = new Object[0];

    /* renamed from: a */
    public static int m706a(int i) {
        return m709b(i * 4) / 4;
    }

    /* renamed from: a */
    static int m707a(int[] iArr, int i, int i2) {
        int i3 = i - 1;
        int i4 = 0;
        while (i4 <= i3) {
            int i5 = (i4 + i3) >>> 1;
            int i6 = iArr[i5];
            if (i6 < i2) {
                i4 = i5 + 1;
            } else if (i6 <= i2) {
                return i5;
            } else {
                i3 = i5 - 1;
            }
        }
        return ~i4;
    }

    /* renamed from: a */
    public static boolean m708a(Object obj, Object obj2) {
        return obj == obj2 || (obj != null && obj.equals(obj2));
    }

    /* renamed from: b */
    public static int m709b(int i) {
        for (int i2 = 4; i2 < 32; i2++) {
            int i3 = (1 << i2) - 12;
            if (i <= i3) {
                return i3;
            }
        }
        return i;
    }
}
