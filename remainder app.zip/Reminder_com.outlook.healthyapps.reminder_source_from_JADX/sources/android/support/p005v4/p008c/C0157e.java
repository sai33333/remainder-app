package android.support.p005v4.p008c;

import android.util.Log;
import java.io.Writer;

/* renamed from: android.support.v4.c.e */
public class C0157e extends Writer {

    /* renamed from: a */
    private final String f494a;

    /* renamed from: b */
    private StringBuilder f495b = new StringBuilder(128);

    public C0157e(String str) {
        this.f494a = str;
    }

    /* renamed from: a */
    private void m711a() {
        if (this.f495b.length() > 0) {
            Log.d(this.f494a, this.f495b.toString());
            StringBuilder sb = this.f495b;
            sb.delete(0, sb.length());
        }
    }

    public void close() {
        m711a();
    }

    public void flush() {
        m711a();
    }

    public void write(char[] cArr, int i, int i2) {
        for (int i3 = 0; i3 < i2; i3++) {
            char c = cArr[i + i3];
            if (c == 10) {
                m711a();
            } else {
                this.f495b.append(c);
            }
        }
    }
}
