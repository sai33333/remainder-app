package android.support.p005v4.p008c;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.NoSuchElementException;
import java.util.Set;

/* renamed from: android.support.v4.c.f */
abstract class C0158f<K, V> {

    /* renamed from: b */
    C0160b f496b;

    /* renamed from: c */
    C0161c f497c;

    /* renamed from: d */
    C0163e f498d;

    /* renamed from: android.support.v4.c.f$a */
    final class C0159a<T> implements Iterator<T> {

        /* renamed from: a */
        final int f499a;

        /* renamed from: b */
        int f500b;

        /* renamed from: c */
        int f501c;

        /* renamed from: d */
        boolean f502d = false;

        C0159a(int i) {
            this.f499a = i;
            this.f500b = C0158f.this.mo588a();
        }

        public boolean hasNext() {
            return this.f501c < this.f500b;
        }

        public T next() {
            if (hasNext()) {
                T a = C0158f.this.mo590a(this.f501c, this.f499a);
                this.f501c++;
                this.f502d = true;
                return a;
            }
            throw new NoSuchElementException();
        }

        public void remove() {
            if (this.f502d) {
                this.f501c--;
                this.f500b--;
                this.f502d = false;
                C0158f.this.mo592a(this.f501c);
                return;
            }
            throw new IllegalStateException();
        }
    }

    /* renamed from: android.support.v4.c.f$b */
    final class C0160b implements Set<Entry<K, V>> {
        C0160b() {
        }

        /* renamed from: a */
        public boolean add(Entry<K, V> entry) {
            throw new UnsupportedOperationException();
        }

        public boolean addAll(Collection<? extends Entry<K, V>> collection) {
            int a = C0158f.this.mo588a();
            for (Entry entry : collection) {
                C0158f.this.mo593a(entry.getKey(), entry.getValue());
            }
            return a != C0158f.this.mo588a();
        }

        public void clear() {
            C0158f.this.mo596c();
        }

        public boolean contains(Object obj) {
            if (!(obj instanceof Entry)) {
                return false;
            }
            Entry entry = (Entry) obj;
            int a = C0158f.this.mo589a(entry.getKey());
            if (a < 0) {
                return false;
            }
            return C0155c.m708a(C0158f.this.mo590a(a, 1), entry.getValue());
        }

        public boolean containsAll(Collection<?> collection) {
            for (Object contains : collection) {
                if (!contains(contains)) {
                    return false;
                }
            }
            return true;
        }

        public boolean equals(Object obj) {
            return C0158f.m713a((Set<T>) this, obj);
        }

        public int hashCode() {
            int i = 0;
            for (int a = C0158f.this.mo588a() - 1; a >= 0; a--) {
                Object a2 = C0158f.this.mo590a(a, 0);
                Object a3 = C0158f.this.mo590a(a, 1);
                i += (a2 == null ? 0 : a2.hashCode()) ^ (a3 == null ? 0 : a3.hashCode());
            }
            return i;
        }

        public boolean isEmpty() {
            return C0158f.this.mo588a() == 0;
        }

        public Iterator<Entry<K, V>> iterator() {
            return new C0162d();
        }

        public boolean remove(Object obj) {
            throw new UnsupportedOperationException();
        }

        public boolean removeAll(Collection<?> collection) {
            throw new UnsupportedOperationException();
        }

        public boolean retainAll(Collection<?> collection) {
            throw new UnsupportedOperationException();
        }

        public int size() {
            return C0158f.this.mo588a();
        }

        public Object[] toArray() {
            throw new UnsupportedOperationException();
        }

        public <T> T[] toArray(T[] tArr) {
            throw new UnsupportedOperationException();
        }
    }

    /* renamed from: android.support.v4.c.f$c */
    final class C0161c implements Set<K> {
        C0161c() {
        }

        public boolean add(K k) {
            throw new UnsupportedOperationException();
        }

        public boolean addAll(Collection<? extends K> collection) {
            throw new UnsupportedOperationException();
        }

        public void clear() {
            C0158f.this.mo596c();
        }

        public boolean contains(Object obj) {
            return C0158f.this.mo589a(obj) >= 0;
        }

        public boolean containsAll(Collection<?> collection) {
            return C0158f.m712a(C0158f.this.mo595b(), collection);
        }

        public boolean equals(Object obj) {
            return C0158f.m713a((Set<T>) this, obj);
        }

        public int hashCode() {
            int i = 0;
            for (int a = C0158f.this.mo588a() - 1; a >= 0; a--) {
                Object a2 = C0158f.this.mo590a(a, 0);
                i += a2 == null ? 0 : a2.hashCode();
            }
            return i;
        }

        public boolean isEmpty() {
            return C0158f.this.mo588a() == 0;
        }

        public Iterator<K> iterator() {
            return new C0159a(0);
        }

        public boolean remove(Object obj) {
            int a = C0158f.this.mo589a(obj);
            if (a < 0) {
                return false;
            }
            C0158f.this.mo592a(a);
            return true;
        }

        public boolean removeAll(Collection<?> collection) {
            return C0158f.m714b(C0158f.this.mo595b(), collection);
        }

        public boolean retainAll(Collection<?> collection) {
            return C0158f.m715c(C0158f.this.mo595b(), collection);
        }

        public int size() {
            return C0158f.this.mo588a();
        }

        public Object[] toArray() {
            return C0158f.this.mo621b(0);
        }

        public <T> T[] toArray(T[] tArr) {
            return C0158f.this.mo620a(tArr, 0);
        }
    }

    /* renamed from: android.support.v4.c.f$d */
    final class C0162d implements Iterator<Entry<K, V>>, Entry<K, V> {

        /* renamed from: a */
        int f506a;

        /* renamed from: b */
        int f507b;

        /* renamed from: c */
        boolean f508c = false;

        C0162d() {
            this.f506a = C0158f.this.mo588a() - 1;
            this.f507b = -1;
        }

        /* renamed from: a */
        public Entry<K, V> next() {
            if (hasNext()) {
                this.f507b++;
                this.f508c = true;
                return this;
            }
            throw new NoSuchElementException();
        }

        public boolean equals(Object obj) {
            if (this.f508c) {
                boolean z = false;
                if (!(obj instanceof Entry)) {
                    return false;
                }
                Entry entry = (Entry) obj;
                if (C0155c.m708a(entry.getKey(), C0158f.this.mo590a(this.f507b, 0)) && C0155c.m708a(entry.getValue(), C0158f.this.mo590a(this.f507b, 1))) {
                    z = true;
                }
                return z;
            }
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }

        public K getKey() {
            if (this.f508c) {
                return C0158f.this.mo590a(this.f507b, 0);
            }
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }

        public V getValue() {
            if (this.f508c) {
                return C0158f.this.mo590a(this.f507b, 1);
            }
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }

        public boolean hasNext() {
            return this.f507b < this.f506a;
        }

        public int hashCode() {
            if (this.f508c) {
                int i = 0;
                Object a = C0158f.this.mo590a(this.f507b, 0);
                Object a2 = C0158f.this.mo590a(this.f507b, 1);
                int hashCode = a == null ? 0 : a.hashCode();
                if (a2 != null) {
                    i = a2.hashCode();
                }
                return hashCode ^ i;
            }
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }

        public void remove() {
            if (this.f508c) {
                C0158f.this.mo592a(this.f507b);
                this.f507b--;
                this.f506a--;
                this.f508c = false;
                return;
            }
            throw new IllegalStateException();
        }

        public V setValue(V v) {
            if (this.f508c) {
                return C0158f.this.mo591a(this.f507b, v);
            }
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append(getKey());
            sb.append("=");
            sb.append(getValue());
            return sb.toString();
        }
    }

    /* renamed from: android.support.v4.c.f$e */
    final class C0163e implements Collection<V> {
        C0163e() {
        }

        public boolean add(V v) {
            throw new UnsupportedOperationException();
        }

        public boolean addAll(Collection<? extends V> collection) {
            throw new UnsupportedOperationException();
        }

        public void clear() {
            C0158f.this.mo596c();
        }

        public boolean contains(Object obj) {
            return C0158f.this.mo594b(obj) >= 0;
        }

        public boolean containsAll(Collection<?> collection) {
            for (Object contains : collection) {
                if (!contains(contains)) {
                    return false;
                }
            }
            return true;
        }

        public boolean isEmpty() {
            return C0158f.this.mo588a() == 0;
        }

        public Iterator<V> iterator() {
            return new C0159a(1);
        }

        public boolean remove(Object obj) {
            int b = C0158f.this.mo594b(obj);
            if (b < 0) {
                return false;
            }
            C0158f.this.mo592a(b);
            return true;
        }

        public boolean removeAll(Collection<?> collection) {
            int a = C0158f.this.mo588a();
            int i = 0;
            boolean z = false;
            while (i < a) {
                if (collection.contains(C0158f.this.mo590a(i, 1))) {
                    C0158f.this.mo592a(i);
                    i--;
                    a--;
                    z = true;
                }
                i++;
            }
            return z;
        }

        public boolean retainAll(Collection<?> collection) {
            int a = C0158f.this.mo588a();
            int i = 0;
            boolean z = false;
            while (i < a) {
                if (!collection.contains(C0158f.this.mo590a(i, 1))) {
                    C0158f.this.mo592a(i);
                    i--;
                    a--;
                    z = true;
                }
                i++;
            }
            return z;
        }

        public int size() {
            return C0158f.this.mo588a();
        }

        public Object[] toArray() {
            return C0158f.this.mo621b(1);
        }

        public <T> T[] toArray(T[] tArr) {
            return C0158f.this.mo620a(tArr, 1);
        }
    }

    C0158f() {
    }

    /* renamed from: a */
    public static <K, V> boolean m712a(Map<K, V> map, Collection<?> collection) {
        for (Object containsKey : collection) {
            if (!map.containsKey(containsKey)) {
                return false;
            }
        }
        return true;
    }

    /* renamed from: a */
    public static <T> boolean m713a(Set<T> set, Object obj) {
        boolean z = true;
        if (set == obj) {
            return true;
        }
        if (obj instanceof Set) {
            Set set2 = (Set) obj;
            try {
                if (set.size() != set2.size() || !set.containsAll(set2)) {
                    z = false;
                }
                return z;
            } catch (ClassCastException | NullPointerException unused) {
            }
        }
        return false;
    }

    /* renamed from: b */
    public static <K, V> boolean m714b(Map<K, V> map, Collection<?> collection) {
        int size = map.size();
        for (Object remove : collection) {
            map.remove(remove);
        }
        return size != map.size();
    }

    /* renamed from: c */
    public static <K, V> boolean m715c(Map<K, V> map, Collection<?> collection) {
        int size = map.size();
        Iterator it = map.keySet().iterator();
        while (it.hasNext()) {
            if (!collection.contains(it.next())) {
                it.remove();
            }
        }
        return size != map.size();
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public abstract int mo588a();

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public abstract int mo589a(Object obj);

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public abstract Object mo590a(int i, int i2);

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public abstract V mo591a(int i, V v);

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public abstract void mo592a(int i);

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public abstract void mo593a(K k, V v);

    /* renamed from: a */
    public <T> T[] mo620a(T[] tArr, int i) {
        int a = mo588a();
        if (tArr.length < a) {
            tArr = (Object[]) Array.newInstance(tArr.getClass().getComponentType(), a);
        }
        for (int i2 = 0; i2 < a; i2++) {
            tArr[i2] = mo590a(i2, i);
        }
        if (tArr.length > a) {
            tArr[a] = null;
        }
        return tArr;
    }

    /* access modifiers changed from: protected */
    /* renamed from: b */
    public abstract int mo594b(Object obj);

    /* access modifiers changed from: protected */
    /* renamed from: b */
    public abstract Map<K, V> mo595b();

    /* renamed from: b */
    public Object[] mo621b(int i) {
        int a = mo588a();
        Object[] objArr = new Object[a];
        for (int i2 = 0; i2 < a; i2++) {
            objArr[i2] = mo590a(i2, i);
        }
        return objArr;
    }

    /* access modifiers changed from: protected */
    /* renamed from: c */
    public abstract void mo596c();

    /* renamed from: d */
    public Set<Entry<K, V>> mo622d() {
        if (this.f496b == null) {
            this.f496b = new C0160b<>();
        }
        return this.f496b;
    }

    /* renamed from: e */
    public Set<K> mo623e() {
        if (this.f497c == null) {
            this.f497c = new C0161c<>();
        }
        return this.f497c;
    }

    /* renamed from: f */
    public Collection<V> mo624f() {
        if (this.f498d == null) {
            this.f498d = new C0163e<>();
        }
        return this.f498d;
    }
}
