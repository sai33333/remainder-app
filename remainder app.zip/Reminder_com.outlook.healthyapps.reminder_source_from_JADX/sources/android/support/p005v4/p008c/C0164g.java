package android.support.p005v4.p008c;

/* renamed from: android.support.v4.c.g */
public class C0164g {
    /* renamed from: a */
    public static <T> T m732a(T t, Object obj) {
        if (t != null) {
            return t;
        }
        throw new NullPointerException(String.valueOf(obj));
    }
}
