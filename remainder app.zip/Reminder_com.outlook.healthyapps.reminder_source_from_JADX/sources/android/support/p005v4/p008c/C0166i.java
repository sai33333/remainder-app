package android.support.p005v4.p008c;

/* renamed from: android.support.v4.c.i */
public class C0166i<E> implements Cloneable {

    /* renamed from: a */
    private static final Object f518a = new Object();

    /* renamed from: b */
    private boolean f519b;

    /* renamed from: c */
    private int[] f520c;

    /* renamed from: d */
    private Object[] f521d;

    /* renamed from: e */
    private int f522e;

    public C0166i() {
        this(10);
    }

    public C0166i(int i) {
        Object[] objArr;
        this.f519b = false;
        if (i == 0) {
            this.f520c = C0155c.f491a;
            objArr = C0155c.f493c;
        } else {
            int a = C0155c.m706a(i);
            this.f520c = new int[a];
            objArr = new Object[a];
        }
        this.f521d = objArr;
        this.f522e = 0;
    }

    /* renamed from: d */
    private void m745d() {
        int i = this.f522e;
        int[] iArr = this.f520c;
        Object[] objArr = this.f521d;
        int i2 = 0;
        for (int i3 = 0; i3 < i; i3++) {
            Object obj = objArr[i3];
            if (obj != f518a) {
                if (i3 != i2) {
                    iArr[i2] = iArr[i3];
                    objArr[i2] = obj;
                    objArr[i3] = null;
                }
                i2++;
            }
        }
        this.f519b = false;
        this.f522e = i2;
    }

    /* renamed from: a */
    public C0166i<E> clone() {
        try {
            C0166i<E> iVar = (C0166i) super.clone();
            iVar.f520c = (int[]) this.f520c.clone();
            iVar.f521d = (Object[]) this.f521d.clone();
            return iVar;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError(e);
        }
    }

    /* renamed from: a */
    public E mo703a(int i) {
        return mo704a(i, null);
    }

    /* renamed from: a */
    public E mo704a(int i, E e) {
        int a = C0155c.m707a(this.f520c, this.f522e, i);
        if (a >= 0) {
            E[] eArr = this.f521d;
            if (eArr[a] != f518a) {
                return eArr[a];
            }
        }
        return e;
    }

    /* renamed from: b */
    public int mo705b() {
        if (this.f519b) {
            m745d();
        }
        return this.f522e;
    }

    /* renamed from: b */
    public void mo706b(int i) {
        int a = C0155c.m707a(this.f520c, this.f522e, i);
        if (a >= 0) {
            Object[] objArr = this.f521d;
            Object obj = objArr[a];
            Object obj2 = f518a;
            if (obj != obj2) {
                objArr[a] = obj2;
                this.f519b = true;
            }
        }
    }

    /* renamed from: b */
    public void mo707b(int i, E e) {
        int a = C0155c.m707a(this.f520c, this.f522e, i);
        if (a >= 0) {
            this.f521d[a] = e;
        } else {
            int i2 = ~a;
            if (i2 < this.f522e) {
                Object[] objArr = this.f521d;
                if (objArr[i2] == f518a) {
                    this.f520c[i2] = i;
                    objArr[i2] = e;
                    return;
                }
            }
            if (this.f519b && this.f522e >= this.f520c.length) {
                m745d();
                i2 = ~C0155c.m707a(this.f520c, this.f522e, i);
            }
            int i3 = this.f522e;
            if (i3 >= this.f520c.length) {
                int a2 = C0155c.m706a(i3 + 1);
                int[] iArr = new int[a2];
                Object[] objArr2 = new Object[a2];
                int[] iArr2 = this.f520c;
                System.arraycopy(iArr2, 0, iArr, 0, iArr2.length);
                Object[] objArr3 = this.f521d;
                System.arraycopy(objArr3, 0, objArr2, 0, objArr3.length);
                this.f520c = iArr;
                this.f521d = objArr2;
            }
            int i4 = this.f522e;
            if (i4 - i2 != 0) {
                int[] iArr3 = this.f520c;
                int i5 = i2 + 1;
                System.arraycopy(iArr3, i2, iArr3, i5, i4 - i2);
                Object[] objArr4 = this.f521d;
                System.arraycopy(objArr4, i2, objArr4, i5, this.f522e - i2);
            }
            this.f520c[i2] = i;
            this.f521d[i2] = e;
            this.f522e++;
        }
    }

    /* renamed from: c */
    public void mo708c() {
        int i = this.f522e;
        Object[] objArr = this.f521d;
        for (int i2 = 0; i2 < i; i2++) {
            objArr[i2] = null;
        }
        this.f522e = 0;
        this.f519b = false;
    }

    /* renamed from: c */
    public void mo709c(int i) {
        mo706b(i);
    }

    /* renamed from: d */
    public int mo711d(int i) {
        if (this.f519b) {
            m745d();
        }
        return this.f520c[i];
    }

    /* renamed from: e */
    public E mo712e(int i) {
        if (this.f519b) {
            m745d();
        }
        return this.f521d[i];
    }

    public String toString() {
        if (mo705b() <= 0) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder(this.f522e * 28);
        sb.append('{');
        for (int i = 0; i < this.f522e; i++) {
            if (i > 0) {
                sb.append(", ");
            }
            sb.append(mo711d(i));
            sb.append('=');
            Object e = mo712e(i);
            if (e != this) {
                sb.append(e);
            } else {
                sb.append("(this Map)");
            }
        }
        sb.append('}');
        return sb.toString();
    }
}
