package android.support.p005v4.p009d;

import android.os.Build.VERSION;
import android.support.p004a.C0045a.C0047b;
import android.util.SparseArray;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/* renamed from: android.support.v4.d.c */
public class C0170c {

    /* renamed from: a */
    private static final AtomicInteger f529a = new AtomicInteger(1);

    /* renamed from: b */
    private static WeakHashMap<View, String> f530b;

    /* renamed from: c */
    private static WeakHashMap<View, Object> f531c = null;

    /* renamed from: d */
    private static boolean f532d = false;

    /* renamed from: android.support.v4.d.c$a */
    public interface C0171a {
        /* renamed from: a */
        boolean mo714a(View view, KeyEvent keyEvent);
    }

    /* renamed from: android.support.v4.d.c$b */
    static class C0172b {

        /* renamed from: a */
        private static final ArrayList<WeakReference<View>> f533a = new ArrayList<>();

        /* renamed from: b */
        private WeakHashMap<View, Boolean> f534b = null;

        /* renamed from: c */
        private SparseArray<WeakReference<View>> f535c = null;

        /* renamed from: d */
        private WeakReference<KeyEvent> f536d = null;

        C0172b() {
        }

        /* renamed from: a */
        static C0172b m772a(View view) {
            C0172b bVar = (C0172b) view.getTag(C0047b.tag_unhandled_key_event_manager);
            if (bVar != null) {
                return bVar;
            }
            C0172b bVar2 = new C0172b();
            view.setTag(C0047b.tag_unhandled_key_event_manager, bVar2);
            return bVar2;
        }

        /* renamed from: a */
        private SparseArray<WeakReference<View>> m773a() {
            if (this.f535c == null) {
                this.f535c = new SparseArray<>();
            }
            return this.f535c;
        }

        /* renamed from: b */
        private View m774b(View view, KeyEvent keyEvent) {
            WeakHashMap<View, Boolean> weakHashMap = this.f534b;
            if (weakHashMap != null && weakHashMap.containsKey(view)) {
                if (view instanceof ViewGroup) {
                    ViewGroup viewGroup = (ViewGroup) view;
                    for (int childCount = viewGroup.getChildCount() - 1; childCount >= 0; childCount--) {
                        View b = m774b(viewGroup.getChildAt(childCount), keyEvent);
                        if (b != null) {
                            return b;
                        }
                    }
                }
                if (m776c(view, keyEvent)) {
                    return view;
                }
            }
            return null;
        }

        /* renamed from: b */
        private void m775b() {
            WeakHashMap<View, Boolean> weakHashMap = this.f534b;
            if (weakHashMap != null) {
                weakHashMap.clear();
            }
            if (!f533a.isEmpty()) {
                synchronized (f533a) {
                    if (this.f534b == null) {
                        this.f534b = new WeakHashMap<>();
                    }
                    for (int size = f533a.size() - 1; size >= 0; size--) {
                        View view = (View) ((WeakReference) f533a.get(size)).get();
                        if (view == null) {
                            f533a.remove(size);
                        } else {
                            this.f534b.put(view, Boolean.TRUE);
                            for (ViewParent parent = view.getParent(); parent instanceof View; parent = parent.getParent()) {
                                this.f534b.put((View) parent, Boolean.TRUE);
                            }
                        }
                    }
                }
            }
        }

        /* renamed from: c */
        private boolean m776c(View view, KeyEvent keyEvent) {
            ArrayList arrayList = (ArrayList) view.getTag(C0047b.tag_unhandled_key_listeners);
            if (arrayList != null) {
                for (int size = arrayList.size() - 1; size >= 0; size--) {
                    if (((C0171a) arrayList.get(size)).mo714a(view, keyEvent)) {
                        return true;
                    }
                }
            }
            return false;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public boolean mo715a(KeyEvent keyEvent) {
            WeakReference<KeyEvent> weakReference = this.f536d;
            if (weakReference != null && weakReference.get() == keyEvent) {
                return false;
            }
            this.f536d = new WeakReference<>(keyEvent);
            WeakReference weakReference2 = null;
            SparseArray a = m773a();
            if (keyEvent.getAction() == 1) {
                int indexOfKey = a.indexOfKey(keyEvent.getKeyCode());
                if (indexOfKey >= 0) {
                    weakReference2 = (WeakReference) a.valueAt(indexOfKey);
                    a.removeAt(indexOfKey);
                }
            }
            if (weakReference2 == null) {
                weakReference2 = (WeakReference) a.get(keyEvent.getKeyCode());
            }
            if (weakReference2 == null) {
                return false;
            }
            View view = (View) weakReference2.get();
            if (view != null && C0170c.m770c(view)) {
                m776c(view, keyEvent);
            }
            return true;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public boolean mo716a(View view, KeyEvent keyEvent) {
            if (keyEvent.getAction() == 0) {
                m775b();
            }
            View b = m774b(view, keyEvent);
            if (keyEvent.getAction() == 0) {
                int keyCode = keyEvent.getKeyCode();
                if (b != null && !KeyEvent.isModifierKey(keyCode)) {
                    m773a().put(keyCode, new WeakReference(b));
                }
            }
            return b != null;
        }
    }

    /* renamed from: a */
    public static String m765a(View view) {
        if (VERSION.SDK_INT >= 21) {
            return view.getTransitionName();
        }
        WeakHashMap<View, String> weakHashMap = f530b;
        if (weakHashMap == null) {
            return null;
        }
        return (String) weakHashMap.get(view);
    }

    /* renamed from: a */
    public static void m766a(View view, String str) {
        if (VERSION.SDK_INT >= 21) {
            view.setTransitionName(str);
            return;
        }
        if (f530b == null) {
            f530b = new WeakHashMap<>();
        }
        f530b.put(view, str);
    }

    /* renamed from: a */
    static boolean m767a(View view, KeyEvent keyEvent) {
        if (VERSION.SDK_INT >= 28) {
            return false;
        }
        return C0172b.m772a(view).mo715a(keyEvent);
    }

    /* renamed from: b */
    public static boolean m768b(View view) {
        if (VERSION.SDK_INT >= 16) {
            return view.hasOverlappingRendering();
        }
        return true;
    }

    /* renamed from: b */
    static boolean m769b(View view, KeyEvent keyEvent) {
        if (VERSION.SDK_INT >= 28) {
            return false;
        }
        return C0172b.m772a(view).mo716a(view, keyEvent);
    }

    /* renamed from: c */
    public static boolean m770c(View view) {
        if (VERSION.SDK_INT >= 19) {
            return view.isAttachedToWindow();
        }
        return view.getWindowToken() != null;
    }
}
