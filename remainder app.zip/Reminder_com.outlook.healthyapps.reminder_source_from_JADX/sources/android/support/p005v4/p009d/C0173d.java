package android.support.p005v4.p009d;

import android.os.Build.VERSION;
import android.support.p004a.C0045a.C0047b;
import android.view.ViewGroup;

/* renamed from: android.support.v4.d.d */
public final class C0173d {
    /* renamed from: a */
    public static boolean m779a(ViewGroup viewGroup) {
        if (VERSION.SDK_INT >= 21) {
            return viewGroup.isTransitionGroup();
        }
        Boolean bool = (Boolean) viewGroup.getTag(C0047b.tag_transition_group);
        return ((bool == null || !bool.booleanValue()) && viewGroup.getBackground() == null && C0170c.m765a(viewGroup) == null) ? false : true;
    }
}
