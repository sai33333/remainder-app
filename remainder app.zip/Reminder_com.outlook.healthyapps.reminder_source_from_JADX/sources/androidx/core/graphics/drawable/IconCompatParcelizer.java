package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.os.Parcelable;
import android.support.p005v4.graphics.drawable.IconCompat;
import androidx.versionedparcelable.C0218a;

public class IconCompatParcelizer {
    public static IconCompat read(C0218a aVar) {
        IconCompat iconCompat = new IconCompat();
        iconCompat.f538a = aVar.mo941b(iconCompat.f538a, 1);
        iconCompat.f540c = aVar.mo947b(iconCompat.f540c, 2);
        iconCompat.f541d = aVar.mo942b(iconCompat.f541d, 3);
        iconCompat.f542e = aVar.mo941b(iconCompat.f542e, 4);
        iconCompat.f543f = aVar.mo941b(iconCompat.f543f, 5);
        iconCompat.f544g = (ColorStateList) aVar.mo942b(iconCompat.f544g, 6);
        iconCompat.f546j = aVar.mo944b(iconCompat.f546j, 7);
        iconCompat.mo720c();
        return iconCompat;
    }

    public static void write(IconCompat iconCompat, C0218a aVar) {
        aVar.mo937a(true, true);
        iconCompat.mo718a(aVar.mo940a());
        aVar.mo930a(iconCompat.f538a, 1);
        aVar.mo939a(iconCompat.f540c, 2);
        aVar.mo932a(iconCompat.f541d, 3);
        aVar.mo930a(iconCompat.f542e, 4);
        aVar.mo930a(iconCompat.f543f, 5);
        aVar.mo932a((Parcelable) iconCompat.f544g, 6);
        aVar.mo936a(iconCompat.f546j, 7);
    }
}
