package androidx.media;

import android.support.p005v4.media.AudioAttributesCompat;
import androidx.versionedparcelable.C0218a;
import androidx.versionedparcelable.C0220c;

public final class AudioAttributesCompatParcelizer {
    public static AudioAttributesCompat read(C0218a aVar) {
        AudioAttributesCompat audioAttributesCompat = new AudioAttributesCompat();
        audioAttributesCompat.mImpl = (C0182a) aVar.mo943b(audioAttributesCompat.mImpl, 1);
        return audioAttributesCompat;
    }

    public static void write(AudioAttributesCompat audioAttributesCompat, C0218a aVar) {
        aVar.mo937a(false, false);
        aVar.mo934a((C0220c) audioAttributesCompat.mImpl, 1);
    }
}
