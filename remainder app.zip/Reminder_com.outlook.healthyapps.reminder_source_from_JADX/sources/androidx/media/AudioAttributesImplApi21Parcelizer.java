package androidx.media;

import android.media.AudioAttributes;
import android.os.Parcelable;
import androidx.versionedparcelable.C0218a;

public final class AudioAttributesImplApi21Parcelizer {
    public static C0183b read(C0218a aVar) {
        C0183b bVar = new C0183b();
        bVar.mAudioAttributes = (AudioAttributes) aVar.mo942b(bVar.mAudioAttributes, 1);
        bVar.mLegacyStreamType = aVar.mo941b(bVar.mLegacyStreamType, 2);
        return bVar;
    }

    public static void write(C0183b bVar, C0218a aVar) {
        aVar.mo937a(false, false);
        aVar.mo932a((Parcelable) bVar.mAudioAttributes, 1);
        aVar.mo930a(bVar.mLegacyStreamType, 2);
    }
}
