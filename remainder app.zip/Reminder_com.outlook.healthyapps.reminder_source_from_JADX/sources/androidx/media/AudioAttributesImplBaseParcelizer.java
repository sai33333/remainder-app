package androidx.media;

import androidx.versionedparcelable.C0218a;

public final class AudioAttributesImplBaseParcelizer {
    public static C0184c read(C0218a aVar) {
        C0184c cVar = new C0184c();
        cVar.mUsage = aVar.mo941b(cVar.mUsage, 1);
        cVar.mContentType = aVar.mo941b(cVar.mContentType, 2);
        cVar.mFlags = aVar.mo941b(cVar.mFlags, 3);
        cVar.mLegacyStream = aVar.mo941b(cVar.mLegacyStream, 4);
        return cVar;
    }

    public static void write(C0184c cVar, C0218a aVar) {
        aVar.mo937a(false, false);
        aVar.mo930a(cVar.mUsage, 1);
        aVar.mo930a(cVar.mContentType, 2);
        aVar.mo930a(cVar.mFlags, 3);
        aVar.mo930a(cVar.mLegacyStream, 4);
    }
}
