package androidx.versionedparcelable;

import android.os.Parcelable;
import java.lang.reflect.InvocationTargetException;

/* renamed from: androidx.versionedparcelable.a */
public abstract class C0218a {
    /* renamed from: a */
    protected static <T extends C0220c> T m1063a(String str, C0218a aVar) {
        try {
            return (C0220c) Class.forName(str, true, C0218a.class.getClassLoader()).getDeclaredMethod("read", new Class[]{C0218a.class}).invoke(null, new Object[]{aVar});
        } catch (IllegalAccessException e) {
            throw new RuntimeException("VersionedParcel encountered IllegalAccessException", e);
        } catch (InvocationTargetException e2) {
            if (e2.getCause() instanceof RuntimeException) {
                throw ((RuntimeException) e2.getCause());
            }
            throw new RuntimeException("VersionedParcel encountered InvocationTargetException", e2);
        } catch (NoSuchMethodException e3) {
            throw new RuntimeException("VersionedParcel encountered NoSuchMethodException", e3);
        } catch (ClassNotFoundException e4) {
            throw new RuntimeException("VersionedParcel encountered ClassNotFoundException", e4);
        }
    }

    /* renamed from: a */
    private static Class m1064a(Class<? extends C0220c> cls) {
        return Class.forName(String.format("%s.%sParcelizer", new Object[]{cls.getPackage().getName(), cls.getSimpleName()}), false, cls.getClassLoader());
    }

    /* renamed from: a */
    protected static <T extends C0220c> void m1065a(T t, C0218a aVar) {
        try {
            m1067c(t).getDeclaredMethod("write", new Class[]{t.getClass(), C0218a.class}).invoke(null, new Object[]{t, aVar});
        } catch (IllegalAccessException e) {
            throw new RuntimeException("VersionedParcel encountered IllegalAccessException", e);
        } catch (InvocationTargetException e2) {
            if (e2.getCause() instanceof RuntimeException) {
                throw ((RuntimeException) e2.getCause());
            }
            throw new RuntimeException("VersionedParcel encountered InvocationTargetException", e2);
        } catch (NoSuchMethodException e3) {
            throw new RuntimeException("VersionedParcel encountered NoSuchMethodException", e3);
        } catch (ClassNotFoundException e4) {
            throw new RuntimeException("VersionedParcel encountered ClassNotFoundException", e4);
        }
    }

    /* renamed from: b */
    private void m1066b(C0220c cVar) {
        try {
            mo935a(m1064a(cVar.getClass()).getName());
        } catch (ClassNotFoundException e) {
            StringBuilder sb = new StringBuilder();
            sb.append(cVar.getClass().getSimpleName());
            sb.append(" does not have a Parcelizer");
            throw new RuntimeException(sb.toString(), e);
        }
    }

    /* renamed from: c */
    private static <T extends C0220c> Class m1067c(T t) {
        return m1064a(t.getClass());
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public abstract void mo929a(int i);

    /* renamed from: a */
    public void mo930a(int i, int i2) {
        mo949c(i2);
        mo929a(i);
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public abstract void mo931a(Parcelable parcelable);

    /* renamed from: a */
    public void mo932a(Parcelable parcelable, int i) {
        mo949c(i);
        mo931a(parcelable);
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public void mo933a(C0220c cVar) {
        if (cVar == null) {
            mo935a((String) null);
            return;
        }
        m1066b(cVar);
        C0218a c = mo948c();
        m1065a((T) cVar, c);
        c.mo945b();
    }

    /* renamed from: a */
    public void mo934a(C0220c cVar, int i) {
        mo949c(i);
        mo933a(cVar);
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public abstract void mo935a(String str);

    /* renamed from: a */
    public void mo936a(String str, int i) {
        mo949c(i);
        mo935a(str);
    }

    /* renamed from: a */
    public void mo937a(boolean z, boolean z2) {
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public abstract void mo938a(byte[] bArr);

    /* renamed from: a */
    public void mo939a(byte[] bArr, int i) {
        mo949c(i);
        mo938a(bArr);
    }

    /* renamed from: a */
    public boolean mo940a() {
        return false;
    }

    /* renamed from: b */
    public int mo941b(int i, int i2) {
        return !mo946b(i2) ? i : mo950d();
    }

    /* renamed from: b */
    public <T extends Parcelable> T mo942b(T t, int i) {
        return !mo946b(i) ? t : mo953g();
    }

    /* renamed from: b */
    public <T extends C0220c> T mo943b(T t, int i) {
        return !mo946b(i) ? t : mo954h();
    }

    /* renamed from: b */
    public String mo944b(String str, int i) {
        return !mo946b(i) ? str : mo951e();
    }

    /* access modifiers changed from: protected */
    /* renamed from: b */
    public abstract void mo945b();

    /* access modifiers changed from: protected */
    /* renamed from: b */
    public abstract boolean mo946b(int i);

    /* renamed from: b */
    public byte[] mo947b(byte[] bArr, int i) {
        return !mo946b(i) ? bArr : mo952f();
    }

    /* access modifiers changed from: protected */
    /* renamed from: c */
    public abstract C0218a mo948c();

    /* access modifiers changed from: protected */
    /* renamed from: c */
    public abstract void mo949c(int i);

    /* access modifiers changed from: protected */
    /* renamed from: d */
    public abstract int mo950d();

    /* access modifiers changed from: protected */
    /* renamed from: e */
    public abstract String mo951e();

    /* access modifiers changed from: protected */
    /* renamed from: f */
    public abstract byte[] mo952f();

    /* access modifiers changed from: protected */
    /* renamed from: g */
    public abstract <T extends Parcelable> T mo953g();

    /* access modifiers changed from: protected */
    /* renamed from: h */
    public <T extends C0220c> T mo954h() {
        String e = mo951e();
        if (e == null) {
            return null;
        }
        return m1063a(e, mo948c());
    }
}
