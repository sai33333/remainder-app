package androidx.versionedparcelable;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.SparseIntArray;

/* renamed from: androidx.versionedparcelable.b */
class C0219b extends C0218a {

    /* renamed from: a */
    private final SparseIntArray f642a;

    /* renamed from: b */
    private final Parcel f643b;

    /* renamed from: c */
    private final int f644c;

    /* renamed from: d */
    private final int f645d;

    /* renamed from: e */
    private final String f646e;

    /* renamed from: f */
    private int f647f;

    /* renamed from: g */
    private int f648g;

    C0219b(Parcel parcel) {
        this(parcel, parcel.dataPosition(), parcel.dataSize(), "");
    }

    C0219b(Parcel parcel, int i, int i2, String str) {
        this.f642a = new SparseIntArray();
        this.f647f = -1;
        this.f648g = 0;
        this.f643b = parcel;
        this.f644c = i;
        this.f645d = i2;
        this.f648g = this.f644c;
        this.f646e = str;
    }

    /* renamed from: d */
    private int m1094d(int i) {
        int readInt;
        do {
            int i2 = this.f648g;
            if (i2 >= this.f645d) {
                return -1;
            }
            this.f643b.setDataPosition(i2);
            int readInt2 = this.f643b.readInt();
            readInt = this.f643b.readInt();
            this.f648g += readInt2;
        } while (readInt != i);
        return this.f643b.dataPosition();
    }

    /* renamed from: a */
    public void mo929a(int i) {
        this.f643b.writeInt(i);
    }

    /* renamed from: a */
    public void mo931a(Parcelable parcelable) {
        this.f643b.writeParcelable(parcelable, 0);
    }

    /* renamed from: a */
    public void mo935a(String str) {
        this.f643b.writeString(str);
    }

    /* renamed from: a */
    public void mo938a(byte[] bArr) {
        if (bArr != null) {
            this.f643b.writeInt(bArr.length);
            this.f643b.writeByteArray(bArr);
            return;
        }
        this.f643b.writeInt(-1);
    }

    /* renamed from: b */
    public void mo945b() {
        int i = this.f647f;
        if (i >= 0) {
            int i2 = this.f642a.get(i);
            int dataPosition = this.f643b.dataPosition();
            int i3 = dataPosition - i2;
            this.f643b.setDataPosition(i2);
            this.f643b.writeInt(i3);
            this.f643b.setDataPosition(dataPosition);
        }
    }

    /* renamed from: b */
    public boolean mo946b(int i) {
        int d = m1094d(i);
        if (d == -1) {
            return false;
        }
        this.f643b.setDataPosition(d);
        return true;
    }

    /* access modifiers changed from: protected */
    /* renamed from: c */
    public C0218a mo948c() {
        Parcel parcel = this.f643b;
        int dataPosition = parcel.dataPosition();
        int i = this.f648g;
        if (i == this.f644c) {
            i = this.f645d;
        }
        StringBuilder sb = new StringBuilder();
        sb.append(this.f646e);
        sb.append("  ");
        return new C0219b(parcel, dataPosition, i, sb.toString());
    }

    /* renamed from: c */
    public void mo949c(int i) {
        mo945b();
        this.f647f = i;
        this.f642a.put(i, this.f643b.dataPosition());
        mo929a(0);
        mo929a(i);
    }

    /* renamed from: d */
    public int mo950d() {
        return this.f643b.readInt();
    }

    /* renamed from: e */
    public String mo951e() {
        return this.f643b.readString();
    }

    /* renamed from: f */
    public byte[] mo952f() {
        int readInt = this.f643b.readInt();
        if (readInt < 0) {
            return null;
        }
        byte[] bArr = new byte[readInt];
        this.f643b.readByteArray(bArr);
        return bArr;
    }

    /* renamed from: g */
    public <T extends Parcelable> T mo953g() {
        return this.f643b.readParcelable(getClass().getClassLoader());
    }
}
