package androidx.versionedparcelable;

public abstract class CustomVersionedParcelable implements C0220c {
    /* renamed from: a */
    public void mo718a(boolean z) {
    }

    /* renamed from: c */
    public void mo720c() {
    }
}
