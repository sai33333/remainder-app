package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.a */
public final class C0611a extends C0646b {
    public C0611a() {
    }

    public C0611a(aey aey) {
        super(aey);
    }
}
