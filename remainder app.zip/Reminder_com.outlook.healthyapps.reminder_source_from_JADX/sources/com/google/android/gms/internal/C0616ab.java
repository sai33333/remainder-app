package com.google.android.gms.internal;

import android.os.IInterface;

/* renamed from: com.google.android.gms.internal.ab */
public interface C0616ab extends IInterface {
}
