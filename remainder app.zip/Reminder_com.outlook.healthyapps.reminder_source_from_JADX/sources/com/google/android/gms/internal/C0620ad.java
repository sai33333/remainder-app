package com.google.android.gms.internal;

import android.os.IBinder;

/* renamed from: com.google.android.gms.internal.ad */
public final class C0620ad extends C1178so implements C0616ab {
    C0620ad(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.ads.internal.request.INonagonStreamingResponseListener");
    }
}
