package com.google.android.gms.internal;

import com.google.android.gms.ads.C0327h.C0328a;

/* renamed from: com.google.android.gms.internal.ads */
public final class C0621ads extends acy {

    /* renamed from: a */
    private final C0328a f1782a;

    public C0621ads(C0328a aVar) {
        this.f1782a = aVar;
    }

    /* renamed from: a */
    public final void mo1981a() {
        this.f1782a.mo1263a();
    }

    /* renamed from: a */
    public final void mo1982a(boolean z) {
        this.f1782a.mo1264a(z);
    }

    /* renamed from: b */
    public final void mo1983b() {
        this.f1782a.mo1265b();
    }

    /* renamed from: c */
    public final void mo1984c() {
        this.f1782a.mo1266c();
    }

    /* renamed from: d */
    public final void mo1985d() {
        this.f1782a.mo1267d();
    }
}
