package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.ParcelFileDescriptor.AutoCloseInputStream;
import android.os.ParcelFileDescriptor.AutoCloseOutputStream;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.google.android.gms.ads.internal.C0354ax;
import com.google.android.gms.common.util.C0579g;
import java.io.DataInputStream;
import java.io.IOException;

@arm
/* renamed from: com.google.android.gms.internal.ae */
public final class C0622ae extends C0940lx {
    public static final Creator<C0622ae> CREATOR = new C0624ag();

    /* renamed from: a */
    private ParcelFileDescriptor f1787a;

    /* renamed from: b */
    private Parcelable f1788b;

    /* renamed from: c */
    private boolean f1789c;

    C0622ae(ParcelFileDescriptor parcelFileDescriptor) {
        this.f1787a = parcelFileDescriptor;
        this.f1788b = null;
        this.f1789c = true;
    }

    public C0622ae(C0945mb mbVar) {
        this.f1787a = null;
        this.f1788b = mbVar;
        this.f1789c = false;
    }

    /* renamed from: a */
    private final <T> ParcelFileDescriptor m2703a(byte[] bArr) {
        AutoCloseOutputStream autoCloseOutputStream;
        try {
            ParcelFileDescriptor[] createPipe = ParcelFileDescriptor.createPipe();
            autoCloseOutputStream = new AutoCloseOutputStream(createPipe[1]);
            try {
                new Thread(new C0623af(this, autoCloseOutputStream, bArr)).start();
                return createPipe[0];
            } catch (IOException e) {
                e = e;
                C0759fe.m4730b("Error transporting the ad response", e);
                C0354ax.m1542i().mo2742a((Throwable) e, "LargeParcelTeleporter.pipeData.2");
                C0579g.m2248a(autoCloseOutputStream);
                return null;
            }
        } catch (IOException e2) {
            e = e2;
            autoCloseOutputStream = null;
            C0759fe.m4730b("Error transporting the ad response", e);
            C0354ax.m1542i().mo2742a((Throwable) e, "LargeParcelTeleporter.pipeData.2");
            C0579g.m2248a(autoCloseOutputStream);
            return null;
        }
    }

    /* JADX INFO: finally extract failed */
    /* renamed from: a */
    public final <T extends C0945mb> T mo2065a(Creator<T> creator) {
        if (this.f1789c) {
            ParcelFileDescriptor parcelFileDescriptor = this.f1787a;
            if (parcelFileDescriptor == null) {
                C0759fe.m4731c("File descriptor is empty, returning null.");
                return null;
            }
            DataInputStream dataInputStream = new DataInputStream(new AutoCloseInputStream(parcelFileDescriptor));
            try {
                byte[] bArr = new byte[dataInputStream.readInt()];
                dataInputStream.readFully(bArr, 0, bArr.length);
                C0579g.m2248a(dataInputStream);
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.unmarshall(bArr, 0, bArr.length);
                    obtain.setDataPosition(0);
                    this.f1788b = (C0945mb) creator.createFromParcel(obtain);
                    obtain.recycle();
                    this.f1789c = false;
                } catch (Throwable th) {
                    obtain.recycle();
                    throw th;
                }
            } catch (IOException e) {
                C0759fe.m4730b("Could not read from parcel file descriptor", e);
                C0579g.m2248a(dataInputStream);
                return null;
            } catch (Throwable th2) {
                C0579g.m2248a(dataInputStream);
                throw th2;
            }
        }
        return (C0945mb) this.f1788b;
    }

    /* JADX INFO: finally extract failed */
    public final void writeToParcel(Parcel parcel, int i) {
        if (this.f1787a == null) {
            Parcel obtain = Parcel.obtain();
            try {
                this.f1788b.writeToParcel(obtain, 0);
                byte[] marshall = obtain.marshall();
                obtain.recycle();
                this.f1787a = m2703a(marshall);
            } catch (Throwable th) {
                obtain.recycle();
                throw th;
            }
        }
        int a = C0944ma.m5103a(parcel);
        C0944ma.m5110a(parcel, 2, (Parcelable) this.f1787a, i, false);
        C0944ma.m5104a(parcel, a);
    }
}
