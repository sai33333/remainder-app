package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.ak */
final class C0628ak implements Runnable {

    /* renamed from: a */
    private /* synthetic */ C0744eq f2348a;

    /* renamed from: b */
    private /* synthetic */ C0627aj f2349b;

    C0628ak(C0627aj ajVar, C0744eq eqVar) {
        this.f2349b = ajVar;
        this.f2348a = eqVar;
    }

    public final void run() {
        this.f2349b.f2306h.mo1298a(this.f2348a);
        if (this.f2349b.f2310l != null) {
            this.f2349b.f2310l.mo1488c();
            this.f2349b.f2310l = null;
        }
    }
}
