package com.google.android.gms.internal;

import android.content.Context;

@arm
/* renamed from: com.google.android.gms.internal.app */
public abstract class C0635app extends C0757fc {

    /* renamed from: a */
    protected final apu f2677a;

    /* renamed from: b */
    protected final Context f2678b;

    /* renamed from: c */
    protected final Object f2679c = new Object();

    /* renamed from: d */
    protected final Object f2680d = new Object();

    /* renamed from: e */
    protected final C0744eq f2681e;

    /* renamed from: f */
    protected C1135r f2682f;

    protected C0635app(Context context, C0744eq eqVar, apu apu) {
        super(true);
        this.f2678b = context;
        this.f2681e = eqVar;
        this.f2682f = eqVar.f3177b;
        this.f2677a = apu;
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public abstract C0743ep mo2515a(int i);

    /* JADX WARNING: Removed duplicated region for block: B:18:0x0033 A[Catch:{ aps -> 0x0014 }] */
    /* JADX WARNING: Removed duplicated region for block: B:20:0x003b A[Catch:{ aps -> 0x0014 }] */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo1567a() {
        /*
            r5 = this;
            java.lang.Object r0 = r5.f2679c
            monitor-enter(r0)
            java.lang.String r1 = "AdRendererBackgroundTask started."
            com.google.android.gms.internal.C0759fe.m4729b(r1)     // Catch:{ all -> 0x0060 }
            com.google.android.gms.internal.eq r1 = r5.f2681e     // Catch:{ all -> 0x0060 }
            int r1 = r1.f3180e     // Catch:{ all -> 0x0060 }
            long r2 = android.os.SystemClock.elapsedRealtime()     // Catch:{ aps -> 0x0014 }
            r5.mo2516a(r2)     // Catch:{ aps -> 0x0014 }
            goto L_0x0050
        L_0x0014:
            r1 = move-exception
            int r2 = r1.mo2519a()     // Catch:{ all -> 0x0060 }
            r3 = 3
            if (r2 == r3) goto L_0x0028
            r3 = -1
            if (r2 != r3) goto L_0x0020
            goto L_0x0028
        L_0x0020:
            java.lang.String r1 = r1.getMessage()     // Catch:{ all -> 0x0060 }
            com.google.android.gms.internal.C0759fe.m4734e(r1)     // Catch:{ all -> 0x0060 }
            goto L_0x002f
        L_0x0028:
            java.lang.String r1 = r1.getMessage()     // Catch:{ all -> 0x0060 }
            com.google.android.gms.internal.C0759fe.m4733d(r1)     // Catch:{ all -> 0x0060 }
        L_0x002f:
            com.google.android.gms.internal.r r1 = r5.f2682f     // Catch:{ all -> 0x0060 }
            if (r1 != 0) goto L_0x003b
            com.google.android.gms.internal.r r1 = new com.google.android.gms.internal.r     // Catch:{ all -> 0x0060 }
            r1.<init>(r2)     // Catch:{ all -> 0x0060 }
        L_0x0038:
            r5.f2682f = r1     // Catch:{ all -> 0x0060 }
            goto L_0x0045
        L_0x003b:
            com.google.android.gms.internal.r r1 = new com.google.android.gms.internal.r     // Catch:{ all -> 0x0060 }
            com.google.android.gms.internal.r r3 = r5.f2682f     // Catch:{ all -> 0x0060 }
            long r3 = r3.f4447j     // Catch:{ all -> 0x0060 }
            r1.<init>(r2, r3)     // Catch:{ all -> 0x0060 }
            goto L_0x0038
        L_0x0045:
            android.os.Handler r1 = com.google.android.gms.internal.C0796go.f3327a     // Catch:{ all -> 0x0060 }
            com.google.android.gms.internal.apq r3 = new com.google.android.gms.internal.apq     // Catch:{ all -> 0x0060 }
            r3.<init>(r5)     // Catch:{ all -> 0x0060 }
            r1.post(r3)     // Catch:{ all -> 0x0060 }
            r1 = r2
        L_0x0050:
            com.google.android.gms.internal.ep r1 = r5.mo2515a(r1)     // Catch:{ all -> 0x0060 }
            android.os.Handler r2 = com.google.android.gms.internal.C0796go.f3327a     // Catch:{ all -> 0x0060 }
            com.google.android.gms.internal.apr r3 = new com.google.android.gms.internal.apr     // Catch:{ all -> 0x0060 }
            r3.<init>(r5, r1)     // Catch:{ all -> 0x0060 }
            r2.post(r3)     // Catch:{ all -> 0x0060 }
            monitor-exit(r0)     // Catch:{ all -> 0x0060 }
            return
        L_0x0060:
            r1 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x0060 }
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.C0635app.mo1567a():void");
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public abstract void mo2516a(long j);

    /* renamed from: b */
    public void mo1568b() {
    }
}
