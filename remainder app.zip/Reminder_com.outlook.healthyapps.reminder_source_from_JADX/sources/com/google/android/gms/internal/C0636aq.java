package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.p017js.C0390a;

/* renamed from: com.google.android.gms.internal.aq */
public final class C0636aq implements C0824hp<C0390a> {
    /* renamed from: a */
    public final /* synthetic */ void mo1487a(Object obj) {
        C0627aj.m3193a((C0390a) obj);
    }
}
