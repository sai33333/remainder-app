package com.google.android.gms.internal;

import android.location.Location;
import android.os.Bundle;
import com.google.android.gms.ads.p015c.C0313a.C0314a;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONObject;

@arm
/* renamed from: com.google.android.gms.internal.au */
public final class C0640au {

    /* renamed from: a */
    public Bundle f2836a;

    /* renamed from: b */
    public Bundle f2837b;

    /* renamed from: c */
    public List<String> f2838c = new ArrayList();

    /* renamed from: d */
    public Location f2839d;

    /* renamed from: e */
    public C0671by f2840e;

    /* renamed from: f */
    public String f2841f;

    /* renamed from: g */
    public String f2842g;

    /* renamed from: h */
    public C0314a f2843h;

    /* renamed from: i */
    public C0970n f2844i;

    /* renamed from: j */
    public C0659bm f2845j;

    /* renamed from: k */
    public JSONObject f2846k = new JSONObject();

    /* renamed from: l */
    public boolean f2847l;
}
