package com.google.android.gms.internal;

@arm
/* renamed from: com.google.android.gms.internal.av */
public final class C0641av {

    /* renamed from: a */
    public final C0657bk f2848a = null;

    /* renamed from: b */
    public final C1382zx f2849b;

    /* renamed from: c */
    public final C0738ek f2850c;

    /* renamed from: d */
    public final aea f2851d;

    /* renamed from: e */
    public final C0668bv f2852e;

    /* renamed from: f */
    public final ame f2853f;

    /* renamed from: g */
    public final C0670bx f2854g;

    /* renamed from: h */
    public final apd f2855h;

    /* renamed from: i */
    public final C0742eo f2856i;

    /* renamed from: j */
    public final boolean f2857j;

    /* renamed from: k */
    private C0669bw f2858k;

    private C0641av(C0657bk bkVar, C1382zx zxVar, C0738ek ekVar, aea aea, C0668bv bvVar, ame ame, C0669bw bwVar, C0670bx bxVar, apd apd, C0742eo eoVar, boolean z) {
        this.f2849b = zxVar;
        this.f2850c = ekVar;
        this.f2851d = aea;
        this.f2852e = bvVar;
        this.f2853f = ame;
        this.f2858k = bwVar;
        this.f2854g = bxVar;
        this.f2855h = apd;
        this.f2856i = eoVar;
        this.f2857j = true;
    }

    /* JADX WARNING: type inference failed for: r7v0, types: [com.google.android.gms.internal.bz, com.google.android.gms.internal.bw] */
    /* JADX WARNING: Multi-variable type inference failed. Error: jadx.core.utils.exceptions.JadxRuntimeException: No candidate types for var: r7v0, types: [com.google.android.gms.internal.bz, com.google.android.gms.internal.bw]
      assigns: [com.google.android.gms.internal.bz]
      uses: [com.google.android.gms.internal.bw]
      mth insns count: 11
    	at jadx.core.dex.visitors.typeinference.TypeSearch.fillTypeCandidates(TypeSearch.java:237)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1540)
    	at jadx.core.dex.visitors.typeinference.TypeSearch.run(TypeSearch.java:53)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runMultiVariableSearch(TypeInferenceVisitor.java:99)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:92)
    	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:27)
    	at jadx.core.dex.visitors.DepthTraversal.lambda$visit$1(DepthTraversal.java:14)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1540)
    	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
    	at jadx.core.ProcessClass.process(ProcessClass.java:30)
    	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:311)
    	at jadx.api.JavaClass.decompile(JavaClass.java:62)
    	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:217)
     */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static com.google.android.gms.internal.C0641av m4000a() {
        /*
            com.google.android.gms.internal.av r12 = new com.google.android.gms.internal.av
            com.google.android.gms.internal.aaa r2 = new com.google.android.gms.internal.aaa
            r2.<init>()
            com.google.android.gms.internal.el r3 = new com.google.android.gms.internal.el
            r3.<init>()
            com.google.android.gms.internal.adz r4 = new com.google.android.gms.internal.adz
            r4.<init>()
            com.google.android.gms.internal.br r5 = new com.google.android.gms.internal.br
            r5.<init>()
            com.google.android.gms.internal.amf r6 = new com.google.android.gms.internal.amf
            r6.<init>()
            com.google.android.gms.internal.bz r7 = new com.google.android.gms.internal.bz
            r7.<init>()
            com.google.android.gms.internal.ca r8 = new com.google.android.gms.internal.ca
            r8.<init>()
            com.google.android.gms.internal.apc r9 = new com.google.android.gms.internal.apc
            r9.<init>()
            com.google.android.gms.internal.em r10 = new com.google.android.gms.internal.em
            r10.<init>()
            r1 = 0
            r11 = 1
            r0 = r12
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11)
            return r12
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.C0641av.m4000a():com.google.android.gms.internal.av");
    }
}
