package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.az */
final class C0645az implements C0875jm {

    /* renamed from: a */
    private /* synthetic */ C0643ax f2872a;

    C0645az(C0643ax axVar) {
        this.f2872a = axVar;
    }

    /* renamed from: a */
    public final void mo1486a() {
        C0759fe.m4731c("JS engine could not be obtained. Cancelling ad request");
        this.f2872a.f2865a.mo2571a();
    }
}
