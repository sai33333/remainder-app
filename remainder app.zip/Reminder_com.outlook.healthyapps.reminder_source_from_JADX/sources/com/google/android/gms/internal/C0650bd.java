package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.bd */
final class C0650bd {

    /* renamed from: a */
    public final String f2883a;

    /* renamed from: b */
    public final long f2884b;

    /* renamed from: c */
    public final long f2885c;

    public C0650bd(String str, long j, long j2) {
        this.f2883a = str;
        this.f2884b = j;
        this.f2885c = j2;
    }
}
