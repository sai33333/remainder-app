package com.google.android.gms.internal;

import android.location.Location;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import org.json.JSONArray;

@arm
/* renamed from: com.google.android.gms.internal.be */
public final class C0651be {

    /* renamed from: a */
    private static final SimpleDateFormat f2886a = new SimpleDateFormat("yyyyMMdd", Locale.US);

    /* JADX WARNING: Removed duplicated region for block: B:36:0x00db A[Catch:{ JSONException -> 0x0247 }] */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x00e1 A[Catch:{ JSONException -> 0x0247 }] */
    /* JADX WARNING: Removed duplicated region for block: B:67:0x0144 A[Catch:{ JSONException -> 0x0247 }] */
    /* JADX WARNING: Removed duplicated region for block: B:68:0x014d A[Catch:{ JSONException -> 0x0247 }] */
    /* JADX WARNING: Removed duplicated region for block: B:71:0x01f4 A[Catch:{ JSONException -> 0x0247 }] */
    /* JADX WARNING: Removed duplicated region for block: B:72:0x01f7 A[Catch:{ JSONException -> 0x0247 }] */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static com.google.android.gms.internal.C1135r m4011a(android.content.Context r50, com.google.android.gms.internal.C0970n r51, java.lang.String r52) {
        /*
            r0 = r51
            r15 = 0
            org.json.JSONObject r9 = new org.json.JSONObject     // Catch:{ JSONException -> 0x0247 }
            r1 = r52
            r9.<init>(r1)     // Catch:{ JSONException -> 0x0247 }
            java.lang.String r1 = "ad_base_url"
            r10 = 0
            java.lang.String r1 = r9.optString(r1, r10)     // Catch:{ JSONException -> 0x0247 }
            java.lang.String r2 = "ad_url"
            java.lang.String r4 = r9.optString(r2, r10)     // Catch:{ JSONException -> 0x0247 }
            java.lang.String r2 = "ad_size"
            java.lang.String r13 = r9.optString(r2, r10)     // Catch:{ JSONException -> 0x0247 }
            java.lang.String r2 = "ad_slot_size"
            java.lang.String r40 = r9.optString(r2, r13)     // Catch:{ JSONException -> 0x0247 }
            r11 = 1
            if (r0 == 0) goto L_0x002d
            int r2 = r0.f4006m     // Catch:{ JSONException -> 0x0247 }
            if (r2 == 0) goto L_0x002d
            r24 = r11
            goto L_0x002f
        L_0x002d:
            r24 = r15
        L_0x002f:
            java.lang.String r2 = "ad_json"
            java.lang.String r2 = r9.optString(r2, r10)     // Catch:{ JSONException -> 0x0247 }
            if (r2 != 0) goto L_0x003d
            java.lang.String r2 = "ad_html"
            java.lang.String r2 = r9.optString(r2, r10)     // Catch:{ JSONException -> 0x0247 }
        L_0x003d:
            if (r2 != 0) goto L_0x0045
            java.lang.String r2 = "body"
            java.lang.String r2 = r9.optString(r2, r10)     // Catch:{ JSONException -> 0x0247 }
        L_0x0045:
            if (r2 != 0) goto L_0x0053
            java.lang.String r3 = "ads"
            boolean r3 = r9.has(r3)     // Catch:{ JSONException -> 0x0247 }
            if (r3 == 0) goto L_0x0053
            java.lang.String r2 = r9.toString()     // Catch:{ JSONException -> 0x0247 }
        L_0x0053:
            java.lang.String r3 = "debug_dialog"
            java.lang.String r19 = r9.optString(r3, r10)     // Catch:{ JSONException -> 0x0247 }
            java.lang.String r3 = "debug_signals"
            java.lang.String r42 = r9.optString(r3, r10)     // Catch:{ JSONException -> 0x0247 }
            java.lang.String r3 = "interstitial_timeout"
            boolean r3 = r9.has(r3)     // Catch:{ JSONException -> 0x0247 }
            r7 = -1
            if (r3 == 0) goto L_0x007a
            java.lang.String r3 = "interstitial_timeout"
            double r5 = r9.getDouble(r3)     // Catch:{ JSONException -> 0x0247 }
            r16 = 4652007308841189376(0x408f400000000000, double:1000.0)
            double r5 = r5 * r16
            long r5 = (long) r5     // Catch:{ JSONException -> 0x0247 }
            r16 = r5
            goto L_0x007c
        L_0x007a:
            r16 = r7
        L_0x007c:
            java.lang.String r3 = "orientation"
            java.lang.String r3 = r9.optString(r3, r10)     // Catch:{ JSONException -> 0x0247 }
            java.lang.String r5 = "portrait"
            boolean r5 = r5.equals(r3)     // Catch:{ JSONException -> 0x0247 }
            r12 = -1
            if (r5 == 0) goto L_0x0095
            com.google.android.gms.internal.gt r3 = com.google.android.gms.ads.internal.C0354ax.m1540g()     // Catch:{ JSONException -> 0x0247 }
            int r3 = r3.mo2824b()     // Catch:{ JSONException -> 0x0247 }
        L_0x0093:
            r14 = r3
            goto L_0x00a7
        L_0x0095:
            java.lang.String r5 = "landscape"
            boolean r3 = r5.equals(r3)     // Catch:{ JSONException -> 0x0247 }
            if (r3 == 0) goto L_0x00a6
            com.google.android.gms.internal.gt r3 = com.google.android.gms.ads.internal.C0354ax.m1540g()     // Catch:{ JSONException -> 0x0247 }
            int r3 = r3.mo2811a()     // Catch:{ JSONException -> 0x0247 }
            goto L_0x0093
        L_0x00a6:
            r14 = r12
        L_0x00a7:
            boolean r3 = android.text.TextUtils.isEmpty(r2)     // Catch:{ JSONException -> 0x0247 }
            if (r3 == 0) goto L_0x00d4
            boolean r3 = android.text.TextUtils.isEmpty(r4)     // Catch:{ JSONException -> 0x0247 }
            if (r3 != 0) goto L_0x00d4
            com.google.android.gms.internal.iv r1 = r0.f4004k     // Catch:{ JSONException -> 0x0247 }
            java.lang.String r3 = r1.f3448a     // Catch:{ JSONException -> 0x0247 }
            r5 = 0
            r6 = 0
            r18 = 0
            r20 = 0
            r1 = r51
            r2 = r50
            r7 = r18
            r8 = r20
            com.google.android.gms.internal.r r1 = com.google.android.gms.internal.C0642aw.m4003a(r1, r2, r3, r4, r5, r6, r7, r8)     // Catch:{ JSONException -> 0x0247 }
            java.lang.String r2 = r1.f4438a     // Catch:{ JSONException -> 0x0247 }
            java.lang.String r3 = r1.f4439b     // Catch:{ JSONException -> 0x0247 }
            long r4 = r1.f4450m     // Catch:{ JSONException -> 0x0247 }
            r20 = r4
            r4 = r3
            r3 = r2
            goto L_0x00d9
        L_0x00d4:
            r3 = r1
            r4 = r2
            r1 = r10
            r20 = -1
        L_0x00d9:
            if (r4 != 0) goto L_0x00e1
            com.google.android.gms.internal.r r0 = new com.google.android.gms.internal.r     // Catch:{ JSONException -> 0x0247 }
            r0.<init>(r15)     // Catch:{ JSONException -> 0x0247 }
            return r0
        L_0x00e1:
            java.lang.String r2 = "click_urls"
            org.json.JSONArray r2 = r9.optJSONArray(r2)     // Catch:{ JSONException -> 0x0247 }
            if (r1 != 0) goto L_0x00eb
            r5 = r10
            goto L_0x00ed
        L_0x00eb:
            java.util.List<java.lang.String> r5 = r1.f4440c     // Catch:{ JSONException -> 0x0247 }
        L_0x00ed:
            if (r2 == 0) goto L_0x00f4
            java.util.List r2 = m4013a(r2, r5)     // Catch:{ JSONException -> 0x0247 }
            r5 = r2
        L_0x00f4:
            java.lang.String r2 = "impression_urls"
            org.json.JSONArray r2 = r9.optJSONArray(r2)     // Catch:{ JSONException -> 0x0247 }
            if (r1 != 0) goto L_0x00fe
            r6 = r10
            goto L_0x0100
        L_0x00fe:
            java.util.List<java.lang.String> r6 = r1.f4442e     // Catch:{ JSONException -> 0x0247 }
        L_0x0100:
            if (r2 == 0) goto L_0x0107
            java.util.List r2 = m4013a(r2, r6)     // Catch:{ JSONException -> 0x0247 }
            r6 = r2
        L_0x0107:
            java.lang.String r2 = "manual_impression_urls"
            org.json.JSONArray r2 = r9.optJSONArray(r2)     // Catch:{ JSONException -> 0x0247 }
            if (r1 != 0) goto L_0x0111
            r7 = r10
            goto L_0x0113
        L_0x0111:
            java.util.List<java.lang.String> r7 = r1.f4446i     // Catch:{ JSONException -> 0x0247 }
        L_0x0113:
            if (r2 == 0) goto L_0x011c
            java.util.List r2 = m4013a(r2, r7)     // Catch:{ JSONException -> 0x0247 }
            r18 = r2
            goto L_0x011e
        L_0x011c:
            r18 = r7
        L_0x011e:
            if (r1 == 0) goto L_0x0132
            int r2 = r1.f4448k     // Catch:{ JSONException -> 0x0247 }
            if (r2 == r12) goto L_0x0126
            int r14 = r1.f4448k     // Catch:{ JSONException -> 0x0247 }
        L_0x0126:
            long r7 = r1.f4443f     // Catch:{ JSONException -> 0x0247 }
            r22 = 0
            int r2 = (r7 > r22 ? 1 : (r7 == r22 ? 0 : -1))
            if (r2 <= 0) goto L_0x0132
            long r1 = r1.f4443f     // Catch:{ JSONException -> 0x0247 }
            r7 = r1
            goto L_0x0134
        L_0x0132:
            r7 = r16
        L_0x0134:
            r16 = r14
            java.lang.String r1 = "active_view"
            java.lang.String r22 = r9.optString(r1)     // Catch:{ JSONException -> 0x0247 }
            java.lang.String r1 = "ad_is_javascript"
            boolean r23 = r9.optBoolean(r1, r15)     // Catch:{ JSONException -> 0x0247 }
            if (r23 == 0) goto L_0x014d
            java.lang.String r1 = "ad_passback_url"
            java.lang.String r1 = r9.optString(r1, r10)     // Catch:{ JSONException -> 0x0247 }
            r25 = r1
            goto L_0x014f
        L_0x014d:
            r25 = r10
        L_0x014f:
            java.lang.String r1 = "mediation"
            boolean r12 = r9.optBoolean(r1, r15)     // Catch:{ JSONException -> 0x0247 }
            java.lang.String r1 = "custom_render_allowed"
            boolean r26 = r9.optBoolean(r1, r15)     // Catch:{ JSONException -> 0x0247 }
            java.lang.String r1 = "content_url_opted_out"
            boolean r27 = r9.optBoolean(r1, r11)     // Catch:{ JSONException -> 0x0247 }
            java.lang.String r1 = "content_vertical_opted_out"
            boolean r43 = r9.optBoolean(r1, r11)     // Catch:{ JSONException -> 0x0247 }
            java.lang.String r1 = "prefetch"
            boolean r28 = r9.optBoolean(r1, r15)     // Catch:{ JSONException -> 0x0247 }
            java.lang.String r1 = "refresh_interval_milliseconds"
            r50 = r12
            r11 = -1
            long r29 = r9.optLong(r1, r11)     // Catch:{ JSONException -> 0x0247 }
            java.lang.String r1 = "mediation_config_cache_time_milliseconds"
            long r11 = r9.optLong(r1, r11)     // Catch:{ JSONException -> 0x0247 }
            java.lang.String r1 = "gws_query_id"
            java.lang.String r2 = ""
            java.lang.String r31 = r9.optString(r1, r2)     // Catch:{ JSONException -> 0x0247 }
            java.lang.String r1 = "height"
            java.lang.String r2 = "fluid"
            java.lang.String r14 = ""
            java.lang.String r2 = r9.optString(r2, r14)     // Catch:{ JSONException -> 0x0247 }
            boolean r32 = r1.equals(r2)     // Catch:{ JSONException -> 0x0247 }
            java.lang.String r1 = "native_express"
            boolean r33 = r9.optBoolean(r1, r15)     // Catch:{ JSONException -> 0x0247 }
            java.lang.String r1 = "video_start_urls"
            org.json.JSONArray r1 = r9.optJSONArray(r1)     // Catch:{ JSONException -> 0x0247 }
            java.util.List r34 = m4013a(r1, r10)     // Catch:{ JSONException -> 0x0247 }
            java.lang.String r1 = "video_complete_urls"
            org.json.JSONArray r1 = r9.optJSONArray(r1)     // Catch:{ JSONException -> 0x0247 }
            java.util.List r35 = m4013a(r1, r10)     // Catch:{ JSONException -> 0x0247 }
            java.lang.String r1 = "rewards"
            org.json.JSONArray r1 = r9.optJSONArray(r1)     // Catch:{ JSONException -> 0x0247 }
            com.google.android.gms.internal.dq r36 = com.google.android.gms.internal.C0717dq.m4251a(r1)     // Catch:{ JSONException -> 0x0247 }
            java.lang.String r1 = "use_displayed_impression"
            boolean r37 = r9.optBoolean(r1, r15)     // Catch:{ JSONException -> 0x0247 }
            java.lang.String r1 = "auto_protection_configuration"
            org.json.JSONObject r1 = r9.optJSONObject(r1)     // Catch:{ JSONException -> 0x0247 }
            com.google.android.gms.internal.t r38 = com.google.android.gms.internal.C1190t.m5764a(r1)     // Catch:{ JSONException -> 0x0247 }
            java.lang.String r1 = "set_cookie"
            java.lang.String r2 = ""
            java.lang.String r39 = r9.optString(r1, r2)     // Catch:{ JSONException -> 0x0247 }
            java.lang.String r1 = "remote_ping_urls"
            org.json.JSONArray r1 = r9.optJSONArray(r1)     // Catch:{ JSONException -> 0x0247 }
            java.util.List r41 = m4013a(r1, r10)     // Catch:{ JSONException -> 0x0247 }
            java.lang.String r1 = "safe_browsing"
            org.json.JSONObject r1 = r9.optJSONObject(r1)     // Catch:{ JSONException -> 0x0247 }
            com.google.android.gms.internal.dy r44 = com.google.android.gms.internal.C0725dy.m4266a(r1)     // Catch:{ JSONException -> 0x0247 }
            java.lang.String r1 = "render_in_browser"
            boolean r2 = r0.f3977K     // Catch:{ JSONException -> 0x0247 }
            boolean r45 = r9.optBoolean(r1, r2)     // Catch:{ JSONException -> 0x0247 }
            java.lang.String r1 = "custom_close_allowed"
            r2 = 1
            boolean r1 = r9.optBoolean(r1, r2)     // Catch:{ JSONException -> 0x0247 }
            if (r1 != 0) goto L_0x01f7
            r46 = r2
            goto L_0x01f9
        L_0x01f7:
            r46 = r15
        L_0x01f9:
            com.google.android.gms.internal.r r47 = new com.google.android.gms.internal.r     // Catch:{ JSONException -> 0x0247 }
            boolean r14 = r0.f4009p     // Catch:{ JSONException -> 0x0247 }
            boolean r10 = r0.f3973G     // Catch:{ JSONException -> 0x0247 }
            boolean r9 = r0.f3987U     // Catch:{ JSONException -> 0x0247 }
            r1 = r47
            r2 = r51
            r0 = r9
            r9 = r50
            r48 = r10
            r10 = r11
            r12 = r18
            r17 = r13
            r49 = r14
            r13 = r29
            r15 = r16
            r16 = r17
            r17 = r20
            r20 = r23
            r21 = r25
            r23 = r26
            r25 = r49
            r26 = r27
            r27 = r28
            r28 = r31
            r29 = r32
            r30 = r33
            r31 = r36
            r32 = r34
            r33 = r35
            r34 = r37
            r35 = r38
            r36 = r48
            r37 = r39
            r38 = r41
            r39 = r45
            r41 = r44
            r44 = r0
            r45 = r46
            r1.<init>(r2, r3, r4, r5, r6, r7, r9, r10, r12, r13, r15, r16, r17, r19, r20, r21, r22, r23, r24, r25, r26, r27, r28, r29, r30, r31, r32, r33, r34, r35, r36, r37, r38, r39, r40, r41, r42, r43, r44, r45)     // Catch:{ JSONException -> 0x0247 }
            return r47
        L_0x0247:
            r0 = move-exception
            java.lang.String r1 = "Could not parse the inline ad response: "
            java.lang.String r0 = r0.getMessage()
            java.lang.String r0 = java.lang.String.valueOf(r0)
            int r2 = r0.length()
            if (r2 == 0) goto L_0x025d
            java.lang.String r0 = r1.concat(r0)
            goto L_0x0262
        L_0x025d:
            java.lang.String r0 = new java.lang.String
            r0.<init>(r1)
        L_0x0262:
            com.google.android.gms.internal.C0759fe.m4734e(r0)
            com.google.android.gms.internal.r r0 = new com.google.android.gms.internal.r
            r1 = 0
            r0.<init>(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.C0651be.m4011a(android.content.Context, com.google.android.gms.internal.n, java.lang.String):com.google.android.gms.internal.r");
    }

    /* renamed from: a */
    private static Integer m4012a(boolean z) {
        return Integer.valueOf(z ? 1 : 0);
    }

    /* renamed from: a */
    private static List<String> m4013a(JSONArray jSONArray, List<String> list) {
        if (jSONArray == null) {
            return null;
        }
        if (list == null) {
            list = new LinkedList<>();
        }
        for (int i = 0; i < jSONArray.length(); i++) {
            list.add(jSONArray.getString(i));
        }
        return list;
    }

    /* renamed from: a */
    private static JSONArray m4014a(List<String> list) {
        JSONArray jSONArray = new JSONArray();
        for (String put : list) {
            jSONArray.put(put);
        }
        return jSONArray;
    }

    /* JADX WARNING: Removed duplicated region for block: B:210:0x05c2 A[Catch:{ JSONException -> 0x08ab }] */
    /* JADX WARNING: Removed duplicated region for block: B:217:0x05df A[Catch:{ JSONException -> 0x08ab }] */
    /* JADX WARNING: Removed duplicated region for block: B:220:0x05ea A[Catch:{ JSONException -> 0x08ab }] */
    /* JADX WARNING: Removed duplicated region for block: B:222:0x060c A[Catch:{ JSONException -> 0x08ab }] */
    /* JADX WARNING: Removed duplicated region for block: B:225:0x0630 A[Catch:{ JSONException -> 0x08ab }] */
    /* JADX WARNING: Removed duplicated region for block: B:237:0x065c A[Catch:{ JSONException -> 0x08ab }] */
    /* JADX WARNING: Removed duplicated region for block: B:245:0x067e A[Catch:{ JSONException -> 0x08ab }] */
    /* JADX WARNING: Removed duplicated region for block: B:248:0x068f A[Catch:{ JSONException -> 0x08ab }] */
    /* JADX WARNING: Removed duplicated region for block: B:256:0x06b5 A[Catch:{ JSONException -> 0x08ab }] */
    /* JADX WARNING: Removed duplicated region for block: B:263:0x06cd A[Catch:{ JSONException -> 0x08ab }] */
    /* JADX WARNING: Removed duplicated region for block: B:266:0x06dc A[Catch:{ JSONException -> 0x08ab }] */
    /* JADX WARNING: Removed duplicated region for block: B:278:0x0707 A[Catch:{ JSONException -> 0x08ab }] */
    /* JADX WARNING: Removed duplicated region for block: B:281:0x0778 A[Catch:{ JSONException -> 0x08ab }] */
    /* JADX WARNING: Removed duplicated region for block: B:289:0x07a2 A[Catch:{ JSONException -> 0x08ab }] */
    /* JADX WARNING: Removed duplicated region for block: B:298:0x07be A[Catch:{ JSONException -> 0x08ab }] */
    /* JADX WARNING: Removed duplicated region for block: B:299:0x07c1 A[Catch:{ JSONException -> 0x08ab }] */
    /* JADX WARNING: Removed duplicated region for block: B:309:0x07f9 A[Catch:{ JSONException -> 0x08ab }] */
    /* JADX WARNING: Removed duplicated region for block: B:311:0x0809 A[Catch:{ JSONException -> 0x08ab }] */
    /* JADX WARNING: Removed duplicated region for block: B:318:0x0824 A[Catch:{ JSONException -> 0x08ab }] */
    /* JADX WARNING: Removed duplicated region for block: B:325:0x0857 A[Catch:{ JSONException -> 0x08ab }] */
    /* JADX WARNING: Removed duplicated region for block: B:331:0x087d A[Catch:{ JSONException -> 0x08ab }] */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static org.json.JSONObject m4015a(android.content.Context r22, com.google.android.gms.internal.C0640au r23) {
        /*
            r1 = r23
            com.google.android.gms.internal.n r2 = r1.f2844i
            android.location.Location r3 = r1.f2839d
            com.google.android.gms.internal.bm r4 = r1.f2845j
            android.os.Bundle r5 = r1.f2836a
            org.json.JSONObject r6 = r1.f2846k
            java.util.HashMap r8 = new java.util.HashMap     // Catch:{ JSONException -> 0x08ab }
            r8.<init>()     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r9 = "extra_caps"
            com.google.android.gms.internal.aeb<java.lang.String> r10 = com.google.android.gms.internal.ael.f1889bH     // Catch:{ JSONException -> 0x08ab }
            com.google.android.gms.internal.aej r11 = com.google.android.gms.ads.internal.C0354ax.m1551r()     // Catch:{ JSONException -> 0x08ab }
            java.lang.Object r10 = r11.mo2079a(r10)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r9, r10)     // Catch:{ JSONException -> 0x08ab }
            java.util.List<java.lang.String> r9 = r1.f2838c     // Catch:{ JSONException -> 0x08ab }
            int r9 = r9.size()     // Catch:{ JSONException -> 0x08ab }
            if (r9 <= 0) goto L_0x0035
            java.lang.String r9 = "eid"
            java.lang.String r10 = ","
            java.util.List<java.lang.String> r11 = r1.f2838c     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r10 = android.text.TextUtils.join(r10, r11)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r9, r10)     // Catch:{ JSONException -> 0x08ab }
        L_0x0035:
            android.os.Bundle r9 = r2.f3995b     // Catch:{ JSONException -> 0x08ab }
            if (r9 == 0) goto L_0x0040
            java.lang.String r9 = "ad_pos"
            android.os.Bundle r10 = r2.f3995b     // Catch:{ JSONException -> 0x08ab }
            r8.put(r9, r10)     // Catch:{ JSONException -> 0x08ab }
        L_0x0040:
            com.google.android.gms.internal.aau r9 = r2.f3996c     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r10 = com.google.android.gms.internal.C0756fb.m4403a()     // Catch:{ JSONException -> 0x08ab }
            if (r10 == 0) goto L_0x004d
            java.lang.String r11 = "abf"
            r8.put(r11, r10)     // Catch:{ JSONException -> 0x08ab }
        L_0x004d:
            long r10 = r9.f1615b     // Catch:{ JSONException -> 0x08ab }
            r12 = -1
            int r10 = (r10 > r12 ? 1 : (r10 == r12 ? 0 : -1))
            if (r10 == 0) goto L_0x0067
            java.lang.String r10 = "cust_age"
            java.text.SimpleDateFormat r11 = f2886a     // Catch:{ JSONException -> 0x08ab }
            java.util.Date r14 = new java.util.Date     // Catch:{ JSONException -> 0x08ab }
            long r12 = r9.f1615b     // Catch:{ JSONException -> 0x08ab }
            r14.<init>(r12)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r11 = r11.format(r14)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r10, r11)     // Catch:{ JSONException -> 0x08ab }
        L_0x0067:
            android.os.Bundle r10 = r9.f1616c     // Catch:{ JSONException -> 0x08ab }
            if (r10 == 0) goto L_0x0072
            java.lang.String r10 = "extras"
            android.os.Bundle r11 = r9.f1616c     // Catch:{ JSONException -> 0x08ab }
            r8.put(r10, r11)     // Catch:{ JSONException -> 0x08ab }
        L_0x0072:
            int r10 = r9.f1617d     // Catch:{ JSONException -> 0x08ab }
            r11 = -1
            if (r10 == r11) goto L_0x0082
            java.lang.String r10 = "cust_gender"
            int r12 = r9.f1617d     // Catch:{ JSONException -> 0x08ab }
            java.lang.Integer r12 = java.lang.Integer.valueOf(r12)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r10, r12)     // Catch:{ JSONException -> 0x08ab }
        L_0x0082:
            java.util.List<java.lang.String> r10 = r9.f1618e     // Catch:{ JSONException -> 0x08ab }
            if (r10 == 0) goto L_0x008d
            java.lang.String r10 = "kw"
            java.util.List<java.lang.String> r12 = r9.f1618e     // Catch:{ JSONException -> 0x08ab }
            r8.put(r10, r12)     // Catch:{ JSONException -> 0x08ab }
        L_0x008d:
            int r10 = r9.f1620g     // Catch:{ JSONException -> 0x08ab }
            if (r10 == r11) goto L_0x009c
            java.lang.String r10 = "tag_for_child_directed_treatment"
            int r12 = r9.f1620g     // Catch:{ JSONException -> 0x08ab }
            java.lang.Integer r12 = java.lang.Integer.valueOf(r12)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r10, r12)     // Catch:{ JSONException -> 0x08ab }
        L_0x009c:
            boolean r10 = r9.f1619f     // Catch:{ JSONException -> 0x08ab }
            if (r10 == 0) goto L_0x00a7
            java.lang.String r10 = "adtest"
            java.lang.String r12 = "on"
            r8.put(r10, r12)     // Catch:{ JSONException -> 0x08ab }
        L_0x00a7:
            int r10 = r9.f1614a     // Catch:{ JSONException -> 0x08ab }
            r12 = 2
            r13 = 1
            if (r10 < r12) goto L_0x00c9
            boolean r10 = r9.f1621h     // Catch:{ JSONException -> 0x08ab }
            if (r10 == 0) goto L_0x00ba
            java.lang.String r10 = "d_imp_hdr"
            java.lang.Integer r14 = java.lang.Integer.valueOf(r13)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r10, r14)     // Catch:{ JSONException -> 0x08ab }
        L_0x00ba:
            java.lang.String r10 = r9.f1622i     // Catch:{ JSONException -> 0x08ab }
            boolean r10 = android.text.TextUtils.isEmpty(r10)     // Catch:{ JSONException -> 0x08ab }
            if (r10 != 0) goto L_0x00c9
            java.lang.String r10 = "ppid"
            java.lang.String r14 = r9.f1622i     // Catch:{ JSONException -> 0x08ab }
            r8.put(r10, r14)     // Catch:{ JSONException -> 0x08ab }
        L_0x00c9:
            int r10 = r9.f1614a     // Catch:{ JSONException -> 0x08ab }
            r14 = 3
            if (r10 < r14) goto L_0x00d9
            java.lang.String r10 = r9.f1625l     // Catch:{ JSONException -> 0x08ab }
            if (r10 == 0) goto L_0x00d9
            java.lang.String r10 = "url"
            java.lang.String r14 = r9.f1625l     // Catch:{ JSONException -> 0x08ab }
            r8.put(r10, r14)     // Catch:{ JSONException -> 0x08ab }
        L_0x00d9:
            int r10 = r9.f1614a     // Catch:{ JSONException -> 0x08ab }
            r14 = 5
            if (r10 < r14) goto L_0x00ff
            android.os.Bundle r10 = r9.f1627n     // Catch:{ JSONException -> 0x08ab }
            if (r10 == 0) goto L_0x00e9
            java.lang.String r10 = "custom_targeting"
            android.os.Bundle r15 = r9.f1627n     // Catch:{ JSONException -> 0x08ab }
            r8.put(r10, r15)     // Catch:{ JSONException -> 0x08ab }
        L_0x00e9:
            java.util.List<java.lang.String> r10 = r9.f1628o     // Catch:{ JSONException -> 0x08ab }
            if (r10 == 0) goto L_0x00f4
            java.lang.String r10 = "category_exclusions"
            java.util.List<java.lang.String> r15 = r9.f1628o     // Catch:{ JSONException -> 0x08ab }
            r8.put(r10, r15)     // Catch:{ JSONException -> 0x08ab }
        L_0x00f4:
            java.lang.String r10 = r9.f1629p     // Catch:{ JSONException -> 0x08ab }
            if (r10 == 0) goto L_0x00ff
            java.lang.String r10 = "request_agent"
            java.lang.String r15 = r9.f1629p     // Catch:{ JSONException -> 0x08ab }
            r8.put(r10, r15)     // Catch:{ JSONException -> 0x08ab }
        L_0x00ff:
            int r10 = r9.f1614a     // Catch:{ JSONException -> 0x08ab }
            r15 = 6
            if (r10 < r15) goto L_0x010f
            java.lang.String r10 = r9.f1630q     // Catch:{ JSONException -> 0x08ab }
            if (r10 == 0) goto L_0x010f
            java.lang.String r10 = "request_pkg"
            java.lang.String r7 = r9.f1630q     // Catch:{ JSONException -> 0x08ab }
            r8.put(r10, r7)     // Catch:{ JSONException -> 0x08ab }
        L_0x010f:
            int r7 = r9.f1614a     // Catch:{ JSONException -> 0x08ab }
            r10 = 7
            if (r7 < r10) goto L_0x011f
            java.lang.String r7 = "is_designed_for_families"
            boolean r9 = r9.f1631r     // Catch:{ JSONException -> 0x08ab }
            java.lang.Boolean r9 = java.lang.Boolean.valueOf(r9)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r7, r9)     // Catch:{ JSONException -> 0x08ab }
        L_0x011f:
            com.google.android.gms.internal.aay r7 = r2.f3997d     // Catch:{ JSONException -> 0x08ab }
            com.google.android.gms.internal.aay[] r7 = r7.f1656g     // Catch:{ JSONException -> 0x08ab }
            if (r7 != 0) goto L_0x013c
            java.lang.String r7 = "format"
            com.google.android.gms.internal.aay r10 = r2.f3997d     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r10 = r10.f1650a     // Catch:{ JSONException -> 0x08ab }
            r8.put(r7, r10)     // Catch:{ JSONException -> 0x08ab }
            com.google.android.gms.internal.aay r7 = r2.f3997d     // Catch:{ JSONException -> 0x08ab }
            boolean r7 = r7.f1658i     // Catch:{ JSONException -> 0x08ab }
            if (r7 == 0) goto L_0x0172
            java.lang.String r7 = "fluid"
            java.lang.String r10 = "height"
            r8.put(r7, r10)     // Catch:{ JSONException -> 0x08ab }
            goto L_0x0172
        L_0x013c:
            com.google.android.gms.internal.aay r7 = r2.f3997d     // Catch:{ JSONException -> 0x08ab }
            com.google.android.gms.internal.aay[] r7 = r7.f1656g     // Catch:{ JSONException -> 0x08ab }
            int r10 = r7.length     // Catch:{ JSONException -> 0x08ab }
            r15 = 0
            r17 = 0
            r18 = 0
        L_0x0146:
            if (r15 >= r10) goto L_0x0172
            r14 = r7[r15]     // Catch:{ JSONException -> 0x08ab }
            boolean r13 = r14.f1658i     // Catch:{ JSONException -> 0x08ab }
            if (r13 != 0) goto L_0x0159
            if (r17 != 0) goto L_0x0159
            java.lang.String r13 = "format"
            java.lang.String r12 = r14.f1650a     // Catch:{ JSONException -> 0x08ab }
            r8.put(r13, r12)     // Catch:{ JSONException -> 0x08ab }
            r17 = 1
        L_0x0159:
            boolean r12 = r14.f1658i     // Catch:{ JSONException -> 0x08ab }
            if (r12 == 0) goto L_0x0168
            if (r18 != 0) goto L_0x0168
            java.lang.String r12 = "fluid"
            java.lang.String r13 = "height"
            r8.put(r12, r13)     // Catch:{ JSONException -> 0x08ab }
            r18 = 1
        L_0x0168:
            if (r17 == 0) goto L_0x016c
            if (r18 != 0) goto L_0x0172
        L_0x016c:
            int r15 = r15 + 1
            r12 = 2
            r13 = 1
            r14 = 5
            goto L_0x0146
        L_0x0172:
            com.google.android.gms.internal.aay r7 = r2.f3997d     // Catch:{ JSONException -> 0x08ab }
            int r7 = r7.f1654e     // Catch:{ JSONException -> 0x08ab }
            if (r7 != r11) goto L_0x017f
            java.lang.String r7 = "smart_w"
            java.lang.String r10 = "full"
            r8.put(r7, r10)     // Catch:{ JSONException -> 0x08ab }
        L_0x017f:
            com.google.android.gms.internal.aay r7 = r2.f3997d     // Catch:{ JSONException -> 0x08ab }
            int r7 = r7.f1651b     // Catch:{ JSONException -> 0x08ab }
            r10 = -2
            if (r7 != r10) goto L_0x018d
            java.lang.String r7 = "smart_h"
            java.lang.String r12 = "auto"
            r8.put(r7, r12)     // Catch:{ JSONException -> 0x08ab }
        L_0x018d:
            com.google.android.gms.internal.aay r7 = r2.f3997d     // Catch:{ JSONException -> 0x08ab }
            com.google.android.gms.internal.aay[] r7 = r7.f1656g     // Catch:{ JSONException -> 0x08ab }
            if (r7 == 0) goto L_0x01fb
            java.lang.StringBuilder r7 = new java.lang.StringBuilder     // Catch:{ JSONException -> 0x08ab }
            r7.<init>()     // Catch:{ JSONException -> 0x08ab }
            com.google.android.gms.internal.aay r12 = r2.f3997d     // Catch:{ JSONException -> 0x08ab }
            com.google.android.gms.internal.aay[] r12 = r12.f1656g     // Catch:{ JSONException -> 0x08ab }
            int r13 = r12.length     // Catch:{ JSONException -> 0x08ab }
            r14 = 0
            r15 = 0
        L_0x019f:
            if (r14 >= r13) goto L_0x01e1
            r9 = r12[r14]     // Catch:{ JSONException -> 0x08ab }
            boolean r10 = r9.f1658i     // Catch:{ JSONException -> 0x08ab }
            if (r10 == 0) goto L_0x01a9
            r15 = 1
            goto L_0x01dc
        L_0x01a9:
            int r10 = r7.length()     // Catch:{ JSONException -> 0x08ab }
            if (r10 == 0) goto L_0x01b4
            java.lang.String r10 = "|"
            r7.append(r10)     // Catch:{ JSONException -> 0x08ab }
        L_0x01b4:
            int r10 = r9.f1654e     // Catch:{ JSONException -> 0x08ab }
            if (r10 != r11) goto L_0x01c0
            int r10 = r9.f1655f     // Catch:{ JSONException -> 0x08ab }
            float r10 = (float) r10     // Catch:{ JSONException -> 0x08ab }
            float r11 = r4.f2966s     // Catch:{ JSONException -> 0x08ab }
            float r10 = r10 / r11
            int r10 = (int) r10     // Catch:{ JSONException -> 0x08ab }
            goto L_0x01c2
        L_0x01c0:
            int r10 = r9.f1654e     // Catch:{ JSONException -> 0x08ab }
        L_0x01c2:
            r7.append(r10)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r10 = "x"
            r7.append(r10)     // Catch:{ JSONException -> 0x08ab }
            int r10 = r9.f1651b     // Catch:{ JSONException -> 0x08ab }
            r11 = -2
            if (r10 != r11) goto L_0x01d7
            int r9 = r9.f1652c     // Catch:{ JSONException -> 0x08ab }
            float r9 = (float) r9     // Catch:{ JSONException -> 0x08ab }
            float r10 = r4.f2966s     // Catch:{ JSONException -> 0x08ab }
            float r9 = r9 / r10
            int r9 = (int) r9     // Catch:{ JSONException -> 0x08ab }
            goto L_0x01d9
        L_0x01d7:
            int r9 = r9.f1651b     // Catch:{ JSONException -> 0x08ab }
        L_0x01d9:
            r7.append(r9)     // Catch:{ JSONException -> 0x08ab }
        L_0x01dc:
            int r14 = r14 + 1
            r10 = -2
            r11 = -1
            goto L_0x019f
        L_0x01e1:
            if (r15 == 0) goto L_0x01f6
            int r9 = r7.length()     // Catch:{ JSONException -> 0x08ab }
            if (r9 == 0) goto L_0x01f0
            java.lang.String r9 = "|"
            r10 = 0
            r7.insert(r10, r9)     // Catch:{ JSONException -> 0x08ab }
            goto L_0x01f1
        L_0x01f0:
            r10 = 0
        L_0x01f1:
            java.lang.String r9 = "320x50"
            r7.insert(r10, r9)     // Catch:{ JSONException -> 0x08ab }
        L_0x01f6:
            java.lang.String r9 = "sz"
            r8.put(r9, r7)     // Catch:{ JSONException -> 0x08ab }
        L_0x01fb:
            int r7 = r2.f4006m     // Catch:{ JSONException -> 0x08ab }
            r9 = 24
            if (r7 == 0) goto L_0x0266
            java.lang.String r7 = "native_version"
            int r10 = r2.f4006m     // Catch:{ JSONException -> 0x08ab }
            java.lang.Integer r10 = java.lang.Integer.valueOf(r10)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r7, r10)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r7 = "native_templates"
            java.util.List<java.lang.String> r10 = r2.f4007n     // Catch:{ JSONException -> 0x08ab }
            r8.put(r7, r10)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r7 = "native_image_orientation"
            com.google.android.gms.internal.agm r10 = r2.f4018y     // Catch:{ JSONException -> 0x08ab }
            if (r10 != 0) goto L_0x021c
        L_0x0219:
            java.lang.String r10 = "any"
            goto L_0x0229
        L_0x021c:
            int r10 = r10.f2210c     // Catch:{ JSONException -> 0x08ab }
            switch(r10) {
                case 0: goto L_0x0219;
                case 1: goto L_0x0227;
                case 2: goto L_0x0224;
                default: goto L_0x0221;
            }     // Catch:{ JSONException -> 0x08ab }
        L_0x0221:
            java.lang.String r10 = "not_set"
            goto L_0x0229
        L_0x0224:
            java.lang.String r10 = "landscape"
            goto L_0x0229
        L_0x0227:
            java.lang.String r10 = "portrait"
        L_0x0229:
            r8.put(r7, r10)     // Catch:{ JSONException -> 0x08ab }
            java.util.List<java.lang.String> r7 = r2.f4019z     // Catch:{ JSONException -> 0x08ab }
            boolean r7 = r7.isEmpty()     // Catch:{ JSONException -> 0x08ab }
            if (r7 != 0) goto L_0x023b
            java.lang.String r7 = "native_custom_templates"
            java.util.List<java.lang.String> r10 = r2.f4019z     // Catch:{ JSONException -> 0x08ab }
            r8.put(r7, r10)     // Catch:{ JSONException -> 0x08ab }
        L_0x023b:
            int r7 = r2.f3993a     // Catch:{ JSONException -> 0x08ab }
            if (r7 < r9) goto L_0x024a
            java.lang.String r7 = "max_num_ads"
            int r10 = r2.f3991Y     // Catch:{ JSONException -> 0x08ab }
            java.lang.Integer r10 = java.lang.Integer.valueOf(r10)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r7, r10)     // Catch:{ JSONException -> 0x08ab }
        L_0x024a:
            java.lang.String r7 = r2.f3989W     // Catch:{ JSONException -> 0x08ab }
            boolean r7 = android.text.TextUtils.isEmpty(r7)     // Catch:{ JSONException -> 0x08ab }
            if (r7 != 0) goto L_0x0266
            java.lang.String r7 = "native_advanced_settings"
            org.json.JSONArray r10 = new org.json.JSONArray     // Catch:{ JSONException -> 0x025f }
            java.lang.String r11 = r2.f3989W     // Catch:{ JSONException -> 0x025f }
            r10.<init>(r11)     // Catch:{ JSONException -> 0x025f }
            r8.put(r7, r10)     // Catch:{ JSONException -> 0x025f }
            goto L_0x0266
        L_0x025f:
            r0 = move-exception
            r7 = r0
            java.lang.String r10 = "Problem creating json from native advanced settings"
            com.google.android.gms.internal.C0759fe.m4732c(r10, r7)     // Catch:{ JSONException -> 0x08ab }
        L_0x0266:
            java.util.List<java.lang.Integer> r7 = r2.f3988V     // Catch:{ JSONException -> 0x08ab }
            if (r7 == 0) goto L_0x02a4
            java.util.List<java.lang.Integer> r7 = r2.f3988V     // Catch:{ JSONException -> 0x08ab }
            int r7 = r7.size()     // Catch:{ JSONException -> 0x08ab }
            if (r7 <= 0) goto L_0x02a4
            java.util.List<java.lang.Integer> r7 = r2.f3988V     // Catch:{ JSONException -> 0x08ab }
            java.util.Iterator r7 = r7.iterator()     // Catch:{ JSONException -> 0x08ab }
        L_0x0278:
            boolean r10 = r7.hasNext()     // Catch:{ JSONException -> 0x08ab }
            if (r10 == 0) goto L_0x02a4
            java.lang.Object r10 = r7.next()     // Catch:{ JSONException -> 0x08ab }
            java.lang.Integer r10 = (java.lang.Integer) r10     // Catch:{ JSONException -> 0x08ab }
            int r11 = r10.intValue()     // Catch:{ JSONException -> 0x08ab }
            r12 = 2
            if (r11 != r12) goto L_0x0296
            java.lang.String r10 = "iba"
            r11 = 1
            java.lang.Boolean r12 = java.lang.Boolean.valueOf(r11)     // Catch:{ JSONException -> 0x08ab }
        L_0x0292:
            r8.put(r10, r12)     // Catch:{ JSONException -> 0x08ab }
            goto L_0x0278
        L_0x0296:
            int r10 = r10.intValue()     // Catch:{ JSONException -> 0x08ab }
            r11 = 1
            if (r10 != r11) goto L_0x0278
            java.lang.String r10 = "ina"
            java.lang.Boolean r12 = java.lang.Boolean.valueOf(r11)     // Catch:{ JSONException -> 0x08ab }
            goto L_0x0292
        L_0x02a4:
            com.google.android.gms.internal.aay r7 = r2.f3997d     // Catch:{ JSONException -> 0x08ab }
            boolean r7 = r7.f1659j     // Catch:{ JSONException -> 0x08ab }
            if (r7 == 0) goto L_0x02b4
            java.lang.String r7 = "ene"
            r10 = 1
            java.lang.Boolean r11 = java.lang.Boolean.valueOf(r10)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r7, r11)     // Catch:{ JSONException -> 0x08ab }
        L_0x02b4:
            com.google.android.gms.internal.ada r7 = r2.f3981O     // Catch:{ JSONException -> 0x08ab }
            if (r7 == 0) goto L_0x02cf
            java.lang.String r7 = "is_icon_ad"
            r10 = 1
            java.lang.Boolean r11 = java.lang.Boolean.valueOf(r10)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r7, r11)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r7 = "icon_ad_expansion_behavior"
            com.google.android.gms.internal.ada r10 = r2.f3981O     // Catch:{ JSONException -> 0x08ab }
            int r10 = r10.f1707a     // Catch:{ JSONException -> 0x08ab }
            java.lang.Integer r10 = java.lang.Integer.valueOf(r10)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r7, r10)     // Catch:{ JSONException -> 0x08ab }
        L_0x02cf:
            java.lang.String r7 = "slotname"
            java.lang.String r10 = r2.f3998e     // Catch:{ JSONException -> 0x08ab }
            r8.put(r7, r10)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r7 = "pn"
            android.content.pm.ApplicationInfo r10 = r2.f3999f     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r10 = r10.packageName     // Catch:{ JSONException -> 0x08ab }
            r8.put(r7, r10)     // Catch:{ JSONException -> 0x08ab }
            android.content.pm.PackageInfo r7 = r2.f4000g     // Catch:{ JSONException -> 0x08ab }
            if (r7 == 0) goto L_0x02f0
            java.lang.String r7 = "vc"
            android.content.pm.PackageInfo r10 = r2.f4000g     // Catch:{ JSONException -> 0x08ab }
            int r10 = r10.versionCode     // Catch:{ JSONException -> 0x08ab }
            java.lang.Integer r10 = java.lang.Integer.valueOf(r10)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r7, r10)     // Catch:{ JSONException -> 0x08ab }
        L_0x02f0:
            java.lang.String r7 = "ms"
            java.lang.String r10 = r1.f2842g     // Catch:{ JSONException -> 0x08ab }
            r8.put(r7, r10)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r7 = "seq_num"
            java.lang.String r10 = r2.f4002i     // Catch:{ JSONException -> 0x08ab }
            r8.put(r7, r10)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r7 = "session_id"
            java.lang.String r10 = r2.f4003j     // Catch:{ JSONException -> 0x08ab }
            r8.put(r7, r10)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r7 = "js"
            com.google.android.gms.internal.iv r10 = r2.f4004k     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r10 = r10.f3448a     // Catch:{ JSONException -> 0x08ab }
            r8.put(r7, r10)     // Catch:{ JSONException -> 0x08ab }
            com.google.android.gms.internal.by r7 = r1.f2840e     // Catch:{ JSONException -> 0x08ab }
            android.os.Bundle r10 = r2.f3979M     // Catch:{ JSONException -> 0x08ab }
            android.os.Bundle r11 = r1.f2837b     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r12 = "am"
            int r13 = r4.f2948a     // Catch:{ JSONException -> 0x08ab }
            java.lang.Integer r13 = java.lang.Integer.valueOf(r13)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r12, r13)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r12 = "cog"
            boolean r13 = r4.f2949b     // Catch:{ JSONException -> 0x08ab }
            java.lang.Integer r13 = m4012a(r13)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r12, r13)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r12 = "coh"
            boolean r13 = r4.f2950c     // Catch:{ JSONException -> 0x08ab }
            java.lang.Integer r13 = m4012a(r13)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r12, r13)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r12 = r4.f2951d     // Catch:{ JSONException -> 0x08ab }
            boolean r12 = android.text.TextUtils.isEmpty(r12)     // Catch:{ JSONException -> 0x08ab }
            if (r12 != 0) goto L_0x0344
            java.lang.String r12 = "carrier"
            java.lang.String r13 = r4.f2951d     // Catch:{ JSONException -> 0x08ab }
            r8.put(r12, r13)     // Catch:{ JSONException -> 0x08ab }
        L_0x0344:
            java.lang.String r12 = "gl"
            java.lang.String r13 = r4.f2952e     // Catch:{ JSONException -> 0x08ab }
            r8.put(r12, r13)     // Catch:{ JSONException -> 0x08ab }
            boolean r12 = r4.f2953f     // Catch:{ JSONException -> 0x08ab }
            if (r12 == 0) goto L_0x0359
            java.lang.String r12 = "simulator"
            r13 = 1
            java.lang.Integer r14 = java.lang.Integer.valueOf(r13)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r12, r14)     // Catch:{ JSONException -> 0x08ab }
        L_0x0359:
            boolean r12 = r4.f2954g     // Catch:{ JSONException -> 0x08ab }
            if (r12 == 0) goto L_0x0368
            java.lang.String r12 = "is_sidewinder"
            r13 = 1
            java.lang.Integer r14 = java.lang.Integer.valueOf(r13)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r12, r14)     // Catch:{ JSONException -> 0x08ab }
            goto L_0x0369
        L_0x0368:
            r13 = 1
        L_0x0369:
            java.lang.String r12 = "ma"
            boolean r14 = r4.f2955h     // Catch:{ JSONException -> 0x08ab }
            java.lang.Integer r14 = m4012a(r14)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r12, r14)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r12 = "sp"
            boolean r14 = r4.f2956i     // Catch:{ JSONException -> 0x08ab }
            java.lang.Integer r14 = m4012a(r14)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r12, r14)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r12 = "hl"
            java.lang.String r14 = r4.f2957j     // Catch:{ JSONException -> 0x08ab }
            r8.put(r12, r14)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r12 = r4.f2958k     // Catch:{ JSONException -> 0x08ab }
            boolean r12 = android.text.TextUtils.isEmpty(r12)     // Catch:{ JSONException -> 0x08ab }
            if (r12 != 0) goto L_0x0395
            java.lang.String r12 = "mv"
            java.lang.String r14 = r4.f2958k     // Catch:{ JSONException -> 0x08ab }
            r8.put(r12, r14)     // Catch:{ JSONException -> 0x08ab }
        L_0x0395:
            java.lang.String r12 = "muv"
            int r14 = r4.f2960m     // Catch:{ JSONException -> 0x08ab }
            java.lang.Integer r14 = java.lang.Integer.valueOf(r14)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r12, r14)     // Catch:{ JSONException -> 0x08ab }
            int r12 = r4.f2961n     // Catch:{ JSONException -> 0x08ab }
            r14 = -2
            if (r12 == r14) goto L_0x03b0
            java.lang.String r12 = "cnt"
            int r14 = r4.f2961n     // Catch:{ JSONException -> 0x08ab }
            java.lang.Integer r14 = java.lang.Integer.valueOf(r14)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r12, r14)     // Catch:{ JSONException -> 0x08ab }
        L_0x03b0:
            java.lang.String r12 = "gnt"
            int r14 = r4.f2962o     // Catch:{ JSONException -> 0x08ab }
            java.lang.Integer r14 = java.lang.Integer.valueOf(r14)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r12, r14)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r12 = "pt"
            int r14 = r4.f2963p     // Catch:{ JSONException -> 0x08ab }
            java.lang.Integer r14 = java.lang.Integer.valueOf(r14)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r12, r14)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r12 = "rm"
            int r14 = r4.f2964q     // Catch:{ JSONException -> 0x08ab }
            java.lang.Integer r14 = java.lang.Integer.valueOf(r14)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r12, r14)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r12 = "riv"
            int r14 = r4.f2965r     // Catch:{ JSONException -> 0x08ab }
            java.lang.Integer r14 = java.lang.Integer.valueOf(r14)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r12, r14)     // Catch:{ JSONException -> 0x08ab }
            android.os.Bundle r12 = new android.os.Bundle     // Catch:{ JSONException -> 0x08ab }
            r12.<init>()     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r14 = "build_build"
            java.lang.String r15 = r4.f2973z     // Catch:{ JSONException -> 0x08ab }
            r12.putString(r14, r15)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r14 = "build_device"
            java.lang.String r15 = r4.f2946A     // Catch:{ JSONException -> 0x08ab }
            r12.putString(r14, r15)     // Catch:{ JSONException -> 0x08ab }
            android.os.Bundle r14 = new android.os.Bundle     // Catch:{ JSONException -> 0x08ab }
            r14.<init>()     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r15 = "is_charging"
            boolean r13 = r4.f2970w     // Catch:{ JSONException -> 0x08ab }
            r14.putBoolean(r15, r13)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r13 = "battery_level"
            r18 = r10
            double r9 = r4.f2969v     // Catch:{ JSONException -> 0x08ab }
            r14.putDouble(r13, r9)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r9 = "battery"
            r12.putBundle(r9, r14)     // Catch:{ JSONException -> 0x08ab }
            android.os.Bundle r9 = new android.os.Bundle     // Catch:{ JSONException -> 0x08ab }
            r9.<init>()     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r10 = "active_network_state"
            int r13 = r4.f2972y     // Catch:{ JSONException -> 0x08ab }
            r9.putInt(r10, r13)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r10 = "active_network_metered"
            boolean r13 = r4.f2971x     // Catch:{ JSONException -> 0x08ab }
            r9.putBoolean(r10, r13)     // Catch:{ JSONException -> 0x08ab }
            if (r7 == 0) goto L_0x043d
            android.os.Bundle r10 = new android.os.Bundle     // Catch:{ JSONException -> 0x08ab }
            r10.<init>()     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r13 = "predicted_latency_micros"
            int r14 = r7.f3016a     // Catch:{ JSONException -> 0x08ab }
            r10.putInt(r13, r14)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r13 = "predicted_down_throughput_bps"
            long r14 = r7.f3017b     // Catch:{ JSONException -> 0x08ab }
            r10.putLong(r13, r14)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r13 = "predicted_up_throughput_bps"
            long r14 = r7.f3018c     // Catch:{ JSONException -> 0x08ab }
            r10.putLong(r13, r14)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r7 = "predictions"
            r9.putBundle(r7, r10)     // Catch:{ JSONException -> 0x08ab }
        L_0x043d:
            java.lang.String r7 = "network"
            r12.putBundle(r7, r9)     // Catch:{ JSONException -> 0x08ab }
            android.os.Bundle r7 = new android.os.Bundle     // Catch:{ JSONException -> 0x08ab }
            r7.<init>()     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r9 = "is_browser_custom_tabs_capable"
            boolean r10 = r4.f2947B     // Catch:{ JSONException -> 0x08ab }
            r7.putBoolean(r9, r10)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r9 = "browser"
            r12.putBundle(r9, r7)     // Catch:{ JSONException -> 0x08ab }
            if (r18 == 0) goto L_0x0511
            java.lang.String r7 = "android_mem_info"
            android.os.Bundle r9 = new android.os.Bundle     // Catch:{ JSONException -> 0x08ab }
            r9.<init>()     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r10 = "runtime_free"
            java.lang.String r13 = "runtime_free_memory"
            r15 = r5
            r16 = r6
            r14 = r18
            r5 = -1
            long r20 = r14.getLong(r13, r5)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r13 = java.lang.Long.toString(r20)     // Catch:{ JSONException -> 0x08ab }
            r9.putString(r10, r13)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r10 = "runtime_max"
            java.lang.String r13 = "runtime_max_memory"
            long r20 = r14.getLong(r13, r5)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r13 = java.lang.Long.toString(r20)     // Catch:{ JSONException -> 0x08ab }
            r9.putString(r10, r13)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r10 = "runtime_total"
            java.lang.String r13 = "runtime_total_memory"
            long r5 = r14.getLong(r13, r5)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r5 = java.lang.Long.toString(r5)     // Catch:{ JSONException -> 0x08ab }
            r9.putString(r10, r5)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r5 = "web_view_count"
            java.lang.String r6 = "web_view_count"
            r10 = 0
            int r6 = r14.getInt(r6, r10)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r6 = java.lang.Integer.toString(r6)     // Catch:{ JSONException -> 0x08ab }
            r9.putString(r5, r6)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r5 = "debug_memory_info"
            android.os.Parcelable r5 = r14.getParcelable(r5)     // Catch:{ JSONException -> 0x08ab }
            android.os.Debug$MemoryInfo r5 = (android.os.Debug.MemoryInfo) r5     // Catch:{ JSONException -> 0x08ab }
            if (r5 == 0) goto L_0x050d
            java.lang.String r6 = "debug_info_dalvik_private_dirty"
            int r13 = r5.dalvikPrivateDirty     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r13 = java.lang.Integer.toString(r13)     // Catch:{ JSONException -> 0x08ab }
            r9.putString(r6, r13)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r6 = "debug_info_dalvik_pss"
            int r13 = r5.dalvikPss     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r13 = java.lang.Integer.toString(r13)     // Catch:{ JSONException -> 0x08ab }
            r9.putString(r6, r13)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r6 = "debug_info_dalvik_shared_dirty"
            int r13 = r5.dalvikSharedDirty     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r13 = java.lang.Integer.toString(r13)     // Catch:{ JSONException -> 0x08ab }
            r9.putString(r6, r13)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r6 = "debug_info_native_private_dirty"
            int r13 = r5.nativePrivateDirty     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r13 = java.lang.Integer.toString(r13)     // Catch:{ JSONException -> 0x08ab }
            r9.putString(r6, r13)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r6 = "debug_info_native_pss"
            int r13 = r5.nativePss     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r13 = java.lang.Integer.toString(r13)     // Catch:{ JSONException -> 0x08ab }
            r9.putString(r6, r13)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r6 = "debug_info_native_shared_dirty"
            int r13 = r5.nativeSharedDirty     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r13 = java.lang.Integer.toString(r13)     // Catch:{ JSONException -> 0x08ab }
            r9.putString(r6, r13)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r6 = "debug_info_other_private_dirty"
            int r13 = r5.otherPrivateDirty     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r13 = java.lang.Integer.toString(r13)     // Catch:{ JSONException -> 0x08ab }
            r9.putString(r6, r13)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r6 = "debug_info_other_pss"
            int r13 = r5.otherPss     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r13 = java.lang.Integer.toString(r13)     // Catch:{ JSONException -> 0x08ab }
            r9.putString(r6, r13)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r6 = "debug_info_other_shared_dirty"
            int r5 = r5.otherSharedDirty     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r5 = java.lang.Integer.toString(r5)     // Catch:{ JSONException -> 0x08ab }
            r9.putString(r6, r5)     // Catch:{ JSONException -> 0x08ab }
        L_0x050d:
            r12.putBundle(r7, r9)     // Catch:{ JSONException -> 0x08ab }
            goto L_0x0515
        L_0x0511:
            r15 = r5
            r16 = r6
            r10 = 0
        L_0x0515:
            android.os.Bundle r5 = new android.os.Bundle     // Catch:{ JSONException -> 0x08ab }
            r5.<init>()     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r6 = "parental_controls"
            r5.putBundle(r6, r11)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r6 = r4.f2959l     // Catch:{ JSONException -> 0x08ab }
            boolean r6 = android.text.TextUtils.isEmpty(r6)     // Catch:{ JSONException -> 0x08ab }
            if (r6 != 0) goto L_0x052e
            java.lang.String r6 = "package_version"
            java.lang.String r7 = r4.f2959l     // Catch:{ JSONException -> 0x08ab }
            r5.putString(r6, r7)     // Catch:{ JSONException -> 0x08ab }
        L_0x052e:
            java.lang.String r6 = "play_store"
            r12.putBundle(r6, r5)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r5 = "device"
            r8.put(r5, r12)     // Catch:{ JSONException -> 0x08ab }
            android.os.Bundle r5 = new android.os.Bundle     // Catch:{ JSONException -> 0x08ab }
            r5.<init>()     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r6 = "doritos"
            java.lang.String r7 = r1.f2841f     // Catch:{ JSONException -> 0x08ab }
            r5.putString(r6, r7)     // Catch:{ JSONException -> 0x08ab }
            com.google.android.gms.internal.aeb<java.lang.Boolean> r6 = com.google.android.gms.internal.ael.f1880az     // Catch:{ JSONException -> 0x08ab }
            com.google.android.gms.internal.aej r7 = com.google.android.gms.ads.internal.C0354ax.m1551r()     // Catch:{ JSONException -> 0x08ab }
            java.lang.Object r6 = r7.mo2079a(r6)     // Catch:{ JSONException -> 0x08ab }
            java.lang.Boolean r6 = (java.lang.Boolean) r6     // Catch:{ JSONException -> 0x08ab }
            boolean r6 = r6.booleanValue()     // Catch:{ JSONException -> 0x08ab }
            if (r6 == 0) goto L_0x0592
            com.google.android.gms.ads.c.a$a r6 = r1.f2843h     // Catch:{ JSONException -> 0x08ab }
            if (r6 == 0) goto L_0x0567
            com.google.android.gms.ads.c.a$a r6 = r1.f2843h     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r7 = r6.mo1221a()     // Catch:{ JSONException -> 0x08ab }
            com.google.android.gms.ads.c.a$a r6 = r1.f2843h     // Catch:{ JSONException -> 0x08ab }
            boolean r9 = r6.mo1222b()     // Catch:{ JSONException -> 0x08ab }
            goto L_0x0569
        L_0x0567:
            r9 = r10
            r7 = 0
        L_0x0569:
            boolean r6 = android.text.TextUtils.isEmpty(r7)     // Catch:{ JSONException -> 0x08ab }
            if (r6 != 0) goto L_0x0581
            java.lang.String r6 = "rdid"
            r5.putString(r6, r7)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r6 = "is_lat"
            r5.putBoolean(r6, r9)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r6 = "idtype"
            java.lang.String r7 = "adid"
        L_0x057d:
            r5.putString(r6, r7)     // Catch:{ JSONException -> 0x08ab }
            goto L_0x0592
        L_0x0581:
            com.google.android.gms.internal.abj.m2380a()     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r6 = com.google.android.gms.internal.C0851ip.m4713b(r22)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r7 = "pdid"
            r5.putString(r7, r6)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r6 = "pdidtype"
            java.lang.String r7 = "ssaid"
            goto L_0x057d
        L_0x0592:
            java.lang.String r6 = "pii"
            r8.put(r6, r5)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r5 = "platform"
            java.lang.String r6 = android.os.Build.MANUFACTURER     // Catch:{ JSONException -> 0x08ab }
            r8.put(r5, r6)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r5 = "submodel"
            java.lang.String r6 = android.os.Build.MODEL     // Catch:{ JSONException -> 0x08ab }
            r8.put(r5, r6)     // Catch:{ JSONException -> 0x08ab }
            if (r3 == 0) goto L_0x05ab
        L_0x05a7:
            m4017a(r8, r3)     // Catch:{ JSONException -> 0x08ab }
            goto L_0x05bd
        L_0x05ab:
            com.google.android.gms.internal.aau r3 = r2.f3996c     // Catch:{ JSONException -> 0x08ab }
            int r3 = r3.f1614a     // Catch:{ JSONException -> 0x08ab }
            r5 = 2
            if (r3 < r5) goto L_0x05bd
            com.google.android.gms.internal.aau r3 = r2.f3996c     // Catch:{ JSONException -> 0x08ab }
            android.location.Location r3 = r3.f1624k     // Catch:{ JSONException -> 0x08ab }
            if (r3 == 0) goto L_0x05bd
            com.google.android.gms.internal.aau r3 = r2.f3996c     // Catch:{ JSONException -> 0x08ab }
            android.location.Location r3 = r3.f1624k     // Catch:{ JSONException -> 0x08ab }
            goto L_0x05a7
        L_0x05bd:
            int r3 = r2.f3993a     // Catch:{ JSONException -> 0x08ab }
            r5 = 2
            if (r3 < r5) goto L_0x05c9
            java.lang.String r3 = "quality_signals"
            android.os.Bundle r5 = r2.f4005l     // Catch:{ JSONException -> 0x08ab }
            r8.put(r3, r5)     // Catch:{ JSONException -> 0x08ab }
        L_0x05c9:
            int r3 = r2.f3993a     // Catch:{ JSONException -> 0x08ab }
            r5 = 4
            if (r3 < r5) goto L_0x05dd
            boolean r3 = r2.f4009p     // Catch:{ JSONException -> 0x08ab }
            if (r3 == 0) goto L_0x05dd
            java.lang.String r3 = "forceHttps"
            boolean r5 = r2.f4009p     // Catch:{ JSONException -> 0x08ab }
            java.lang.Boolean r5 = java.lang.Boolean.valueOf(r5)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r3, r5)     // Catch:{ JSONException -> 0x08ab }
        L_0x05dd:
            if (r15 == 0) goto L_0x05e5
            java.lang.String r3 = "content_info"
            r5 = r15
            r8.put(r3, r5)     // Catch:{ JSONException -> 0x08ab }
        L_0x05e5:
            int r3 = r2.f3993a     // Catch:{ JSONException -> 0x08ab }
            r5 = 5
            if (r3 < r5) goto L_0x060c
            java.lang.String r3 = "u_sd"
            float r4 = r2.f4012s     // Catch:{ JSONException -> 0x08ab }
            java.lang.Float r4 = java.lang.Float.valueOf(r4)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r3, r4)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r3 = "sh"
            int r4 = r2.f4011r     // Catch:{ JSONException -> 0x08ab }
            java.lang.Integer r4 = java.lang.Integer.valueOf(r4)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r3, r4)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r3 = "sw"
            int r4 = r2.f4010q     // Catch:{ JSONException -> 0x08ab }
            java.lang.Integer r4 = java.lang.Integer.valueOf(r4)     // Catch:{ JSONException -> 0x08ab }
        L_0x0608:
            r8.put(r3, r4)     // Catch:{ JSONException -> 0x08ab }
            goto L_0x062b
        L_0x060c:
            java.lang.String r3 = "u_sd"
            float r5 = r4.f2966s     // Catch:{ JSONException -> 0x08ab }
            java.lang.Float r5 = java.lang.Float.valueOf(r5)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r3, r5)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r3 = "sh"
            int r5 = r4.f2968u     // Catch:{ JSONException -> 0x08ab }
            java.lang.Integer r5 = java.lang.Integer.valueOf(r5)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r3, r5)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r3 = "sw"
            int r4 = r4.f2967t     // Catch:{ JSONException -> 0x08ab }
            java.lang.Integer r4 = java.lang.Integer.valueOf(r4)     // Catch:{ JSONException -> 0x08ab }
            goto L_0x0608
        L_0x062b:
            int r3 = r2.f3993a     // Catch:{ JSONException -> 0x08ab }
            r4 = 6
            if (r3 < r4) goto L_0x0657
            java.lang.String r3 = r2.f4013t     // Catch:{ JSONException -> 0x08ab }
            boolean r3 = android.text.TextUtils.isEmpty(r3)     // Catch:{ JSONException -> 0x08ab }
            if (r3 != 0) goto L_0x064c
            java.lang.String r3 = "view_hierarchy"
            org.json.JSONObject r4 = new org.json.JSONObject     // Catch:{ JSONException -> 0x0645 }
            java.lang.String r5 = r2.f4013t     // Catch:{ JSONException -> 0x0645 }
            r4.<init>(r5)     // Catch:{ JSONException -> 0x0645 }
            r8.put(r3, r4)     // Catch:{ JSONException -> 0x0645 }
            goto L_0x064c
        L_0x0645:
            r0 = move-exception
            r3 = r0
            java.lang.String r4 = "Problem serializing view hierarchy to JSON"
            com.google.android.gms.internal.C0759fe.m4732c(r4, r3)     // Catch:{ JSONException -> 0x08ab }
        L_0x064c:
            java.lang.String r3 = "correlation_id"
            long r4 = r2.f4014u     // Catch:{ JSONException -> 0x08ab }
            java.lang.Long r4 = java.lang.Long.valueOf(r4)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r3, r4)     // Catch:{ JSONException -> 0x08ab }
        L_0x0657:
            int r3 = r2.f3993a     // Catch:{ JSONException -> 0x08ab }
            r4 = 7
            if (r3 < r4) goto L_0x0663
            java.lang.String r3 = "request_id"
            java.lang.String r4 = r2.f4015v     // Catch:{ JSONException -> 0x08ab }
            r8.put(r3, r4)     // Catch:{ JSONException -> 0x08ab }
        L_0x0663:
            int r3 = r2.f3993a     // Catch:{ JSONException -> 0x08ab }
            r4 = 12
            if (r3 < r4) goto L_0x0678
            java.lang.String r3 = r2.f3968B     // Catch:{ JSONException -> 0x08ab }
            boolean r3 = android.text.TextUtils.isEmpty(r3)     // Catch:{ JSONException -> 0x08ab }
            if (r3 != 0) goto L_0x0678
            java.lang.String r3 = "anchor"
            java.lang.String r4 = r2.f3968B     // Catch:{ JSONException -> 0x08ab }
            r8.put(r3, r4)     // Catch:{ JSONException -> 0x08ab }
        L_0x0678:
            int r3 = r2.f3993a     // Catch:{ JSONException -> 0x08ab }
            r4 = 13
            if (r3 < r4) goto L_0x0689
            java.lang.String r3 = "android_app_volume"
            float r4 = r2.f3969C     // Catch:{ JSONException -> 0x08ab }
            java.lang.Float r4 = java.lang.Float.valueOf(r4)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r3, r4)     // Catch:{ JSONException -> 0x08ab }
        L_0x0689:
            int r3 = r2.f3993a     // Catch:{ JSONException -> 0x08ab }
            r4 = 18
            if (r3 < r4) goto L_0x069a
            java.lang.String r3 = "android_app_muted"
            boolean r5 = r2.f3975I     // Catch:{ JSONException -> 0x08ab }
            java.lang.Boolean r5 = java.lang.Boolean.valueOf(r5)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r3, r5)     // Catch:{ JSONException -> 0x08ab }
        L_0x069a:
            int r3 = r2.f3993a     // Catch:{ JSONException -> 0x08ab }
            r5 = 14
            if (r3 < r5) goto L_0x06af
            int r3 = r2.f3970D     // Catch:{ JSONException -> 0x08ab }
            if (r3 <= 0) goto L_0x06af
            java.lang.String r3 = "target_api"
            int r5 = r2.f3970D     // Catch:{ JSONException -> 0x08ab }
            java.lang.Integer r5 = java.lang.Integer.valueOf(r5)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r3, r5)     // Catch:{ JSONException -> 0x08ab }
        L_0x06af:
            int r3 = r2.f3993a     // Catch:{ JSONException -> 0x08ab }
            r5 = 15
            if (r3 < r5) goto L_0x06c7
            java.lang.String r3 = "scroll_index"
            int r5 = r2.f3971E     // Catch:{ JSONException -> 0x08ab }
            r6 = -1
            if (r5 != r6) goto L_0x06bd
            goto L_0x06c0
        L_0x06bd:
            int r11 = r2.f3971E     // Catch:{ JSONException -> 0x08ab }
            r6 = r11
        L_0x06c0:
            java.lang.Integer r5 = java.lang.Integer.valueOf(r6)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r3, r5)     // Catch:{ JSONException -> 0x08ab }
        L_0x06c7:
            int r3 = r2.f3993a     // Catch:{ JSONException -> 0x08ab }
            r5 = 16
            if (r3 < r5) goto L_0x06d8
            java.lang.String r3 = "_activity_context"
            boolean r5 = r2.f3972F     // Catch:{ JSONException -> 0x08ab }
            java.lang.Boolean r5 = java.lang.Boolean.valueOf(r5)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r3, r5)     // Catch:{ JSONException -> 0x08ab }
        L_0x06d8:
            int r3 = r2.f3993a     // Catch:{ JSONException -> 0x08ab }
            if (r3 < r4) goto L_0x0703
            java.lang.String r3 = r2.f3976J     // Catch:{ JSONException -> 0x08ab }
            boolean r3 = android.text.TextUtils.isEmpty(r3)     // Catch:{ JSONException -> 0x08ab }
            if (r3 != 0) goto L_0x06f8
            java.lang.String r3 = "app_settings"
            org.json.JSONObject r5 = new org.json.JSONObject     // Catch:{ JSONException -> 0x06f1 }
            java.lang.String r6 = r2.f3976J     // Catch:{ JSONException -> 0x06f1 }
            r5.<init>(r6)     // Catch:{ JSONException -> 0x06f1 }
            r8.put(r3, r5)     // Catch:{ JSONException -> 0x06f1 }
            goto L_0x06f8
        L_0x06f1:
            r0 = move-exception
            r3 = r0
            java.lang.String r5 = "Problem creating json from app settings"
            com.google.android.gms.internal.C0759fe.m4732c(r5, r3)     // Catch:{ JSONException -> 0x08ab }
        L_0x06f8:
            java.lang.String r3 = "render_in_browser"
            boolean r5 = r2.f3977K     // Catch:{ JSONException -> 0x08ab }
            java.lang.Boolean r5 = java.lang.Boolean.valueOf(r5)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r3, r5)     // Catch:{ JSONException -> 0x08ab }
        L_0x0703:
            int r3 = r2.f3993a     // Catch:{ JSONException -> 0x08ab }
            if (r3 < r4) goto L_0x0712
            java.lang.String r3 = "android_num_video_cache_tasks"
            int r4 = r2.f3978L     // Catch:{ JSONException -> 0x08ab }
            java.lang.Integer r4 = java.lang.Integer.valueOf(r4)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r3, r4)     // Catch:{ JSONException -> 0x08ab }
        L_0x0712:
            com.google.android.gms.internal.iv r3 = r2.f4004k     // Catch:{ JSONException -> 0x08ab }
            boolean r4 = r2.f3992Z     // Catch:{ JSONException -> 0x08ab }
            boolean r1 = r1.f2847l     // Catch:{ JSONException -> 0x08ab }
            android.os.Bundle r5 = new android.os.Bundle     // Catch:{ JSONException -> 0x08ab }
            r5.<init>()     // Catch:{ JSONException -> 0x08ab }
            android.os.Bundle r6 = new android.os.Bundle     // Catch:{ JSONException -> 0x08ab }
            r6.<init>()     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r7 = "cl"
            java.lang.String r9 = "169154428"
            r6.putString(r7, r9)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r7 = "rapid_rc"
            java.lang.String r9 = "dev"
            r6.putString(r7, r9)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r7 = "rapid_rollup"
            java.lang.String r9 = "HEAD"
            r6.putString(r7, r9)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r7 = "build_meta"
            r5.putBundle(r7, r6)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r6 = "mf"
            com.google.android.gms.internal.aeb<java.lang.Boolean> r7 = com.google.android.gms.internal.ael.f1891bJ     // Catch:{ JSONException -> 0x08ab }
            com.google.android.gms.internal.aej r9 = com.google.android.gms.ads.internal.C0354ax.m1551r()     // Catch:{ JSONException -> 0x08ab }
            java.lang.Object r7 = r9.mo2079a(r7)     // Catch:{ JSONException -> 0x08ab }
            java.lang.Boolean r7 = (java.lang.Boolean) r7     // Catch:{ JSONException -> 0x08ab }
            boolean r7 = r7.booleanValue()     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r7 = java.lang.Boolean.toString(r7)     // Catch:{ JSONException -> 0x08ab }
            r5.putString(r6, r7)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r6 = "instant_app"
            r5.putBoolean(r6, r4)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r4 = "lite"
            boolean r3 = r3.f3452e     // Catch:{ JSONException -> 0x08ab }
            r5.putBoolean(r4, r3)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r3 = "local_service"
            r5.putBoolean(r3, r1)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r1 = "sdk_env"
            r8.put(r1, r5)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r1 = "cache_state"
            r3 = r16
            r8.put(r1, r3)     // Catch:{ JSONException -> 0x08ab }
            int r1 = r2.f3993a     // Catch:{ JSONException -> 0x08ab }
            r3 = 19
            if (r1 < r3) goto L_0x077f
            java.lang.String r1 = "gct"
            java.lang.String r3 = r2.f3980N     // Catch:{ JSONException -> 0x08ab }
            r8.put(r1, r3)     // Catch:{ JSONException -> 0x08ab }
        L_0x077f:
            int r1 = r2.f3993a     // Catch:{ JSONException -> 0x08ab }
            r3 = 21
            if (r1 < r3) goto L_0x0790
            boolean r1 = r2.f3982P     // Catch:{ JSONException -> 0x08ab }
            if (r1 == 0) goto L_0x0790
            java.lang.String r1 = "de"
            java.lang.String r3 = "1"
            r8.put(r1, r3)     // Catch:{ JSONException -> 0x08ab }
        L_0x0790:
            com.google.android.gms.internal.aeb<java.lang.Boolean> r1 = com.google.android.gms.internal.ael.f1836aH     // Catch:{ JSONException -> 0x08ab }
            com.google.android.gms.internal.aej r3 = com.google.android.gms.ads.internal.C0354ax.m1551r()     // Catch:{ JSONException -> 0x08ab }
            java.lang.Object r1 = r3.mo2079a(r1)     // Catch:{ JSONException -> 0x08ab }
            java.lang.Boolean r1 = (java.lang.Boolean) r1     // Catch:{ JSONException -> 0x08ab }
            boolean r1 = r1.booleanValue()     // Catch:{ JSONException -> 0x08ab }
            if (r1 == 0) goto L_0x07d6
            com.google.android.gms.internal.aay r1 = r2.f3997d     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r1 = r1.f1650a     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r3 = "interstitial_mb"
            boolean r3 = r1.equals(r3)     // Catch:{ JSONException -> 0x08ab }
            if (r3 != 0) goto L_0x07b9
            java.lang.String r3 = "reward_mb"
            boolean r1 = r1.equals(r3)     // Catch:{ JSONException -> 0x08ab }
            if (r1 == 0) goto L_0x07b7
            goto L_0x07b9
        L_0x07b7:
            r1 = r10
            goto L_0x07ba
        L_0x07b9:
            r1 = 1
        L_0x07ba:
            android.os.Bundle r3 = r2.f3983Q     // Catch:{ JSONException -> 0x08ab }
            if (r3 == 0) goto L_0x07c1
            r19 = 1
            goto L_0x07c3
        L_0x07c1:
            r19 = r10
        L_0x07c3:
            if (r1 == 0) goto L_0x07d6
            if (r19 == 0) goto L_0x07d6
            android.os.Bundle r1 = new android.os.Bundle     // Catch:{ JSONException -> 0x08ab }
            r1.<init>()     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r4 = "interstitial_pool"
            r1.putBundle(r4, r3)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r3 = "counters"
            r8.put(r3, r1)     // Catch:{ JSONException -> 0x08ab }
        L_0x07d6:
            int r1 = r2.f3993a     // Catch:{ JSONException -> 0x08ab }
            r3 = 22
            if (r1 < r3) goto L_0x081e
            com.google.android.gms.internal.eg r1 = com.google.android.gms.ads.internal.C0354ax.m1532D()     // Catch:{ JSONException -> 0x08ab }
            r3 = r22
            boolean r1 = r1.mo2686a(r3)     // Catch:{ JSONException -> 0x08ab }
            if (r1 == 0) goto L_0x081e
            java.lang.String r1 = "gmp_app_id"
            java.lang.String r3 = r2.f3984R     // Catch:{ JSONException -> 0x08ab }
            r8.put(r1, r3)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r1 = "TIME_OUT"
            java.lang.String r3 = r2.f3985S     // Catch:{ JSONException -> 0x08ab }
            boolean r1 = r1.equals(r3)     // Catch:{ JSONException -> 0x08ab }
            if (r1 == 0) goto L_0x0809
            java.lang.String r1 = "sai_timeout"
            com.google.android.gms.internal.aeb<java.lang.Long> r3 = com.google.android.gms.internal.ael.f1871aq     // Catch:{ JSONException -> 0x08ab }
            com.google.android.gms.internal.aej r4 = com.google.android.gms.ads.internal.C0354ax.m1551r()     // Catch:{ JSONException -> 0x08ab }
            java.lang.Object r3 = r4.mo2079a(r3)     // Catch:{ JSONException -> 0x08ab }
        L_0x0805:
            r8.put(r1, r3)     // Catch:{ JSONException -> 0x08ab }
            goto L_0x0817
        L_0x0809:
            java.lang.String r1 = r2.f3985S     // Catch:{ JSONException -> 0x08ab }
            if (r1 != 0) goto L_0x0812
            java.lang.String r1 = "fbs_aiid"
            java.lang.String r3 = ""
            goto L_0x0805
        L_0x0812:
            java.lang.String r1 = "fbs_aiid"
            java.lang.String r3 = r2.f3985S     // Catch:{ JSONException -> 0x08ab }
            goto L_0x0805
        L_0x0817:
            java.lang.String r1 = "fbs_aeid"
            java.lang.String r3 = r2.f3986T     // Catch:{ JSONException -> 0x08ab }
            r8.put(r1, r3)     // Catch:{ JSONException -> 0x08ab }
        L_0x081e:
            int r1 = r2.f3993a     // Catch:{ JSONException -> 0x08ab }
            r3 = 24
            if (r1 < r3) goto L_0x082f
            java.lang.String r1 = "disable_ml"
            boolean r2 = r2.f3994aa     // Catch:{ JSONException -> 0x08ab }
            java.lang.Boolean r2 = java.lang.Boolean.valueOf(r2)     // Catch:{ JSONException -> 0x08ab }
            r8.put(r1, r2)     // Catch:{ JSONException -> 0x08ab }
        L_0x082f:
            com.google.android.gms.internal.aeb<java.lang.String> r1 = com.google.android.gms.internal.ael.f1803B     // Catch:{ JSONException -> 0x08ab }
            com.google.android.gms.internal.aej r2 = com.google.android.gms.ads.internal.C0354ax.m1551r()     // Catch:{ JSONException -> 0x08ab }
            java.lang.Object r1 = r2.mo2079a(r1)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r1 = (java.lang.String) r1     // Catch:{ JSONException -> 0x08ab }
            if (r1 == 0) goto L_0x0876
            boolean r2 = r1.isEmpty()     // Catch:{ JSONException -> 0x08ab }
            if (r2 != 0) goto L_0x0876
            int r2 = android.os.Build.VERSION.SDK_INT     // Catch:{ JSONException -> 0x08ab }
            com.google.android.gms.internal.aeb<java.lang.Integer> r3 = com.google.android.gms.internal.ael.f1804C     // Catch:{ JSONException -> 0x08ab }
            com.google.android.gms.internal.aej r4 = com.google.android.gms.ads.internal.C0354ax.m1551r()     // Catch:{ JSONException -> 0x08ab }
            java.lang.Object r3 = r4.mo2079a(r3)     // Catch:{ JSONException -> 0x08ab }
            java.lang.Integer r3 = (java.lang.Integer) r3     // Catch:{ JSONException -> 0x08ab }
            int r3 = r3.intValue()     // Catch:{ JSONException -> 0x08ab }
            if (r2 < r3) goto L_0x0876
            java.util.HashMap r2 = new java.util.HashMap     // Catch:{ JSONException -> 0x08ab }
            r2.<init>()     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r3 = ","
            java.lang.String[] r1 = r1.split(r3)     // Catch:{ JSONException -> 0x08ab }
            int r3 = r1.length     // Catch:{ JSONException -> 0x08ab }
        L_0x0863:
            if (r10 >= r3) goto L_0x0871
            r4 = r1[r10]     // Catch:{ JSONException -> 0x08ab }
            java.util.List r5 = com.google.android.gms.internal.C0849in.m4693a(r4)     // Catch:{ JSONException -> 0x08ab }
            r2.put(r4, r5)     // Catch:{ JSONException -> 0x08ab }
            int r10 = r10 + 1
            goto L_0x0863
        L_0x0871:
            java.lang.String r1 = "video_decoders"
            r8.put(r1, r2)     // Catch:{ JSONException -> 0x08ab }
        L_0x0876:
            r1 = 2
            boolean r2 = com.google.android.gms.internal.C0759fe.m4728a(r1)     // Catch:{ JSONException -> 0x08ab }
            if (r2 == 0) goto L_0x08a2
            com.google.android.gms.internal.go r2 = com.google.android.gms.ads.internal.C0354ax.m1538e()     // Catch:{ JSONException -> 0x08ab }
            org.json.JSONObject r2 = r2.mo2798a(r8)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r1 = r2.toString(r1)     // Catch:{ JSONException -> 0x08ab }
            java.lang.String r2 = "Ad Request JSON: "
            java.lang.String r1 = java.lang.String.valueOf(r1)     // Catch:{ JSONException -> 0x08ab }
            int r3 = r1.length()     // Catch:{ JSONException -> 0x08ab }
            if (r3 == 0) goto L_0x089a
            java.lang.String r1 = r2.concat(r1)     // Catch:{ JSONException -> 0x08ab }
            goto L_0x089f
        L_0x089a:
            java.lang.String r1 = new java.lang.String     // Catch:{ JSONException -> 0x08ab }
            r1.<init>(r2)     // Catch:{ JSONException -> 0x08ab }
        L_0x089f:
            com.google.android.gms.internal.C0759fe.m4411a(r1)     // Catch:{ JSONException -> 0x08ab }
        L_0x08a2:
            com.google.android.gms.internal.go r1 = com.google.android.gms.ads.internal.C0354ax.m1538e()     // Catch:{ JSONException -> 0x08ab }
            org.json.JSONObject r1 = r1.mo2798a(r8)     // Catch:{ JSONException -> 0x08ab }
            return r1
        L_0x08ab:
            r0 = move-exception
            r1 = r0
            java.lang.String r2 = "Problem serializing ad request to JSON: "
            java.lang.String r1 = r1.getMessage()
            java.lang.String r1 = java.lang.String.valueOf(r1)
            int r3 = r1.length()
            if (r3 == 0) goto L_0x08c2
            java.lang.String r1 = r2.concat(r1)
            goto L_0x08c7
        L_0x08c2:
            java.lang.String r1 = new java.lang.String
            r1.<init>(r2)
        L_0x08c7:
            com.google.android.gms.internal.C0759fe.m4734e(r1)
            r1 = 0
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.C0651be.m4015a(android.content.Context, com.google.android.gms.internal.au):org.json.JSONObject");
    }

    /* JADX WARNING: Removed duplicated region for block: B:28:0x0085  */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x0094  */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x00a3  */
    /* JADX WARNING: Removed duplicated region for block: B:37:0x00b2  */
    /* JADX WARNING: Removed duplicated region for block: B:40:0x00c4  */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x00f4  */
    /* JADX WARNING: Removed duplicated region for block: B:46:0x0101  */
    /* JADX WARNING: Removed duplicated region for block: B:49:0x0110  */
    /* JADX WARNING: Removed duplicated region for block: B:52:0x011d  */
    /* JADX WARNING: Removed duplicated region for block: B:53:0x0120  */
    /* JADX WARNING: Removed duplicated region for block: B:56:0x0130  */
    /* JADX WARNING: Removed duplicated region for block: B:59:0x013f  */
    /* JADX WARNING: Removed duplicated region for block: B:62:0x014e  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static org.json.JSONObject m4016a(com.google.android.gms.internal.C1135r r9) {
        /*
            org.json.JSONObject r0 = new org.json.JSONObject
            r0.<init>()
            java.lang.String r1 = r9.f4438a
            if (r1 == 0) goto L_0x0010
            java.lang.String r1 = "ad_base_url"
            java.lang.String r2 = r9.f4438a
            r0.put(r1, r2)
        L_0x0010:
            java.lang.String r1 = r9.f4449l
            if (r1 == 0) goto L_0x001b
            java.lang.String r1 = "ad_size"
            java.lang.String r2 = r9.f4449l
            r0.put(r1, r2)
        L_0x001b:
            java.lang.String r1 = "native"
            boolean r2 = r9.f4456s
            r0.put(r1, r2)
            boolean r1 = r9.f4456s
            if (r1 == 0) goto L_0x0029
            java.lang.String r1 = "ad_json"
            goto L_0x002b
        L_0x0029:
            java.lang.String r1 = "ad_html"
        L_0x002b:
            java.lang.String r2 = r9.f4439b
            r0.put(r1, r2)
            java.lang.String r1 = r9.f4451n
            if (r1 == 0) goto L_0x003b
            java.lang.String r1 = "debug_dialog"
            java.lang.String r2 = r9.f4451n
            r0.put(r1, r2)
        L_0x003b:
            java.lang.String r1 = r9.f4430L
            if (r1 == 0) goto L_0x0046
            java.lang.String r1 = "debug_signals"
            java.lang.String r2 = r9.f4430L
            r0.put(r1, r2)
        L_0x0046:
            long r1 = r9.f4443f
            r3 = -1
            int r1 = (r1 > r3 ? 1 : (r1 == r3 ? 0 : -1))
            if (r1 == 0) goto L_0x005c
            java.lang.String r1 = "interstitial_timeout"
            long r5 = r9.f4443f
            double r5 = (double) r5
            r7 = 4652007308841189376(0x408f400000000000, double:1000.0)
            double r5 = r5 / r7
            r0.put(r1, r5)
        L_0x005c:
            int r1 = r9.f4448k
            com.google.android.gms.internal.gt r2 = com.google.android.gms.ads.internal.C0354ax.m1540g()
            int r2 = r2.mo2824b()
            if (r1 != r2) goto L_0x0070
            java.lang.String r1 = "orientation"
            java.lang.String r2 = "portrait"
        L_0x006c:
            r0.put(r1, r2)
            goto L_0x0081
        L_0x0070:
            int r1 = r9.f4448k
            com.google.android.gms.internal.gt r2 = com.google.android.gms.ads.internal.C0354ax.m1540g()
            int r2 = r2.mo2811a()
            if (r1 != r2) goto L_0x0081
            java.lang.String r1 = "orientation"
            java.lang.String r2 = "landscape"
            goto L_0x006c
        L_0x0081:
            java.util.List<java.lang.String> r1 = r9.f4440c
            if (r1 == 0) goto L_0x0090
            java.lang.String r1 = "click_urls"
            java.util.List<java.lang.String> r2 = r9.f4440c
            org.json.JSONArray r2 = m4014a(r2)
            r0.put(r1, r2)
        L_0x0090:
            java.util.List<java.lang.String> r1 = r9.f4442e
            if (r1 == 0) goto L_0x009f
            java.lang.String r1 = "impression_urls"
            java.util.List<java.lang.String> r2 = r9.f4442e
            org.json.JSONArray r2 = m4014a(r2)
            r0.put(r1, r2)
        L_0x009f:
            java.util.List<java.lang.String> r1 = r9.f4446i
            if (r1 == 0) goto L_0x00ae
            java.lang.String r1 = "manual_impression_urls"
            java.util.List<java.lang.String> r2 = r9.f4446i
            org.json.JSONArray r2 = m4014a(r2)
            r0.put(r1, r2)
        L_0x00ae:
            java.lang.String r1 = r9.f4454q
            if (r1 == 0) goto L_0x00b9
            java.lang.String r1 = "active_view"
            java.lang.String r2 = r9.f4454q
            r0.put(r1, r2)
        L_0x00b9:
            java.lang.String r1 = "ad_is_javascript"
            boolean r2 = r9.f4452o
            r0.put(r1, r2)
            java.lang.String r1 = r9.f4453p
            if (r1 == 0) goto L_0x00cb
            java.lang.String r1 = "ad_passback_url"
            java.lang.String r2 = r9.f4453p
            r0.put(r1, r2)
        L_0x00cb:
            java.lang.String r1 = "mediation"
            boolean r2 = r9.f4444g
            r0.put(r1, r2)
            java.lang.String r1 = "custom_render_allowed"
            boolean r2 = r9.f4455r
            r0.put(r1, r2)
            java.lang.String r1 = "content_url_opted_out"
            boolean r2 = r9.f4458u
            r0.put(r1, r2)
            java.lang.String r1 = "content_vertical_opted_out"
            boolean r2 = r9.f4431M
            r0.put(r1, r2)
            java.lang.String r1 = "prefetch"
            boolean r2 = r9.f4459v
            r0.put(r1, r2)
            long r1 = r9.f4447j
            int r1 = (r1 > r3 ? 1 : (r1 == r3 ? 0 : -1))
            if (r1 == 0) goto L_0x00fb
            java.lang.String r1 = "refresh_interval_milliseconds"
            long r5 = r9.f4447j
            r0.put(r1, r5)
        L_0x00fb:
            long r1 = r9.f4445h
            int r1 = (r1 > r3 ? 1 : (r1 == r3 ? 0 : -1))
            if (r1 == 0) goto L_0x0108
            java.lang.String r1 = "mediation_config_cache_time_milliseconds"
            long r2 = r9.f4445h
            r0.put(r1, r2)
        L_0x0108:
            java.lang.String r1 = r9.f4461x
            boolean r1 = android.text.TextUtils.isEmpty(r1)
            if (r1 != 0) goto L_0x0117
            java.lang.String r1 = "gws_query_id"
            java.lang.String r2 = r9.f4461x
            r0.put(r1, r2)
        L_0x0117:
            java.lang.String r1 = "fluid"
            boolean r2 = r9.f4462y
            if (r2 == 0) goto L_0x0120
            java.lang.String r2 = "height"
            goto L_0x0122
        L_0x0120:
            java.lang.String r2 = ""
        L_0x0122:
            r0.put(r1, r2)
            java.lang.String r1 = "native_express"
            boolean r2 = r9.f4463z
            r0.put(r1, r2)
            java.util.List<java.lang.String> r1 = r9.f4420B
            if (r1 == 0) goto L_0x013b
            java.lang.String r1 = "video_start_urls"
            java.util.List<java.lang.String> r2 = r9.f4420B
            org.json.JSONArray r2 = m4014a(r2)
            r0.put(r1, r2)
        L_0x013b:
            java.util.List<java.lang.String> r1 = r9.f4421C
            if (r1 == 0) goto L_0x014a
            java.lang.String r1 = "video_complete_urls"
            java.util.List<java.lang.String> r2 = r9.f4421C
            org.json.JSONArray r2 = m4014a(r2)
            r0.put(r1, r2)
        L_0x014a:
            com.google.android.gms.internal.dq r1 = r9.f4419A
            if (r1 == 0) goto L_0x0170
            java.lang.String r1 = "rewards"
            com.google.android.gms.internal.dq r2 = r9.f4419A
            org.json.JSONObject r3 = new org.json.JSONObject
            r3.<init>()
            java.lang.String r4 = "rb_type"
            java.lang.String r5 = r2.f3096a
            r3.put(r4, r5)
            java.lang.String r4 = "rb_amount"
            int r2 = r2.f3097b
            r3.put(r4, r2)
            org.json.JSONArray r2 = new org.json.JSONArray
            r2.<init>()
            r2.put(r3)
            r0.put(r1, r2)
        L_0x0170:
            java.lang.String r1 = "use_displayed_impression"
            boolean r2 = r9.f4422D
            r0.put(r1, r2)
            java.lang.String r1 = "auto_protection_configuration"
            com.google.android.gms.internal.t r2 = r9.f4423E
            r0.put(r1, r2)
            java.lang.String r1 = "render_in_browser"
            boolean r9 = r9.f4427I
            r0.put(r1, r9)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.C0651be.m4016a(com.google.android.gms.internal.r):org.json.JSONObject");
    }

    /* renamed from: a */
    private static void m4017a(HashMap<String, Object> hashMap, Location location) {
        HashMap hashMap2 = new HashMap();
        Float valueOf = Float.valueOf(location.getAccuracy() * 1000.0f);
        Long valueOf2 = Long.valueOf(location.getTime() * 1000);
        Long valueOf3 = Long.valueOf((long) (location.getLatitude() * 1.0E7d));
        Long valueOf4 = Long.valueOf((long) (location.getLongitude() * 1.0E7d));
        hashMap2.put("radius", valueOf);
        hashMap2.put("lat", valueOf3);
        hashMap2.put("long", valueOf4);
        hashMap2.put("time", valueOf2);
        hashMap.put("uule", hashMap2);
    }
}
