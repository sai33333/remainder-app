package com.google.android.gms.internal;

import java.util.Map;

/* renamed from: com.google.android.gms.internal.bi */
final class C0655bi implements ajh {

    /* renamed from: a */
    private /* synthetic */ C0652bf f2897a;

    C0655bi(C0652bf bfVar) {
        this.f2897a = bfVar;
    }

    /* renamed from: a */
    public final void mo1441a(C0885jw jwVar, Map<String, String> map) {
        synchronized (this.f2897a.f2891e) {
            if (!this.f2897a.f2894h.isDone()) {
                C0658bl blVar = new C0658bl(-2, map);
                if (this.f2897a.f2892f.equals(blVar.mo2584h())) {
                    this.f2897a.f2894h.mo2904b(blVar);
                }
            }
        }
    }
}
