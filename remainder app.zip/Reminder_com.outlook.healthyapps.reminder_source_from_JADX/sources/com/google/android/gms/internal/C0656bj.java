package com.google.android.gms.internal;

import android.net.Uri;
import android.net.Uri.Builder;
import android.text.TextUtils;
import com.google.android.gms.ads.internal.C0354ax;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

@arm
/* renamed from: com.google.android.gms.internal.bj */
public final class C0656bj {

    /* renamed from: A */
    private C1190t f2898A;

    /* renamed from: B */
    private boolean f2899B = false;

    /* renamed from: C */
    private String f2900C;

    /* renamed from: D */
    private List<String> f2901D;

    /* renamed from: E */
    private boolean f2902E;

    /* renamed from: F */
    private String f2903F;

    /* renamed from: G */
    private C0725dy f2904G;

    /* renamed from: H */
    private boolean f2905H;

    /* renamed from: I */
    private boolean f2906I;

    /* renamed from: J */
    private final C0970n f2907J;

    /* renamed from: a */
    private String f2908a;

    /* renamed from: b */
    private String f2909b;

    /* renamed from: c */
    private String f2910c;

    /* renamed from: d */
    private List<String> f2911d;

    /* renamed from: e */
    private String f2912e;

    /* renamed from: f */
    private String f2913f;

    /* renamed from: g */
    private String f2914g;

    /* renamed from: h */
    private List<String> f2915h;

    /* renamed from: i */
    private long f2916i = -1;

    /* renamed from: j */
    private boolean f2917j = false;

    /* renamed from: k */
    private final long f2918k = -1;

    /* renamed from: l */
    private List<String> f2919l;

    /* renamed from: m */
    private long f2920m = -1;

    /* renamed from: n */
    private int f2921n = -1;

    /* renamed from: o */
    private boolean f2922o = false;

    /* renamed from: p */
    private boolean f2923p = false;

    /* renamed from: q */
    private boolean f2924q = false;

    /* renamed from: r */
    private boolean f2925r = true;

    /* renamed from: s */
    private boolean f2926s = true;

    /* renamed from: t */
    private String f2927t = "";

    /* renamed from: u */
    private boolean f2928u = false;

    /* renamed from: v */
    private boolean f2929v = false;

    /* renamed from: w */
    private C0717dq f2930w;

    /* renamed from: x */
    private List<String> f2931x;

    /* renamed from: y */
    private List<String> f2932y;

    /* renamed from: z */
    private boolean f2933z = false;

    public C0656bj(C0970n nVar, String str) {
        this.f2909b = str;
        this.f2907J = nVar;
    }

    /* renamed from: a */
    private static String m4027a(Map<String, List<String>> map, String str) {
        List list = (List) map.get(str);
        if (list == null || list.isEmpty()) {
            return null;
        }
        return (String) list.get(0);
    }

    /* renamed from: a */
    private static boolean m4028a(Map<String, List<String>> map, String str, boolean z) {
        List list = (List) map.get(str);
        return (list == null || list.isEmpty()) ? z : Boolean.valueOf((String) list.get(0)).booleanValue();
    }

    /* renamed from: b */
    private static long m4029b(Map<String, List<String>> map, String str) {
        List list = (List) map.get(str);
        if (list != null && !list.isEmpty()) {
            String str2 = (String) list.get(0);
            try {
                return (long) (Float.parseFloat(str2) * 1000.0f);
            } catch (NumberFormatException unused) {
                StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 36 + String.valueOf(str2).length());
                sb.append("Could not parse float from ");
                sb.append(str);
                sb.append(" header: ");
                sb.append(str2);
                C0759fe.m4734e(sb.toString());
            }
        }
        return -1;
    }

    /* renamed from: c */
    private static List<String> m4030c(Map<String, List<String>> map, String str) {
        List list = (List) map.get(str);
        if (list != null && !list.isEmpty()) {
            String str2 = (String) list.get(0);
            if (str2 != null) {
                return Arrays.asList(str2.trim().split("\\s+"));
            }
        }
        return null;
    }

    /* renamed from: a */
    public final C1135r mo2573a(long j) {
        C1135r rVar = new C1135r(this.f2907J, this.f2909b, this.f2910c, this.f2911d, this.f2915h, this.f2916i, this.f2917j, -1, this.f2919l, this.f2920m, this.f2921n, this.f2908a, j, this.f2913f, this.f2914g, this.f2922o, this.f2923p, this.f2924q, this.f2925r, false, this.f2927t, this.f2928u, this.f2929v, this.f2930w, this.f2931x, this.f2932y, this.f2933z, this.f2898A, this.f2899B, this.f2900C, this.f2901D, this.f2902E, this.f2903F, this.f2904G, this.f2912e, this.f2926s, this.f2905H, this.f2906I);
        return rVar;
    }

    /* renamed from: a */
    public final void mo2574a(String str, Map<String, List<String>> map, String str2) {
        this.f2910c = str2;
        mo2575a(map);
    }

    /* renamed from: a */
    public final void mo2575a(Map<String, List<String>> map) {
        int a;
        this.f2908a = m4027a(map, "X-Afma-Ad-Size");
        this.f2903F = m4027a(map, "X-Afma-Ad-Slot-Size");
        List<String> c = m4030c(map, "X-Afma-Click-Tracking-Urls");
        if (c != null) {
            this.f2911d = c;
        }
        this.f2912e = m4027a(map, "X-Afma-Debug-Signals");
        List list = (List) map.get("X-Afma-Debug-Dialog");
        if (list != null && !list.isEmpty()) {
            this.f2913f = (String) list.get(0);
        }
        List<String> c2 = m4030c(map, "X-Afma-Tracking-Urls");
        if (c2 != null) {
            this.f2915h = c2;
        }
        long b = m4029b(map, "X-Afma-Interstitial-Timeout");
        if (b != -1) {
            this.f2916i = b;
        }
        this.f2917j |= m4028a(map, "X-Afma-Mediation", false);
        List<String> c3 = m4030c(map, "X-Afma-Manual-Tracking-Urls");
        if (c3 != null) {
            this.f2919l = c3;
        }
        long b2 = m4029b(map, "X-Afma-Refresh-Rate");
        if (b2 != -1) {
            this.f2920m = b2;
        }
        List list2 = (List) map.get("X-Afma-Orientation");
        if (list2 != null && !list2.isEmpty()) {
            String str = (String) list2.get(0);
            if ("portrait".equalsIgnoreCase(str)) {
                a = C0354ax.m1540g().mo2824b();
            } else if ("landscape".equalsIgnoreCase(str)) {
                a = C0354ax.m1540g().mo2811a();
            }
            this.f2921n = a;
        }
        this.f2914g = m4027a(map, "X-Afma-ActiveView");
        List list3 = (List) map.get("X-Afma-Use-HTTPS");
        if (list3 != null && !list3.isEmpty()) {
            this.f2924q = Boolean.valueOf((String) list3.get(0)).booleanValue();
        }
        this.f2922o |= m4028a(map, "X-Afma-Custom-Rendering-Allowed", false);
        this.f2923p = "native".equals(m4027a(map, "X-Afma-Ad-Format"));
        List list4 = (List) map.get("X-Afma-Content-Url-Opted-Out");
        if (list4 != null && !list4.isEmpty()) {
            this.f2925r = Boolean.valueOf((String) list4.get(0)).booleanValue();
        }
        List list5 = (List) map.get("X-Afma-Content-Vertical-Opted-Out");
        if (list5 != null && !list5.isEmpty()) {
            this.f2926s = Boolean.valueOf((String) list5.get(0)).booleanValue();
        }
        List list6 = (List) map.get("X-Afma-Gws-Query-Id");
        if (list6 != null && !list6.isEmpty()) {
            this.f2927t = (String) list6.get(0);
        }
        String a2 = m4027a(map, "X-Afma-Fluid");
        if (a2 != null && a2.equals("height")) {
            this.f2928u = true;
        }
        this.f2929v = "native_express".equals(m4027a(map, "X-Afma-Ad-Format"));
        this.f2930w = C0717dq.m4250a(m4027a(map, "X-Afma-Rewards"));
        if (this.f2931x == null) {
            this.f2931x = m4030c(map, "X-Afma-Reward-Video-Start-Urls");
        }
        if (this.f2932y == null) {
            this.f2932y = m4030c(map, "X-Afma-Reward-Video-Complete-Urls");
        }
        this.f2933z |= m4028a(map, "X-Afma-Use-Displayed-Impression", false);
        this.f2899B |= m4028a(map, "X-Afma-Auto-Collect-Location", false);
        this.f2900C = m4027a(map, "Set-Cookie");
        String a3 = m4027a(map, "X-Afma-Auto-Protection-Configuration");
        if (a3 == null || TextUtils.isEmpty(a3)) {
            Builder buildUpon = Uri.parse("https://pagead2.googlesyndication.com/pagead/gen_204").buildUpon();
            buildUpon.appendQueryParameter("id", "gmob-apps-blocked-navigation");
            if (!TextUtils.isEmpty(this.f2913f)) {
                buildUpon.appendQueryParameter("debugDialog", this.f2913f);
            }
            boolean booleanValue = ((Boolean) C0354ax.m1551r().mo2079a(ael.f2040e)).booleanValue();
            String builder = buildUpon.toString();
            String str2 = "navigationURL";
            StringBuilder sb = new StringBuilder(String.valueOf(builder).length() + 18 + String.valueOf(str2).length());
            sb.append(builder);
            sb.append("&");
            sb.append(str2);
            sb.append("={NAVIGATION_URL}");
            this.f2898A = new C1190t(booleanValue, Arrays.asList(new String[]{sb.toString()}));
        } else {
            try {
                this.f2898A = C1190t.m5764a(new JSONObject(a3));
            } catch (JSONException e) {
                C0759fe.m4732c("Error parsing configuration JSON", e);
                this.f2898A = new C1190t();
            }
        }
        List<String> c4 = m4030c(map, "X-Afma-Remote-Ping-Urls");
        if (c4 != null) {
            this.f2901D = c4;
        }
        String a4 = m4027a(map, "X-Afma-Safe-Browsing");
        if (!TextUtils.isEmpty(a4)) {
            try {
                this.f2904G = C0725dy.m4266a(new JSONObject(a4));
            } catch (JSONException e2) {
                C0759fe.m4732c("Error parsing safe browsing header", e2);
            }
        }
        this.f2902E |= m4028a(map, "X-Afma-Render-In-Browser", false);
        String a5 = m4027a(map, "X-Afma-Pool");
        if (!TextUtils.isEmpty(a5)) {
            try {
                this.f2905H = new JSONObject(a5).getBoolean("never_pool");
            } catch (JSONException e3) {
                C0759fe.m4732c("Error parsing interstitial pool header", e3);
            }
        }
        this.f2906I = !m4028a(map, "X-Afma-Custom-Close-Allowed", true);
    }
}
