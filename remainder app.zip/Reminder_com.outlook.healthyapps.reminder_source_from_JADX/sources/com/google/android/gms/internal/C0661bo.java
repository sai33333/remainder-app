package com.google.android.gms.internal;

import android.content.Context;
import java.util.WeakHashMap;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

@arm
/* renamed from: com.google.android.gms.internal.bo */
public final class C0661bo {
    /* access modifiers changed from: private */

    /* renamed from: a */
    public WeakHashMap<Context, C0663bq> f3002a = new WeakHashMap<>();

    /* renamed from: a */
    public final Future<C0659bm> mo2587a(Context context) {
        return C0790gi.m4480a((ExecutorService) C0790gi.f3317a, (Callable<T>) new C0662bp<T>(this, context));
    }
}
