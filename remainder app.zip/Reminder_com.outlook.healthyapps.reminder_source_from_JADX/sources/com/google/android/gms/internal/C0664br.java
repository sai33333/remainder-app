package com.google.android.gms.internal;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.android.gms.ads.internal.C0354ax;
import com.google.android.gms.ads.internal.p017js.C0400aj;
import org.json.JSONException;
import org.json.JSONObject;

@arm
/* renamed from: com.google.android.gms.internal.br */
public final class C0664br extends C0668bv {

    /* renamed from: a */
    private final Object f3007a = new Object();

    /* renamed from: b */
    private SharedPreferences f3008b;

    /* access modifiers changed from: private */
    /* renamed from: a */
    public final void m4055a() {
        this.f3008b.edit().putLong("js_last_update", C0354ax.m1544k().mo1882a()).apply();
    }

    /* renamed from: a */
    public final void mo2589a(Context context, C0857iv ivVar, C0400aj ajVar) {
        synchronized (this.f3007a) {
            if (this.f3008b == null) {
                this.f3008b = context.getSharedPreferences("google_ads_flags_meta", 0);
            }
        }
        if (C0354ax.m1544k().mo1882a() - this.f3008b.getLong("js_last_update", 0) < ((Long) C0354ax.m1551r().mo2079a(ael.f1890bI)).longValue()) {
            ajVar.mo1488c();
            return;
        }
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("js", ivVar.f3448a);
            jSONObject.put("mf", C0354ax.m1551r().mo2079a(ael.f1891bJ));
            jSONObject.put("cl", "169154428");
            jSONObject.put("rapid_rc", "dev");
            jSONObject.put("rapid_rollup", "HEAD");
            ajVar.mo1494a(new C0666bt(this, new C0665bs(this, context, ajVar), jSONObject, ajVar), new C0667bu(this, ajVar));
        } catch (JSONException e) {
            C0759fe.m4730b("Unable to populate SDK Core Constants parameters.", e);
            ajVar.mo1488c();
        }
    }
}
