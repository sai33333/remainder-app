package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.p017js.C0400aj;

/* renamed from: com.google.android.gms.internal.bu */
final class C0667bu implements C0875jm {

    /* renamed from: a */
    private /* synthetic */ C0400aj f3015a;

    C0667bu(C0664br brVar, C0400aj ajVar) {
        this.f3015a = ajVar;
    }

    /* renamed from: a */
    public final void mo1486a() {
        this.f3015a.mo1488c();
    }
}
