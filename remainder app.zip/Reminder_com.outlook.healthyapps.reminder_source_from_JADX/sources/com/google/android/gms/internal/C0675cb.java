package com.google.android.gms.internal;

import com.google.android.gms.common.internal.C0554q;

@arm
/* renamed from: com.google.android.gms.internal.cb */
public final class C0675cb extends C0682ci {

    /* renamed from: a */
    private final String f3020a;

    /* renamed from: b */
    private final int f3021b;

    public C0675cb(String str, int i) {
        this.f3020a = str;
        this.f3021b = i;
    }

    /* renamed from: a */
    public final String mo2592a() {
        return this.f3020a;
    }

    /* renamed from: b */
    public final int mo2593b() {
        return this.f3021b;
    }

    public final boolean equals(Object obj) {
        if (obj != null && (obj instanceof C0675cb)) {
            C0675cb cbVar = (C0675cb) obj;
            if (C0554q.m2145a(this.f3020a, cbVar.f3020a) && C0554q.m2145a(Integer.valueOf(this.f3021b), Integer.valueOf(cbVar.f3021b))) {
                return true;
            }
        }
        return false;
    }
}
