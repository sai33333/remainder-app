package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.cf */
final class C0679cf implements Runnable {

    /* renamed from: a */
    private /* synthetic */ C0677cd f3037a;

    C0679cf(C0677cd cdVar) {
        this.f3037a = cdVar;
    }

    public final void run() {
        this.f3037a.mo1282a(1);
    }
}
