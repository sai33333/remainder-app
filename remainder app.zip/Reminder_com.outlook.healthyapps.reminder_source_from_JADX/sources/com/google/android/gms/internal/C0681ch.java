package com.google.android.gms.internal;

import android.os.IInterface;

/* renamed from: com.google.android.gms.internal.ch */
public interface C0681ch extends IInterface {
    /* renamed from: a */
    String mo2592a();

    /* renamed from: b */
    int mo2593b();
}
