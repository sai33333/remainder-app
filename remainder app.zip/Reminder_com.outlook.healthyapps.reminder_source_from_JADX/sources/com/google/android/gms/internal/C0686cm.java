package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.p012a.C0279a;

/* renamed from: com.google.android.gms.internal.cm */
public final class C0686cm extends C1178so implements C0684ck {
    C0686cm(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.ads.internal.reward.client.IRewardedVideoAd");
    }

    /* renamed from: a */
    public final void mo2595a() {
        mo3283b(2, mo3284j_());
    }

    /* renamed from: a */
    public final void mo2596a(C0279a aVar) {
        Parcel j_ = mo3284j_();
        C1181sr.m5731a(j_, (IInterface) aVar);
        mo3283b(9, j_);
    }

    /* renamed from: a */
    public final void mo2597a(C0689cp cpVar) {
        Parcel j_ = mo3284j_();
        C1181sr.m5731a(j_, (IInterface) cpVar);
        mo3283b(3, j_);
    }

    /* renamed from: a */
    public final void mo2598a(C0695cv cvVar) {
        Parcel j_ = mo3284j_();
        C1181sr.m5732a(j_, (Parcelable) cvVar);
        mo3283b(1, j_);
    }

    /* renamed from: a */
    public final void mo2599a(String str) {
        Parcel j_ = mo3284j_();
        j_.writeString(str);
        mo3283b(4, j_);
    }

    /* renamed from: a */
    public final void mo2600a(boolean z) {
        Parcel j_ = mo3284j_();
        C1181sr.m5733a(j_, z);
        mo3283b(34, j_);
    }

    /* renamed from: b */
    public final void mo2601b(C0279a aVar) {
        Parcel j_ = mo3284j_();
        C1181sr.m5731a(j_, (IInterface) aVar);
        mo3283b(10, j_);
    }

    /* renamed from: b */
    public final boolean mo2602b() {
        Parcel a = mo3281a(5, mo3284j_());
        boolean a2 = C1181sr.m5734a(a);
        a.recycle();
        return a2;
    }

    /* renamed from: c */
    public final void mo2603c() {
        mo3283b(6, mo3284j_());
    }

    /* renamed from: c */
    public final void mo2604c(C0279a aVar) {
        Parcel j_ = mo3284j_();
        C1181sr.m5731a(j_, (IInterface) aVar);
        mo3283b(11, j_);
    }

    /* renamed from: d */
    public final void mo2605d() {
        mo3283b(7, mo3284j_());
    }

    /* renamed from: e */
    public final void mo2606e() {
        mo3283b(8, mo3284j_());
    }

    /* renamed from: f */
    public final String mo2607f() {
        Parcel a = mo3281a(12, mo3284j_());
        String readString = a.readString();
        a.recycle();
        return readString;
    }
}
