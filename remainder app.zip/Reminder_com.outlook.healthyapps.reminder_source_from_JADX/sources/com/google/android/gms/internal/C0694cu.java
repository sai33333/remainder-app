package com.google.android.gms.internal;

import com.google.android.gms.ads.reward.C0513a;
import com.google.android.gms.ads.reward.C0514b;

@arm
/* renamed from: com.google.android.gms.internal.cu */
public final class C0694cu extends C0690cq {

    /* renamed from: a */
    private final C0514b f3041a;

    public C0694cu(C0514b bVar) {
        this.f3041a = bVar;
    }

    /* renamed from: a */
    public final void mo2319a() {
        C0514b bVar = this.f3041a;
        if (bVar != null) {
            bVar.mo1098a();
        }
    }

    /* renamed from: a */
    public final void mo2320a(int i) {
        C0514b bVar = this.f3041a;
        if (bVar != null) {
            bVar.mo1099a(i);
        }
    }

    /* renamed from: a */
    public final void mo2321a(C0681ch chVar) {
        C0514b bVar = this.f3041a;
        if (bVar != null) {
            bVar.mo1100a((C0513a) new C0692cs(chVar));
        }
    }

    /* renamed from: b */
    public final void mo2322b() {
        C0514b bVar = this.f3041a;
        if (bVar != null) {
            bVar.mo1101b();
        }
    }

    /* renamed from: c */
    public final void mo2323c() {
        C0514b bVar = this.f3041a;
        if (bVar != null) {
            bVar.mo1102c();
        }
    }

    /* renamed from: d */
    public final void mo2324d() {
        C0514b bVar = this.f3041a;
        if (bVar != null) {
            bVar.mo1103d();
        }
    }

    /* renamed from: e */
    public final void mo2325e() {
        C0514b bVar = this.f3041a;
        if (bVar != null) {
            bVar.mo1104e();
        }
    }
}
