package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.dd */
public interface C0704dd {
    /* renamed from: a */
    void mo2626a(int i);

    /* renamed from: g */
    void mo2631g();
}
