package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.df */
public interface C0706df {
    /* renamed from: F */
    void mo2610F();

    /* renamed from: G */
    void mo2611G();

    /* renamed from: H */
    void mo2612H();

    /* renamed from: I */
    void mo2613I();

    /* renamed from: J */
    void mo2614J();

    /* renamed from: b */
    void mo2617b(C0717dq dqVar);
}
