package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.dh */
public interface C0708dh {
    /* renamed from: a */
    void mo2627a(String str);

    /* renamed from: a */
    void mo2628a(String str, int i);
}
