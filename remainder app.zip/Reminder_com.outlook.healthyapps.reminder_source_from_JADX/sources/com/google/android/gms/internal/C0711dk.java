package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.dk */
final class C0711dk implements Runnable {

    /* renamed from: a */
    private /* synthetic */ C0743ep f3091a;

    /* renamed from: b */
    private /* synthetic */ C0709di f3092b;

    C0711dk(C0709di diVar, C0743ep epVar) {
        this.f3092b = diVar;
        this.f3091a = epVar;
    }

    public final void run() {
        this.f3092b.f3087i.mo1307b(this.f3091a);
    }
}
