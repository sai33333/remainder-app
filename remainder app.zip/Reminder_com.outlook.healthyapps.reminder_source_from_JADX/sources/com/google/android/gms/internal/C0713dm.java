package com.google.android.gms.internal;

import android.os.IInterface;
import com.google.android.gms.p012a.C0279a;

/* renamed from: com.google.android.gms.internal.dm */
public interface C0713dm extends IInterface {
    /* renamed from: a */
    void mo2641a(C0279a aVar);

    /* renamed from: a */
    void mo2642a(C0279a aVar, int i);

    /* renamed from: a */
    void mo2643a(C0279a aVar, C0717dq dqVar);

    /* renamed from: b */
    void mo2646b(C0279a aVar);

    /* renamed from: b */
    void mo2647b(C0279a aVar, int i);

    /* renamed from: c */
    void mo2648c(C0279a aVar);

    /* renamed from: d */
    void mo2649d(C0279a aVar);

    /* renamed from: e */
    void mo2650e(C0279a aVar);

    /* renamed from: f */
    void mo2651f(C0279a aVar);

    /* renamed from: g */
    void mo2652g(C0279a aVar);
}
