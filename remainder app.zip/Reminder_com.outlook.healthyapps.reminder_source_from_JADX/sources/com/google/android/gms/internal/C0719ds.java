package com.google.android.gms.internal;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.View;
import com.google.android.gms.ads.internal.C0354ax;
import com.google.android.gms.common.C0528i;
import com.google.android.gms.common.internal.C0557t;
import com.google.android.gms.common.util.C0580h;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;

@arm
/* renamed from: com.google.android.gms.internal.ds */
public final class C0719ds implements C0729eb {

    /* renamed from: a */
    boolean f3098a;
    /* access modifiers changed from: private */

    /* renamed from: b */
    public final C1283wf f3099b;

    /* renamed from: c */
    private final LinkedHashMap<String, C1291wn> f3100c;

    /* renamed from: d */
    private final Context f3101d;

    /* renamed from: e */
    private final C0731ed f3102e;

    /* renamed from: f */
    private final C0725dy f3103f;
    /* access modifiers changed from: private */

    /* renamed from: g */
    public final Object f3104g = new Object();

    /* renamed from: h */
    private HashSet<String> f3105h = new HashSet<>();

    /* renamed from: i */
    private boolean f3106i = false;

    /* renamed from: j */
    private boolean f3107j = false;

    /* renamed from: k */
    private boolean f3108k = false;

    public C0719ds(Context context, C0857iv ivVar, C1135r rVar, C0731ed edVar) {
        C0557t.m2148a(rVar.f4429K, (Object) "SafeBrowsing config is not present.");
        if (context.getApplicationContext() != null) {
            context = context.getApplicationContext();
        }
        this.f3101d = context;
        this.f3100c = new LinkedHashMap<>();
        this.f3102e = edVar;
        this.f3103f = rVar.f4429K;
        for (String lowerCase : this.f3103f.f3118e) {
            this.f3105h.add(lowerCase.toLowerCase(Locale.ENGLISH));
        }
        this.f3105h.remove("cookie".toLowerCase(Locale.ENGLISH));
        C1283wf wfVar = new C1283wf();
        wfVar.f4745a = Integer.valueOf(8);
        wfVar.f4746b = rVar.f4438a;
        wfVar.f4747c = rVar.f4438a;
        wfVar.f4748d = new C1284wg();
        wfVar.f4748d.f4761a = this.f3103f.f3114a;
        C1292wo woVar = new C1292wo();
        woVar.f4795a = ivVar.f3448a;
        woVar.f4797c = Boolean.valueOf(C0948me.m5127a(this.f3101d).mo3085a());
        C0528i.m2089a();
        long b = (long) C0528i.m2090b(this.f3101d);
        if (b > 0) {
            woVar.f4796b = Long.valueOf(b);
        }
        wfVar.f4752h = woVar;
        this.f3099b = wfVar;
    }

    /* renamed from: b */
    private final C1291wn m4254b(String str) {
        C1291wn wnVar;
        synchronized (this.f3104g) {
            wnVar = (C1291wn) this.f3100c.get(str);
        }
        return wnVar;
    }

    /* renamed from: a */
    public final C0725dy mo2663a() {
        return this.f3103f;
    }

    /* renamed from: a */
    public final void mo2664a(View view) {
        if (this.f3103f.f3116c && !this.f3107j) {
            C0354ax.m1538e();
            Bitmap b = C0796go.m4516b(view);
            if (b == null) {
                C0728ea.m4268a("Failed to capture the webview bitmap.");
                return;
            }
            this.f3107j = true;
            C0796go.m4522b((Runnable) new C0720dt(this, b));
        }
    }

    /* renamed from: a */
    public final void mo2665a(String str) {
        synchronized (this.f3104g) {
            this.f3099b.f4750f = str;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0022, code lost:
        return;
     */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo2666a(java.lang.String r7, java.util.Map<java.lang.String, java.lang.String> r8, int r9) {
        /*
            r6 = this;
            java.lang.Object r0 = r6.f3104g
            monitor-enter(r0)
            r1 = 3
            if (r9 != r1) goto L_0x0009
            r2 = 1
            r6.f3108k = r2     // Catch:{ all -> 0x00c6 }
        L_0x0009:
            java.util.LinkedHashMap<java.lang.String, com.google.android.gms.internal.wn> r2 = r6.f3100c     // Catch:{ all -> 0x00c6 }
            boolean r2 = r2.containsKey(r7)     // Catch:{ all -> 0x00c6 }
            if (r2 == 0) goto L_0x0023
            if (r9 != r1) goto L_0x0021
            java.util.LinkedHashMap<java.lang.String, com.google.android.gms.internal.wn> r8 = r6.f3100c     // Catch:{ all -> 0x00c6 }
            java.lang.Object r7 = r8.get(r7)     // Catch:{ all -> 0x00c6 }
            com.google.android.gms.internal.wn r7 = (com.google.android.gms.internal.C1291wn) r7     // Catch:{ all -> 0x00c6 }
            java.lang.Integer r8 = java.lang.Integer.valueOf(r9)     // Catch:{ all -> 0x00c6 }
            r7.f4789d = r8     // Catch:{ all -> 0x00c6 }
        L_0x0021:
            monitor-exit(r0)     // Catch:{ all -> 0x00c6 }
            return
        L_0x0023:
            com.google.android.gms.internal.wn r1 = new com.google.android.gms.internal.wn     // Catch:{ all -> 0x00c6 }
            r1.<init>()     // Catch:{ all -> 0x00c6 }
            java.lang.Integer r9 = java.lang.Integer.valueOf(r9)     // Catch:{ all -> 0x00c6 }
            r1.f4789d = r9     // Catch:{ all -> 0x00c6 }
            java.util.LinkedHashMap<java.lang.String, com.google.android.gms.internal.wn> r9 = r6.f3100c     // Catch:{ all -> 0x00c6 }
            int r9 = r9.size()     // Catch:{ all -> 0x00c6 }
            java.lang.Integer r9 = java.lang.Integer.valueOf(r9)     // Catch:{ all -> 0x00c6 }
            r1.f4786a = r9     // Catch:{ all -> 0x00c6 }
            r1.f4787b = r7     // Catch:{ all -> 0x00c6 }
            com.google.android.gms.internal.wi r9 = new com.google.android.gms.internal.wi     // Catch:{ all -> 0x00c6 }
            r9.<init>()     // Catch:{ all -> 0x00c6 }
            r1.f4788c = r9     // Catch:{ all -> 0x00c6 }
            java.util.HashSet<java.lang.String> r9 = r6.f3105h     // Catch:{ all -> 0x00c6 }
            int r9 = r9.size()     // Catch:{ all -> 0x00c6 }
            if (r9 <= 0) goto L_0x00bf
            if (r8 == 0) goto L_0x00bf
            java.util.LinkedList r9 = new java.util.LinkedList     // Catch:{ all -> 0x00c6 }
            r9.<init>()     // Catch:{ all -> 0x00c6 }
            java.util.Set r8 = r8.entrySet()     // Catch:{ all -> 0x00c6 }
            java.util.Iterator r8 = r8.iterator()     // Catch:{ all -> 0x00c6 }
        L_0x005a:
            boolean r2 = r8.hasNext()     // Catch:{ all -> 0x00c6 }
            if (r2 == 0) goto L_0x00b2
            java.lang.Object r2 = r8.next()     // Catch:{ all -> 0x00c6 }
            java.util.Map$Entry r2 = (java.util.Map.Entry) r2     // Catch:{ all -> 0x00c6 }
            java.lang.Object r3 = r2.getKey()     // Catch:{ UnsupportedEncodingException -> 0x00ac }
            if (r3 == 0) goto L_0x0073
            java.lang.Object r3 = r2.getKey()     // Catch:{ UnsupportedEncodingException -> 0x00ac }
            java.lang.String r3 = (java.lang.String) r3     // Catch:{ UnsupportedEncodingException -> 0x00ac }
            goto L_0x0075
        L_0x0073:
            java.lang.String r3 = ""
        L_0x0075:
            java.lang.Object r4 = r2.getValue()     // Catch:{ UnsupportedEncodingException -> 0x00ac }
            if (r4 == 0) goto L_0x0082
            java.lang.Object r2 = r2.getValue()     // Catch:{ UnsupportedEncodingException -> 0x00ac }
            java.lang.String r2 = (java.lang.String) r2     // Catch:{ UnsupportedEncodingException -> 0x00ac }
            goto L_0x0084
        L_0x0082:
            java.lang.String r2 = ""
        L_0x0084:
            java.util.Locale r4 = java.util.Locale.ENGLISH     // Catch:{ UnsupportedEncodingException -> 0x00ac }
            java.lang.String r4 = r3.toLowerCase(r4)     // Catch:{ UnsupportedEncodingException -> 0x00ac }
            java.util.HashSet<java.lang.String> r5 = r6.f3105h     // Catch:{ UnsupportedEncodingException -> 0x00ac }
            boolean r4 = r5.contains(r4)     // Catch:{ UnsupportedEncodingException -> 0x00ac }
            if (r4 != 0) goto L_0x0093
            goto L_0x005a
        L_0x0093:
            com.google.android.gms.internal.wh r4 = new com.google.android.gms.internal.wh     // Catch:{ UnsupportedEncodingException -> 0x00ac }
            r4.<init>()     // Catch:{ UnsupportedEncodingException -> 0x00ac }
            java.lang.String r5 = "UTF-8"
            byte[] r3 = r3.getBytes(r5)     // Catch:{ UnsupportedEncodingException -> 0x00ac }
            r4.f4763a = r3     // Catch:{ UnsupportedEncodingException -> 0x00ac }
            java.lang.String r3 = "UTF-8"
            byte[] r2 = r2.getBytes(r3)     // Catch:{ UnsupportedEncodingException -> 0x00ac }
            r4.f4764b = r2     // Catch:{ UnsupportedEncodingException -> 0x00ac }
            r9.add(r4)     // Catch:{ UnsupportedEncodingException -> 0x00ac }
            goto L_0x005a
        L_0x00ac:
            java.lang.String r2 = "Cannot convert string to bytes, skip header."
            com.google.android.gms.internal.C0728ea.m4268a(r2)     // Catch:{ all -> 0x00c6 }
            goto L_0x005a
        L_0x00b2:
            int r8 = r9.size()     // Catch:{ all -> 0x00c6 }
            com.google.android.gms.internal.wh[] r8 = new com.google.android.gms.internal.C1285wh[r8]     // Catch:{ all -> 0x00c6 }
            r9.toArray(r8)     // Catch:{ all -> 0x00c6 }
            com.google.android.gms.internal.wi r9 = r1.f4788c     // Catch:{ all -> 0x00c6 }
            r9.f4765a = r8     // Catch:{ all -> 0x00c6 }
        L_0x00bf:
            java.util.LinkedHashMap<java.lang.String, com.google.android.gms.internal.wn> r8 = r6.f3100c     // Catch:{ all -> 0x00c6 }
            r8.put(r7, r1)     // Catch:{ all -> 0x00c6 }
            monitor-exit(r0)     // Catch:{ all -> 0x00c6 }
            return
        L_0x00c6:
            r7 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x00c6 }
            throw r7
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.C0719ds.mo2666a(java.lang.String, java.util.Map, int):void");
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public final void mo2667a(Map<String, String> map) {
        if (map != null) {
            for (String str : map.keySet()) {
                JSONArray optJSONArray = new JSONObject((String) map.get(str)).optJSONArray("matches");
                if (optJSONArray != null) {
                    synchronized (this.f3104g) {
                        int length = optJSONArray.length();
                        C1291wn b = m4254b(str);
                        if (b == null) {
                            String str2 = "Cannot find the corresponding resource object for ";
                            String valueOf = String.valueOf(str);
                            C0728ea.m4268a(valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2));
                        } else {
                            b.f4790e = new String[length];
                            boolean z = false;
                            for (int i = 0; i < length; i++) {
                                b.f4790e[i] = optJSONArray.getJSONObject(i).getString("threat_type");
                            }
                            boolean z2 = this.f3098a;
                            if (length > 0) {
                                z = true;
                            }
                            this.f3098a = z | z2;
                        }
                    }
                }
            }
        }
    }

    /* renamed from: b */
    public final boolean mo2668b() {
        return C0580h.m2253d() && this.f3103f.f3116c && !this.f3107j;
    }

    /* renamed from: c */
    public final void mo2669c() {
        this.f3106i = true;
    }

    /* renamed from: d */
    public final void mo2670d() {
        synchronized (this.f3104g) {
            C0865jc a = this.f3102e.mo2676a(this.f3101d, this.f3100c.keySet());
            a.mo2892a(new C0721du(this, a), C0790gi.f3317a);
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: e */
    public final void mo2671e() {
        C1291wn[] wnVarArr;
        if ((this.f3098a && this.f3103f.f3120g) || (this.f3108k && this.f3103f.f3119f) || (!this.f3098a && this.f3103f.f3117d)) {
            synchronized (this.f3104g) {
                this.f3099b.f4749e = new C1291wn[this.f3100c.size()];
                this.f3100c.values().toArray(this.f3099b.f4749e);
                if (C0728ea.m4269a()) {
                    String str = this.f3099b.f4746b;
                    String str2 = this.f3099b.f4750f;
                    StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 53 + String.valueOf(str2).length());
                    sb.append("Sending SB report\n  url: ");
                    sb.append(str);
                    sb.append("\n  clickUrl: ");
                    sb.append(str2);
                    sb.append("\n  resources: \n");
                    StringBuilder sb2 = new StringBuilder(sb.toString());
                    for (C1291wn wnVar : this.f3099b.f4749e) {
                        sb2.append("    [");
                        sb2.append(wnVar.f4790e.length);
                        sb2.append("] ");
                        sb2.append(wnVar.f4787b);
                    }
                    C0728ea.m4268a(sb2.toString());
                }
                C0865jc a = new C0829hu(this.f3101d).mo2862a(1, this.f3103f.f3115b, null, C1279wb.m6126a((C1279wb) this.f3099b));
                if (C0728ea.m4269a()) {
                    a.mo2892a(new C0722dv(this), C0790gi.f3317a);
                }
            }
        }
    }
}
