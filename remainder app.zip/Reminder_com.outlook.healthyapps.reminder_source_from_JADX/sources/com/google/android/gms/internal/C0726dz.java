package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import java.util.List;

/* renamed from: com.google.android.gms.internal.dz */
public final class C0726dz implements Creator<C0725dy> {
    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        int a = C0941ly.m5082a(parcel);
        String str = null;
        String str2 = null;
        List list = null;
        boolean z = false;
        boolean z2 = false;
        boolean z3 = false;
        boolean z4 = false;
        while (parcel.dataPosition() < a) {
            int readInt = parcel.readInt();
            switch (65535 & readInt) {
                case 2:
                    str = C0941ly.m5092g(parcel, readInt);
                    break;
                case 3:
                    str2 = C0941ly.m5092g(parcel, readInt);
                    break;
                case C1217ty.f4597d /*4*/:
                    z = C0941ly.m5088c(parcel, readInt);
                    break;
                case C1217ty.f4598e /*5*/:
                    z2 = C0941ly.m5088c(parcel, readInt);
                    break;
                case C1217ty.f4599f /*6*/:
                    list = C0941ly.m5097l(parcel, readInt);
                    break;
                case C1217ty.f4600g /*7*/:
                    z3 = C0941ly.m5088c(parcel, readInt);
                    break;
                case C1217ty.f4601h /*8*/:
                    z4 = C0941ly.m5088c(parcel, readInt);
                    break;
                default:
                    C0941ly.m5086b(parcel, readInt);
                    break;
            }
        }
        C0941ly.m5098m(parcel, a);
        C0725dy dyVar = new C0725dy(str, str2, z, z2, list, z3, z4);
        return dyVar;
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new C0725dy[i];
    }
}
