package com.google.android.gms.internal;

import android.content.Context;

@arm
/* renamed from: com.google.android.gms.internal.ee */
public final class C0732ee implements C1334yc {

    /* renamed from: a */
    private final Context f3122a;

    /* renamed from: b */
    private final Object f3123b = new Object();

    /* renamed from: c */
    private String f3124c;

    /* renamed from: d */
    private boolean f3125d = false;

    public C0732ee(Context context, String str) {
        this.f3122a = context;
        this.f3124c = str;
    }

    /* renamed from: a */
    public final void mo2681a(C1332ya yaVar) {
        mo2683a(yaVar.f4885a);
    }

    /* renamed from: a */
    public final void mo2682a(String str) {
        this.f3124c = str;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:15:0x0034, code lost:
        return;
     */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo2683a(boolean r4) {
        /*
            r3 = this;
            com.google.android.gms.internal.eg r0 = com.google.android.gms.ads.internal.C0354ax.m1532D()
            android.content.Context r1 = r3.f3122a
            boolean r0 = r0.mo2686a(r1)
            if (r0 != 0) goto L_0x000d
            return
        L_0x000d:
            java.lang.Object r0 = r3.f3123b
            monitor-enter(r0)
            boolean r1 = r3.f3125d     // Catch:{ all -> 0x0035 }
            if (r1 != r4) goto L_0x0016
            monitor-exit(r0)     // Catch:{ all -> 0x0035 }
            return
        L_0x0016:
            r3.f3125d = r4     // Catch:{ all -> 0x0035 }
            boolean r4 = r3.f3125d     // Catch:{ all -> 0x0035 }
            if (r4 == 0) goto L_0x0028
            com.google.android.gms.internal.eg r4 = com.google.android.gms.ads.internal.C0354ax.m1532D()     // Catch:{ all -> 0x0035 }
            android.content.Context r1 = r3.f3122a     // Catch:{ all -> 0x0035 }
            java.lang.String r2 = r3.f3124c     // Catch:{ all -> 0x0035 }
            r4.mo2685a(r1, r2)     // Catch:{ all -> 0x0035 }
            goto L_0x0033
        L_0x0028:
            com.google.android.gms.internal.eg r4 = com.google.android.gms.ads.internal.C0354ax.m1532D()     // Catch:{ all -> 0x0035 }
            android.content.Context r1 = r3.f3122a     // Catch:{ all -> 0x0035 }
            java.lang.String r2 = r3.f3124c     // Catch:{ all -> 0x0035 }
            r4.mo2687b(r1, r2)     // Catch:{ all -> 0x0035 }
        L_0x0033:
            monitor-exit(r0)     // Catch:{ all -> 0x0035 }
            return
        L_0x0035:
            r4 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x0035 }
            throw r4
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.C0732ee.mo2683a(boolean):void");
    }
}
