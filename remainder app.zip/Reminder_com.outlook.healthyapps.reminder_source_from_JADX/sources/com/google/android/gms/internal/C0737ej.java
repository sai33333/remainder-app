package com.google.android.gms.internal;

import android.content.Context;
import android.text.TextUtils;
import com.google.android.gms.ads.internal.C0354ax;

@arm
/* renamed from: com.google.android.gms.internal.ej */
public final class C0737ej {
    /* renamed from: a */
    public static String m4309a(String str, Context context) {
        if (C0354ax.m1532D().mo2686a(context) && !TextUtils.isEmpty(str)) {
            String i = C0354ax.m1532D().mo2700i(context);
            if (i == null) {
                return str;
            }
            if (((Boolean) C0354ax.m1551r().mo2079a(ael.f1869ao)).booleanValue()) {
                String str2 = (String) C0354ax.m1551r().mo2079a(ael.f1870ap);
                if (str.contains(str2)) {
                    C0354ax.m1538e();
                    if (C0796go.m4531d(str)) {
                        C0354ax.m1532D().mo2691d(context, i);
                        return str.replace(str2, i);
                    }
                    C0354ax.m1538e();
                    if (C0796go.m4535e(str)) {
                        C0354ax.m1532D().mo2693e(context, i);
                        return str.replace(str2, i);
                    }
                }
            } else if (!str.contains("fbs_aeid")) {
                C0354ax.m1538e();
                if (C0796go.m4531d(str)) {
                    C0354ax.m1532D().mo2691d(context, i);
                    C0354ax.m1538e();
                    return C0796go.m4483a(str, "fbs_aeid", i).toString();
                }
                C0354ax.m1538e();
                if (C0796go.m4535e(str)) {
                    C0354ax.m1532D().mo2693e(context, i);
                    C0354ax.m1538e();
                    str = C0796go.m4483a(str, "fbs_aeid", i).toString();
                }
            }
        }
        return str;
    }
}
