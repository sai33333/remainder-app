package com.google.android.gms.internal;

import android.content.Context;
import android.content.pm.PackageInfo;
import com.google.android.gms.ads.p015c.C0313a.C0314a;

/* renamed from: com.google.android.gms.internal.eo */
public interface C0742eo {
    /* renamed from: a */
    C0865jc<C0314a> mo2705a(Context context);

    /* renamed from: a */
    C0865jc<String> mo2706a(String str, PackageInfo packageInfo);
}
