package com.google.android.gms.internal;

import android.text.TextUtils;
import com.google.android.gms.ads.internal.C0354ax;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@arm
/* renamed from: com.google.android.gms.internal.et */
public final class C0747et {

    /* renamed from: a */
    private final long f3199a;

    /* renamed from: b */
    private final List<String> f3200b = new ArrayList();

    /* renamed from: c */
    private final List<String> f3201c = new ArrayList();

    /* renamed from: d */
    private final Map<String, ami> f3202d = new HashMap();

    /* renamed from: e */
    private String f3203e;

    /* renamed from: f */
    private String f3204f;

    /* renamed from: g */
    private boolean f3205g = false;

    public C0747et(String str, long j) {
        this.f3204f = str;
        this.f3199a = j;
        m4331a(str);
    }

    /* renamed from: a */
    private final void m4331a(String str) {
        if (!TextUtils.isEmpty(str)) {
            try {
                JSONObject jSONObject = new JSONObject(str);
                if (jSONObject.optInt("status", -1) != 1) {
                    this.f3205g = false;
                    C0759fe.m4734e("App settings could not be fetched successfully.");
                    return;
                }
                this.f3205g = true;
                this.f3203e = jSONObject.optString("app_id");
                JSONArray optJSONArray = jSONObject.optJSONArray("ad_unit_id_settings");
                if (optJSONArray != null) {
                    for (int i = 0; i < optJSONArray.length(); i++) {
                        JSONObject jSONObject2 = optJSONArray.getJSONObject(i);
                        String optString = jSONObject2.optString("format");
                        String optString2 = jSONObject2.optString("ad_unit_id");
                        if (!TextUtils.isEmpty(optString)) {
                            if (!TextUtils.isEmpty(optString2)) {
                                if ("interstitial".equalsIgnoreCase(optString)) {
                                    this.f3201c.add(optString2);
                                } else if ("rewarded".equalsIgnoreCase(optString)) {
                                    JSONObject optJSONObject = jSONObject2.optJSONObject("mediation_config");
                                    if (optJSONObject != null) {
                                        this.f3202d.put(optString2, new ami(optJSONObject));
                                    }
                                }
                            }
                        }
                    }
                }
                m4332a(jSONObject);
            } catch (JSONException e) {
                C0759fe.m4732c("Exception occurred while processing app setting json", e);
                C0354ax.m1542i().mo2742a((Throwable) e, "AppSettings.parseAppSettingsJson");
            }
        }
    }

    /* renamed from: a */
    private final void m4332a(JSONObject jSONObject) {
        JSONArray optJSONArray = jSONObject.optJSONArray("persistable_banner_ad_unit_ids");
        if (optJSONArray != null) {
            for (int i = 0; i < optJSONArray.length(); i++) {
                this.f3200b.add(optJSONArray.optString(i));
            }
        }
    }

    /* renamed from: a */
    public final long mo2722a() {
        return this.f3199a;
    }

    /* renamed from: b */
    public final boolean mo2723b() {
        return this.f3205g;
    }

    /* renamed from: c */
    public final String mo2724c() {
        return this.f3204f;
    }

    /* renamed from: d */
    public final String mo2725d() {
        return this.f3203e;
    }

    /* renamed from: e */
    public final Map<String, ami> mo2726e() {
        return this.f3202d;
    }
}
