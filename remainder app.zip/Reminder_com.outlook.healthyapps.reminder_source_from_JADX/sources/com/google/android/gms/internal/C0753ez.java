package com.google.android.gms.internal;

import java.util.HashSet;

/* renamed from: com.google.android.gms.internal.ez */
public interface C0753ez {
    /* renamed from: a */
    void mo1302a(HashSet<C0745er> hashSet);
}
