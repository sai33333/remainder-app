package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.f */
public interface C0754f {
    /* renamed from: a */
    void mo2556a(C1135r rVar);
}
