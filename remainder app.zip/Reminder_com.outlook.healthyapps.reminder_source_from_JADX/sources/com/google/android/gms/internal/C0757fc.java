package com.google.android.gms.internal;

import java.util.concurrent.Future;

@arm
/* renamed from: com.google.android.gms.internal.fc */
public abstract class C0757fc implements C0813he<Future> {

    /* renamed from: a */
    private final Runnable f3263a = new C0758fd(this);
    /* access modifiers changed from: private */

    /* renamed from: b */
    public volatile Thread f3264b;

    /* renamed from: c */
    private boolean f3265c = false;

    public C0757fc() {
    }

    public C0757fc(boolean z) {
    }

    /* renamed from: a */
    public abstract void mo1567a();

    /* renamed from: b */
    public abstract void mo1568b();

    /* renamed from: c */
    public final void mo2512c() {
        mo1568b();
        if (this.f3264b != null) {
            this.f3264b.interrupt();
        }
    }

    /* renamed from: d */
    public final /* synthetic */ Object mo2513d() {
        return this.f3265c ? C0790gi.m4478a(1, this.f3263a) : C0790gi.m4479a(this.f3263a);
    }

    /* renamed from: h */
    public final Future mo2785h() {
        return this.f3265c ? C0790gi.m4478a(1, this.f3263a) : C0790gi.m4479a(this.f3263a);
    }
}
