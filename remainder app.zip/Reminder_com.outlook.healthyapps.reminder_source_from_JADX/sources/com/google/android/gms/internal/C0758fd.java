package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.fd */
final class C0758fd implements Runnable {

    /* renamed from: a */
    private /* synthetic */ C0757fc f3266a;

    C0758fd(C0757fc fcVar) {
        this.f3266a = fcVar;
    }

    public final void run() {
        this.f3266a.f3264b = Thread.currentThread();
        this.f3266a.mo1567a();
    }
}
