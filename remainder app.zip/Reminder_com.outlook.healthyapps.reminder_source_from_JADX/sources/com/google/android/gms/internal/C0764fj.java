package com.google.android.gms.internal;

import android.content.Context;
import android.content.SharedPreferences.Editor;

/* renamed from: com.google.android.gms.internal.fj */
final class C0764fj extends C0787gf {

    /* renamed from: a */
    private /* synthetic */ Context f3273a;

    /* renamed from: b */
    private /* synthetic */ String f3274b;

    C0764fj(Context context, String str) {
        this.f3273a = context;
        this.f3274b = str;
        super(null);
    }

    /* renamed from: a */
    public final void mo1567a() {
        Editor edit = this.f3273a.getSharedPreferences("admob", 0).edit();
        edit.putString("content_vertical_hashes", this.f3274b);
        edit.apply();
    }
}
