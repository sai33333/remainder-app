package com.google.android.gms.internal;

import android.content.Context;
import android.content.SharedPreferences.Editor;

/* renamed from: com.google.android.gms.internal.fk */
final class C0765fk extends C0787gf {

    /* renamed from: a */
    private /* synthetic */ Context f3275a;

    /* renamed from: b */
    private /* synthetic */ boolean f3276b;

    C0765fk(Context context, boolean z) {
        this.f3275a = context;
        this.f3276b = z;
        super(null);
    }

    /* renamed from: a */
    public final void mo1567a() {
        Editor edit = this.f3275a.getSharedPreferences("admob", 0).edit();
        edit.putBoolean("auto_collect_location", this.f3276b);
        edit.apply();
    }
}
