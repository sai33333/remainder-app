package com.google.android.gms.internal;

import android.content.Context;
import android.content.SharedPreferences.Editor;

/* renamed from: com.google.android.gms.internal.fo */
final class C0769fo extends C0787gf {

    /* renamed from: a */
    private /* synthetic */ Context f3283a;

    /* renamed from: b */
    private /* synthetic */ String f3284b;

    /* renamed from: c */
    private /* synthetic */ long f3285c;

    C0769fo(Context context, String str, long j) {
        this.f3283a = context;
        this.f3284b = str;
        this.f3285c = j;
        super(null);
    }

    /* renamed from: a */
    public final void mo1567a() {
        Editor edit = this.f3283a.getSharedPreferences("admob", 0).edit();
        edit.putString("app_settings_json", this.f3284b);
        edit.putLong("app_settings_last_update_ms", this.f3285c);
        edit.apply();
    }
}
