package com.google.android.gms.internal;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

/* renamed from: com.google.android.gms.internal.fp */
final class C0770fp extends C0787gf {

    /* renamed from: a */
    private /* synthetic */ Context f3286a;

    /* renamed from: b */
    private /* synthetic */ C0788gg f3287b;

    C0770fp(Context context, C0788gg ggVar) {
        this.f3286a = context;
        this.f3287b = ggVar;
        super(null);
    }

    /* renamed from: a */
    public final void mo1567a() {
        SharedPreferences sharedPreferences = this.f3286a.getSharedPreferences("admob", 0);
        Bundle bundle = new Bundle();
        bundle.putString("app_settings_json", sharedPreferences.getString("app_settings_json", ""));
        bundle.putLong("app_settings_last_update_ms", sharedPreferences.getLong("app_settings_last_update_ms", 0));
        C0788gg ggVar = this.f3287b;
        if (ggVar != null) {
            ggVar.mo2738a(bundle);
        }
    }
}
