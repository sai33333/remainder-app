package com.google.android.gms.internal;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

/* renamed from: com.google.android.gms.internal.fs */
final class C0773fs extends C0787gf {

    /* renamed from: a */
    private /* synthetic */ Context f3292a;

    /* renamed from: b */
    private /* synthetic */ C0788gg f3293b;

    C0773fs(Context context, C0788gg ggVar) {
        this.f3292a = context;
        this.f3293b = ggVar;
        super(null);
    }

    /* renamed from: a */
    public final void mo1567a() {
        SharedPreferences sharedPreferences = this.f3292a.getSharedPreferences("admob", 0);
        Bundle bundle = new Bundle();
        bundle.putString("native_advanced_settings", sharedPreferences.getString("native_advanced_settings", "{}"));
        C0788gg ggVar = this.f3293b;
        if (ggVar != null) {
            ggVar.mo2738a(bundle);
        }
    }
}
