package com.google.android.gms.internal;

import android.content.Context;
import android.content.SharedPreferences.Editor;

/* renamed from: com.google.android.gms.internal.ft */
final class C0774ft extends C0787gf {

    /* renamed from: a */
    private /* synthetic */ Context f3294a;

    C0774ft(Context context) {
        this.f3294a = context;
        super(null);
    }

    /* renamed from: a */
    public final void mo1567a() {
        Editor edit = this.f3294a.getSharedPreferences("admob", 0).edit();
        edit.remove("native_advanced_settings");
        edit.apply();
    }
}
