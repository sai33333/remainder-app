package com.google.android.gms.internal;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

/* renamed from: com.google.android.gms.internal.fv */
final class C0776fv extends C0787gf {

    /* renamed from: a */
    private /* synthetic */ Context f3297a;

    /* renamed from: b */
    private /* synthetic */ C0788gg f3298b;

    C0776fv(Context context, C0788gg ggVar) {
        this.f3297a = context;
        this.f3298b = ggVar;
        super(null);
    }

    /* renamed from: a */
    public final void mo1567a() {
        SharedPreferences sharedPreferences = this.f3297a.getSharedPreferences("admob", 0);
        Bundle bundle = new Bundle();
        bundle.putLong("app_last_background_time_ms", sharedPreferences.getLong("app_last_background_time_ms", 0));
        C0788gg ggVar = this.f3298b;
        if (ggVar != null) {
            ggVar.mo2738a(bundle);
        }
    }
}
