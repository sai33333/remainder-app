package com.google.android.gms.internal;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

/* renamed from: com.google.android.gms.internal.fx */
final class C0778fx extends C0787gf {

    /* renamed from: a */
    private /* synthetic */ Context f3301a;

    /* renamed from: b */
    private /* synthetic */ C0788gg f3302b;

    C0778fx(Context context, C0788gg ggVar) {
        this.f3301a = context;
        this.f3302b = ggVar;
        super(null);
    }

    /* renamed from: a */
    public final void mo1567a() {
        SharedPreferences sharedPreferences = this.f3301a.getSharedPreferences("admob", 0);
        Bundle bundle = new Bundle();
        bundle.putInt("request_in_session_count", sharedPreferences.getInt("request_in_session_count", -1));
        C0788gg ggVar = this.f3302b;
        if (ggVar != null) {
            ggVar.mo2738a(bundle);
        }
    }
}
