package com.google.android.gms.internal;

import android.content.Context;
import android.content.SharedPreferences.Editor;

/* renamed from: com.google.android.gms.internal.fy */
final class C0779fy extends C0787gf {

    /* renamed from: a */
    private /* synthetic */ Context f3303a;

    /* renamed from: b */
    private /* synthetic */ long f3304b;

    C0779fy(Context context, long j) {
        this.f3303a = context;
        this.f3304b = j;
        super(null);
    }

    /* renamed from: a */
    public final void mo1567a() {
        Editor edit = this.f3303a.getSharedPreferences("admob", 0).edit();
        edit.putLong("first_ad_req_time_ms", this.f3304b);
        edit.apply();
    }
}
