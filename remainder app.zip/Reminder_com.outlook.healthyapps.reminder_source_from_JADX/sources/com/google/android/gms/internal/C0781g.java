package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.g */
interface C0781g {
    /* renamed from: a */
    boolean mo2680a(C0857iv ivVar);
}
