package com.google.android.gms.internal;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

@arm
/* renamed from: com.google.android.gms.internal.gi */
public final class C0790gi {

    /* renamed from: a */
    public static final ThreadPoolExecutor f3317a;

    /* renamed from: b */
    private static final ThreadPoolExecutor f3318b;

    static {
        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(20, 20, 1, TimeUnit.MINUTES, new LinkedBlockingQueue(), m4481a("Default"));
        f3317a = threadPoolExecutor;
        ThreadPoolExecutor threadPoolExecutor2 = new ThreadPoolExecutor(5, 5, 1, TimeUnit.MINUTES, new LinkedBlockingQueue(), m4481a("Loader"));
        f3318b = threadPoolExecutor2;
        f3317a.allowCoreThreadTimeOut(true);
        f3318b.allowCoreThreadTimeOut(true);
    }

    /* renamed from: a */
    public static C0865jc<Void> m4478a(int i, Runnable runnable) {
        ThreadPoolExecutor threadPoolExecutor;
        Callable gkVar;
        if (i == 1) {
            threadPoolExecutor = f3318b;
            gkVar = new C0791gj(runnable);
        } else {
            threadPoolExecutor = f3317a;
            gkVar = new C0792gk(runnable);
        }
        return m4480a((ExecutorService) threadPoolExecutor, gkVar);
    }

    /* renamed from: a */
    public static C0865jc<Void> m4479a(Runnable runnable) {
        return m4478a(0, runnable);
    }

    /* renamed from: a */
    public static <T> C0865jc<T> m4480a(ExecutorService executorService, Callable<T> callable) {
        C0871ji jiVar = new C0871ji();
        try {
            jiVar.mo2892a(new C0794gm(jiVar, executorService.submit(new C0793gl(jiVar, callable))), C0868jf.f3466a);
        } catch (RejectedExecutionException e) {
            C0759fe.m4732c("Thread execution is rejected.", e);
            jiVar.mo2903a(e);
        }
        return jiVar;
    }

    /* renamed from: a */
    private static ThreadFactory m4481a(String str) {
        return new C0795gn(str);
    }
}
