package com.google.android.gms.internal;

import java.util.concurrent.Callable;

/* renamed from: com.google.android.gms.internal.gk */
final class C0792gk implements Callable<Void> {

    /* renamed from: a */
    private /* synthetic */ Runnable f3320a;

    C0792gk(Runnable runnable) {
        this.f3320a = runnable;
    }

    public final /* synthetic */ Object call() {
        this.f3320a.run();
        return null;
    }
}
