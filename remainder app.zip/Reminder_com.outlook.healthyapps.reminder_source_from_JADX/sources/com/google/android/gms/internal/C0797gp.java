package com.google.android.gms.internal;

import android.content.Context;
import java.util.List;

/* renamed from: com.google.android.gms.internal.gp */
final class C0797gp implements afk {

    /* renamed from: a */
    private /* synthetic */ List f3334a;

    /* renamed from: b */
    private /* synthetic */ afj f3335b;

    /* renamed from: c */
    private /* synthetic */ Context f3336c;

    C0797gp(C0796go goVar, List list, afj afj, Context context) {
        this.f3334a = list;
        this.f3335b = afj;
        this.f3336c = context;
    }
}
