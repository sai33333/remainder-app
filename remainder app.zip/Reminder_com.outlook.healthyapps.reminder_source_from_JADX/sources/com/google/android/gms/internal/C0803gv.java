package com.google.android.gms.internal;

import android.annotation.TargetApi;
import android.app.DownloadManager.Request;

@TargetApi(9)
/* renamed from: com.google.android.gms.internal.gv */
public class C0803gv extends C0801gt {
    public C0803gv() {
        super();
    }

    /* renamed from: a */
    public final int mo2811a() {
        return 6;
    }

    /* renamed from: a */
    public boolean mo2820a(Request request) {
        request.setShowRunningNotification(true);
        return true;
    }

    /* renamed from: b */
    public final int mo2824b() {
        return 7;
    }
}
