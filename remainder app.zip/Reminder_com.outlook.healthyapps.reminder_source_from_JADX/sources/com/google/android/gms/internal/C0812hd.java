package com.google.android.gms.internal;

import android.annotation.TargetApi;
import android.content.Context;
import android.webkit.CookieManager;
import com.google.android.gms.ads.internal.C0354ax;

@TargetApi(21)
/* renamed from: com.google.android.gms.internal.hd */
public final class C0812hd extends C0811hc {
    /* renamed from: a */
    public final C0886jx mo2813a(C0885jw jwVar, boolean z) {
        return new C0921le(jwVar, z);
    }

    /* renamed from: c */
    public final CookieManager mo2828c(Context context) {
        try {
            return CookieManager.getInstance();
        } catch (Exception e) {
            C0759fe.m4730b("Failed to obtain CookieManager.", e);
            C0354ax.m1542i().mo2742a((Throwable) e, "ApiLevelUtil.getCookieManager");
            return null;
        }
    }

    /* renamed from: e */
    public final int mo2832e() {
        return 16974374;
    }
}
