package com.google.android.gms.internal;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

/* renamed from: com.google.android.gms.internal.hj */
final class C0818hj implements OnClickListener {
    C0818hj(C0814hf hfVar) {
    }

    public final void onClick(DialogInterface dialogInterface, int i) {
    }
}
