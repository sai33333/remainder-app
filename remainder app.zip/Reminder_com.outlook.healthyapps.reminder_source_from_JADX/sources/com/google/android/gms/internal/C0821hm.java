package com.google.android.gms.internal;

import android.app.Activity;
import android.content.Context;
import android.net.Uri;
import android.net.Uri.Builder;
import android.os.Handler;
import android.text.TextUtils;
import com.google.android.gms.ads.internal.C0354ax;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import org.json.JSONException;
import org.json.JSONObject;

@arm
/* renamed from: com.google.android.gms.internal.hm */
public final class C0821hm {

    /* renamed from: a */
    private final Object f3372a = new Object();

    /* renamed from: b */
    private String f3373b = "";

    /* renamed from: c */
    private String f3374c = "";

    /* renamed from: d */
    private boolean f3375d = false;

    /* renamed from: e */
    private String f3376e = "";

    /* renamed from: a */
    private final String m4640a(Context context) {
        String str;
        synchronized (this.f3372a) {
            if (TextUtils.isEmpty(this.f3373b)) {
                C0354ax.m1538e();
                this.f3373b = C0796go.m4518b(context, "debug_signals_id.txt");
                if (TextUtils.isEmpty(this.f3373b)) {
                    C0354ax.m1538e();
                    this.f3373b = C0796go.m4489a();
                    C0354ax.m1538e();
                    C0796go.m4526c(context, "debug_signals_id.txt", this.f3373b);
                }
            }
            str = this.f3373b;
        }
        return str;
    }

    /* renamed from: a */
    private final void m4641a(Context context, String str, boolean z, boolean z2) {
        if (!(context instanceof Activity)) {
            C0759fe.m4733d("Can not create dialog without Activity Context");
            return;
        }
        Handler handler = C0796go.f3327a;
        C0822hn hnVar = new C0822hn(this, context, str, z, z2);
        handler.post(hnVar);
    }

    /* renamed from: b */
    private final Uri m4642b(Context context, String str, String str2, String str3) {
        Builder buildUpon = Uri.parse(str).buildUpon();
        buildUpon.appendQueryParameter("linkedDeviceId", m4640a(context));
        buildUpon.appendQueryParameter("adSlotPath", str2);
        buildUpon.appendQueryParameter("afmaVersion", str3);
        return buildUpon.build();
    }

    /* renamed from: c */
    private final boolean m4643c(Context context, String str, String str2) {
        String e = m4645e(context, m4642b(context, (String) C0354ax.m1551r().mo2079a(ael.f1985cy), str, str2).toString(), str2);
        if (TextUtils.isEmpty(e)) {
            C0759fe.m4729b("Not linked for in app preview.");
            return false;
        }
        try {
            JSONObject jSONObject = new JSONObject(e.trim());
            String optString = jSONObject.optString("gct");
            this.f3376e = jSONObject.optString("status");
            synchronized (this.f3372a) {
                this.f3374c = optString;
            }
            return true;
        } catch (JSONException e2) {
            C0759fe.m4732c("Fail to get in app preview response json.", e2);
            return false;
        }
    }

    /* renamed from: d */
    private final boolean m4644d(Context context, String str, String str2) {
        String e = m4645e(context, m4642b(context, (String) C0354ax.m1551r().mo2079a(ael.f1986cz), str, str2).toString(), str2);
        if (TextUtils.isEmpty(e)) {
            C0759fe.m4729b("Not linked for debug signals.");
            return false;
        }
        try {
            boolean equals = "1".equals(new JSONObject(e.trim()).optString("debug_mode"));
            synchronized (this.f3372a) {
                this.f3375d = equals;
            }
            return equals;
        } catch (JSONException e2) {
            C0759fe.m4732c("Fail to get debug mode response json.", e2);
            return false;
        }
    }

    /* renamed from: e */
    private static String m4645e(Context context, String str, String str2) {
        String str3;
        Throwable e;
        String str4;
        String str5;
        HashMap hashMap = new HashMap();
        hashMap.put("User-Agent", C0354ax.m1538e().mo2796a(context, str2));
        C0865jc a = new C0829hu(context).mo2864a(str, (Map<String, String>) hashMap);
        try {
            return (String) a.get((long) ((Integer) C0354ax.m1551r().mo2079a(ael.f1936cB)).intValue(), TimeUnit.MILLISECONDS);
        } catch (TimeoutException e2) {
            e = e2;
            str5 = "Timeout while retriving a response from: ";
            str4 = String.valueOf(str);
            if (str4.length() == 0) {
                str3 = new String(str5);
                C0759fe.m4730b(str3, e);
                a.cancel(true);
                return null;
            }
            str3 = str5.concat(str4);
            C0759fe.m4730b(str3, e);
            a.cancel(true);
            return null;
        } catch (InterruptedException e3) {
            e = e3;
            str5 = "Interrupted while retriving a response from: ";
            str4 = String.valueOf(str);
            if (str4.length() == 0) {
                str3 = new String(str5);
                C0759fe.m4730b(str3, e);
                a.cancel(true);
                return null;
            }
            str3 = str5.concat(str4);
            C0759fe.m4730b(str3, e);
            a.cancel(true);
            return null;
        } catch (Exception e4) {
            String str6 = "Error retriving a response from: ";
            String valueOf = String.valueOf(str);
            C0759fe.m4730b(valueOf.length() != 0 ? str6.concat(valueOf) : new String(str6), e4);
            return null;
        }
    }

    /* renamed from: f */
    private final void m4646f(Context context, String str, String str2) {
        C0354ax.m1538e();
        C0796go.m4502a(context, m4642b(context, (String) C0354ax.m1551r().mo2079a(ael.f1984cx), str, str2));
    }

    /* renamed from: a */
    public final String mo2848a() {
        String str;
        synchronized (this.f3372a) {
            str = this.f3374c;
        }
        return str;
    }

    /* renamed from: a */
    public final void mo2849a(Context context, String str, String str2) {
        if (!m4643c(context, str, str2)) {
            m4641a(context, "In-app preview failed to load because of a system error. Please try again later.", true, true);
        } else if ("2".equals(this.f3376e)) {
            C0759fe.m4729b("Creative is not pushed for this device.");
            m4641a(context, "There was no creative pushed from DFP to the device.", false, false);
        } else if ("1".equals(this.f3376e)) {
            C0759fe.m4729b("The app is not linked for creative preview.");
            m4646f(context, str, str2);
        } else {
            if ("0".equals(this.f3376e)) {
                C0759fe.m4729b("Device is linked for in app preview.");
                m4641a(context, "The device is successfully linked for creative preview.", false, true);
            }
        }
    }

    /* renamed from: a */
    public final void mo2850a(Context context, String str, String str2, String str3) {
        Builder buildUpon = m4642b(context, (String) C0354ax.m1551r().mo2079a(ael.f1935cA), str3, str).buildUpon();
        buildUpon.appendQueryParameter("debugData", str2);
        C0354ax.m1538e();
        C0796go.m4521b(context, str, buildUpon.build().toString());
    }

    /* renamed from: b */
    public final void mo2851b(Context context, String str, String str2) {
        if (m4644d(context, str, str2)) {
            C0759fe.m4729b("Device is linked for debug signals.");
            m4641a(context, "The device is successfully linked for troubleshooting.", false, true);
            return;
        }
        m4646f(context, str, str2);
    }

    /* renamed from: b */
    public final boolean mo2852b() {
        boolean z;
        synchronized (this.f3372a) {
            z = this.f3375d;
        }
        return z;
    }
}
