package com.google.android.gms.internal;

import android.app.AlertDialog.Builder;
import android.content.Context;

/* renamed from: com.google.android.gms.internal.hn */
final class C0822hn implements Runnable {

    /* renamed from: a */
    final /* synthetic */ Context f3377a;

    /* renamed from: b */
    private /* synthetic */ String f3378b;

    /* renamed from: c */
    private /* synthetic */ boolean f3379c;

    /* renamed from: d */
    private /* synthetic */ boolean f3380d;

    C0822hn(C0821hm hmVar, Context context, String str, boolean z, boolean z2) {
        this.f3377a = context;
        this.f3378b = str;
        this.f3379c = z;
        this.f3380d = z2;
    }

    public final void run() {
        Builder builder = new Builder(this.f3377a);
        builder.setMessage(this.f3378b);
        builder.setTitle(this.f3379c ? "Error" : "Info");
        if (this.f3380d) {
            builder.setNeutralButton("Dismiss", null);
        } else {
            builder.setPositiveButton("Learn More", new C0823ho(this));
            builder.setNegativeButton("Dismiss", null);
        }
        builder.create().show();
    }
}
