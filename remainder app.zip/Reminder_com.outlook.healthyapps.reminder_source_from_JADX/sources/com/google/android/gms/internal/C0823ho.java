package com.google.android.gms.internal;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.net.Uri;
import com.google.android.gms.ads.internal.C0354ax;

/* renamed from: com.google.android.gms.internal.ho */
final class C0823ho implements OnClickListener {

    /* renamed from: a */
    private /* synthetic */ C0822hn f3381a;

    C0823ho(C0822hn hnVar) {
        this.f3381a = hnVar;
    }

    public final void onClick(DialogInterface dialogInterface, int i) {
        C0354ax.m1538e();
        C0796go.m4502a(this.f3381a.f3377a, Uri.parse("https://support.google.com/dfp_premium/answer/7160685#push"));
    }
}
