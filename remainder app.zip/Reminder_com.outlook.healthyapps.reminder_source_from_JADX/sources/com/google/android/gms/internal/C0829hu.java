package com.google.android.gms.internal;

import android.content.Context;
import java.util.Map;

@arm
/* renamed from: com.google.android.gms.internal.hu */
public final class C0829hu {

    /* renamed from: a */
    private static akb f3395a;

    /* renamed from: b */
    private static final Object f3396b = new Object();

    /* renamed from: c */
    private static C0833hy<Void> f3397c = new C0830hv();

    public C0829hu(Context context) {
        m4661a(context);
    }

    /* renamed from: a */
    private static akb m4661a(Context context) {
        akb akb;
        synchronized (f3396b) {
            if (f3395a == null) {
                f3395a = C0928ll.m5047a(context.getApplicationContext(), null);
            }
            akb = f3395a;
        }
        return akb;
    }

    /* renamed from: a */
    public final C0865jc<String> mo2862a(int i, String str, Map<String, String> map, byte[] bArr) {
        C0839id idVar = new C0839id(this, null);
        C0832hx hxVar = new C0832hx(this, i, str, idVar, new C0831hw(this, str, idVar), bArr, map);
        f3395a.mo2297a(hxVar);
        return idVar;
    }

    /* renamed from: a */
    public final <T> C0865jc<T> mo2863a(String str, C0833hy<T> hyVar) {
        C0839id idVar = new C0839id(this, null);
        f3395a.mo2297a(new C0834hz(str, hyVar, idVar));
        return idVar;
    }

    /* renamed from: a */
    public final C0865jc<String> mo2864a(String str, Map<String, String> map) {
        return mo2862a(0, str, map, null);
    }
}
