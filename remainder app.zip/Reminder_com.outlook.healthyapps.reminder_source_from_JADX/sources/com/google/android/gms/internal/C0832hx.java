package com.google.android.gms.internal;

import java.util.Map;

/* renamed from: com.google.android.gms.internal.hx */
final class C0832hx extends C0927lk {

    /* renamed from: a */
    private /* synthetic */ byte[] f3400a;

    /* renamed from: b */
    private /* synthetic */ Map f3401b;

    C0832hx(C0829hu huVar, int i, String str, ane ane, amd amd, byte[] bArr, Map map) {
        this.f3400a = bArr;
        this.f3401b = map;
        super(i, str, ane, amd);
    }

    /* renamed from: a */
    public final byte[] mo2243a() {
        byte[] bArr = this.f3400a;
        return bArr == null ? super.mo2243a() : bArr;
    }

    /* renamed from: b */
    public final Map<String, String> mo2244b() {
        Map<String, String> map = this.f3401b;
        return map == null ? super.mo2244b() : map;
    }
}
