package com.google.android.gms.internal;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;

/* renamed from: com.google.android.gms.internal.hz */
final class C0834hz<T> extends aha<InputStream> {
    /* access modifiers changed from: private */

    /* renamed from: a */
    public final C0833hy<T> f3402a;
    /* access modifiers changed from: private */

    /* renamed from: b */
    public final ane<T> f3403b;

    public C0834hz(String str, C0833hy<T> hyVar, ane<T> ane) {
        super(0, str, new C0836ia(ane, hyVar));
        this.f3402a = hyVar;
        this.f3403b = ane;
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public final alc<InputStream> mo2239a(aey aey) {
        return alc.m3300a(new ByteArrayInputStream(aey.f2092a), C0922lf.m5037a(aey));
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public final /* synthetic */ void mo2241a(Object obj) {
        C0865jc a = C0790gi.m4480a((ExecutorService) C0790gi.f3317a, (Callable<T>) new C0837ib<T>(this, (InputStream) obj));
        a.mo2892a(new C0838ic(this, a), C0868jf.f3466a);
    }
}
