package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.C0354ax;

/* renamed from: com.google.android.gms.internal.ic */
final class C0838ic implements Runnable {

    /* renamed from: a */
    private /* synthetic */ C0865jc f3410a;

    /* renamed from: b */
    private /* synthetic */ C0834hz f3411b;

    C0838ic(C0834hz hzVar, C0865jc jcVar) {
        this.f3411b = hzVar;
        this.f3410a = jcVar;
    }

    public final void run() {
        try {
            this.f3411b.f3403b.mo2421a(this.f3410a.get());
        } catch (Exception e) {
            C0759fe.m4730b("Error occured while dispatching http response in getter.", e);
            C0354ax.m1542i().mo2742a((Throwable) e, "HttpGetter.deliverResponse.1");
        }
    }
}
