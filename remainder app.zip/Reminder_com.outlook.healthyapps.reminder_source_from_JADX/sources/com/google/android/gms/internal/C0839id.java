package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.id */
final class C0839id<T> extends C0871ji<T> implements ane<T> {
    private C0839id(C0829hu huVar) {
    }

    /* synthetic */ C0839id(C0829hu huVar, C0830hv hvVar) {
        this(huVar);
    }

    /* renamed from: a */
    public final void mo2421a(T t) {
        super.mo2904b(t);
    }
}
