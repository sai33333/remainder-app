package com.google.android.gms.internal;

@arm
/* renamed from: com.google.android.gms.internal.ii */
public final class C0844ii<T> {

    /* renamed from: a */
    private T f3423a;

    /* renamed from: a */
    public final T mo2873a() {
        return this.f3423a;
    }

    /* renamed from: a */
    public final void mo2874a(T t) {
        this.f3423a = t;
    }
}
