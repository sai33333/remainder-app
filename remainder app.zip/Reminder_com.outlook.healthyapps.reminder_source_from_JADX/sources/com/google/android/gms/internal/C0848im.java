package com.google.android.gms.internal;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import android.webkit.WebSettings;
import java.util.concurrent.Callable;

/* renamed from: com.google.android.gms.internal.im */
final class C0848im implements Callable<String> {

    /* renamed from: a */
    private /* synthetic */ Context f3427a;

    /* renamed from: b */
    private /* synthetic */ Context f3428b;

    C0848im(C0847il ilVar, Context context, Context context2) {
        this.f3427a = context;
        this.f3428b = context2;
    }

    public final /* synthetic */ Object call() {
        SharedPreferences sharedPreferences;
        boolean z = false;
        if (this.f3427a != null) {
            C0759fe.m4411a("Attempting to read user agent from Google Play Services.");
            sharedPreferences = this.f3427a.getSharedPreferences("admob_user_agent", 0);
        } else {
            C0759fe.m4411a("Attempting to read user agent from local cache.");
            sharedPreferences = this.f3428b.getSharedPreferences("admob_user_agent", 0);
            z = true;
        }
        String string = sharedPreferences.getString("user_agent", "");
        if (TextUtils.isEmpty(string)) {
            C0759fe.m4411a("Reading user agent from WebSettings");
            string = WebSettings.getDefaultUserAgent(this.f3428b);
            if (z) {
                sharedPreferences.edit().putString("user_agent", string).apply();
                C0759fe.m4411a("Persisting user agent.");
            }
        }
        return string;
    }
}
