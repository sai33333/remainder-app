package com.google.android.gms.internal;

import android.app.Activity;
import android.view.View;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.view.ViewTreeObserver.OnScrollChangedListener;
import com.google.android.gms.ads.internal.C0354ax;

@arm
/* renamed from: com.google.android.gms.internal.io */
public final class C0850io {

    /* renamed from: a */
    private final View f3432a;

    /* renamed from: b */
    private Activity f3433b;

    /* renamed from: c */
    private boolean f3434c;

    /* renamed from: d */
    private boolean f3435d;

    /* renamed from: e */
    private boolean f3436e;

    /* renamed from: f */
    private OnGlobalLayoutListener f3437f;

    /* renamed from: g */
    private OnScrollChangedListener f3438g;

    public C0850io(Activity activity, View view, OnGlobalLayoutListener onGlobalLayoutListener, OnScrollChangedListener onScrollChangedListener) {
        this.f3433b = activity;
        this.f3432a = view;
        this.f3437f = onGlobalLayoutListener;
        this.f3438g = onScrollChangedListener;
    }

    /* renamed from: e */
    private final void m4695e() {
        if (!this.f3434c) {
            if (this.f3437f != null) {
                if (this.f3433b != null) {
                    C0354ax.m1538e();
                    C0796go.m4499a(this.f3433b, this.f3437f);
                }
                C0354ax.m1531C();
                C0880jr.m4763a(this.f3432a, this.f3437f);
            }
            if (this.f3438g != null) {
                if (this.f3433b != null) {
                    C0354ax.m1538e();
                    C0796go.m4500a(this.f3433b, this.f3438g);
                }
                C0354ax.m1531C();
                C0880jr.m4764a(this.f3432a, this.f3438g);
            }
            this.f3434c = true;
        }
    }

    /* renamed from: f */
    private final void m4696f() {
        Activity activity = this.f3433b;
        if (activity != null && this.f3434c) {
            if (!(this.f3437f == null || activity == null)) {
                C0354ax.m1540g().mo2817a(this.f3433b, this.f3437f);
            }
            if (!(this.f3438g == null || this.f3433b == null)) {
                C0354ax.m1538e();
                C0796go.m4519b(this.f3433b, this.f3438g);
            }
            this.f3434c = false;
        }
    }

    /* renamed from: a */
    public final void mo2878a() {
        this.f3436e = true;
        if (this.f3435d) {
            m4695e();
        }
    }

    /* renamed from: a */
    public final void mo2879a(Activity activity) {
        this.f3433b = activity;
    }

    /* renamed from: b */
    public final void mo2880b() {
        this.f3436e = false;
        m4696f();
    }

    /* renamed from: c */
    public final void mo2881c() {
        this.f3435d = true;
        if (this.f3436e) {
            m4695e();
        }
    }

    /* renamed from: d */
    public final void mo2882d() {
        this.f3435d = false;
        m4696f();
    }
}
