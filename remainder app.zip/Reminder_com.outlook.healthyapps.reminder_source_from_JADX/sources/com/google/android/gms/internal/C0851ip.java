package com.google.android.gms.internal;

import android.annotation.TargetApi;
import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri.Builder;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings.Secure;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Display;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.TextView;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.C0291b;
import com.google.android.gms.ads.C0326g;
import com.google.android.gms.ads.p013a.C0289d;
import com.google.android.gms.ads.p013a.C0290e;
import com.google.android.gms.ads.p016d.C0323b;
import com.google.android.gms.common.C0528i;
import com.google.android.gms.common.util.C0580h;
import com.google.android.gms.dynamite.DynamiteModule;
import com.google.android.gms.dynamite.descriptors.com.google.android.gms.ads.dynamite.ModuleDescriptor;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Locale;
import java.util.StringTokenizer;

@arm
/* renamed from: com.google.android.gms.internal.ip */
public final class C0851ip {

    /* renamed from: a */
    public static final Handler f3439a = new Handler(Looper.getMainLooper());

    /* renamed from: b */
    private static final String f3440b = AdView.class.getName();

    /* renamed from: c */
    private static final String f3441c = C0326g.class.getName();

    /* renamed from: d */
    private static final String f3442d = C0289d.class.getName();

    /* renamed from: e */
    private static final String f3443e = C0290e.class.getName();

    /* renamed from: f */
    private static final String f3444f = C0323b.class.getName();

    /* renamed from: g */
    private static final String f3445g = C0291b.class.getName();

    /* renamed from: a */
    public static int m4702a(Context context, int i) {
        return m4703a(context.getResources().getDisplayMetrics(), i);
    }

    /* renamed from: a */
    public static int m4703a(DisplayMetrics displayMetrics, int i) {
        return (int) TypedValue.applyDimension(1, (float) i, displayMetrics);
    }

    /* renamed from: a */
    public static String m4704a(Context context) {
        ContentResolver contentResolver = context.getContentResolver();
        String string = contentResolver == null ? null : Secure.getString(contentResolver, "android_id");
        if (string == null || m4710a()) {
            string = "emulator";
        }
        return m4705a(string);
    }

    /* renamed from: a */
    public static String m4705a(String str) {
        int i = 0;
        while (i < 2) {
            try {
                MessageDigest instance = MessageDigest.getInstance("MD5");
                instance.update(str.getBytes());
                return String.format(Locale.US, "%032X", new Object[]{new BigInteger(1, instance.digest())});
            } catch (NoSuchAlgorithmException unused) {
                i++;
            } catch (ArithmeticException unused2) {
                return null;
            }
        }
        return null;
    }

    /* renamed from: a */
    public static String m4706a(StackTraceElement[] stackTraceElementArr, String str) {
        int i;
        String str2;
        int i2 = 0;
        while (true) {
            i = i2 + 1;
            if (i >= stackTraceElementArr.length) {
                str2 = null;
                break;
            }
            StackTraceElement stackTraceElement = stackTraceElementArr[i2];
            String className = stackTraceElement.getClassName();
            if (!"loadAd".equalsIgnoreCase(stackTraceElement.getMethodName()) || (!f3440b.equalsIgnoreCase(className) && !f3441c.equalsIgnoreCase(className) && !f3442d.equalsIgnoreCase(className) && !f3443e.equalsIgnoreCase(className) && !f3444f.equalsIgnoreCase(className) && !f3445g.equalsIgnoreCase(className))) {
                i2 = i;
            }
        }
        str2 = stackTraceElementArr[i].getClassName();
        if (str != null) {
            StringTokenizer stringTokenizer = new StringTokenizer(str, ".");
            StringBuilder sb = new StringBuilder();
            int i3 = 2;
            if (stringTokenizer.hasMoreElements()) {
                sb.append(stringTokenizer.nextToken());
                while (true) {
                    int i4 = i3 - 1;
                    if (i3 <= 0 || !stringTokenizer.hasMoreElements()) {
                        str = sb.toString();
                    } else {
                        sb.append(".");
                        sb.append(stringTokenizer.nextToken());
                        i3 = i4;
                    }
                }
                str = sb.toString();
            }
            if (str2 == null || str2.contains(str)) {
                return null;
            }
            return str2;
        }
        return null;
    }

    /* renamed from: a */
    public static void m4707a(Context context, String str, String str2, Bundle bundle, boolean z, C0854is isVar) {
        if (z) {
            Context applicationContext = context.getApplicationContext();
            if (applicationContext == null) {
                applicationContext = context;
            }
            bundle.putString("os", VERSION.RELEASE);
            bundle.putString("api", String.valueOf(VERSION.SDK_INT));
            bundle.putString("appid", applicationContext.getPackageName());
            if (str == null) {
                C0528i.m2089a();
                int b = C0528i.m2090b(context);
                StringBuilder sb = new StringBuilder(23);
                sb.append(b);
                sb.append(".11400000");
                str = sb.toString();
            }
            bundle.putString("js", str);
        }
        Builder appendQueryParameter = new Builder().scheme("https").path("//pagead2.googlesyndication.com/pagead/gen_204").appendQueryParameter("id", str2);
        for (String str3 : bundle.keySet()) {
            appendQueryParameter.appendQueryParameter(str3, bundle.getString(str3));
        }
        isVar.mo2809a(appendQueryParameter.toString());
    }

    /* renamed from: a */
    private final void m4708a(ViewGroup viewGroup, aay aay, String str, int i, int i2) {
        if (viewGroup.getChildCount() == 0) {
            Context context = viewGroup.getContext();
            TextView textView = new TextView(context);
            textView.setGravity(17);
            textView.setText(str);
            textView.setTextColor(i);
            textView.setBackgroundColor(i2);
            FrameLayout frameLayout = new FrameLayout(context);
            frameLayout.setBackgroundColor(i);
            int a = m4702a(context, 3);
            frameLayout.addView(textView, new LayoutParams(aay.f1655f - a, aay.f1652c - a, 17));
            viewGroup.addView(frameLayout, aay.f1655f, aay.f1652c);
        }
    }

    /* renamed from: a */
    public static void m4709a(boolean z, HttpURLConnection httpURLConnection, String str) {
        httpURLConnection.setConnectTimeout(60000);
        httpURLConnection.setInstanceFollowRedirects(true);
        httpURLConnection.setReadTimeout(60000);
        if (str != null) {
            httpURLConnection.setRequestProperty("User-Agent", str);
        }
        httpURLConnection.setUseCaches(false);
    }

    /* renamed from: a */
    public static boolean m4710a() {
        return Build.DEVICE.startsWith("generic");
    }

    /* renamed from: b */
    public static int m4711b(Context context, int i) {
        Display defaultDisplay = ((WindowManager) context.getSystemService("window")).getDefaultDisplay();
        DisplayMetrics displayMetrics = new DisplayMetrics();
        defaultDisplay.getMetrics(displayMetrics);
        return m4712b(displayMetrics, i);
    }

    /* renamed from: b */
    public static int m4712b(DisplayMetrics displayMetrics, int i) {
        return Math.round(((float) i) / displayMetrics.density);
    }

    /* renamed from: b */
    public static String m4713b(Context context) {
        ContentResolver contentResolver = context.getContentResolver();
        if (contentResolver == null) {
            return null;
        }
        return Secure.getString(contentResolver, "android_id");
    }

    /* renamed from: b */
    public static boolean m4714b() {
        return Looper.myLooper() == Looper.getMainLooper();
    }

    /* renamed from: c */
    public static boolean m4715c(Context context) {
        return C0528i.m2089a().mo1796a(context) == 0;
    }

    /* renamed from: d */
    public static int m4716d(Context context) {
        return DynamiteModule.m2266b(context, ModuleDescriptor.MODULE_ID);
    }

    /* renamed from: e */
    public static int m4717e(Context context) {
        return DynamiteModule.m2259a(context, ModuleDescriptor.MODULE_ID);
    }

    /* renamed from: f */
    public static boolean m4718f(Context context) {
        int a = C0528i.m2089a().mo1796a(context);
        return a == 0 || a == 2;
    }

    /* renamed from: g */
    public static boolean m4719g(Context context) {
        if (context.getResources().getConfiguration().orientation != 2) {
            return false;
        }
        DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        return ((int) (((float) displayMetrics.heightPixels) / displayMetrics.density)) < 600;
    }

    @TargetApi(17)
    /* renamed from: h */
    public static boolean m4720h(Context context) {
        int i;
        int i2;
        DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        Display defaultDisplay = ((WindowManager) context.getSystemService("window")).getDefaultDisplay();
        if (C0580h.m2251b()) {
            defaultDisplay.getRealMetrics(displayMetrics);
            i2 = displayMetrics.heightPixels;
            i = displayMetrics.widthPixels;
        } else {
            try {
                i2 = ((Integer) Display.class.getMethod("getRawHeight", new Class[0]).invoke(defaultDisplay, new Object[0])).intValue();
                i = ((Integer) Display.class.getMethod("getRawWidth", new Class[0]).invoke(defaultDisplay, new Object[0])).intValue();
            } catch (Exception unused) {
            }
        }
        defaultDisplay.getMetrics(displayMetrics);
        int i3 = displayMetrics.heightPixels;
        int i4 = displayMetrics.widthPixels;
        if (i3 == i2 && i4 == i) {
            return true;
        }
        return false;
    }

    /* renamed from: i */
    public static int m4721i(Context context) {
        int identifier = context.getResources().getIdentifier("navigation_bar_width", "dimen", "android");
        if (identifier > 0) {
            return context.getResources().getDimensionPixelSize(identifier);
        }
        return 0;
    }

    /* renamed from: a */
    public final void mo2883a(Context context, String str, String str2, Bundle bundle, boolean z) {
        m4707a(context, null, str2, bundle, true, new C0852iq(this));
    }

    /* renamed from: a */
    public final void mo2884a(ViewGroup viewGroup, aay aay, String str) {
        m4708a(viewGroup, aay, str, -16777216, -1);
    }

    /* renamed from: a */
    public final void mo2885a(ViewGroup viewGroup, aay aay, String str, String str2) {
        C0855it.m4734e(str2);
        m4708a(viewGroup, aay, str, -65536, -16777216);
    }
}
