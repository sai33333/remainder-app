package com.google.android.gms.internal;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

@arm
/* renamed from: com.google.android.gms.internal.iu */
public final class C0856iu implements C0854is {

    /* renamed from: a */
    private final String f3447a;

    public C0856iu() {
        this(null);
    }

    public C0856iu(String str) {
        this.f3447a = str;
    }

    /* renamed from: a */
    public final void mo2809a(String str) {
        String message;
        StringBuilder sb;
        String str2;
        HttpURLConnection httpURLConnection;
        String str3 = "Pinging URL: ";
        try {
            String valueOf = String.valueOf(str);
            C0855it.m4729b(valueOf.length() != 0 ? str3.concat(valueOf) : new String(str3));
            httpURLConnection = (HttpURLConnection) new URL(str).openConnection();
            abj.m2380a();
            C0851ip.m4709a(true, httpURLConnection, this.f3447a);
            int responseCode = httpURLConnection.getResponseCode();
            if (responseCode < 200 || responseCode >= 300) {
                StringBuilder sb2 = new StringBuilder(String.valueOf(str).length() + 65);
                sb2.append("Received non-success response code ");
                sb2.append(responseCode);
                sb2.append(" from pinging URL: ");
                sb2.append(str);
                C0855it.m4734e(sb2.toString());
            }
            httpURLConnection.disconnect();
        } catch (IndexOutOfBoundsException e) {
            message = e.getMessage();
            sb = new StringBuilder(String.valueOf(str).length() + 32 + String.valueOf(message).length());
            str2 = "Error while parsing ping URL: ";
            sb.append(str2);
            sb.append(str);
            sb.append(". ");
            sb.append(message);
            C0855it.m4734e(sb.toString());
        } catch (IOException e2) {
            message = e2.getMessage();
            sb = new StringBuilder(String.valueOf(str).length() + 27 + String.valueOf(message).length());
            str2 = "Error while pinging URL: ";
            sb.append(str2);
            sb.append(str);
            sb.append(". ");
            sb.append(message);
            C0855it.m4734e(sb.toString());
        } catch (RuntimeException e3) {
            message = e3.getMessage();
            sb = new StringBuilder(String.valueOf(str).length() + 27 + String.valueOf(message).length());
            str2 = "Error while pinging URL: ";
            sb.append(str2);
            sb.append(str);
            sb.append(". ");
            sb.append(message);
            C0855it.m4734e(sb.toString());
        } catch (Throwable th) {
            httpURLConnection.disconnect();
            throw th;
        }
    }
}
