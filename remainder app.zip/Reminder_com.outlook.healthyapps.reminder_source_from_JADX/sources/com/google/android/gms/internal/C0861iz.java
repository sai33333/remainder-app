package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.iz */
final /* synthetic */ class C0861iz implements Runnable {

    /* renamed from: a */
    private final C0871ji f3453a;

    /* renamed from: b */
    private final C0859ix f3454b;

    /* renamed from: c */
    private final C0865jc f3455c;

    C0861iz(C0871ji jiVar, C0859ix ixVar, C0865jc jcVar) {
        this.f3453a = jiVar;
        this.f3454b = ixVar;
        this.f3455c = jcVar;
    }

    /* JADX WARNING: type inference failed for: r2v1, types: [java.lang.Throwable] */
    /* JADX WARNING: type inference failed for: r1v3, types: [java.lang.Throwable] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void run() {
        /*
            r3 = this;
            com.google.android.gms.internal.ji r0 = r3.f3453a
            com.google.android.gms.internal.ix r1 = r3.f3454b
            com.google.android.gms.internal.jc r2 = r3.f3455c
            java.lang.Object r2 = r2.get()     // Catch:{ CancellationException -> 0x002b, ExecutionException -> 0x001e, InterruptedException -> 0x0012 }
            java.lang.Object r1 = r1.mo2540a(r2)     // Catch:{ CancellationException -> 0x002b, ExecutionException -> 0x001e, InterruptedException -> 0x0012 }
            r0.mo2904b(r1)     // Catch:{ CancellationException -> 0x002b, ExecutionException -> 0x001e, InterruptedException -> 0x0012 }
            return
        L_0x0012:
            r1 = move-exception
            java.lang.Thread r2 = java.lang.Thread.currentThread()
            r2.interrupt()
            r0.mo2903a(r1)
            return
        L_0x001e:
            r1 = move-exception
            java.lang.Throwable r2 = r1.getCause()
            if (r2 != 0) goto L_0x0026
            goto L_0x0027
        L_0x0026:
            r1 = r2
        L_0x0027:
            r0.mo2903a(r1)
            return
        L_0x002b:
            r1 = 1
            r0.cancel(r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.C0861iz.run():void");
    }
}
