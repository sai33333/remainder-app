package com.google.android.gms.internal;

import java.util.concurrent.Future;

/* renamed from: com.google.android.gms.internal.ja */
final /* synthetic */ class C0863ja implements Runnable {

    /* renamed from: a */
    private final C0865jc f3457a;

    /* renamed from: b */
    private final Future f3458b;

    C0863ja(C0865jc jcVar, Future future) {
        this.f3457a = jcVar;
        this.f3458b = future;
    }

    public final void run() {
        C0865jc jcVar = this.f3457a;
        Future future = this.f3458b;
        if (jcVar.isCancelled()) {
            future.cancel(true);
        }
    }
}
