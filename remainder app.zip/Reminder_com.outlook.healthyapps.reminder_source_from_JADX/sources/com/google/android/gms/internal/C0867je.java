package com.google.android.gms.internal;

import java.util.concurrent.Executor;

/* renamed from: com.google.android.gms.internal.je */
final /* synthetic */ class C0867je implements Runnable {

    /* renamed from: a */
    private final Executor f3464a;

    /* renamed from: b */
    private final Runnable f3465b;

    C0867je(Executor executor, Runnable runnable) {
        this.f3464a = executor;
        this.f3465b = runnable;
    }

    public final void run() {
        this.f3464a.execute(this.f3465b);
    }
}
