package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.jl */
public interface C0874jl<T> {
    /* renamed from: a */
    void mo1494a(C0877jo<T> joVar, C0875jm jmVar);

    /* renamed from: a */
    void mo1495a(T t);
}
