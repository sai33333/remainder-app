package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.jn */
public final class C0876jn implements C0875jm {
    /* renamed from: a */
    public final void mo1486a() {
    }
}
