package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.jo */
public interface C0877jo<T> {
    /* renamed from: a */
    void mo1464a(T t);
}
