package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.jq */
final class C0879jq {

    /* renamed from: a */
    public final C0877jo<T> f3480a;

    /* renamed from: b */
    public final C0875jm f3481b;

    public C0879jq(C0878jp jpVar, C0877jo<T> joVar, C0875jm jmVar) {
        this.f3480a = joVar;
        this.f3481b = jmVar;
    }
}
