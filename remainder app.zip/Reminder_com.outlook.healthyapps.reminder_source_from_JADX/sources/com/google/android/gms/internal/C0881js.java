package com.google.android.gms.internal;

import android.view.View;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import com.google.android.gms.ads.internal.C0354ax;
import java.lang.ref.WeakReference;

@arm
/* renamed from: com.google.android.gms.internal.js */
final class C0881js extends C0883ju implements OnGlobalLayoutListener {

    /* renamed from: a */
    private final WeakReference<OnGlobalLayoutListener> f3482a;

    public C0881js(View view, OnGlobalLayoutListener onGlobalLayoutListener) {
        super(view);
        this.f3482a = new WeakReference<>(onGlobalLayoutListener);
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public final void mo2911a(ViewTreeObserver viewTreeObserver) {
        viewTreeObserver.addOnGlobalLayoutListener(this);
    }

    /* access modifiers changed from: protected */
    /* renamed from: b */
    public final void mo2912b(ViewTreeObserver viewTreeObserver) {
        C0354ax.m1540g().mo2819a(viewTreeObserver, (OnGlobalLayoutListener) this);
    }

    public final void onGlobalLayout() {
        OnGlobalLayoutListener onGlobalLayoutListener = (OnGlobalLayoutListener) this.f3482a.get();
        if (onGlobalLayoutListener != null) {
            onGlobalLayoutListener.onGlobalLayout();
        } else {
            mo2916b();
        }
    }
}
