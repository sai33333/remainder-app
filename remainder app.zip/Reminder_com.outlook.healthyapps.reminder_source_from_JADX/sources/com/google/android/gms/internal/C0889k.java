package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.ads.internal.C0354ax;

@arm
/* renamed from: com.google.android.gms.internal.k */
public final class C0889k extends C0808h {

    /* renamed from: a */
    private final Context f3525a;

    public C0889k(Context context, C0874jl<C0970n> jlVar, C0754f fVar) {
        super(jlVar, fVar);
        this.f3525a = context;
    }

    /* renamed from: a */
    public final void mo2834a() {
    }

    /* renamed from: b */
    public final C1246v mo2836b() {
        return C0642aw.m4001a(this.f3525a, new ady((String) C0354ax.m1551r().mo2079a(ael.f1828a)), C0641av.m4000a());
    }
}
