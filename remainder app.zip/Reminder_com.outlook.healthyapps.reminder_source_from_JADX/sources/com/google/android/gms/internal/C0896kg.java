package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.ads.internal.C0347aq;
import com.google.android.gms.ads.internal.C0377bt;

@arm
/* renamed from: com.google.android.gms.internal.kg */
public final class C0896kg {
    /* renamed from: a */
    public final C0885jw mo3030a(Context context, aay aay, boolean z, boolean z2, C0992nv nvVar, C0857iv ivVar, aez aez, C0347aq aqVar, C0377bt btVar, aac aac) {
        try {
            C0897kh khVar = new C0897kh(this, context, aay, z, z2, nvVar, ivVar, aez, aqVar, btVar, aac);
            return (C0885jw) C0846ik.m4691b(khVar);
        } catch (Throwable th) {
            throw new C0898ki(this, "Webview initialization failed.", th);
        }
    }
}
