package com.google.android.gms.internal;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import com.google.android.gms.ads.internal.C0377bt;
import com.google.android.gms.ads.internal.overlay.C0440ah;
import java.util.Map;
import org.json.JSONObject;

@arm
/* renamed from: com.google.android.gms.internal.kj */
final class C0899kj extends FrameLayout implements C0885jw {

    /* renamed from: a */
    private static final int f3539a = Color.argb(0, 0, 0, 0);

    /* renamed from: b */
    private final C0885jw f3540b;

    /* renamed from: c */
    private final C0884jv f3541c;

    public C0899kj(C0885jw jwVar) {
        super(jwVar.getContext());
        this.f3540b = jwVar;
        this.f3541c = new C0884jv(jwVar.mo2951g(), this, this);
        C0886jx m = this.f3540b.mo2967m();
        if (m != null) {
            m.f3495a = this;
        }
        C0885jw jwVar2 = this.f3540b;
        if (jwVar2 != null) {
            addView((View) jwVar2);
            return;
        }
        throw null;
    }

    /* renamed from: A */
    public final C0905kp mo2922A() {
        return this.f3540b.mo2922A();
    }

    /* renamed from: B */
    public final boolean mo2923B() {
        return this.f3540b.mo2923B();
    }

    /* renamed from: C */
    public final void mo2924C() {
        this.f3540b.mo2924C();
    }

    /* renamed from: D */
    public final void mo2925D() {
        this.f3540b.mo2925D();
    }

    /* renamed from: E */
    public final OnClickListener mo2926E() {
        return this.f3540b.mo2926E();
    }

    /* renamed from: F */
    public final afu mo2927F() {
        return this.f3540b.mo2927F();
    }

    /* renamed from: G */
    public final void mo2928G() {
        setBackgroundColor(f3539a);
        this.f3540b.setBackgroundColor(f3539a);
    }

    /* renamed from: a */
    public final WebView mo2929a() {
        return this.f3540b.mo2929a();
    }

    /* renamed from: a */
    public final void mo2930a(int i) {
        this.f3540b.mo2930a(i);
    }

    /* renamed from: a */
    public final void mo2931a(Context context) {
        this.f3540b.mo2931a(context);
    }

    /* renamed from: a */
    public final void mo2932a(Context context, aay aay, aez aez) {
        this.f3541c.mo2921c();
        this.f3540b.mo2932a(context, aay, aez);
    }

    /* renamed from: a */
    public final void mo2933a(C0440ah ahVar) {
        this.f3540b.mo2933a(ahVar);
    }

    /* renamed from: a */
    public final void mo2934a(aay aay) {
        this.f3540b.mo2934a(aay);
    }

    /* renamed from: a */
    public final void mo2935a(afu afu) {
        this.f3540b.mo2935a(afu);
    }

    /* renamed from: a */
    public final void mo2936a(C0905kp kpVar) {
        this.f3540b.mo2936a(kpVar);
    }

    /* renamed from: a */
    public final void mo2681a(C1332ya yaVar) {
        this.f3540b.mo2681a(yaVar);
    }

    /* renamed from: a */
    public final void mo2937a(String str) {
        this.f3540b.mo2937a(str);
    }

    /* renamed from: a */
    public final void mo1498a(String str, ajh ajh) {
        this.f3540b.mo1498a(str, ajh);
    }

    /* renamed from: a */
    public final void mo1499a(String str, String str2) {
        this.f3540b.mo1499a(str, str2);
    }

    /* renamed from: a */
    public final void mo2938a(String str, Map<String, ?> map) {
        this.f3540b.mo2938a(str, map);
    }

    /* renamed from: a */
    public final void mo1500a(String str, JSONObject jSONObject) {
        this.f3540b.mo1500a(str, jSONObject);
    }

    /* renamed from: a */
    public final void mo2939a(boolean z) {
        this.f3540b.mo2939a(z);
    }

    /* renamed from: b */
    public final void mo2940b() {
        this.f3540b.mo2940b();
    }

    /* renamed from: b */
    public final void mo2941b(int i) {
        this.f3540b.mo2941b(i);
    }

    /* renamed from: b */
    public final void mo2942b(C0440ah ahVar) {
        this.f3540b.mo2942b(ahVar);
    }

    /* renamed from: b */
    public final void mo2943b(String str) {
        this.f3540b.mo2943b(str);
    }

    /* renamed from: b */
    public final void mo1501b(String str, ajh ajh) {
        this.f3540b.mo1501b(str, ajh);
    }

    /* renamed from: b */
    public final void mo1502b(String str, JSONObject jSONObject) {
        this.f3540b.mo1502b(str, jSONObject);
    }

    /* renamed from: b */
    public final void mo2944b(boolean z) {
        this.f3540b.mo2944b(z);
    }

    /* renamed from: c */
    public final void mo2945c() {
        this.f3540b.mo2945c();
    }

    /* renamed from: c */
    public final void mo2946c(boolean z) {
        this.f3540b.mo2946c(z);
    }

    /* renamed from: d */
    public final void mo2947d() {
        this.f3540b.mo2947d();
    }

    /* renamed from: d */
    public final void mo2948d(boolean z) {
        this.f3540b.mo2948d(z);
    }

    public final void destroy() {
        this.f3540b.destroy();
    }

    /* renamed from: e */
    public final Activity mo2950e() {
        return this.f3540b.mo2950e();
    }

    /* renamed from: g */
    public final Context mo2951g() {
        return this.f3540b.mo2951g();
    }

    /* renamed from: h_ */
    public final void mo1375h_() {
        this.f3540b.mo1375h_();
    }

    /* renamed from: i */
    public final C0377bt mo2960i() {
        return this.f3540b.mo2960i();
    }

    /* renamed from: i_ */
    public final void mo1376i_() {
        this.f3540b.mo1376i_();
    }

    /* renamed from: j */
    public final C0440ah mo2961j() {
        return this.f3540b.mo2961j();
    }

    /* renamed from: k */
    public final C0440ah mo2962k() {
        return this.f3540b.mo2962k();
    }

    /* renamed from: l */
    public final aay mo2963l() {
        return this.f3540b.mo2963l();
    }

    public final void loadData(String str, String str2, String str3) {
        this.f3540b.loadData(str, str2, str3);
    }

    public final void loadDataWithBaseURL(String str, String str2, String str3, String str4, String str5) {
        this.f3540b.loadDataWithBaseURL(str, str2, str3, str4, str5);
    }

    public final void loadUrl(String str) {
        this.f3540b.loadUrl(str);
    }

    /* renamed from: m */
    public final C0886jx mo2967m() {
        return this.f3540b.mo2967m();
    }

    /* renamed from: n */
    public final boolean mo2969n() {
        return this.f3540b.mo2969n();
    }

    /* renamed from: o */
    public final C0992nv mo2970o() {
        return this.f3540b.mo2970o();
    }

    public final void onPause() {
        this.f3541c.mo2920b();
        this.f3540b.onPause();
    }

    public final void onResume() {
        this.f3540b.onResume();
    }

    /* renamed from: p */
    public final C0857iv mo2973p() {
        return this.f3540b.mo2973p();
    }

    /* renamed from: q */
    public final boolean mo2974q() {
        return this.f3540b.mo2974q();
    }

    /* renamed from: r */
    public final int mo2975r() {
        return this.f3540b.mo2975r();
    }

    /* renamed from: s */
    public final boolean mo2976s() {
        return this.f3540b.mo2976s();
    }

    public final void setOnClickListener(OnClickListener onClickListener) {
        this.f3540b.setOnClickListener(onClickListener);
    }

    public final void setOnTouchListener(OnTouchListener onTouchListener) {
        this.f3540b.setOnTouchListener(onTouchListener);
    }

    public final void setWebChromeClient(WebChromeClient webChromeClient) {
        this.f3540b.setWebChromeClient(webChromeClient);
    }

    public final void setWebViewClient(WebViewClient webViewClient) {
        this.f3540b.setWebViewClient(webViewClient);
    }

    public final void stopLoading() {
        this.f3540b.stopLoading();
    }

    /* renamed from: t */
    public final void mo2983t() {
        this.f3541c.mo2921c();
        this.f3540b.mo2983t();
    }

    /* renamed from: u */
    public final boolean mo2984u() {
        return this.f3540b.mo2984u();
    }

    /* renamed from: v */
    public final boolean mo2985v() {
        return this.f3540b.mo2985v();
    }

    /* renamed from: w */
    public final String mo2986w() {
        return this.f3540b.mo2986w();
    }

    /* renamed from: x */
    public final C0884jv mo2987x() {
        return this.f3541c;
    }

    /* renamed from: y */
    public final aew mo2988y() {
        return this.f3540b.mo2988y();
    }

    /* renamed from: z */
    public final aex mo2989z() {
        return this.f3540b.mo2989z();
    }
}
