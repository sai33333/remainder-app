package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.kn */
final class C0903kn implements Runnable {

    /* renamed from: a */
    private /* synthetic */ C0900kk f3582a;

    C0903kn(C0900kk kkVar) {
        this.f3582a = kkVar;
    }

    public final void run() {
        C0903kn.super.destroy();
    }
}
