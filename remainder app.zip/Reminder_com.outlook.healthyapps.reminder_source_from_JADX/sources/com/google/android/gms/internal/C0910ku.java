package com.google.android.gms.internal;

import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.webkit.JsResult;

/* renamed from: com.google.android.gms.internal.ku */
final class C0910ku implements OnCancelListener {

    /* renamed from: a */
    private /* synthetic */ JsResult f3607a;

    C0910ku(JsResult jsResult) {
        this.f3607a = jsResult;
    }

    public final void onCancel(DialogInterface dialogInterface) {
        this.f3607a.cancel();
    }
}
