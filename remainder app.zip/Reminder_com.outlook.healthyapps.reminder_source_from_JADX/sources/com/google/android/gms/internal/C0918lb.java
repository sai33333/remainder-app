package com.google.android.gms.internal;

import android.annotation.TargetApi;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;

@arm
@TargetApi(11)
/* renamed from: com.google.android.gms.internal.lb */
public final class C0918lb extends C0920ld {
    public C0918lb(C0885jw jwVar, boolean z) {
        super(jwVar, z);
    }

    public final WebResourceResponse shouldInterceptRequest(WebView webView, String str) {
        return mo3073a(webView, str, null);
    }
}
