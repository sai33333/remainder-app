package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.lp */
public final class C0932lp extends C1272vv<C0932lp> {

    /* renamed from: A */
    public Long f3640A;

    /* renamed from: B */
    public Long f3641B;

    /* renamed from: C */
    public String f3642C;

    /* renamed from: D */
    public String f3643D;

    /* renamed from: E */
    public Integer f3644E;

    /* renamed from: F */
    public Integer f3645F;

    /* renamed from: G */
    public Long f3646G;

    /* renamed from: H */
    public Long f3647H;

    /* renamed from: I */
    public Integer f3648I;

    /* renamed from: J */
    public C0933lq f3649J;

    /* renamed from: K */
    public C0933lq[] f3650K;

    /* renamed from: L */
    public C0934lr f3651L;

    /* renamed from: M */
    public String f3652M;

    /* renamed from: N */
    public Integer f3653N;

    /* renamed from: O */
    public Boolean f3654O;

    /* renamed from: P */
    public Long f3655P;

    /* renamed from: Q */
    public C0938lv f3656Q;

    /* renamed from: T */
    private Long f3657T;

    /* renamed from: U */
    private Long f3658U;

    /* renamed from: V */
    private Long f3659V;

    /* renamed from: W */
    private Long f3660W;

    /* renamed from: X */
    private Long f3661X;

    /* renamed from: Y */
    private Long f3662Y;

    /* renamed from: Z */
    private String f3663Z;

    /* renamed from: a */
    public String f3664a;

    /* renamed from: aa */
    private Long f3665aa;

    /* renamed from: ab */
    private Long f3666ab;

    /* renamed from: ac */
    private C0935ls f3667ac;

    /* renamed from: ad */
    private Long f3668ad;

    /* renamed from: ae */
    private Long f3669ae;

    /* renamed from: af */
    private Long f3670af;

    /* renamed from: ag */
    private Long f3671ag;

    /* renamed from: ah */
    private Long f3672ah;

    /* renamed from: ai */
    private String f3673ai;

    /* renamed from: b */
    public String f3674b;

    /* renamed from: c */
    public Long f3675c;

    /* renamed from: d */
    public Long f3676d;

    /* renamed from: e */
    public Long f3677e;

    /* renamed from: f */
    public Long f3678f;

    /* renamed from: g */
    public Long f3679g;

    /* renamed from: h */
    public Long f3680h;

    /* renamed from: i */
    public Long f3681i;

    /* renamed from: j */
    public Long f3682j;

    /* renamed from: k */
    public Long f3683k;

    /* renamed from: l */
    public Long f3684l;

    /* renamed from: m */
    public Long f3685m;

    /* renamed from: n */
    public String f3686n;

    /* renamed from: o */
    public String f3687o;

    /* renamed from: p */
    public Long f3688p;

    /* renamed from: q */
    public Long f3689q;

    /* renamed from: r */
    public Long f3690r;

    /* renamed from: s */
    public String f3691s;

    /* renamed from: t */
    public Long f3692t;

    /* renamed from: u */
    public Long f3693u;

    /* renamed from: v */
    public Long f3694v;

    /* renamed from: w */
    public Long f3695w;

    /* renamed from: x */
    public Long f3696x;

    /* renamed from: y */
    public Long f3697y;

    /* renamed from: z */
    public Long f3698z;

    public C0932lp() {
        this.f3664a = null;
        this.f3674b = null;
        this.f3675c = null;
        this.f3657T = null;
        this.f3676d = null;
        this.f3677e = null;
        this.f3658U = null;
        this.f3659V = null;
        this.f3660W = null;
        this.f3661X = null;
        this.f3662Y = null;
        this.f3678f = null;
        this.f3663Z = null;
        this.f3679g = null;
        this.f3680h = null;
        this.f3681i = null;
        this.f3682j = null;
        this.f3665aa = null;
        this.f3666ab = null;
        this.f3683k = null;
        this.f3684l = null;
        this.f3685m = null;
        this.f3686n = null;
        this.f3687o = null;
        this.f3688p = null;
        this.f3689q = null;
        this.f3690r = null;
        this.f3691s = null;
        this.f3692t = null;
        this.f3693u = null;
        this.f3694v = null;
        this.f3667ac = null;
        this.f3695w = null;
        this.f3696x = null;
        this.f3697y = null;
        this.f3698z = null;
        this.f3640A = null;
        this.f3641B = null;
        this.f3642C = null;
        this.f3643D = null;
        this.f3646G = null;
        this.f3647H = null;
        this.f3668ad = null;
        this.f3669ae = null;
        this.f3670af = null;
        this.f3649J = null;
        this.f3650K = C0933lq.m5060b();
        this.f3651L = null;
        this.f3671ag = null;
        this.f3672ah = null;
        this.f3652M = null;
        this.f3654O = null;
        this.f3673ai = null;
        this.f3655P = null;
        this.f3656Q = null;
        this.f4730S = -1;
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public final int mo1918a() {
        int a = super.mo1918a();
        String str = this.f3664a;
        if (str != null) {
            a += C1270vt.m6081b(1, str);
        }
        String str2 = this.f3674b;
        if (str2 != null) {
            a += C1270vt.m6081b(2, str2);
        }
        Long l = this.f3675c;
        if (l != null) {
            a += C1270vt.m6086c(3, l.longValue());
        }
        Long l2 = this.f3657T;
        if (l2 != null) {
            a += C1270vt.m6086c(4, l2.longValue());
        }
        Long l3 = this.f3676d;
        if (l3 != null) {
            a += C1270vt.m6086c(5, l3.longValue());
        }
        Long l4 = this.f3677e;
        if (l4 != null) {
            a += C1270vt.m6086c(6, l4.longValue());
        }
        Long l5 = this.f3658U;
        if (l5 != null) {
            a += C1270vt.m6086c(7, l5.longValue());
        }
        Long l6 = this.f3659V;
        if (l6 != null) {
            a += C1270vt.m6086c(8, l6.longValue());
        }
        Long l7 = this.f3660W;
        if (l7 != null) {
            a += C1270vt.m6086c(9, l7.longValue());
        }
        Long l8 = this.f3661X;
        if (l8 != null) {
            a += C1270vt.m6086c(10, l8.longValue());
        }
        Long l9 = this.f3662Y;
        if (l9 != null) {
            a += C1270vt.m6086c(11, l9.longValue());
        }
        Long l10 = this.f3678f;
        if (l10 != null) {
            a += C1270vt.m6086c(12, l10.longValue());
        }
        String str3 = this.f3663Z;
        if (str3 != null) {
            a += C1270vt.m6081b(13, str3);
        }
        Long l11 = this.f3679g;
        if (l11 != null) {
            a += C1270vt.m6086c(14, l11.longValue());
        }
        Long l12 = this.f3680h;
        if (l12 != null) {
            a += C1270vt.m6086c(15, l12.longValue());
        }
        Long l13 = this.f3681i;
        if (l13 != null) {
            a += C1270vt.m6086c(16, l13.longValue());
        }
        Long l14 = this.f3682j;
        if (l14 != null) {
            a += C1270vt.m6086c(17, l14.longValue());
        }
        Long l15 = this.f3665aa;
        if (l15 != null) {
            a += C1270vt.m6086c(18, l15.longValue());
        }
        Long l16 = this.f3666ab;
        if (l16 != null) {
            a += C1270vt.m6086c(19, l16.longValue());
        }
        Long l17 = this.f3683k;
        if (l17 != null) {
            a += C1270vt.m6086c(20, l17.longValue());
        }
        Long l18 = this.f3672ah;
        if (l18 != null) {
            a += C1270vt.m6086c(21, l18.longValue());
        }
        Long l19 = this.f3684l;
        if (l19 != null) {
            a += C1270vt.m6086c(22, l19.longValue());
        }
        Long l20 = this.f3685m;
        if (l20 != null) {
            a += C1270vt.m6086c(23, l20.longValue());
        }
        String str4 = this.f3652M;
        if (str4 != null) {
            a += C1270vt.m6081b(24, str4);
        }
        Long l21 = this.f3655P;
        if (l21 != null) {
            a += C1270vt.m6086c(25, l21.longValue());
        }
        Integer num = this.f3653N;
        if (num != null) {
            a += C1270vt.m6079b(26, num.intValue());
        }
        String str5 = this.f3686n;
        if (str5 != null) {
            a += C1270vt.m6081b(27, str5);
        }
        Boolean bool = this.f3654O;
        if (bool != null) {
            bool.booleanValue();
            a += C1270vt.m6078b(28) + 1;
        }
        String str6 = this.f3687o;
        if (str6 != null) {
            a += C1270vt.m6081b(29, str6);
        }
        String str7 = this.f3673ai;
        if (str7 != null) {
            a += C1270vt.m6081b(30, str7);
        }
        Long l22 = this.f3688p;
        if (l22 != null) {
            a += C1270vt.m6086c(31, l22.longValue());
        }
        Long l23 = this.f3689q;
        if (l23 != null) {
            a += C1270vt.m6086c(32, l23.longValue());
        }
        Long l24 = this.f3690r;
        if (l24 != null) {
            a += C1270vt.m6086c(33, l24.longValue());
        }
        String str8 = this.f3691s;
        if (str8 != null) {
            a += C1270vt.m6081b(34, str8);
        }
        Long l25 = this.f3692t;
        if (l25 != null) {
            a += C1270vt.m6086c(35, l25.longValue());
        }
        Long l26 = this.f3693u;
        if (l26 != null) {
            a += C1270vt.m6086c(36, l26.longValue());
        }
        Long l27 = this.f3694v;
        if (l27 != null) {
            a += C1270vt.m6086c(37, l27.longValue());
        }
        C0935ls lsVar = this.f3667ac;
        if (lsVar != null) {
            a += C1270vt.m6080b(38, (C1279wb) lsVar);
        }
        Long l28 = this.f3695w;
        if (l28 != null) {
            a += C1270vt.m6086c(39, l28.longValue());
        }
        Long l29 = this.f3696x;
        if (l29 != null) {
            a += C1270vt.m6086c(40, l29.longValue());
        }
        Long l30 = this.f3697y;
        if (l30 != null) {
            a += C1270vt.m6086c(41, l30.longValue());
        }
        Long l31 = this.f3698z;
        if (l31 != null) {
            a += C1270vt.m6086c(42, l31.longValue());
        }
        C0933lq[] lqVarArr = this.f3650K;
        if (lqVarArr != null && lqVarArr.length > 0) {
            int i = 0;
            while (true) {
                C0933lq[] lqVarArr2 = this.f3650K;
                if (i >= lqVarArr2.length) {
                    break;
                }
                C0933lq lqVar = lqVarArr2[i];
                if (lqVar != null) {
                    a += C1270vt.m6080b(43, (C1279wb) lqVar);
                }
                i++;
            }
        }
        Long l32 = this.f3640A;
        if (l32 != null) {
            a += C1270vt.m6086c(44, l32.longValue());
        }
        Long l33 = this.f3641B;
        if (l33 != null) {
            a += C1270vt.m6086c(45, l33.longValue());
        }
        String str9 = this.f3642C;
        if (str9 != null) {
            a += C1270vt.m6081b(46, str9);
        }
        String str10 = this.f3643D;
        if (str10 != null) {
            a += C1270vt.m6081b(47, str10);
        }
        Integer num2 = this.f3644E;
        if (num2 != null) {
            a += C1270vt.m6079b(48, num2.intValue());
        }
        Integer num3 = this.f3645F;
        if (num3 != null) {
            a += C1270vt.m6079b(49, num3.intValue());
        }
        C0933lq lqVar2 = this.f3649J;
        if (lqVar2 != null) {
            a += C1270vt.m6080b(50, (C1279wb) lqVar2);
        }
        Long l34 = this.f3646G;
        if (l34 != null) {
            a += C1270vt.m6086c(51, l34.longValue());
        }
        Long l35 = this.f3647H;
        if (l35 != null) {
            a += C1270vt.m6086c(52, l35.longValue());
        }
        Long l36 = this.f3668ad;
        if (l36 != null) {
            a += C1270vt.m6086c(53, l36.longValue());
        }
        Long l37 = this.f3669ae;
        if (l37 != null) {
            a += C1270vt.m6086c(54, l37.longValue());
        }
        Long l38 = this.f3670af;
        if (l38 != null) {
            a += C1270vt.m6086c(55, l38.longValue());
        }
        Integer num4 = this.f3648I;
        if (num4 != null) {
            a += C1270vt.m6079b(56, num4.intValue());
        }
        C0934lr lrVar = this.f3651L;
        if (lrVar != null) {
            a += C1270vt.m6080b(57, (C1279wb) lrVar);
        }
        Long l39 = this.f3671ag;
        if (l39 != null) {
            a += C1270vt.m6086c(58, l39.longValue());
        }
        C0938lv lvVar = this.f3656Q;
        return lvVar != null ? a + C1270vt.m6080b(201, (C1279wb) lvVar) : a;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:34:0x00b9, code lost:
        r5.mo3471e(r2);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:59:0x016a, code lost:
        r5.mo3461a(r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:74:0x01f1, code lost:
        mo3491a(r5, r0);
     */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final /* synthetic */ com.google.android.gms.internal.C1279wb mo1919a(com.google.android.gms.internal.C1269vs r5) {
        /*
            r4 = this;
        L_0x0000:
            int r0 = r5.mo3459a()
            r1 = 1000(0x3e8, float:1.401E-42)
            switch(r0) {
                case 0: goto L_0x031a;
                case 10: goto L_0x0312;
                case 18: goto L_0x030a;
                case 24: goto L_0x02fe;
                case 32: goto L_0x02f2;
                case 40: goto L_0x02e6;
                case 48: goto L_0x02da;
                case 56: goto L_0x02ce;
                case 64: goto L_0x02c2;
                case 72: goto L_0x02b6;
                case 80: goto L_0x02aa;
                case 88: goto L_0x029e;
                case 96: goto L_0x0292;
                case 106: goto L_0x028a;
                case 112: goto L_0x027e;
                case 120: goto L_0x0272;
                case 128: goto L_0x0266;
                case 136: goto L_0x025a;
                case 144: goto L_0x024e;
                case 152: goto L_0x0242;
                case 160: goto L_0x0236;
                case 168: goto L_0x022a;
                case 176: goto L_0x021e;
                case 184: goto L_0x0212;
                case 194: goto L_0x020a;
                case 200: goto L_0x01fe;
                case 208: goto L_0x01e3;
                case 218: goto L_0x01db;
                case 224: goto L_0x01cf;
                case 234: goto L_0x01c7;
                case 242: goto L_0x01bf;
                case 248: goto L_0x01b3;
                case 256: goto L_0x01a7;
                case 264: goto L_0x019b;
                case 274: goto L_0x0193;
                case 280: goto L_0x0187;
                case 288: goto L_0x017b;
                case 296: goto L_0x016f;
                case 306: goto L_0x015d;
                case 312: goto L_0x0151;
                case 320: goto L_0x0145;
                case 328: goto L_0x0139;
                case 336: goto L_0x012d;
                case 346: goto L_0x00ee;
                case 352: goto L_0x00e2;
                case 360: goto L_0x00d6;
                case 370: goto L_0x00ce;
                case 378: goto L_0x00c6;
                case 384: goto L_0x00ac;
                case 392: goto L_0x0096;
                case 402: goto L_0x0087;
                case 408: goto L_0x007b;
                case 416: goto L_0x0070;
                case 424: goto L_0x0065;
                case 432: goto L_0x005a;
                case 440: goto L_0x004f;
                case 448: goto L_0x0039;
                case 458: goto L_0x002a;
                case 464: goto L_0x001f;
                case 1610: goto L_0x0010;
                default: goto L_0x0009;
            }
        L_0x0009:
            boolean r0 = super.mo3491a(r5, r0)
            if (r0 != 0) goto L_0x0000
            return r4
        L_0x0010:
            com.google.android.gms.internal.lv r0 = r4.f3656Q
            if (r0 != 0) goto L_0x001b
            com.google.android.gms.internal.lv r0 = new com.google.android.gms.internal.lv
            r0.<init>()
            r4.f3656Q = r0
        L_0x001b:
            com.google.android.gms.internal.lv r0 = r4.f3656Q
            goto L_0x016a
        L_0x001f:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3671ag = r0
            goto L_0x0000
        L_0x002a:
            com.google.android.gms.internal.lr r0 = r4.f3651L
            if (r0 != 0) goto L_0x0035
            com.google.android.gms.internal.lr r0 = new com.google.android.gms.internal.lr
            r0.<init>()
            r4.f3651L = r0
        L_0x0035:
            com.google.android.gms.internal.lr r0 = r4.f3651L
            goto L_0x016a
        L_0x0039:
            int r2 = r5.mo3478l()
            int r3 = r5.mo3473g()
            if (r3 == r1) goto L_0x0048
            switch(r3) {
                case 0: goto L_0x0048;
                case 1: goto L_0x0048;
                case 2: goto L_0x0048;
                default: goto L_0x0046;
            }
        L_0x0046:
            goto L_0x00b9
        L_0x0048:
            java.lang.Integer r0 = java.lang.Integer.valueOf(r3)
            r4.f3648I = r0
            goto L_0x0000
        L_0x004f:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3670af = r0
            goto L_0x0000
        L_0x005a:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3669ae = r0
            goto L_0x0000
        L_0x0065:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3668ad = r0
            goto L_0x0000
        L_0x0070:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3647H = r0
            goto L_0x0000
        L_0x007b:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3646G = r0
            goto L_0x0000
        L_0x0087:
            com.google.android.gms.internal.lq r0 = r4.f3649J
            if (r0 != 0) goto L_0x0092
            com.google.android.gms.internal.lq r0 = new com.google.android.gms.internal.lq
            r0.<init>()
            r4.f3649J = r0
        L_0x0092:
            com.google.android.gms.internal.lq r0 = r4.f3649J
            goto L_0x016a
        L_0x0096:
            int r2 = r5.mo3478l()
            int r3 = r5.mo3473g()
            if (r3 == r1) goto L_0x00a4
            switch(r3) {
                case 0: goto L_0x00a4;
                case 1: goto L_0x00a4;
                case 2: goto L_0x00a4;
                default: goto L_0x00a3;
            }
        L_0x00a3:
            goto L_0x00b9
        L_0x00a4:
            java.lang.Integer r0 = java.lang.Integer.valueOf(r3)
            r4.f3645F = r0
            goto L_0x0000
        L_0x00ac:
            int r2 = r5.mo3478l()
            int r3 = r5.mo3473g()
            if (r3 == r1) goto L_0x00be
            switch(r3) {
                case 0: goto L_0x00be;
                case 1: goto L_0x00be;
                case 2: goto L_0x00be;
                default: goto L_0x00b9;
            }
        L_0x00b9:
            r5.mo3471e(r2)
            goto L_0x01f1
        L_0x00be:
            java.lang.Integer r0 = java.lang.Integer.valueOf(r3)
            r4.f3644E = r0
            goto L_0x0000
        L_0x00c6:
            java.lang.String r0 = r5.mo3470e()
            r4.f3643D = r0
            goto L_0x0000
        L_0x00ce:
            java.lang.String r0 = r5.mo3470e()
            r4.f3642C = r0
            goto L_0x0000
        L_0x00d6:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3641B = r0
            goto L_0x0000
        L_0x00e2:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3640A = r0
            goto L_0x0000
        L_0x00ee:
            r0 = 346(0x15a, float:4.85E-43)
            int r0 = com.google.android.gms.internal.C1282we.m6138a(r5, r0)
            com.google.android.gms.internal.lq[] r1 = r4.f3650K
            r2 = 0
            if (r1 != 0) goto L_0x00fb
            r1 = r2
            goto L_0x00fc
        L_0x00fb:
            int r1 = r1.length
        L_0x00fc:
            int r0 = r0 + r1
            com.google.android.gms.internal.lq[] r0 = new com.google.android.gms.internal.C0933lq[r0]
            if (r1 == 0) goto L_0x0106
            com.google.android.gms.internal.lq[] r3 = r4.f3650K
            java.lang.System.arraycopy(r3, r2, r0, r2, r1)
        L_0x0106:
            int r2 = r0.length
            int r2 = r2 + -1
            if (r1 >= r2) goto L_0x011d
            com.google.android.gms.internal.lq r2 = new com.google.android.gms.internal.lq
            r2.<init>()
            r0[r1] = r2
            r2 = r0[r1]
            r5.mo3461a(r2)
            r5.mo3459a()
            int r1 = r1 + 1
            goto L_0x0106
        L_0x011d:
            com.google.android.gms.internal.lq r2 = new com.google.android.gms.internal.lq
            r2.<init>()
            r0[r1] = r2
            r1 = r0[r1]
            r5.mo3461a(r1)
            r4.f3650K = r0
            goto L_0x0000
        L_0x012d:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3698z = r0
            goto L_0x0000
        L_0x0139:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3697y = r0
            goto L_0x0000
        L_0x0145:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3696x = r0
            goto L_0x0000
        L_0x0151:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3695w = r0
            goto L_0x0000
        L_0x015d:
            com.google.android.gms.internal.ls r0 = r4.f3667ac
            if (r0 != 0) goto L_0x0168
            com.google.android.gms.internal.ls r0 = new com.google.android.gms.internal.ls
            r0.<init>()
            r4.f3667ac = r0
        L_0x0168:
            com.google.android.gms.internal.ls r0 = r4.f3667ac
        L_0x016a:
            r5.mo3461a(r0)
            goto L_0x0000
        L_0x016f:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3694v = r0
            goto L_0x0000
        L_0x017b:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3693u = r0
            goto L_0x0000
        L_0x0187:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3692t = r0
            goto L_0x0000
        L_0x0193:
            java.lang.String r0 = r5.mo3470e()
            r4.f3691s = r0
            goto L_0x0000
        L_0x019b:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3690r = r0
            goto L_0x0000
        L_0x01a7:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3689q = r0
            goto L_0x0000
        L_0x01b3:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3688p = r0
            goto L_0x0000
        L_0x01bf:
            java.lang.String r0 = r5.mo3470e()
            r4.f3673ai = r0
            goto L_0x0000
        L_0x01c7:
            java.lang.String r0 = r5.mo3470e()
            r4.f3687o = r0
            goto L_0x0000
        L_0x01cf:
            boolean r0 = r5.mo3469d()
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            r4.f3654O = r0
            goto L_0x0000
        L_0x01db:
            java.lang.String r0 = r5.mo3470e()
            r4.f3686n = r0
            goto L_0x0000
        L_0x01e3:
            int r1 = r5.mo3478l()
            int r2 = r5.mo3473g()
            switch(r2) {
                case 0: goto L_0x01f6;
                case 1: goto L_0x01f6;
                case 2: goto L_0x01f6;
                case 3: goto L_0x01f6;
                case 4: goto L_0x01f6;
                case 5: goto L_0x01f6;
                case 6: goto L_0x01f6;
                default: goto L_0x01ee;
            }
        L_0x01ee:
            r5.mo3471e(r1)
        L_0x01f1:
            r4.mo3491a(r5, r0)
            goto L_0x0000
        L_0x01f6:
            java.lang.Integer r0 = java.lang.Integer.valueOf(r2)
            r4.f3653N = r0
            goto L_0x0000
        L_0x01fe:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3655P = r0
            goto L_0x0000
        L_0x020a:
            java.lang.String r0 = r5.mo3470e()
            r4.f3652M = r0
            goto L_0x0000
        L_0x0212:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3685m = r0
            goto L_0x0000
        L_0x021e:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3684l = r0
            goto L_0x0000
        L_0x022a:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3672ah = r0
            goto L_0x0000
        L_0x0236:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3683k = r0
            goto L_0x0000
        L_0x0242:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3666ab = r0
            goto L_0x0000
        L_0x024e:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3665aa = r0
            goto L_0x0000
        L_0x025a:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3682j = r0
            goto L_0x0000
        L_0x0266:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3681i = r0
            goto L_0x0000
        L_0x0272:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3680h = r0
            goto L_0x0000
        L_0x027e:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3679g = r0
            goto L_0x0000
        L_0x028a:
            java.lang.String r0 = r5.mo3470e()
            r4.f3663Z = r0
            goto L_0x0000
        L_0x0292:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3678f = r0
            goto L_0x0000
        L_0x029e:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3662Y = r0
            goto L_0x0000
        L_0x02aa:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3661X = r0
            goto L_0x0000
        L_0x02b6:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3660W = r0
            goto L_0x0000
        L_0x02c2:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3659V = r0
            goto L_0x0000
        L_0x02ce:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3658U = r0
            goto L_0x0000
        L_0x02da:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3677e = r0
            goto L_0x0000
        L_0x02e6:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3676d = r0
            goto L_0x0000
        L_0x02f2:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3657T = r0
            goto L_0x0000
        L_0x02fe:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3675c = r0
            goto L_0x0000
        L_0x030a:
            java.lang.String r0 = r5.mo3470e()
            r4.f3674b = r0
            goto L_0x0000
        L_0x0312:
            java.lang.String r0 = r5.mo3470e()
            r4.f3664a = r0
            goto L_0x0000
        L_0x031a:
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.C0932lp.mo1919a(com.google.android.gms.internal.vs):com.google.android.gms.internal.wb");
    }

    /* renamed from: a */
    public final void mo1920a(C1270vt vtVar) {
        String str = this.f3664a;
        if (str != null) {
            vtVar.mo3483a(1, str);
        }
        String str2 = this.f3674b;
        if (str2 != null) {
            vtVar.mo3483a(2, str2);
        }
        Long l = this.f3675c;
        if (l != null) {
            vtVar.mo3487b(3, l.longValue());
        }
        Long l2 = this.f3657T;
        if (l2 != null) {
            vtVar.mo3487b(4, l2.longValue());
        }
        Long l3 = this.f3676d;
        if (l3 != null) {
            vtVar.mo3487b(5, l3.longValue());
        }
        Long l4 = this.f3677e;
        if (l4 != null) {
            vtVar.mo3487b(6, l4.longValue());
        }
        Long l5 = this.f3658U;
        if (l5 != null) {
            vtVar.mo3487b(7, l5.longValue());
        }
        Long l6 = this.f3659V;
        if (l6 != null) {
            vtVar.mo3487b(8, l6.longValue());
        }
        Long l7 = this.f3660W;
        if (l7 != null) {
            vtVar.mo3487b(9, l7.longValue());
        }
        Long l8 = this.f3661X;
        if (l8 != null) {
            vtVar.mo3487b(10, l8.longValue());
        }
        Long l9 = this.f3662Y;
        if (l9 != null) {
            vtVar.mo3487b(11, l9.longValue());
        }
        Long l10 = this.f3678f;
        if (l10 != null) {
            vtVar.mo3487b(12, l10.longValue());
        }
        String str3 = this.f3663Z;
        if (str3 != null) {
            vtVar.mo3483a(13, str3);
        }
        Long l11 = this.f3679g;
        if (l11 != null) {
            vtVar.mo3487b(14, l11.longValue());
        }
        Long l12 = this.f3680h;
        if (l12 != null) {
            vtVar.mo3487b(15, l12.longValue());
        }
        Long l13 = this.f3681i;
        if (l13 != null) {
            vtVar.mo3487b(16, l13.longValue());
        }
        Long l14 = this.f3682j;
        if (l14 != null) {
            vtVar.mo3487b(17, l14.longValue());
        }
        Long l15 = this.f3665aa;
        if (l15 != null) {
            vtVar.mo3487b(18, l15.longValue());
        }
        Long l16 = this.f3666ab;
        if (l16 != null) {
            vtVar.mo3487b(19, l16.longValue());
        }
        Long l17 = this.f3683k;
        if (l17 != null) {
            vtVar.mo3487b(20, l17.longValue());
        }
        Long l18 = this.f3672ah;
        if (l18 != null) {
            vtVar.mo3487b(21, l18.longValue());
        }
        Long l19 = this.f3684l;
        if (l19 != null) {
            vtVar.mo3487b(22, l19.longValue());
        }
        Long l20 = this.f3685m;
        if (l20 != null) {
            vtVar.mo3487b(23, l20.longValue());
        }
        String str4 = this.f3652M;
        if (str4 != null) {
            vtVar.mo3483a(24, str4);
        }
        Long l21 = this.f3655P;
        if (l21 != null) {
            vtVar.mo3487b(25, l21.longValue());
        }
        Integer num = this.f3653N;
        if (num != null) {
            vtVar.mo3480a(26, num.intValue());
        }
        String str5 = this.f3686n;
        if (str5 != null) {
            vtVar.mo3483a(27, str5);
        }
        Boolean bool = this.f3654O;
        if (bool != null) {
            vtVar.mo3484a(28, bool.booleanValue());
        }
        String str6 = this.f3687o;
        if (str6 != null) {
            vtVar.mo3483a(29, str6);
        }
        String str7 = this.f3673ai;
        if (str7 != null) {
            vtVar.mo3483a(30, str7);
        }
        Long l22 = this.f3688p;
        if (l22 != null) {
            vtVar.mo3487b(31, l22.longValue());
        }
        Long l23 = this.f3689q;
        if (l23 != null) {
            vtVar.mo3487b(32, l23.longValue());
        }
        Long l24 = this.f3690r;
        if (l24 != null) {
            vtVar.mo3487b(33, l24.longValue());
        }
        String str8 = this.f3691s;
        if (str8 != null) {
            vtVar.mo3483a(34, str8);
        }
        Long l25 = this.f3692t;
        if (l25 != null) {
            vtVar.mo3487b(35, l25.longValue());
        }
        Long l26 = this.f3693u;
        if (l26 != null) {
            vtVar.mo3487b(36, l26.longValue());
        }
        Long l27 = this.f3694v;
        if (l27 != null) {
            vtVar.mo3487b(37, l27.longValue());
        }
        C0935ls lsVar = this.f3667ac;
        if (lsVar != null) {
            vtVar.mo3482a(38, (C1279wb) lsVar);
        }
        Long l28 = this.f3695w;
        if (l28 != null) {
            vtVar.mo3487b(39, l28.longValue());
        }
        Long l29 = this.f3696x;
        if (l29 != null) {
            vtVar.mo3487b(40, l29.longValue());
        }
        Long l30 = this.f3697y;
        if (l30 != null) {
            vtVar.mo3487b(41, l30.longValue());
        }
        Long l31 = this.f3698z;
        if (l31 != null) {
            vtVar.mo3487b(42, l31.longValue());
        }
        C0933lq[] lqVarArr = this.f3650K;
        if (lqVarArr != null && lqVarArr.length > 0) {
            int i = 0;
            while (true) {
                C0933lq[] lqVarArr2 = this.f3650K;
                if (i >= lqVarArr2.length) {
                    break;
                }
                C0933lq lqVar = lqVarArr2[i];
                if (lqVar != null) {
                    vtVar.mo3482a(43, (C1279wb) lqVar);
                }
                i++;
            }
        }
        Long l32 = this.f3640A;
        if (l32 != null) {
            vtVar.mo3487b(44, l32.longValue());
        }
        Long l33 = this.f3641B;
        if (l33 != null) {
            vtVar.mo3487b(45, l33.longValue());
        }
        String str9 = this.f3642C;
        if (str9 != null) {
            vtVar.mo3483a(46, str9);
        }
        String str10 = this.f3643D;
        if (str10 != null) {
            vtVar.mo3483a(47, str10);
        }
        Integer num2 = this.f3644E;
        if (num2 != null) {
            vtVar.mo3480a(48, num2.intValue());
        }
        Integer num3 = this.f3645F;
        if (num3 != null) {
            vtVar.mo3480a(49, num3.intValue());
        }
        C0933lq lqVar2 = this.f3649J;
        if (lqVar2 != null) {
            vtVar.mo3482a(50, (C1279wb) lqVar2);
        }
        Long l34 = this.f3646G;
        if (l34 != null) {
            vtVar.mo3487b(51, l34.longValue());
        }
        Long l35 = this.f3647H;
        if (l35 != null) {
            vtVar.mo3487b(52, l35.longValue());
        }
        Long l36 = this.f3668ad;
        if (l36 != null) {
            vtVar.mo3487b(53, l36.longValue());
        }
        Long l37 = this.f3669ae;
        if (l37 != null) {
            vtVar.mo3487b(54, l37.longValue());
        }
        Long l38 = this.f3670af;
        if (l38 != null) {
            vtVar.mo3487b(55, l38.longValue());
        }
        Integer num4 = this.f3648I;
        if (num4 != null) {
            vtVar.mo3480a(56, num4.intValue());
        }
        C0934lr lrVar = this.f3651L;
        if (lrVar != null) {
            vtVar.mo3482a(57, (C1279wb) lrVar);
        }
        Long l39 = this.f3671ag;
        if (l39 != null) {
            vtVar.mo3487b(58, l39.longValue());
        }
        C0938lv lvVar = this.f3656Q;
        if (lvVar != null) {
            vtVar.mo3482a(201, (C1279wb) lvVar);
        }
        super.mo1920a(vtVar);
    }
}
