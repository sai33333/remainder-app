package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.lq */
public final class C0933lq extends C1272vv<C0933lq> {

    /* renamed from: v */
    private static volatile C0933lq[] f3699v;

    /* renamed from: a */
    public Long f3700a;

    /* renamed from: b */
    public Long f3701b;

    /* renamed from: c */
    public Long f3702c;

    /* renamed from: d */
    public Long f3703d;

    /* renamed from: e */
    public Long f3704e;

    /* renamed from: f */
    public Long f3705f;

    /* renamed from: g */
    public Integer f3706g;

    /* renamed from: h */
    public Long f3707h;

    /* renamed from: i */
    public Long f3708i;

    /* renamed from: j */
    public Long f3709j;

    /* renamed from: k */
    public Integer f3710k;

    /* renamed from: l */
    public Long f3711l;

    /* renamed from: m */
    public Long f3712m;

    /* renamed from: n */
    public Long f3713n;

    /* renamed from: o */
    public Long f3714o;

    /* renamed from: p */
    public Long f3715p;

    /* renamed from: q */
    public Long f3716q;

    /* renamed from: r */
    public Long f3717r;

    /* renamed from: s */
    public Long f3718s;

    /* renamed from: t */
    public Long f3719t;

    /* renamed from: u */
    public Long f3720u;

    public C0933lq() {
        this.f3700a = null;
        this.f3701b = null;
        this.f3702c = null;
        this.f3703d = null;
        this.f3704e = null;
        this.f3705f = null;
        this.f3707h = null;
        this.f3708i = null;
        this.f3709j = null;
        this.f3711l = null;
        this.f3712m = null;
        this.f3713n = null;
        this.f3714o = null;
        this.f3715p = null;
        this.f3716q = null;
        this.f3717r = null;
        this.f3718s = null;
        this.f3719t = null;
        this.f3720u = null;
        this.f4730S = -1;
    }

    /* renamed from: b */
    public static C0933lq[] m5060b() {
        if (f3699v == null) {
            synchronized (C1276vz.f4728b) {
                if (f3699v == null) {
                    f3699v = new C0933lq[0];
                }
            }
        }
        return f3699v;
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public final int mo1918a() {
        int a = super.mo1918a();
        Long l = this.f3700a;
        if (l != null) {
            a += C1270vt.m6086c(1, l.longValue());
        }
        Long l2 = this.f3701b;
        if (l2 != null) {
            a += C1270vt.m6086c(2, l2.longValue());
        }
        Long l3 = this.f3702c;
        if (l3 != null) {
            a += C1270vt.m6086c(3, l3.longValue());
        }
        Long l4 = this.f3703d;
        if (l4 != null) {
            a += C1270vt.m6086c(4, l4.longValue());
        }
        Long l5 = this.f3704e;
        if (l5 != null) {
            a += C1270vt.m6086c(5, l5.longValue());
        }
        Long l6 = this.f3705f;
        if (l6 != null) {
            a += C1270vt.m6086c(6, l6.longValue());
        }
        Integer num = this.f3706g;
        if (num != null) {
            a += C1270vt.m6079b(7, num.intValue());
        }
        Long l7 = this.f3707h;
        if (l7 != null) {
            a += C1270vt.m6086c(8, l7.longValue());
        }
        Long l8 = this.f3708i;
        if (l8 != null) {
            a += C1270vt.m6086c(9, l8.longValue());
        }
        Long l9 = this.f3709j;
        if (l9 != null) {
            a += C1270vt.m6086c(10, l9.longValue());
        }
        Integer num2 = this.f3710k;
        if (num2 != null) {
            a += C1270vt.m6079b(11, num2.intValue());
        }
        Long l10 = this.f3711l;
        if (l10 != null) {
            a += C1270vt.m6086c(12, l10.longValue());
        }
        Long l11 = this.f3712m;
        if (l11 != null) {
            a += C1270vt.m6086c(13, l11.longValue());
        }
        Long l12 = this.f3713n;
        if (l12 != null) {
            a += C1270vt.m6086c(14, l12.longValue());
        }
        Long l13 = this.f3714o;
        if (l13 != null) {
            a += C1270vt.m6086c(15, l13.longValue());
        }
        Long l14 = this.f3715p;
        if (l14 != null) {
            a += C1270vt.m6086c(16, l14.longValue());
        }
        Long l15 = this.f3716q;
        if (l15 != null) {
            a += C1270vt.m6086c(17, l15.longValue());
        }
        Long l16 = this.f3717r;
        if (l16 != null) {
            a += C1270vt.m6086c(18, l16.longValue());
        }
        Long l17 = this.f3718s;
        if (l17 != null) {
            a += C1270vt.m6086c(19, l17.longValue());
        }
        Long l18 = this.f3719t;
        if (l18 != null) {
            a += C1270vt.m6086c(20, l18.longValue());
        }
        Long l19 = this.f3720u;
        return l19 != null ? a + C1270vt.m6086c(21, l19.longValue()) : a;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:25:0x00c5, code lost:
        r5.mo3471e(r2);
        mo3491a(r5, r0);
     */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final /* synthetic */ com.google.android.gms.internal.C1279wb mo1919a(com.google.android.gms.internal.C1269vs r5) {
        /*
            r4 = this;
        L_0x0000:
            int r0 = r5.mo3459a()
            r1 = 1000(0x3e8, float:1.401E-42)
            switch(r0) {
                case 0: goto L_0x011d;
                case 8: goto L_0x0111;
                case 16: goto L_0x0105;
                case 24: goto L_0x00f9;
                case 32: goto L_0x00ed;
                case 40: goto L_0x00e1;
                case 48: goto L_0x00d5;
                case 56: goto L_0x00b8;
                case 64: goto L_0x00ac;
                case 72: goto L_0x00a0;
                case 80: goto L_0x0094;
                case 88: goto L_0x007e;
                case 96: goto L_0x0073;
                case 104: goto L_0x0068;
                case 112: goto L_0x005d;
                case 120: goto L_0x0052;
                case 128: goto L_0x0047;
                case 136: goto L_0x003c;
                case 144: goto L_0x0031;
                case 152: goto L_0x0026;
                case 160: goto L_0x001b;
                case 168: goto L_0x0010;
                default: goto L_0x0009;
            }
        L_0x0009:
            boolean r0 = super.mo3491a(r5, r0)
            if (r0 != 0) goto L_0x0000
            return r4
        L_0x0010:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3720u = r0
            goto L_0x0000
        L_0x001b:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3719t = r0
            goto L_0x0000
        L_0x0026:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3718s = r0
            goto L_0x0000
        L_0x0031:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3717r = r0
            goto L_0x0000
        L_0x003c:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3716q = r0
            goto L_0x0000
        L_0x0047:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3715p = r0
            goto L_0x0000
        L_0x0052:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3714o = r0
            goto L_0x0000
        L_0x005d:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3713n = r0
            goto L_0x0000
        L_0x0068:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3712m = r0
            goto L_0x0000
        L_0x0073:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3711l = r0
            goto L_0x0000
        L_0x007e:
            int r2 = r5.mo3478l()
            int r3 = r5.mo3473g()
            if (r3 == r1) goto L_0x008c
            switch(r3) {
                case 0: goto L_0x008c;
                case 1: goto L_0x008c;
                case 2: goto L_0x008c;
                default: goto L_0x008b;
            }
        L_0x008b:
            goto L_0x00c5
        L_0x008c:
            java.lang.Integer r0 = java.lang.Integer.valueOf(r3)
            r4.f3710k = r0
            goto L_0x0000
        L_0x0094:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3709j = r0
            goto L_0x0000
        L_0x00a0:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3708i = r0
            goto L_0x0000
        L_0x00ac:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3707h = r0
            goto L_0x0000
        L_0x00b8:
            int r2 = r5.mo3478l()
            int r3 = r5.mo3473g()
            if (r3 == r1) goto L_0x00cd
            switch(r3) {
                case 0: goto L_0x00cd;
                case 1: goto L_0x00cd;
                case 2: goto L_0x00cd;
                default: goto L_0x00c5;
            }
        L_0x00c5:
            r5.mo3471e(r2)
            r4.mo3491a(r5, r0)
            goto L_0x0000
        L_0x00cd:
            java.lang.Integer r0 = java.lang.Integer.valueOf(r3)
            r4.f3706g = r0
            goto L_0x0000
        L_0x00d5:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3705f = r0
            goto L_0x0000
        L_0x00e1:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3704e = r0
            goto L_0x0000
        L_0x00ed:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3703d = r0
            goto L_0x0000
        L_0x00f9:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3702c = r0
            goto L_0x0000
        L_0x0105:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3701b = r0
            goto L_0x0000
        L_0x0111:
            long r0 = r5.mo3474h()
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            r4.f3700a = r0
            goto L_0x0000
        L_0x011d:
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.C0933lq.mo1919a(com.google.android.gms.internal.vs):com.google.android.gms.internal.wb");
    }

    /* renamed from: a */
    public final void mo1920a(C1270vt vtVar) {
        Long l = this.f3700a;
        if (l != null) {
            vtVar.mo3487b(1, l.longValue());
        }
        Long l2 = this.f3701b;
        if (l2 != null) {
            vtVar.mo3487b(2, l2.longValue());
        }
        Long l3 = this.f3702c;
        if (l3 != null) {
            vtVar.mo3487b(3, l3.longValue());
        }
        Long l4 = this.f3703d;
        if (l4 != null) {
            vtVar.mo3487b(4, l4.longValue());
        }
        Long l5 = this.f3704e;
        if (l5 != null) {
            vtVar.mo3487b(5, l5.longValue());
        }
        Long l6 = this.f3705f;
        if (l6 != null) {
            vtVar.mo3487b(6, l6.longValue());
        }
        Integer num = this.f3706g;
        if (num != null) {
            vtVar.mo3480a(7, num.intValue());
        }
        Long l7 = this.f3707h;
        if (l7 != null) {
            vtVar.mo3487b(8, l7.longValue());
        }
        Long l8 = this.f3708i;
        if (l8 != null) {
            vtVar.mo3487b(9, l8.longValue());
        }
        Long l9 = this.f3709j;
        if (l9 != null) {
            vtVar.mo3487b(10, l9.longValue());
        }
        Integer num2 = this.f3710k;
        if (num2 != null) {
            vtVar.mo3480a(11, num2.intValue());
        }
        Long l10 = this.f3711l;
        if (l10 != null) {
            vtVar.mo3487b(12, l10.longValue());
        }
        Long l11 = this.f3712m;
        if (l11 != null) {
            vtVar.mo3487b(13, l11.longValue());
        }
        Long l12 = this.f3713n;
        if (l12 != null) {
            vtVar.mo3487b(14, l12.longValue());
        }
        Long l13 = this.f3714o;
        if (l13 != null) {
            vtVar.mo3487b(15, l13.longValue());
        }
        Long l14 = this.f3715p;
        if (l14 != null) {
            vtVar.mo3487b(16, l14.longValue());
        }
        Long l15 = this.f3716q;
        if (l15 != null) {
            vtVar.mo3487b(17, l15.longValue());
        }
        Long l16 = this.f3717r;
        if (l16 != null) {
            vtVar.mo3487b(18, l16.longValue());
        }
        Long l17 = this.f3718s;
        if (l17 != null) {
            vtVar.mo3487b(19, l17.longValue());
        }
        Long l18 = this.f3719t;
        if (l18 != null) {
            vtVar.mo3487b(20, l18.longValue());
        }
        Long l19 = this.f3720u;
        if (l19 != null) {
            vtVar.mo3487b(21, l19.longValue());
        }
        super.mo1920a(vtVar);
    }
}
