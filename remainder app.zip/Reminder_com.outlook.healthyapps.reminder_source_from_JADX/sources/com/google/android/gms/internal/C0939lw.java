package com.google.android.gms.internal;

import com.google.android.gms.C0276a.C0278b;

/* renamed from: com.google.android.gms.internal.lw */
public final class C0939lw extends C1272vv<C0939lw> {

    /* renamed from: a */
    public byte[][] f3738a;

    /* renamed from: b */
    public byte[] f3739b;

    /* renamed from: c */
    public Integer f3740c;

    /* renamed from: d */
    private Integer f3741d;

    public C0939lw() {
        this.f3738a = C1282we.f4738f;
        this.f3739b = null;
        this.f4730S = -1;
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public final int mo1918a() {
        int a = super.mo1918a();
        byte[][] bArr = this.f3738a;
        if (bArr != null && bArr.length > 0) {
            int i = 0;
            int i2 = 0;
            int i3 = 0;
            while (true) {
                byte[][] bArr2 = this.f3738a;
                if (i >= bArr2.length) {
                    break;
                }
                byte[] bArr3 = bArr2[i];
                if (bArr3 != null) {
                    i3++;
                    i2 += C1270vt.m6083b(bArr3);
                }
                i++;
            }
            a = a + i2 + (i3 * 1);
        }
        byte[] bArr4 = this.f3739b;
        if (bArr4 != null) {
            a += C1270vt.m6082b(2, bArr4);
        }
        Integer num = this.f3741d;
        if (num != null) {
            a += C1270vt.m6079b(3, num.intValue());
        }
        Integer num2 = this.f3740c;
        return num2 != null ? a + C1270vt.m6079b(4, num2.intValue()) : a;
    }

    /* renamed from: a */
    public final /* synthetic */ C1279wb mo1919a(C1269vs vsVar) {
        int i;
        while (true) {
            int a = vsVar.mo3459a();
            if (a == 0) {
                return this;
            }
            if (a == 10) {
                int a2 = C1282we.m6138a(vsVar, 10);
                byte[][] bArr = this.f3738a;
                int length = bArr == null ? 0 : bArr.length;
                byte[][] bArr2 = new byte[(a2 + length)][];
                if (length != 0) {
                    System.arraycopy(this.f3738a, 0, bArr2, 0, length);
                }
                while (length < bArr2.length - 1) {
                    bArr2[length] = vsVar.mo3472f();
                    vsVar.mo3459a();
                    length++;
                }
                bArr2[length] = vsVar.mo3472f();
                this.f3738a = bArr2;
            } else if (a != 18) {
                if (a == 24) {
                    i = vsVar.mo3478l();
                    int g = vsVar.mo3473g();
                    switch (g) {
                        case C0278b.AdsAttrs_adSize /*0*/:
                        case 1:
                            this.f3741d = Integer.valueOf(g);
                            continue;
                    }
                } else if (a == 32) {
                    i = vsVar.mo3478l();
                    int g2 = vsVar.mo3473g();
                    switch (g2) {
                        case C0278b.AdsAttrs_adSize /*0*/:
                        case 1:
                        case 2:
                            this.f3740c = Integer.valueOf(g2);
                            continue;
                    }
                } else if (!super.mo3491a(vsVar, a)) {
                    return this;
                }
                vsVar.mo3471e(i);
                mo3491a(vsVar, a);
            } else {
                this.f3739b = vsVar.mo3472f();
            }
        }
    }

    /* renamed from: a */
    public final void mo1920a(C1270vt vtVar) {
        byte[][] bArr = this.f3738a;
        if (bArr != null && bArr.length > 0) {
            int i = 0;
            while (true) {
                byte[][] bArr2 = this.f3738a;
                if (i >= bArr2.length) {
                    break;
                }
                byte[] bArr3 = bArr2[i];
                if (bArr3 != null) {
                    vtVar.mo3485a(1, bArr3);
                }
                i++;
            }
        }
        byte[] bArr4 = this.f3739b;
        if (bArr4 != null) {
            vtVar.mo3485a(2, bArr4);
        }
        Integer num = this.f3741d;
        if (num != null) {
            vtVar.mo3480a(3, num.intValue());
        }
        Integer num2 = this.f3740c;
        if (num2 != null) {
            vtVar.mo3480a(4, num2.intValue());
        }
        super.mo1920a(vtVar);
    }
}
