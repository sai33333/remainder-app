package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.lx */
public abstract class C0940lx implements C0945mb {
    public final int describeContents() {
        return 0;
    }
}
