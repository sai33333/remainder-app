package com.google.android.gms.internal;

import android.os.Parcelable;

/* renamed from: com.google.android.gms.internal.mb */
public interface C0945mb extends Parcelable {
}
