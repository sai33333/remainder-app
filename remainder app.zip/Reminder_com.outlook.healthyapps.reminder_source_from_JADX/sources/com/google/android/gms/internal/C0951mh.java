package com.google.android.gms.internal;

import java.util.HashMap;

/* renamed from: com.google.android.gms.internal.mh */
public final class C0951mh extends C0949mf<Integer, Object> {

    /* renamed from: a */
    public String f3749a;

    /* renamed from: b */
    public long f3750b;

    /* renamed from: c */
    public String f3751c;

    /* renamed from: d */
    public String f3752d;

    /* renamed from: e */
    public String f3753e;

    public C0951mh() {
        this.f3749a = "E";
        this.f3750b = -1;
        this.f3751c = "E";
        this.f3752d = "E";
        this.f3753e = "E";
    }

    public C0951mh(String str) {
        this();
        mo3088a(str);
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public final HashMap<Integer, Object> mo3087a() {
        HashMap<Integer, Object> hashMap = new HashMap<>();
        hashMap.put(Integer.valueOf(0), this.f3749a);
        hashMap.put(Integer.valueOf(4), this.f3753e);
        hashMap.put(Integer.valueOf(3), this.f3752d);
        hashMap.put(Integer.valueOf(2), this.f3751c);
        hashMap.put(Integer.valueOf(1), Long.valueOf(this.f3750b));
        return hashMap;
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public final void mo3088a(String str) {
        HashMap b = m5129b(str);
        if (b != null) {
            this.f3749a = b.get(Integer.valueOf(0)) == null ? "E" : (String) b.get(Integer.valueOf(0));
            this.f3750b = b.get(Integer.valueOf(1)) == null ? -1 : ((Long) b.get(Integer.valueOf(1))).longValue();
            this.f3751c = b.get(Integer.valueOf(2)) == null ? "E" : (String) b.get(Integer.valueOf(2));
            this.f3752d = b.get(Integer.valueOf(3)) == null ? "E" : (String) b.get(Integer.valueOf(3));
            this.f3753e = b.get(Integer.valueOf(4)) == null ? "E" : (String) b.get(Integer.valueOf(4));
        }
    }
}
