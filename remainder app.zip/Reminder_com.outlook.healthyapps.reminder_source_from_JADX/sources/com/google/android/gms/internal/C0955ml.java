package com.google.android.gms.internal;

import android.os.IInterface;
import com.google.android.gms.p012a.C0279a;

/* renamed from: com.google.android.gms.internal.ml */
public interface C0955ml extends IInterface {
    boolean getBooleanFlagValue(String str, boolean z, int i);

    int getIntFlagValue(String str, int i, int i2);

    long getLongFlagValue(String str, long j, int i);

    String getStringFlagValue(String str, String str2, int i);

    void init(C0279a aVar);
}
