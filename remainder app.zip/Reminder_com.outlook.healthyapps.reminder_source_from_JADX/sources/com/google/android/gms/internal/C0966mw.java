package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;

/* renamed from: com.google.android.gms.internal.mw */
public final class C0966mw implements Creator<C0965mv> {
    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        int a = C0941ly.m5082a(parcel);
        int i = 0;
        byte[] bArr = null;
        while (parcel.dataPosition() < a) {
            int readInt = parcel.readInt();
            switch (65535 & readInt) {
                case 1:
                    i = C0941ly.m5089d(parcel, readInt);
                    break;
                case 2:
                    bArr = C0941ly.m5095j(parcel, readInt);
                    break;
                default:
                    C0941ly.m5086b(parcel, readInt);
                    break;
            }
        }
        C0941ly.m5098m(parcel, a);
        return new C0965mv(i, bArr);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new C0965mv[i];
    }
}
