package com.google.android.gms.internal;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

@arm
/* renamed from: com.google.android.gms.internal.n */
public final class C0970n extends C0940lx {
    public static final Creator<C0970n> CREATOR = new C1046p();

    /* renamed from: A */
    public final long f3967A;

    /* renamed from: B */
    public final String f3968B;

    /* renamed from: C */
    public final float f3969C;

    /* renamed from: D */
    public final int f3970D;

    /* renamed from: E */
    public final int f3971E;

    /* renamed from: F */
    public final boolean f3972F;

    /* renamed from: G */
    public final boolean f3973G;

    /* renamed from: H */
    public final String f3974H;

    /* renamed from: I */
    public final boolean f3975I;

    /* renamed from: J */
    public final String f3976J;

    /* renamed from: K */
    public final boolean f3977K;

    /* renamed from: L */
    public final int f3978L;

    /* renamed from: M */
    public final Bundle f3979M;

    /* renamed from: N */
    public final String f3980N;

    /* renamed from: O */
    public final ada f3981O;

    /* renamed from: P */
    public final boolean f3982P;

    /* renamed from: Q */
    public final Bundle f3983Q;

    /* renamed from: R */
    public final String f3984R;

    /* renamed from: S */
    public final String f3985S;

    /* renamed from: T */
    public final String f3986T;

    /* renamed from: U */
    public final boolean f3987U;

    /* renamed from: V */
    public final List<Integer> f3988V;

    /* renamed from: W */
    public final String f3989W;

    /* renamed from: X */
    public final List<String> f3990X;

    /* renamed from: Y */
    public final int f3991Y;

    /* renamed from: Z */
    public final boolean f3992Z;

    /* renamed from: a */
    public final int f3993a;

    /* renamed from: aa */
    public final boolean f3994aa;

    /* renamed from: b */
    public final Bundle f3995b;

    /* renamed from: c */
    public final aau f3996c;

    /* renamed from: d */
    public final aay f3997d;

    /* renamed from: e */
    public final String f3998e;

    /* renamed from: f */
    public final ApplicationInfo f3999f;

    /* renamed from: g */
    public final PackageInfo f4000g;

    /* renamed from: h */
    public final String f4001h;

    /* renamed from: i */
    public final String f4002i;

    /* renamed from: j */
    public final String f4003j;

    /* renamed from: k */
    public final C0857iv f4004k;

    /* renamed from: l */
    public final Bundle f4005l;

    /* renamed from: m */
    public final int f4006m;

    /* renamed from: n */
    public final List<String> f4007n;

    /* renamed from: o */
    public final Bundle f4008o;

    /* renamed from: p */
    public final boolean f4009p;

    /* renamed from: q */
    public final int f4010q;

    /* renamed from: r */
    public final int f4011r;

    /* renamed from: s */
    public final float f4012s;

    /* renamed from: t */
    public final String f4013t;

    /* renamed from: u */
    public final long f4014u;

    /* renamed from: v */
    public final String f4015v;

    /* renamed from: w */
    public final List<String> f4016w;

    /* renamed from: x */
    public final String f4017x;

    /* renamed from: y */
    public final agm f4018y;

    /* renamed from: z */
    public final List<String> f4019z;

    C0970n(int i, Bundle bundle, aau aau, aay aay, String str, ApplicationInfo applicationInfo, PackageInfo packageInfo, String str2, String str3, String str4, C0857iv ivVar, Bundle bundle2, int i2, List<String> list, Bundle bundle3, boolean z, int i3, int i4, float f, String str5, long j, String str6, List<String> list2, String str7, agm agm, List<String> list3, long j2, String str8, float f2, boolean z2, int i5, int i6, boolean z3, boolean z4, String str9, String str10, boolean z5, int i7, Bundle bundle4, String str11, ada ada, boolean z6, Bundle bundle5, String str12, String str13, String str14, boolean z7, List<Integer> list4, String str15, List<String> list5, int i8, boolean z8, boolean z9) {
        this.f3993a = i;
        this.f3995b = bundle;
        this.f3996c = aau;
        this.f3997d = aay;
        this.f3998e = str;
        this.f3999f = applicationInfo;
        this.f4000g = packageInfo;
        this.f4001h = str2;
        this.f4002i = str3;
        this.f4003j = str4;
        this.f4004k = ivVar;
        this.f4005l = bundle2;
        this.f4006m = i2;
        this.f4007n = list;
        this.f4019z = list3 == null ? Collections.emptyList() : Collections.unmodifiableList(list3);
        this.f4008o = bundle3;
        this.f4009p = z;
        this.f4010q = i3;
        this.f4011r = i4;
        this.f4012s = f;
        this.f4013t = str5;
        this.f4014u = j;
        this.f4015v = str6;
        this.f4016w = list2 == null ? Collections.emptyList() : Collections.unmodifiableList(list2);
        this.f4017x = str7;
        this.f4018y = agm;
        this.f3967A = j2;
        this.f3968B = str8;
        this.f3969C = f2;
        this.f3975I = z2;
        this.f3970D = i5;
        this.f3971E = i6;
        this.f3972F = z3;
        this.f3973G = z4;
        this.f3974H = str9;
        this.f3976J = str10;
        this.f3977K = z5;
        this.f3978L = i7;
        this.f3979M = bundle4;
        this.f3980N = str11;
        this.f3981O = ada;
        this.f3982P = z6;
        this.f3983Q = bundle5;
        this.f3984R = str12;
        this.f3985S = str13;
        this.f3986T = str14;
        this.f3987U = z7;
        this.f3988V = list4;
        this.f3989W = str15;
        this.f3990X = list5;
        this.f3991Y = i8;
        this.f3992Z = z8;
        this.f3994aa = z9;
    }

    private C0970n(Bundle bundle, aau aau, aay aay, String str, ApplicationInfo applicationInfo, PackageInfo packageInfo, String str2, String str3, String str4, C0857iv ivVar, Bundle bundle2, int i, List<String> list, List<String> list2, Bundle bundle3, boolean z, int i2, int i3, float f, String str5, long j, String str6, List<String> list3, String str7, agm agm, long j2, String str8, float f2, boolean z2, int i4, int i5, boolean z3, boolean z4, String str9, String str10, boolean z5, int i6, Bundle bundle4, String str11, ada ada, boolean z6, Bundle bundle5, String str12, String str13, String str14, boolean z7, List<Integer> list4, String str15, List<String> list5, int i7, boolean z8, boolean z9) {
        this(24, bundle, aau, aay, str, applicationInfo, packageInfo, str2, str3, str4, ivVar, bundle2, i, list, bundle3, z, i2, i3, f, str5, j, str6, list3, str7, agm, list2, j2, str8, f2, z2, i4, i5, z3, z4, str9, str10, z5, i6, bundle4, str11, ada, z6, bundle5, str12, str13, str14, z7, list4, str15, list5, i7, z8, z9);
    }

    public C0970n(C0997o oVar, long j, String str, String str2, String str3) {
        C0997o oVar2 = oVar;
        long j2 = j;
        String str4 = str;
        String str5 = str2;
        String str6 = str3;
        Bundle bundle = oVar2.f4105a;
        aau aau = oVar2.f4106b;
        aay aay = oVar2.f4107c;
        this(bundle, aau, aay, oVar2.f4108d, oVar2.f4109e, oVar2.f4110f, (String) C0860iy.m4739a(oVar2.f4099Q, ""), oVar2.f4111g, oVar2.f4112h, oVar2.f4114j, oVar2.f4113i, oVar2.f4115k, oVar2.f4116l, oVar2.f4117m, oVar2.f4119o, oVar2.f4120p, oVar2.f4121q, oVar2.f4122r, oVar2.f4123s, oVar2.f4124t, oVar2.f4125u, oVar2.f4126v, oVar2.f4127w, oVar2.f4128x, oVar2.f4129y, j2, oVar2.f4130z, oVar2.f4083A, oVar2.f4084B, oVar2.f4085C, oVar2.f4086D, oVar2.f4087E, oVar2.f4088F, (String) C0860iy.m4740a(oVar2.f4089G, "", 1, TimeUnit.SECONDS), oVar2.f4090H, oVar2.f4091I, oVar2.f4092J, oVar2.f4093K, oVar2.f4094L, oVar2.f4095M, oVar2.f4096N, oVar2.f4097O, str4, str5, str6, oVar2.f4098P, oVar2.f4100R, oVar2.f4101S, oVar2.f4118n, oVar2.f4102T, oVar2.f4103U, oVar2.f4104V);
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a = C0944ma.m5103a(parcel);
        C0944ma.m5106a(parcel, 1, this.f3993a);
        C0944ma.m5108a(parcel, 2, this.f3995b, false);
        C0944ma.m5110a(parcel, 3, (Parcelable) this.f3996c, i, false);
        C0944ma.m5110a(parcel, 4, (Parcelable) this.f3997d, i, false);
        C0944ma.m5111a(parcel, 5, this.f3998e, false);
        C0944ma.m5110a(parcel, 6, (Parcelable) this.f3999f, i, false);
        C0944ma.m5110a(parcel, 7, (Parcelable) this.f4000g, i, false);
        C0944ma.m5111a(parcel, 8, this.f4001h, false);
        C0944ma.m5111a(parcel, 9, this.f4002i, false);
        C0944ma.m5111a(parcel, 10, this.f4003j, false);
        C0944ma.m5110a(parcel, 11, (Parcelable) this.f4004k, i, false);
        C0944ma.m5108a(parcel, 12, this.f4005l, false);
        C0944ma.m5106a(parcel, 13, this.f4006m);
        C0944ma.m5119b(parcel, 14, this.f4007n, false);
        C0944ma.m5108a(parcel, 15, this.f4008o, false);
        C0944ma.m5113a(parcel, 16, this.f4009p);
        C0944ma.m5106a(parcel, 18, this.f4010q);
        C0944ma.m5106a(parcel, 19, this.f4011r);
        C0944ma.m5105a(parcel, 20, this.f4012s);
        C0944ma.m5111a(parcel, 21, this.f4013t, false);
        C0944ma.m5107a(parcel, 25, this.f4014u);
        C0944ma.m5111a(parcel, 26, this.f4015v, false);
        C0944ma.m5119b(parcel, 27, this.f4016w, false);
        C0944ma.m5111a(parcel, 28, this.f4017x, false);
        C0944ma.m5110a(parcel, 29, (Parcelable) this.f4018y, i, false);
        C0944ma.m5119b(parcel, 30, this.f4019z, false);
        C0944ma.m5107a(parcel, 31, this.f3967A);
        C0944ma.m5111a(parcel, 33, this.f3968B, false);
        C0944ma.m5105a(parcel, 34, this.f3969C);
        C0944ma.m5106a(parcel, 35, this.f3970D);
        C0944ma.m5106a(parcel, 36, this.f3971E);
        C0944ma.m5113a(parcel, 37, this.f3972F);
        C0944ma.m5113a(parcel, 38, this.f3973G);
        C0944ma.m5111a(parcel, 39, this.f3974H, false);
        C0944ma.m5113a(parcel, 40, this.f3975I);
        C0944ma.m5111a(parcel, 41, this.f3976J, false);
        C0944ma.m5113a(parcel, 42, this.f3977K);
        C0944ma.m5106a(parcel, 43, this.f3978L);
        C0944ma.m5108a(parcel, 44, this.f3979M, false);
        C0944ma.m5111a(parcel, 45, this.f3980N, false);
        C0944ma.m5110a(parcel, 46, (Parcelable) this.f3981O, i, false);
        C0944ma.m5113a(parcel, 47, this.f3982P);
        C0944ma.m5108a(parcel, 48, this.f3983Q, false);
        C0944ma.m5111a(parcel, 49, this.f3984R, false);
        C0944ma.m5111a(parcel, 50, this.f3985S, false);
        C0944ma.m5111a(parcel, 51, this.f3986T, false);
        C0944ma.m5113a(parcel, 52, this.f3987U);
        C0944ma.m5112a(parcel, 53, this.f3988V, false);
        C0944ma.m5111a(parcel, 54, this.f3989W, false);
        C0944ma.m5119b(parcel, 55, this.f3990X, false);
        C0944ma.m5106a(parcel, 56, this.f3991Y);
        C0944ma.m5113a(parcel, 57, this.f3992Z);
        C0944ma.m5113a(parcel, 58, this.f3994aa);
        C0944ma.m5104a(parcel, a);
    }
}
