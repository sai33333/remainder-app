package com.google.android.gms.internal;

import android.content.Context;
import android.view.MotionEvent;
import android.view.View;

/* renamed from: com.google.android.gms.internal.nr */
public interface C0988nr {
    /* renamed from: a */
    String mo1465a(Context context);

    /* renamed from: a */
    String mo1466a(Context context, String str, View view);

    /* renamed from: a */
    void mo1467a(int i, int i2, int i3);

    /* renamed from: a */
    void mo1468a(MotionEvent motionEvent);
}
