package com.google.android.gms.internal;

import android.content.Context;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import com.google.android.gms.ads.internal.C0354ax;
import java.io.UnsupportedEncodingException;
import java.security.GeneralSecurityException;
import java.util.LinkedList;

/* renamed from: com.google.android.gms.internal.ns */
public abstract class C0989ns implements C0988nr {

    /* renamed from: a */
    protected MotionEvent f4045a;

    /* renamed from: b */
    protected LinkedList<MotionEvent> f4046b = new LinkedList<>();

    /* renamed from: c */
    protected long f4047c = 0;

    /* renamed from: d */
    protected long f4048d = 0;

    /* renamed from: e */
    protected long f4049e = 0;

    /* renamed from: f */
    protected long f4050f = 0;

    /* renamed from: g */
    protected long f4051g = 0;

    /* renamed from: h */
    protected long f4052h = 0;

    /* renamed from: i */
    protected long f4053i = 0;

    /* renamed from: j */
    protected double f4054j;

    /* renamed from: k */
    protected float f4055k;

    /* renamed from: l */
    protected float f4056l;

    /* renamed from: m */
    protected float f4057m;

    /* renamed from: n */
    protected float f4058n;

    /* renamed from: o */
    protected boolean f4059o = false;

    /* renamed from: p */
    protected DisplayMetrics f4060p;

    /* renamed from: q */
    private double f4061q;

    /* renamed from: r */
    private double f4062r;

    /* renamed from: s */
    private boolean f4063s = false;

    protected C0989ns(Context context) {
        try {
            if (((Boolean) C0354ax.m1551r().mo2079a(ael.f1933bz)).booleanValue()) {
                C0952mi.m5140a();
            } else {
                C0960mq.m5147a();
            }
            this.f4060p = context.getResources().getDisplayMetrics();
        } catch (Throwable unused) {
        }
    }

    /* renamed from: a */
    private final String m5186a(Context context, String str, boolean z, View view, byte[] bArr) {
        C0932lp lpVar;
        int i;
        if (z) {
            try {
                lpVar = mo3107a(context, view);
                this.f4063s = true;
            } catch (UnsupportedEncodingException | GeneralSecurityException unused) {
                i = 7;
                return Integer.toString(i);
            } catch (Throwable unused2) {
                i = 3;
                return Integer.toString(i);
            }
        } else {
            lpVar = mo3108a(context, (C0930ln) null);
        }
        if (lpVar != null) {
            if (lpVar.mo3514f() != 0) {
                return C0952mi.m5137a(lpVar, str);
            }
        }
        return Integer.toString(5);
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public abstract long mo3106a(StackTraceElement[] stackTraceElementArr);

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public abstract C0932lp mo3107a(Context context, View view);

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public abstract C0932lp mo3108a(Context context, C0930ln lnVar);

    /* renamed from: a */
    public final String mo1465a(Context context) {
        if (C1006oi.m5260b()) {
            if (((Boolean) C0354ax.m1551r().mo2079a(ael.f1883bB)).booleanValue()) {
                throw new IllegalStateException("The caller must not be called from the UI thread.");
            }
        }
        return m5186a(context, null, false, null, null);
    }

    /* renamed from: a */
    public final String mo1466a(Context context, String str, View view) {
        return m5186a(context, str, true, view, null);
    }

    /* renamed from: a */
    public final void mo1467a(int i, int i2, int i3) {
        MotionEvent motionEvent;
        MotionEvent motionEvent2 = this.f4045a;
        if (motionEvent2 != null) {
            motionEvent2.recycle();
        }
        DisplayMetrics displayMetrics = this.f4060p;
        if (displayMetrics != null) {
            motionEvent = MotionEvent.obtain(0, (long) i3, 1, ((float) i) * displayMetrics.density, this.f4060p.density * ((float) i2), 0.0f, 0.0f, 0, 0.0f, 0.0f, 0, 0);
        } else {
            motionEvent = null;
        }
        this.f4045a = motionEvent;
        this.f4059o = false;
    }

    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo1468a(android.view.MotionEvent r13) {
        /*
            r12 = this;
            boolean r0 = r12.f4063s
            r1 = 0
            if (r0 == 0) goto L_0x0035
            r2 = 0
            r12.f4050f = r2
            r12.f4049e = r2
            r12.f4048d = r2
            r12.f4047c = r2
            r12.f4051g = r2
            r12.f4053i = r2
            r12.f4052h = r2
            java.util.LinkedList<android.view.MotionEvent> r0 = r12.f4046b
            java.util.Iterator r0 = r0.iterator()
        L_0x001b:
            boolean r2 = r0.hasNext()
            if (r2 == 0) goto L_0x002b
            java.lang.Object r2 = r0.next()
            android.view.MotionEvent r2 = (android.view.MotionEvent) r2
            r2.recycle()
            goto L_0x001b
        L_0x002b:
            java.util.LinkedList<android.view.MotionEvent> r0 = r12.f4046b
            r0.clear()
            r0 = 0
            r12.f4045a = r0
            r12.f4063s = r1
        L_0x0035:
            com.google.android.gms.internal.aeb<java.lang.Boolean> r0 = com.google.android.gms.internal.ael.f1927bt
            com.google.android.gms.internal.aej r2 = com.google.android.gms.ads.internal.C0354ax.m1551r()
            java.lang.Object r0 = r2.mo2079a(r0)
            java.lang.Boolean r0 = (java.lang.Boolean) r0
            boolean r0 = r0.booleanValue()
            if (r0 == 0) goto L_0x0084
            int r0 = r13.getAction()
            switch(r0) {
                case 0: goto L_0x0072;
                case 1: goto L_0x004f;
                case 2: goto L_0x004f;
                default: goto L_0x004e;
            }
        L_0x004e:
            goto L_0x0084
        L_0x004f:
            float r0 = r13.getRawX()
            double r2 = (double) r0
            float r0 = r13.getRawY()
            double r4 = (double) r0
            double r6 = r12.f4061q
            double r6 = r2 - r6
            double r8 = r12.f4062r
            double r8 = r4 - r8
            double r10 = r12.f4054j
            double r6 = r6 * r6
            double r8 = r8 * r8
            double r6 = r6 + r8
            double r6 = java.lang.Math.sqrt(r6)
            double r10 = r10 + r6
            r12.f4054j = r10
            r12.f4061q = r2
            r12.f4062r = r4
            goto L_0x0084
        L_0x0072:
            r2 = 0
            r12.f4054j = r2
            float r0 = r13.getRawX()
            double r2 = (double) r0
            r12.f4061q = r2
            float r0 = r13.getRawY()
            double r2 = (double) r0
            r12.f4062r = r2
        L_0x0084:
            int r0 = r13.getAction()
            r2 = 1
            r4 = 1
            switch(r0) {
                case 0: goto L_0x0121;
                case 1: goto L_0x00eb;
                case 2: goto L_0x0097;
                case 3: goto L_0x0090;
                default: goto L_0x008e;
            }
        L_0x008e:
            goto L_0x0150
        L_0x0090:
            long r0 = r12.f4050f
            long r0 = r0 + r2
            r12.f4050f = r0
            goto L_0x0150
        L_0x0097:
            long r2 = r12.f4048d
            int r0 = r13.getHistorySize()
            int r0 = r0 + r4
            long r5 = (long) r0
            long r2 = r2 + r5
            r12.f4048d = r2
            com.google.android.gms.internal.oh r13 = r12.mo3109b(r13)     // Catch:{ nz -> 0x0150 }
            if (r13 == 0) goto L_0x00b2
            java.lang.Long r0 = r13.f4169d     // Catch:{ nz -> 0x0150 }
            if (r0 == 0) goto L_0x00b2
            java.lang.Long r0 = r13.f4172g     // Catch:{ nz -> 0x0150 }
            if (r0 == 0) goto L_0x00b2
            r0 = r4
            goto L_0x00b3
        L_0x00b2:
            r0 = r1
        L_0x00b3:
            if (r0 == 0) goto L_0x00c7
            long r2 = r12.f4052h     // Catch:{ nz -> 0x0150 }
            java.lang.Long r0 = r13.f4169d     // Catch:{ nz -> 0x0150 }
            long r5 = r0.longValue()     // Catch:{ nz -> 0x0150 }
            java.lang.Long r0 = r13.f4172g     // Catch:{ nz -> 0x0150 }
            long r7 = r0.longValue()     // Catch:{ nz -> 0x0150 }
            long r5 = r5 + r7
            long r2 = r2 + r5
            r12.f4052h = r2     // Catch:{ nz -> 0x0150 }
        L_0x00c7:
            android.util.DisplayMetrics r0 = r12.f4060p     // Catch:{ nz -> 0x0150 }
            if (r0 == 0) goto L_0x00d6
            if (r13 == 0) goto L_0x00d6
            java.lang.Long r0 = r13.f4170e     // Catch:{ nz -> 0x0150 }
            if (r0 == 0) goto L_0x00d6
            java.lang.Long r0 = r13.f4173h     // Catch:{ nz -> 0x0150 }
            if (r0 == 0) goto L_0x00d6
            r1 = r4
        L_0x00d6:
            if (r1 == 0) goto L_0x0150
            long r0 = r12.f4053i     // Catch:{ nz -> 0x0150 }
            java.lang.Long r2 = r13.f4170e     // Catch:{ nz -> 0x0150 }
            long r2 = r2.longValue()     // Catch:{ nz -> 0x0150 }
            java.lang.Long r13 = r13.f4173h     // Catch:{ nz -> 0x0150 }
            long r5 = r13.longValue()     // Catch:{ nz -> 0x0150 }
            long r2 = r2 + r5
            long r0 = r0 + r2
            r12.f4053i = r0     // Catch:{ nz -> 0x0150 }
            goto L_0x0150
        L_0x00eb:
            android.view.MotionEvent r13 = android.view.MotionEvent.obtain(r13)
            r12.f4045a = r13
            java.util.LinkedList<android.view.MotionEvent> r13 = r12.f4046b
            android.view.MotionEvent r0 = r12.f4045a
            r13.add(r0)
            java.util.LinkedList<android.view.MotionEvent> r13 = r12.f4046b
            int r13 = r13.size()
            r0 = 6
            if (r13 <= r0) goto L_0x010c
            java.util.LinkedList<android.view.MotionEvent> r13 = r12.f4046b
            java.lang.Object r13 = r13.remove()
            android.view.MotionEvent r13 = (android.view.MotionEvent) r13
            r13.recycle()
        L_0x010c:
            long r0 = r12.f4049e
            long r0 = r0 + r2
            r12.f4049e = r0
            java.lang.Throwable r13 = new java.lang.Throwable     // Catch:{ nz -> 0x0150 }
            r13.<init>()     // Catch:{ nz -> 0x0150 }
            java.lang.StackTraceElement[] r13 = r13.getStackTrace()     // Catch:{ nz -> 0x0150 }
            long r0 = r12.mo3106a(r13)     // Catch:{ nz -> 0x0150 }
            r12.f4051g = r0     // Catch:{ nz -> 0x0150 }
            goto L_0x0150
        L_0x0121:
            com.google.android.gms.internal.aeb<java.lang.Boolean> r0 = com.google.android.gms.internal.ael.f1928bu
            com.google.android.gms.internal.aej r1 = com.google.android.gms.ads.internal.C0354ax.m1551r()
            java.lang.Object r0 = r1.mo2079a(r0)
            java.lang.Boolean r0 = (java.lang.Boolean) r0
            boolean r0 = r0.booleanValue()
            if (r0 == 0) goto L_0x014b
            float r0 = r13.getX()
            r12.f4055k = r0
            float r0 = r13.getY()
            r12.f4056l = r0
            float r0 = r13.getRawX()
            r12.f4057m = r0
            float r13 = r13.getRawY()
            r12.f4058n = r13
        L_0x014b:
            long r0 = r12.f4047c
            long r0 = r0 + r2
            r12.f4047c = r0
        L_0x0150:
            r12.f4059o = r4
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.C0989ns.mo1468a(android.view.MotionEvent):void");
    }

    /* access modifiers changed from: protected */
    /* renamed from: b */
    public abstract C1005oh mo3109b(MotionEvent motionEvent);
}
