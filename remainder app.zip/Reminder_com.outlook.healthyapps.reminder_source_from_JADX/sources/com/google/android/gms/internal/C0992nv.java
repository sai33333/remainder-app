package com.google.android.gms.internal;

import android.content.Context;
import android.net.Uri;
import android.view.MotionEvent;
import android.view.View;

/* renamed from: com.google.android.gms.internal.nv */
public final class C0992nv {

    /* renamed from: e */
    private static final String[] f4073e = {"/aclk", "/pcs/click"};

    /* renamed from: a */
    private String f4074a = "googleads.g.doubleclick.net";

    /* renamed from: b */
    private String f4075b = "/pagead/ads";

    /* renamed from: c */
    private String f4076c = "ad.doubleclick.net";

    /* renamed from: d */
    private String[] f4077d = {".doubleclick.net", ".googleadservices.com", ".googlesyndication.com"};

    /* renamed from: f */
    private C0988nr f4078f;

    public C0992nv(C0988nr nrVar) {
        this.f4078f = nrVar;
    }

    /* renamed from: a */
    private final Uri m5206a(Uri uri, Context context, String str, boolean z, View view) {
        try {
            boolean c = m5207c(uri);
            if (c) {
                if (uri.toString().contains("dc_ms=")) {
                    throw new C0993nw("Parameter already exists: dc_ms");
                }
            } else if (uri.getQueryParameter("ms") != null) {
                throw new C0993nw("Query parameter already exists: ms");
            }
            String a = z ? this.f4078f.mo1466a(context, str, view) : this.f4078f.mo1465a(context);
            if (c) {
                String str2 = "dc_ms";
                String uri2 = uri.toString();
                int indexOf = uri2.indexOf(";adurl");
                if (indexOf != -1) {
                    int i = indexOf + 1;
                    StringBuilder sb = new StringBuilder(uri2.substring(0, i));
                    sb.append(str2);
                    sb.append("=");
                    sb.append(a);
                    sb.append(";");
                    sb.append(uri2.substring(i));
                    return Uri.parse(sb.toString());
                }
                String encodedPath = uri.getEncodedPath();
                int indexOf2 = uri2.indexOf(encodedPath);
                StringBuilder sb2 = new StringBuilder(uri2.substring(0, encodedPath.length() + indexOf2));
                sb2.append(";");
                sb2.append(str2);
                sb2.append("=");
                sb2.append(a);
                sb2.append(";");
                sb2.append(uri2.substring(indexOf2 + encodedPath.length()));
                return Uri.parse(sb2.toString());
            }
            String str3 = "ms";
            String uri3 = uri.toString();
            int indexOf3 = uri3.indexOf("&adurl");
            if (indexOf3 == -1) {
                indexOf3 = uri3.indexOf("?adurl");
            }
            if (indexOf3 == -1) {
                return uri.buildUpon().appendQueryParameter(str3, a).build();
            }
            int i2 = indexOf3 + 1;
            StringBuilder sb3 = new StringBuilder(uri3.substring(0, i2));
            sb3.append(str3);
            sb3.append("=");
            sb3.append(a);
            sb3.append("&");
            sb3.append(uri3.substring(i2));
            return Uri.parse(sb3.toString());
        } catch (UnsupportedOperationException unused) {
            throw new C0993nw("Provided Uri is not in a valid state");
        }
    }

    /* renamed from: c */
    private final boolean m5207c(Uri uri) {
        if (uri != null) {
            try {
                return uri.getHost().equals(this.f4076c);
            } catch (NullPointerException unused) {
                return false;
            }
        } else {
            throw new NullPointerException();
        }
    }

    /* renamed from: a */
    public final Uri mo3111a(Uri uri, Context context) {
        return m5206a(uri, context, null, false, null);
    }

    /* renamed from: a */
    public final Uri mo3112a(Uri uri, Context context, View view) {
        try {
            return m5206a(uri, context, uri.getQueryParameter("ai"), true, view);
        } catch (UnsupportedOperationException unused) {
            throw new C0993nw("Provided Uri is not in a valid state");
        }
    }

    /* renamed from: a */
    public final C0988nr mo3113a() {
        return this.f4078f;
    }

    /* renamed from: a */
    public final void mo3114a(MotionEvent motionEvent) {
        this.f4078f.mo1468a(motionEvent);
    }

    /* renamed from: a */
    public final boolean mo3115a(Uri uri) {
        if (uri != null) {
            try {
                String host = uri.getHost();
                for (String endsWith : this.f4077d) {
                    if (host.endsWith(endsWith)) {
                        return true;
                    }
                }
            } catch (NullPointerException unused) {
            }
            return false;
        }
        throw new NullPointerException();
    }

    /* renamed from: b */
    public final boolean mo3116b(Uri uri) {
        if (mo3115a(uri)) {
            for (String endsWith : f4073e) {
                if (uri.getPath().endsWith(endsWith)) {
                    return true;
                }
            }
        }
        return false;
    }
}
