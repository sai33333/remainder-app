package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.nw */
public final class C0993nw extends Exception {
    public C0993nw() {
    }

    public C0993nw(String str) {
        super(str);
    }
}
