package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.ny */
public final class C0995ny extends Exception {
    public C0995ny(C0994nx nxVar) {
    }

    public C0995ny(C0994nx nxVar, Throwable th) {
        super(th);
    }
}
