package com.google.android.gms.internal;

import java.util.HashMap;

/* renamed from: com.google.android.gms.internal.ob */
public final class C0999ob extends C0949mf<Integer, Long> {

    /* renamed from: a */
    public Long f4134a;

    /* renamed from: b */
    public Long f4135b;

    public C0999ob() {
    }

    public C0999ob(String str) {
        mo3088a(str);
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public final HashMap<Integer, Long> mo3087a() {
        HashMap<Integer, Long> hashMap = new HashMap<>();
        hashMap.put(Integer.valueOf(0), this.f4134a);
        hashMap.put(Integer.valueOf(1), this.f4135b);
        return hashMap;
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public final void mo3088a(String str) {
        HashMap b = m5129b(str);
        if (b != null) {
            this.f4134a = (Long) b.get(Integer.valueOf(0));
            this.f4135b = (Long) b.get(Integer.valueOf(1));
        }
    }
}
