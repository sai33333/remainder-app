package com.google.android.gms.internal;

import android.os.Process;
import java.util.concurrent.BlockingQueue;

/* renamed from: com.google.android.gms.internal.od */
public final class C1001od extends Thread {

    /* renamed from: a */
    private static final boolean f4155a = C0618ac.f1702a;

    /* renamed from: b */
    private final BlockingQueue<aha<?>> f4156b;
    /* access modifiers changed from: private */

    /* renamed from: c */
    public final BlockingQueue<aha<?>> f4157c;

    /* renamed from: d */
    private final C0936lt f4158d;

    /* renamed from: e */
    private final aoa f4159e;

    /* renamed from: f */
    private volatile boolean f4160f = false;

    public C1001od(BlockingQueue<aha<?>> blockingQueue, BlockingQueue<aha<?>> blockingQueue2, C0936lt ltVar, aoa aoa) {
        this.f4156b = blockingQueue;
        this.f4157c = blockingQueue2;
        this.f4158d = ltVar;
        this.f4159e = aoa;
    }

    /* renamed from: a */
    public final void mo3138a() {
        this.f4160f = true;
        interrupt();
    }

    public final void run() {
        if (f4155a) {
            C0618ac.m2436a("start new dispatcher", new Object[0]);
        }
        Process.setThreadPriority(10);
        this.f4158d.mo2789a();
        while (true) {
            try {
                aha aha = (aha) this.f4156b.take();
                aha.mo2242a("cache-queue-take");
                C0973nc a = this.f4158d.mo2788a(aha.mo2249e());
                if (a == null) {
                    aha.mo2242a("cache-miss");
                } else {
                    if (a.f4024e < System.currentTimeMillis()) {
                        aha.mo2242a("cache-hit-expired");
                        aha.mo2238a(a);
                    } else {
                        aha.mo2242a("cache-hit");
                        alc a2 = aha.mo2239a(new aey(a.f4020a, a.f4026g));
                        aha.mo2242a("cache-hit-parsed");
                        if (!(a.f4025f < System.currentTimeMillis())) {
                            this.f4159e.mo2468a(aha, a2);
                        } else {
                            aha.mo2242a("cache-hit-refresh-needed");
                            aha.mo2238a(a);
                            a2.f2409d = true;
                            this.f4159e.mo2469a(aha, a2, new C1176sm(this, aha));
                        }
                    }
                }
                this.f4157c.put(aha);
            } catch (InterruptedException unused) {
                if (this.f4160f) {
                    return;
                }
            }
        }
    }
}
