package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.og */
final class C1004og implements Runnable {

    /* renamed from: a */
    private /* synthetic */ C1000oc f4165a;

    C1004og(C1000oc ocVar) {
        this.f4165a = ocVar;
    }

    public final void run() {
        ael.m2744a(this.f4165a.f4139a);
    }
}
