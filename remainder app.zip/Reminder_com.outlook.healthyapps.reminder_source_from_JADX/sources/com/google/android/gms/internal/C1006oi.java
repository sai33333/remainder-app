package com.google.android.gms.internal;

import android.os.Looper;
import android.util.DisplayMetrics;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.ByteBuffer;
import java.util.Calendar;
import java.util.TimeZone;
import java.util.UUID;

/* renamed from: com.google.android.gms.internal.oi */
public final class C1006oi {

    /* renamed from: a */
    private static final char[] f4179a = "0123456789abcdef".toCharArray();

    /* renamed from: a */
    public static long m5255a(double d, int i, DisplayMetrics displayMetrics) {
        return Math.round((d * ((double) i)) / ((double) displayMetrics.density));
    }

    /* renamed from: a */
    public static Long m5256a() {
        return Long.valueOf(Calendar.getInstance(TimeZone.getTimeZone("America/Los_Angeles")).getTime().getTime());
    }

    /* renamed from: a */
    public static String m5257a(String str) {
        if (str == null || !str.matches("^[a-fA-F0-9]{8}-([a-fA-F0-9]{4}-){3}[a-fA-F0-9]{12}$")) {
            return str;
        }
        UUID fromString = UUID.fromString(str);
        byte[] bArr = new byte[16];
        ByteBuffer wrap = ByteBuffer.wrap(bArr);
        wrap.putLong(fromString.getMostSignificantBits());
        wrap.putLong(fromString.getLeastSignificantBits());
        return C0950mg.m5132a(bArr, true);
    }

    /* renamed from: a */
    public static String m5258a(Throwable th) {
        StringWriter stringWriter = new StringWriter();
        C1151rp.m5696a(th, new PrintWriter(stringWriter));
        return stringWriter.toString();
    }

    /* renamed from: a */
    public static boolean m5259a(DisplayMetrics displayMetrics) {
        return (displayMetrics == null || displayMetrics.density == 0.0f) ? false : true;
    }

    /* renamed from: b */
    public static boolean m5260b() {
        return Looper.myLooper() == Looper.getMainLooper();
    }

    /* renamed from: b */
    public static boolean m5261b(String str) {
        return str == null || str.isEmpty();
    }
}
