package com.google.android.gms.internal;

import java.io.IOException;

/* renamed from: com.google.android.gms.internal.on */
public final class C1015on {

    /* renamed from: com.google.android.gms.internal.on$a */
    public static final class C1016a extends C1209tq<C1016a, C1017a> implements C1233un {
        /* access modifiers changed from: private */

        /* renamed from: g */
        public static final C1016a f4193g;

        /* renamed from: h */
        private static volatile C1235up<C1016a> f4194h;

        /* renamed from: d */
        private int f4195d;

        /* renamed from: e */
        private C1020c f4196e;

        /* renamed from: f */
        private C1187sx f4197f = C1187sx.f4540a;

        /* renamed from: com.google.android.gms.internal.on$a$a */
        public static final class C1017a extends C1210tr<C1016a, C1017a> implements C1233un {
            private C1017a() {
                super(C1016a.f4193g);
            }

            /* synthetic */ C1017a(C1022oo ooVar) {
                this();
            }

            /* renamed from: a */
            public final C1017a mo3155a(int i) {
                mo3382b();
                ((C1016a) this.f4585a).m5291a(0);
                return this;
            }

            /* renamed from: a */
            public final C1017a mo3156a(C1020c cVar) {
                mo3382b();
                ((C1016a) this.f4585a).m5295a(cVar);
                return this;
            }

            /* renamed from: a */
            public final C1017a mo3157a(C1187sx sxVar) {
                mo3382b();
                ((C1016a) this.f4585a).m5296b(sxVar);
                return this;
            }
        }

        static {
            C1016a aVar = new C1016a();
            f4193g = aVar;
            aVar.mo1909a(C1217ty.f4597d, (Object) null, (Object) null);
            aVar.f4583b.mo3449c();
        }

        private C1016a() {
        }

        /* renamed from: a */
        public static C1016a m5290a(C1187sx sxVar) {
            return (C1016a) C1209tq.m5882a(f4193g, sxVar);
        }

        /* access modifiers changed from: private */
        /* renamed from: a */
        public final void m5291a(int i) {
            this.f4195d = i;
        }

        /* access modifiers changed from: private */
        /* renamed from: a */
        public final void m5295a(C1020c cVar) {
            if (cVar != null) {
                this.f4196e = cVar;
                return;
            }
            throw new NullPointerException();
        }

        /* access modifiers changed from: private */
        /* renamed from: b */
        public final void m5296b(C1187sx sxVar) {
            if (sxVar != null) {
                this.f4197f = sxVar;
                return;
            }
            throw new NullPointerException();
        }

        /* renamed from: e */
        public static C1017a m5297e() {
            C1016a aVar = f4193g;
            C1210tr trVar = (C1210tr) aVar.mo1909a(C1217ty.f4599f, (Object) null, (Object) null);
            trVar.mo3291a(aVar);
            return (C1017a) trVar;
        }

        /* renamed from: f */
        public static C1016a m5298f() {
            return f4193g;
        }

        /* renamed from: a */
        public final int mo3152a() {
            return this.f4195d;
        }

        /* access modifiers changed from: protected */
        /* renamed from: a */
        public final Object mo1909a(int i, Object obj, Object obj2) {
            C1210tr trVar;
            boolean z = false;
            switch (C1022oo.f4205a[i - 1]) {
                case 1:
                    return new C1016a();
                case 2:
                    return f4193g;
                case 3:
                    return null;
                case C1217ty.f4597d /*4*/:
                    return new C1017a(null);
                case C1217ty.f4598e /*5*/:
                    C1218tz tzVar = (C1218tz) obj;
                    C1016a aVar = (C1016a) obj2;
                    this.f4195d = tzVar.mo3386a(this.f4195d != 0, this.f4195d, aVar.f4195d != 0, aVar.f4195d);
                    this.f4196e = (C1020c) tzVar.mo3389a(this.f4196e, aVar.f4196e);
                    boolean z2 = this.f4197f != C1187sx.f4540a;
                    C1187sx sxVar = this.f4197f;
                    if (aVar.f4197f != C1187sx.f4540a) {
                        z = true;
                    }
                    this.f4197f = tzVar.mo3387a(z2, sxVar, z, aVar.f4197f);
                    return this;
                case C1217ty.f4599f /*6*/:
                    C1197tg tgVar = (C1197tg) obj;
                    C1205tm tmVar = (C1205tm) obj2;
                    while (!z) {
                        try {
                            int a = tgVar.mo3333a();
                            if (a != 0) {
                                if (a == 8) {
                                    this.f4195d = tgVar.mo3343g();
                                } else if (a == 18) {
                                    if (this.f4196e != null) {
                                        C1020c cVar = this.f4196e;
                                        C1210tr trVar2 = (C1210tr) cVar.mo1909a(C1217ty.f4599f, (Object) null, (Object) null);
                                        trVar2.mo3291a(cVar);
                                        trVar = (C1021a) trVar2;
                                    } else {
                                        trVar = null;
                                    }
                                    this.f4196e = (C1020c) tgVar.mo3334a(C1020c.m5317b(), tmVar);
                                    if (trVar != null) {
                                        trVar.mo3291a(this.f4196e);
                                        this.f4196e = (C1020c) trVar.mo3383c();
                                    }
                                } else if (a == 26) {
                                    this.f4197f = tgVar.mo3342f();
                                } else if (!mo3375a(a, tgVar)) {
                                }
                            }
                            z = true;
                        } catch (C1224ue e) {
                            throw new RuntimeException(e.mo3395a(this));
                        } catch (IOException e2) {
                            throw new RuntimeException(new C1224ue(e2.getMessage()).mo3395a(this));
                        }
                    }
                    break;
                case C1217ty.f4600g /*7*/:
                    break;
                case C1217ty.f4601h /*8*/:
                    if (f4194h == null) {
                        synchronized (C1016a.class) {
                            if (f4194h == null) {
                                f4194h = new C1211ts(f4193g);
                            }
                        }
                    }
                    return f4194h;
                default:
                    throw new UnsupportedOperationException();
            }
            return f4193g;
        }

        /* renamed from: a */
        public final void mo1910a(C1200tj tjVar) {
            int i = this.f4195d;
            if (i != 0) {
                tjVar.mo3367c(1, i);
            }
            C1020c cVar = this.f4196e;
            if (cVar != null) {
                if (cVar == null) {
                    cVar = C1020c.m5317b();
                }
                tjVar.mo3353a(2, (C1231ul) cVar);
            }
            if (!this.f4197f.mo3316b()) {
                tjVar.mo3352a(3, this.f4197f);
            }
            this.f4583b.mo3446a(tjVar);
        }

        /* renamed from: b */
        public final C1020c mo3153b() {
            C1020c cVar = this.f4196e;
            return cVar == null ? C1020c.m5317b() : cVar;
        }

        /* renamed from: c */
        public final C1187sx mo3154c() {
            return this.f4197f;
        }

        /* renamed from: d */
        public final int mo1911d() {
            int i = this.f4584c;
            if (i != -1) {
                return i;
            }
            int i2 = this.f4195d;
            int i3 = 0;
            if (i2 != 0) {
                i3 = 0 + C1200tj.m5827e(1, i2);
            }
            C1020c cVar = this.f4196e;
            if (cVar != null) {
                if (cVar == null) {
                    cVar = C1020c.m5317b();
                }
                i3 += C1200tj.m5819b(2, (C1231ul) cVar);
            }
            if (!this.f4197f.mo3316b()) {
                i3 += C1200tj.m5818b(3, this.f4197f);
            }
            int d = i3 + this.f4583b.mo3450d();
            this.f4584c = d;
            return d;
        }
    }

    /* renamed from: com.google.android.gms.internal.on$b */
    public static final class C1018b extends C1209tq<C1018b, C1019a> implements C1233un {
        /* access modifiers changed from: private */

        /* renamed from: f */
        public static final C1018b f4198f;

        /* renamed from: g */
        private static volatile C1235up<C1018b> f4199g;

        /* renamed from: d */
        private C1020c f4200d;

        /* renamed from: e */
        private int f4201e;

        /* renamed from: com.google.android.gms.internal.on$b$a */
        public static final class C1019a extends C1210tr<C1018b, C1019a> implements C1233un {
            private C1019a() {
                super(C1018b.f4198f);
            }

            /* synthetic */ C1019a(C1022oo ooVar) {
                this();
            }
        }

        static {
            C1018b bVar = new C1018b();
            f4198f = bVar;
            bVar.mo1909a(C1217ty.f4597d, (Object) null, (Object) null);
            bVar.f4583b.mo3449c();
        }

        private C1018b() {
        }

        /* renamed from: a */
        public static C1018b m5309a(C1187sx sxVar) {
            return (C1018b) C1209tq.m5882a(f4198f, sxVar);
        }

        /* renamed from: c */
        public static C1018b m5310c() {
            return f4198f;
        }

        /* renamed from: a */
        public final C1020c mo3158a() {
            C1020c cVar = this.f4200d;
            return cVar == null ? C1020c.m5317b() : cVar;
        }

        /* access modifiers changed from: protected */
        /* renamed from: a */
        public final Object mo1909a(int i, Object obj, Object obj2) {
            C1210tr trVar;
            boolean z = false;
            switch (C1022oo.f4205a[i - 1]) {
                case 1:
                    return new C1018b();
                case 2:
                    return f4198f;
                case 3:
                    return null;
                case C1217ty.f4597d /*4*/:
                    return new C1019a(null);
                case C1217ty.f4598e /*5*/:
                    C1218tz tzVar = (C1218tz) obj;
                    C1018b bVar = (C1018b) obj2;
                    this.f4200d = (C1020c) tzVar.mo3389a(this.f4200d, bVar.f4200d);
                    boolean z2 = this.f4201e != 0;
                    int i2 = this.f4201e;
                    if (bVar.f4201e != 0) {
                        z = true;
                    }
                    this.f4201e = tzVar.mo3386a(z2, i2, z, bVar.f4201e);
                    return this;
                case C1217ty.f4599f /*6*/:
                    C1197tg tgVar = (C1197tg) obj;
                    C1205tm tmVar = (C1205tm) obj2;
                    while (!z) {
                        try {
                            int a = tgVar.mo3333a();
                            if (a != 0) {
                                if (a == 10) {
                                    if (this.f4200d != null) {
                                        C1020c cVar = this.f4200d;
                                        C1210tr trVar2 = (C1210tr) cVar.mo1909a(C1217ty.f4599f, (Object) null, (Object) null);
                                        trVar2.mo3291a(cVar);
                                        trVar = (C1021a) trVar2;
                                    } else {
                                        trVar = null;
                                    }
                                    this.f4200d = (C1020c) tgVar.mo3334a(C1020c.m5317b(), tmVar);
                                    if (trVar != null) {
                                        trVar.mo3291a(this.f4200d);
                                        this.f4200d = (C1020c) trVar.mo3383c();
                                    }
                                } else if (a == 16) {
                                    this.f4201e = tgVar.mo3343g();
                                } else if (!mo3375a(a, tgVar)) {
                                }
                            }
                            z = true;
                        } catch (C1224ue e) {
                            throw new RuntimeException(e.mo3395a(this));
                        } catch (IOException e2) {
                            throw new RuntimeException(new C1224ue(e2.getMessage()).mo3395a(this));
                        }
                    }
                    break;
                case C1217ty.f4600g /*7*/:
                    break;
                case C1217ty.f4601h /*8*/:
                    if (f4199g == null) {
                        synchronized (C1018b.class) {
                            if (f4199g == null) {
                                f4199g = new C1211ts(f4198f);
                            }
                        }
                    }
                    return f4199g;
                default:
                    throw new UnsupportedOperationException();
            }
            return f4198f;
        }

        /* renamed from: a */
        public final void mo1910a(C1200tj tjVar) {
            C1020c cVar = this.f4200d;
            if (cVar != null) {
                if (cVar == null) {
                    cVar = C1020c.m5317b();
                }
                tjVar.mo3353a(1, (C1231ul) cVar);
            }
            int i = this.f4201e;
            if (i != 0) {
                tjVar.mo3367c(2, i);
            }
            this.f4583b.mo3446a(tjVar);
        }

        /* renamed from: b */
        public final int mo3159b() {
            return this.f4201e;
        }

        /* renamed from: d */
        public final int mo1911d() {
            int i = this.f4584c;
            if (i != -1) {
                return i;
            }
            C1020c cVar = this.f4200d;
            int i2 = 0;
            if (cVar != null) {
                if (cVar == null) {
                    cVar = C1020c.m5317b();
                }
                i2 = 0 + C1200tj.m5819b(1, (C1231ul) cVar);
            }
            int i3 = this.f4201e;
            if (i3 != 0) {
                i2 += C1200tj.m5827e(2, i3);
            }
            int d = i2 + this.f4583b.mo3450d();
            this.f4584c = d;
            return d;
        }
    }

    /* renamed from: com.google.android.gms.internal.on$c */
    public static final class C1020c extends C1209tq<C1020c, C1021a> implements C1233un {
        /* access modifiers changed from: private */

        /* renamed from: e */
        public static final C1020c f4202e;

        /* renamed from: f */
        private static volatile C1235up<C1020c> f4203f;

        /* renamed from: d */
        private int f4204d;

        /* renamed from: com.google.android.gms.internal.on$c$a */
        public static final class C1021a extends C1210tr<C1020c, C1021a> implements C1233un {
            private C1021a() {
                super(C1020c.f4202e);
            }

            /* synthetic */ C1021a(C1022oo ooVar) {
                this();
            }
        }

        static {
            C1020c cVar = new C1020c();
            f4202e = cVar;
            cVar.mo1909a(C1217ty.f4597d, (Object) null, (Object) null);
            cVar.f4583b.mo3449c();
        }

        private C1020c() {
        }

        /* renamed from: b */
        public static C1020c m5317b() {
            return f4202e;
        }

        /* renamed from: a */
        public final int mo3160a() {
            return this.f4204d;
        }

        /* access modifiers changed from: protected */
        /* renamed from: a */
        public final Object mo1909a(int i, Object obj, Object obj2) {
            boolean z = true;
            boolean z2 = false;
            switch (C1022oo.f4205a[i - 1]) {
                case 1:
                    return new C1020c();
                case 2:
                    return f4202e;
                case 3:
                    return null;
                case C1217ty.f4597d /*4*/:
                    return new C1021a(null);
                case C1217ty.f4598e /*5*/:
                    C1218tz tzVar = (C1218tz) obj;
                    C1020c cVar = (C1020c) obj2;
                    boolean z3 = this.f4204d != 0;
                    int i2 = this.f4204d;
                    if (cVar.f4204d == 0) {
                        z = false;
                    }
                    this.f4204d = tzVar.mo3386a(z3, i2, z, cVar.f4204d);
                    return this;
                case C1217ty.f4599f /*6*/:
                    C1197tg tgVar = (C1197tg) obj;
                    while (!z2) {
                        try {
                            int a = tgVar.mo3333a();
                            if (a != 0) {
                                if (a == 8) {
                                    this.f4204d = tgVar.mo3343g();
                                } else if (!mo3375a(a, tgVar)) {
                                }
                            }
                            z2 = true;
                        } catch (C1224ue e) {
                            throw new RuntimeException(e.mo3395a(this));
                        } catch (IOException e2) {
                            throw new RuntimeException(new C1224ue(e2.getMessage()).mo3395a(this));
                        }
                    }
                    break;
                case C1217ty.f4600g /*7*/:
                    break;
                case C1217ty.f4601h /*8*/:
                    if (f4203f == null) {
                        synchronized (C1020c.class) {
                            if (f4203f == null) {
                                f4203f = new C1211ts(f4202e);
                            }
                        }
                    }
                    return f4203f;
                default:
                    throw new UnsupportedOperationException();
            }
            return f4202e;
        }

        /* renamed from: a */
        public final void mo1910a(C1200tj tjVar) {
            int i = this.f4204d;
            if (i != 0) {
                tjVar.mo3367c(1, i);
            }
            this.f4583b.mo3446a(tjVar);
        }

        /* renamed from: d */
        public final int mo1911d() {
            int i = this.f4584c;
            if (i != -1) {
                return i;
            }
            int i2 = this.f4204d;
            int i3 = 0;
            if (i2 != 0) {
                i3 = 0 + C1200tj.m5827e(1, i2);
            }
            int d = i3 + this.f4583b.mo3450d();
            this.f4584c = d;
            return d;
        }
    }
}
