package com.google.android.gms.internal;

import com.google.android.gms.C0276a.C0278b;

/* renamed from: com.google.android.gms.internal.ov */
public enum C1041ov implements C1221ub {
    UNKNOWN_CURVE(0),
    NIST_P224(1),
    NIST_P256(2),
    NIST_P384(3),
    NIST_P521(4),
    UNRECOGNIZED(-1);
    

    /* renamed from: g */
    private static final C1222uc<C1041ov> f4244g = null;

    /* renamed from: h */
    private final int f4246h;

    static {
        f4244g = new C1043ox();
    }

    private C1041ov(int i) {
        this.f4246h = i;
    }

    /* renamed from: a */
    public static C1041ov m5385a(int i) {
        switch (i) {
            case C0278b.AdsAttrs_adSize /*0*/:
                return UNKNOWN_CURVE;
            case 1:
                return NIST_P224;
            case 2:
                return NIST_P256;
            case 3:
                return NIST_P384;
            case C1217ty.f4597d /*4*/:
                return NIST_P521;
            default:
                return null;
        }
    }

    /* renamed from: a */
    public final int mo3178a() {
        if (this != UNRECOGNIZED) {
            return this.f4246h;
        }
        throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
    }
}
