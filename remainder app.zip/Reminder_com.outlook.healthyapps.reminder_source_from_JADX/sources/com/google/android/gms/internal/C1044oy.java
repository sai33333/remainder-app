package com.google.android.gms.internal;

import com.google.android.gms.C0276a.C0278b;

/* renamed from: com.google.android.gms.internal.oy */
public enum C1044oy implements C1221ub {
    UNKNOWN_HASH(0),
    SHA1(1),
    SHA224(2),
    SHA256(3),
    SHA512(4),
    UNRECOGNIZED(-1);
    

    /* renamed from: g */
    private static final C1222uc<C1044oy> f4253g = null;

    /* renamed from: h */
    private final int f4255h;

    static {
        f4253g = new C1045oz();
    }

    private C1044oy(int i) {
        this.f4255h = i;
    }

    /* renamed from: a */
    public static C1044oy m5388a(int i) {
        switch (i) {
            case C0278b.AdsAttrs_adSize /*0*/:
                return UNKNOWN_HASH;
            case 1:
                return SHA1;
            case 2:
                return SHA224;
            case 3:
                return SHA256;
            case C1217ty.f4597d /*4*/:
                return SHA512;
            default:
                return null;
        }
    }

    /* renamed from: a */
    public final int mo3180a() {
        if (this != UNRECOGNIZED) {
            return this.f4255h;
        }
        throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
    }
}
