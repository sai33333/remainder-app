package com.google.android.gms.internal;

import com.google.android.gms.internal.C1083pq.C1086b;

/* renamed from: com.google.android.gms.internal.ph */
public interface C1068ph<P> {
    /* renamed from: a */
    P mo3205a(C1187sx sxVar);

    /* renamed from: a */
    P mo3206a(C1231ul ulVar);

    /* renamed from: a */
    String mo3207a();

    /* renamed from: b */
    C1231ul mo3208b(C1187sx sxVar);

    /* renamed from: b */
    C1231ul mo3209b(C1231ul ulVar);

    /* renamed from: c */
    C1086b mo3210c(C1187sx sxVar);
}
