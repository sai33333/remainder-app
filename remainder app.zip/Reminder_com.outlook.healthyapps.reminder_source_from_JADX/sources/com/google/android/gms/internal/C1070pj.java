package com.google.android.gms.internal;

import com.google.android.gms.internal.C1083pq.C1086b;
import com.google.android.gms.internal.C1083pq.C1086b.C1087a;
import com.google.android.gms.internal.C1083pq.C1089c;
import com.google.android.gms.internal.C1083pq.C1089c.C1090a;
import java.io.IOException;

/* renamed from: com.google.android.gms.internal.pj */
public final class C1070pj {

    /* renamed from: com.google.android.gms.internal.pj$a */
    public static final class C1071a extends C1209tq<C1071a, C1072a> implements C1233un {
        /* access modifiers changed from: private */

        /* renamed from: f */
        public static final C1071a f4294f;

        /* renamed from: g */
        private static volatile C1235up<C1071a> f4295g;

        /* renamed from: d */
        private int f4296d;

        /* renamed from: e */
        private C1075c f4297e;

        /* renamed from: com.google.android.gms.internal.pj$a$a */
        public static final class C1072a extends C1210tr<C1071a, C1072a> implements C1233un {
            private C1072a() {
                super(C1071a.f4294f);
            }

            /* synthetic */ C1072a(C1077pk pkVar) {
                this();
            }

            /* renamed from: a */
            public final C1072a mo3215a(int i) {
                mo3382b();
                ((C1071a) this.f4585a).m5465a(0);
                return this;
            }

            /* renamed from: a */
            public final C1072a mo3216a(C1075c cVar) {
                mo3382b();
                ((C1071a) this.f4585a).m5468a(cVar);
                return this;
            }
        }

        static {
            C1071a aVar = new C1071a();
            f4294f = aVar;
            aVar.mo1909a(C1217ty.f4597d, (Object) null, (Object) null);
            aVar.f4583b.mo3449c();
        }

        private C1071a() {
        }

        /* renamed from: a */
        public static C1071a m5464a(C1187sx sxVar) {
            return (C1071a) C1209tq.m5882a(f4294f, sxVar);
        }

        /* access modifiers changed from: private */
        /* renamed from: a */
        public final void m5465a(int i) {
            this.f4296d = i;
        }

        /* access modifiers changed from: private */
        /* renamed from: a */
        public final void m5468a(C1075c cVar) {
            if (cVar != null) {
                this.f4297e = cVar;
                return;
            }
            throw new NullPointerException();
        }

        /* renamed from: c */
        public static C1072a m5469c() {
            C1071a aVar = f4294f;
            C1210tr trVar = (C1210tr) aVar.mo1909a(C1217ty.f4599f, (Object) null, (Object) null);
            trVar.mo3291a(aVar);
            return (C1072a) trVar;
        }

        /* renamed from: a */
        public final int mo3213a() {
            return this.f4296d;
        }

        /* access modifiers changed from: protected */
        /* renamed from: a */
        public final Object mo1909a(int i, Object obj, Object obj2) {
            C1210tr trVar;
            boolean z = false;
            switch (C1077pk.f4305a[i - 1]) {
                case 1:
                    return new C1071a();
                case 2:
                    return f4294f;
                case 3:
                    return null;
                case C1217ty.f4597d /*4*/:
                    return new C1072a(null);
                case C1217ty.f4598e /*5*/:
                    C1218tz tzVar = (C1218tz) obj;
                    C1071a aVar = (C1071a) obj2;
                    boolean z2 = this.f4296d != 0;
                    int i2 = this.f4296d;
                    if (aVar.f4296d != 0) {
                        z = true;
                    }
                    this.f4296d = tzVar.mo3386a(z2, i2, z, aVar.f4296d);
                    this.f4297e = (C1075c) tzVar.mo3389a(this.f4297e, aVar.f4297e);
                    return this;
                case C1217ty.f4599f /*6*/:
                    C1197tg tgVar = (C1197tg) obj;
                    C1205tm tmVar = (C1205tm) obj2;
                    while (!z) {
                        try {
                            int a = tgVar.mo3333a();
                            if (a != 0) {
                                if (a == 8) {
                                    this.f4296d = tgVar.mo3343g();
                                } else if (a == 18) {
                                    if (this.f4297e != null) {
                                        C1075c cVar = this.f4297e;
                                        C1210tr trVar2 = (C1210tr) cVar.mo1909a(C1217ty.f4599f, (Object) null, (Object) null);
                                        trVar2.mo3291a(cVar);
                                        trVar = (C1076a) trVar2;
                                    } else {
                                        trVar = null;
                                    }
                                    this.f4297e = (C1075c) tgVar.mo3334a(C1075c.m5484c(), tmVar);
                                    if (trVar != null) {
                                        trVar.mo3291a(this.f4297e);
                                        this.f4297e = (C1075c) trVar.mo3383c();
                                    }
                                } else if (!mo3375a(a, tgVar)) {
                                }
                            }
                            z = true;
                        } catch (C1224ue e) {
                            throw new RuntimeException(e.mo3395a(this));
                        } catch (IOException e2) {
                            throw new RuntimeException(new C1224ue(e2.getMessage()).mo3395a(this));
                        }
                    }
                    break;
                case C1217ty.f4600g /*7*/:
                    break;
                case C1217ty.f4601h /*8*/:
                    if (f4295g == null) {
                        synchronized (C1071a.class) {
                            if (f4295g == null) {
                                f4295g = new C1211ts(f4294f);
                            }
                        }
                    }
                    return f4295g;
                default:
                    throw new UnsupportedOperationException();
            }
            return f4294f;
        }

        /* renamed from: a */
        public final void mo1910a(C1200tj tjVar) {
            int i = this.f4296d;
            if (i != 0) {
                tjVar.mo3367c(1, i);
            }
            C1075c cVar = this.f4297e;
            if (cVar != null) {
                if (cVar == null) {
                    cVar = C1075c.m5484c();
                }
                tjVar.mo3353a(2, (C1231ul) cVar);
            }
            this.f4583b.mo3446a(tjVar);
        }

        /* renamed from: b */
        public final C1075c mo3214b() {
            C1075c cVar = this.f4297e;
            return cVar == null ? C1075c.m5484c() : cVar;
        }

        /* renamed from: d */
        public final int mo1911d() {
            int i = this.f4584c;
            if (i != -1) {
                return i;
            }
            int i2 = this.f4296d;
            int i3 = 0;
            if (i2 != 0) {
                i3 = 0 + C1200tj.m5827e(1, i2);
            }
            C1075c cVar = this.f4297e;
            if (cVar != null) {
                if (cVar == null) {
                    cVar = C1075c.m5484c();
                }
                i3 += C1200tj.m5819b(2, (C1231ul) cVar);
            }
            int d = i3 + this.f4583b.mo3450d();
            this.f4584c = d;
            return d;
        }
    }

    /* renamed from: com.google.android.gms.internal.pj$b */
    public static final class C1073b extends C1209tq<C1073b, C1074a> implements C1233un {
        /* access modifiers changed from: private */

        /* renamed from: e */
        public static final C1073b f4298e;

        /* renamed from: f */
        private static volatile C1235up<C1073b> f4299f;

        /* renamed from: d */
        private C1075c f4300d;

        /* renamed from: com.google.android.gms.internal.pj$b$a */
        public static final class C1074a extends C1210tr<C1073b, C1074a> implements C1233un {
            private C1074a() {
                super(C1073b.f4298e);
            }

            /* synthetic */ C1074a(C1077pk pkVar) {
                this();
            }
        }

        static {
            C1073b bVar = new C1073b();
            f4298e = bVar;
            bVar.mo1909a(C1217ty.f4597d, (Object) null, (Object) null);
            bVar.f4583b.mo3449c();
        }

        private C1073b() {
        }

        /* renamed from: a */
        public static C1073b m5478a(C1187sx sxVar) {
            return (C1073b) C1209tq.m5882a(f4298e, sxVar);
        }

        /* renamed from: a */
        public final C1075c mo3217a() {
            C1075c cVar = this.f4300d;
            return cVar == null ? C1075c.m5484c() : cVar;
        }

        /* access modifiers changed from: protected */
        /* renamed from: a */
        public final Object mo1909a(int i, Object obj, Object obj2) {
            C1210tr trVar;
            switch (C1077pk.f4305a[i - 1]) {
                case 1:
                    return new C1073b();
                case 2:
                    return f4298e;
                case 3:
                    return null;
                case C1217ty.f4597d /*4*/:
                    return new C1074a(null);
                case C1217ty.f4598e /*5*/:
                    this.f4300d = (C1075c) ((C1218tz) obj).mo3389a(this.f4300d, ((C1073b) obj2).f4300d);
                    return this;
                case C1217ty.f4599f /*6*/:
                    C1197tg tgVar = (C1197tg) obj;
                    C1205tm tmVar = (C1205tm) obj2;
                    boolean z = false;
                    while (!z) {
                        try {
                            int a = tgVar.mo3333a();
                            if (a != 0) {
                                if (a == 10) {
                                    if (this.f4300d != null) {
                                        C1075c cVar = this.f4300d;
                                        C1210tr trVar2 = (C1210tr) cVar.mo1909a(C1217ty.f4599f, (Object) null, (Object) null);
                                        trVar2.mo3291a(cVar);
                                        trVar = (C1076a) trVar2;
                                    } else {
                                        trVar = null;
                                    }
                                    this.f4300d = (C1075c) tgVar.mo3334a(C1075c.m5484c(), tmVar);
                                    if (trVar != null) {
                                        trVar.mo3291a(this.f4300d);
                                        this.f4300d = (C1075c) trVar.mo3383c();
                                    }
                                } else if (!mo3375a(a, tgVar)) {
                                }
                            }
                            z = true;
                        } catch (C1224ue e) {
                            throw new RuntimeException(e.mo3395a(this));
                        } catch (IOException e2) {
                            throw new RuntimeException(new C1224ue(e2.getMessage()).mo3395a(this));
                        }
                    }
                    break;
                case C1217ty.f4600g /*7*/:
                    break;
                case C1217ty.f4601h /*8*/:
                    if (f4299f == null) {
                        synchronized (C1073b.class) {
                            if (f4299f == null) {
                                f4299f = new C1211ts(f4298e);
                            }
                        }
                    }
                    return f4299f;
                default:
                    throw new UnsupportedOperationException();
            }
            return f4298e;
        }

        /* renamed from: a */
        public final void mo1910a(C1200tj tjVar) {
            C1075c cVar = this.f4300d;
            if (cVar != null) {
                if (cVar == null) {
                    cVar = C1075c.m5484c();
                }
                tjVar.mo3353a(1, (C1231ul) cVar);
            }
            this.f4583b.mo3446a(tjVar);
        }

        /* renamed from: d */
        public final int mo1911d() {
            int i = this.f4584c;
            if (i != -1) {
                return i;
            }
            C1075c cVar = this.f4300d;
            int i2 = 0;
            if (cVar != null) {
                if (cVar == null) {
                    cVar = C1075c.m5484c();
                }
                i2 = 0 + C1200tj.m5819b(1, (C1231ul) cVar);
            }
            int d = i2 + this.f4583b.mo3450d();
            this.f4584c = d;
            return d;
        }
    }

    /* renamed from: com.google.android.gms.internal.pj$c */
    public static final class C1075c extends C1209tq<C1075c, C1076a> implements C1233un {
        /* access modifiers changed from: private */

        /* renamed from: f */
        public static final C1075c f4301f;

        /* renamed from: g */
        private static volatile C1235up<C1075c> f4302g;

        /* renamed from: d */
        private C1086b f4303d;

        /* renamed from: e */
        private C1089c f4304e;

        /* renamed from: com.google.android.gms.internal.pj$c$a */
        public static final class C1076a extends C1210tr<C1075c, C1076a> implements C1233un {
            private C1076a() {
                super(C1075c.f4301f);
            }

            /* synthetic */ C1076a(C1077pk pkVar) {
                this();
            }
        }

        static {
            C1075c cVar = new C1075c();
            f4301f = cVar;
            cVar.mo1909a(C1217ty.f4597d, (Object) null, (Object) null);
            cVar.f4583b.mo3449c();
        }

        private C1075c() {
        }

        /* renamed from: c */
        public static C1075c m5484c() {
            return f4301f;
        }

        /* renamed from: a */
        public final C1086b mo3218a() {
            C1086b bVar = this.f4303d;
            return bVar == null ? C1086b.m5519f() : bVar;
        }

        /* access modifiers changed from: protected */
        /* renamed from: a */
        public final Object mo1909a(int i, Object obj, Object obj2) {
            C1210tr trVar;
            C1210tr trVar2;
            switch (C1077pk.f4305a[i - 1]) {
                case 1:
                    return new C1075c();
                case 2:
                    return f4301f;
                case 3:
                    return null;
                case C1217ty.f4597d /*4*/:
                    return new C1076a(null);
                case C1217ty.f4598e /*5*/:
                    C1218tz tzVar = (C1218tz) obj;
                    C1075c cVar = (C1075c) obj2;
                    this.f4303d = (C1086b) tzVar.mo3389a(this.f4303d, cVar.f4303d);
                    this.f4304e = (C1089c) tzVar.mo3389a(this.f4304e, cVar.f4304e);
                    return this;
                case C1217ty.f4599f /*6*/:
                    C1197tg tgVar = (C1197tg) obj;
                    C1205tm tmVar = (C1205tm) obj2;
                    boolean z = false;
                    while (!z) {
                        try {
                            int a = tgVar.mo3333a();
                            if (a != 0) {
                                if (a == 10) {
                                    if (this.f4303d != null) {
                                        C1086b bVar = this.f4303d;
                                        C1210tr trVar3 = (C1210tr) bVar.mo1909a(C1217ty.f4599f, (Object) null, (Object) null);
                                        trVar3.mo3291a(bVar);
                                        trVar = (C1087a) trVar3;
                                    } else {
                                        trVar = null;
                                    }
                                    this.f4303d = (C1086b) tgVar.mo3334a(C1086b.m5519f(), tmVar);
                                    if (trVar != null) {
                                        trVar.mo3291a(this.f4303d);
                                        this.f4303d = (C1086b) trVar.mo3383c();
                                    }
                                } else if (a == 18) {
                                    if (this.f4304e != null) {
                                        C1089c cVar2 = this.f4304e;
                                        C1210tr trVar4 = (C1210tr) cVar2.mo1909a(C1217ty.f4599f, (Object) null, (Object) null);
                                        trVar4.mo3291a(cVar2);
                                        trVar2 = (C1090a) trVar4;
                                    } else {
                                        trVar2 = null;
                                    }
                                    this.f4304e = (C1089c) tgVar.mo3334a(C1089c.m5532c(), tmVar);
                                    if (trVar2 != null) {
                                        trVar2.mo3291a(this.f4304e);
                                        this.f4304e = (C1089c) trVar2.mo3383c();
                                    }
                                } else if (!mo3375a(a, tgVar)) {
                                }
                            }
                            z = true;
                        } catch (C1224ue e) {
                            throw new RuntimeException(e.mo3395a(this));
                        } catch (IOException e2) {
                            throw new RuntimeException(new C1224ue(e2.getMessage()).mo3395a(this));
                        }
                    }
                    break;
                case C1217ty.f4600g /*7*/:
                    break;
                case C1217ty.f4601h /*8*/:
                    if (f4302g == null) {
                        synchronized (C1075c.class) {
                            if (f4302g == null) {
                                f4302g = new C1211ts(f4301f);
                            }
                        }
                    }
                    return f4302g;
                default:
                    throw new UnsupportedOperationException();
            }
            return f4301f;
        }

        /* renamed from: a */
        public final void mo1910a(C1200tj tjVar) {
            C1086b bVar = this.f4303d;
            if (bVar != null) {
                if (bVar == null) {
                    bVar = C1086b.m5519f();
                }
                tjVar.mo3353a(1, (C1231ul) bVar);
            }
            C1089c cVar = this.f4304e;
            if (cVar != null) {
                if (cVar == null) {
                    cVar = C1089c.m5532c();
                }
                tjVar.mo3353a(2, (C1231ul) cVar);
            }
            this.f4583b.mo3446a(tjVar);
        }

        /* renamed from: b */
        public final C1089c mo3219b() {
            C1089c cVar = this.f4304e;
            return cVar == null ? C1089c.m5532c() : cVar;
        }

        /* renamed from: d */
        public final int mo1911d() {
            int i = this.f4584c;
            if (i != -1) {
                return i;
            }
            C1086b bVar = this.f4303d;
            int i2 = 0;
            if (bVar != null) {
                if (bVar == null) {
                    bVar = C1086b.m5519f();
                }
                i2 = 0 + C1200tj.m5819b(1, (C1231ul) bVar);
            }
            C1089c cVar = this.f4304e;
            if (cVar != null) {
                if (cVar == null) {
                    cVar = C1089c.m5532c();
                }
                i2 += C1200tj.m5819b(2, (C1231ul) cVar);
            }
            int d = i2 + this.f4583b.mo3450d();
            this.f4584c = d;
            return d;
        }
    }
}
