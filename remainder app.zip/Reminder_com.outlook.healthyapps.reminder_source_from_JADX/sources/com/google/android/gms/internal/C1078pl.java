package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.pl */
public interface C1078pl {
    /* renamed from: a */
    byte[] mo3220a(byte[] bArr);
}
