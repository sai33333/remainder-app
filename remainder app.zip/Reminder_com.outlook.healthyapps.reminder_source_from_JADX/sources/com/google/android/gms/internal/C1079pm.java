package com.google.android.gms.internal;

import com.google.android.gms.internal.C1083pq.C1086b.C1088b;
import com.google.android.gms.internal.C1083pq.C1091d;
import com.google.android.gms.internal.C1083pq.C1091d.C1093b;
import java.security.GeneralSecurityException;

/* renamed from: com.google.android.gms.internal.pm */
public final class C1079pm {
    /* renamed from: a */
    public static final C1069pi m5492a(byte[] bArr) {
        try {
            C1091d a = C1091d.m5539a(bArr);
            C1069pi.m5462a(a);
            for (C1093b bVar : a.mo3244b()) {
                if (bVar.mo3247b().mo3236c() == C1088b.UNKNOWN_KEYMATERIAL || bVar.mo3247b().mo3236c() == C1088b.SYMMETRIC || bVar.mo3247b().mo3236c() == C1088b.ASYMMETRIC_PRIVATE) {
                    throw new GeneralSecurityException("keyset contains secret key material");
                }
            }
            C1069pi.m5462a(a);
            return new C1069pi(a);
        } catch (C1224ue unused) {
            throw new GeneralSecurityException("invalid keyset");
        }
    }
}
