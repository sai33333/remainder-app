package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.pr */
final /* synthetic */ class C1099pr {

    /* renamed from: a */
    static final /* synthetic */ int[] f4359a = new int[C1217ty.m5920a().length];

    /* JADX WARNING: Can't wrap try/catch for region: R(16:0|1|2|3|4|5|6|7|8|9|10|11|12|13|14|(3:15|16|18)) */
    /* JADX WARNING: Can't wrap try/catch for region: R(18:0|1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|18) */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:11:0x0031 */
    /* JADX WARNING: Missing exception handler attribute for start block: B:13:0x0039 */
    /* JADX WARNING: Missing exception handler attribute for start block: B:15:0x0041 */
    /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0011 */
    /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x0019 */
    /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x0021 */
    /* JADX WARNING: Missing exception handler attribute for start block: B:9:0x0029 */
    static {
        /*
            int[] r0 = com.google.android.gms.internal.C1217ty.m5920a()
            int r0 = r0.length
            int[] r0 = new int[r0]
            f4359a = r0
            r0 = 1
            int[] r1 = f4359a     // Catch:{ NoSuchFieldError -> 0x0011 }
            int r2 = com.google.android.gms.internal.C1217ty.f4598e     // Catch:{ NoSuchFieldError -> 0x0011 }
            int r2 = r2 - r0
            r1[r2] = r0     // Catch:{ NoSuchFieldError -> 0x0011 }
        L_0x0011:
            int[] r1 = f4359a     // Catch:{ NoSuchFieldError -> 0x0019 }
            int r2 = com.google.android.gms.internal.C1217ty.f4594a     // Catch:{ NoSuchFieldError -> 0x0019 }
            int r2 = r2 - r0
            r3 = 2
            r1[r2] = r3     // Catch:{ NoSuchFieldError -> 0x0019 }
        L_0x0019:
            int[] r1 = f4359a     // Catch:{ NoSuchFieldError -> 0x0021 }
            int r2 = com.google.android.gms.internal.C1217ty.f4597d     // Catch:{ NoSuchFieldError -> 0x0021 }
            int r2 = r2 - r0
            r3 = 3
            r1[r2] = r3     // Catch:{ NoSuchFieldError -> 0x0021 }
        L_0x0021:
            int[] r1 = f4359a     // Catch:{ NoSuchFieldError -> 0x0029 }
            int r2 = com.google.android.gms.internal.C1217ty.f4599f     // Catch:{ NoSuchFieldError -> 0x0029 }
            int r2 = r2 - r0
            r3 = 4
            r1[r2] = r3     // Catch:{ NoSuchFieldError -> 0x0029 }
        L_0x0029:
            int[] r1 = f4359a     // Catch:{ NoSuchFieldError -> 0x0031 }
            int r2 = com.google.android.gms.internal.C1217ty.f4595b     // Catch:{ NoSuchFieldError -> 0x0031 }
            int r2 = r2 - r0
            r3 = 5
            r1[r2] = r3     // Catch:{ NoSuchFieldError -> 0x0031 }
        L_0x0031:
            int[] r1 = f4359a     // Catch:{ NoSuchFieldError -> 0x0039 }
            int r2 = com.google.android.gms.internal.C1217ty.f4596c     // Catch:{ NoSuchFieldError -> 0x0039 }
            int r2 = r2 - r0
            r3 = 6
            r1[r2] = r3     // Catch:{ NoSuchFieldError -> 0x0039 }
        L_0x0039:
            int[] r1 = f4359a     // Catch:{ NoSuchFieldError -> 0x0041 }
            int r2 = com.google.android.gms.internal.C1217ty.f4600g     // Catch:{ NoSuchFieldError -> 0x0041 }
            int r2 = r2 - r0
            r3 = 7
            r1[r2] = r3     // Catch:{ NoSuchFieldError -> 0x0041 }
        L_0x0041:
            int[] r1 = f4359a     // Catch:{ NoSuchFieldError -> 0x004a }
            int r2 = com.google.android.gms.internal.C1217ty.f4601h     // Catch:{ NoSuchFieldError -> 0x004a }
            int r2 = r2 - r0
            r0 = 8
            r1[r2] = r0     // Catch:{ NoSuchFieldError -> 0x004a }
        L_0x004a:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.C1099pr.<clinit>():void");
    }
}
