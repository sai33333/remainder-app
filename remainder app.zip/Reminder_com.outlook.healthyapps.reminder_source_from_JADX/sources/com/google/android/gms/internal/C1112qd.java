package com.google.android.gms.internal;

import com.google.android.gms.internal.C1023op.C1024a;
import com.google.android.gms.internal.C1023op.C1026b;
import com.google.android.gms.internal.C1083pq.C1086b;
import com.google.android.gms.internal.C1083pq.C1086b.C1088b;
import java.security.GeneralSecurityException;

/* renamed from: com.google.android.gms.internal.qd */
public final class C1112qd implements C1068ph<C1008ok> {
    C1112qd() {
    }

    /* access modifiers changed from: private */
    /* renamed from: d */
    public final C1008ok mo3205a(C1187sx sxVar) {
        try {
            C1024a a = C1024a.m5323a(sxVar);
            if (a instanceof C1024a) {
                C1024a aVar = a;
                C1150ro.m5692a(aVar.mo3161a(), 0);
                C1150ro.m5691a(aVar.mo3163c().mo3311a());
                if (aVar.mo3162b().mo3169a() != 12) {
                    if (aVar.mo3162b().mo3169a() != 16) {
                        throw new GeneralSecurityException("invalid IV size; acceptable values have 12 or 16 bytes");
                    }
                }
                return new C1127qs(aVar.mo3163c().mo3317c(), aVar.mo3162b().mo3169a());
            }
            throw new GeneralSecurityException("expected AesEaxKey proto");
        } catch (C1224ue e) {
            throw new GeneralSecurityException("expected serialized AesEaxKey proto", e);
        }
    }

    /* renamed from: a */
    public final /* synthetic */ Object mo3206a(C1231ul ulVar) {
        if (ulVar instanceof C1024a) {
            C1024a aVar = (C1024a) ulVar;
            C1150ro.m5692a(aVar.mo3161a(), 0);
            C1150ro.m5691a(aVar.mo3163c().mo3311a());
            if (aVar.mo3162b().mo3169a() == 12 || aVar.mo3162b().mo3169a() == 16) {
                return new C1127qs(aVar.mo3163c().mo3317c(), aVar.mo3162b().mo3169a());
            }
            throw new GeneralSecurityException("invalid IV size; acceptable values have 12 or 16 bytes");
        }
        throw new GeneralSecurityException("expected AesEaxKey proto");
    }

    /* renamed from: a */
    public final String mo3207a() {
        return "type.googleapis.com/google.crypto.tink.AesEaxKey";
    }

    /* renamed from: b */
    public final C1231ul mo3208b(C1187sx sxVar) {
        try {
            return mo3209b((C1231ul) C1026b.m5341a(sxVar));
        } catch (C1224ue e) {
            throw new GeneralSecurityException("expected serialized AesEaxKeyFormat proto", e);
        }
    }

    /* renamed from: b */
    public final C1231ul mo3209b(C1231ul ulVar) {
        if (ulVar instanceof C1026b) {
            C1026b bVar = (C1026b) ulVar;
            C1150ro.m5691a(bVar.mo3168b());
            if (bVar.mo3167a().mo3169a() == 12 || bVar.mo3167a().mo3169a() == 16) {
                return C1024a.m5330e().mo3166a(C1187sx.m5747a(C1149rn.m5690a(bVar.mo3168b()))).mo3165a(bVar.mo3167a()).mo3164a(0).mo3384d();
            }
            throw new GeneralSecurityException("invalid IV size; acceptable values have 12 or 16 bytes");
        }
        throw new GeneralSecurityException("expected AesEaxKeyFormat proto");
    }

    /* renamed from: c */
    public final C1086b mo3210c(C1187sx sxVar) {
        return (C1086b) C1086b.m5518e().mo3239a("type.googleapis.com/google.crypto.tink.AesEaxKey").mo3238a(((C1024a) mo3208b(sxVar)).mo3288i()).mo3237a(C1088b.SYMMETRIC).mo3384d();
    }
}
