package com.google.android.gms.internal;

import com.google.android.gms.internal.C1031or.C1032a;
import com.google.android.gms.internal.C1031or.C1034b;
import com.google.android.gms.internal.C1083pq.C1086b;
import com.google.android.gms.internal.C1083pq.C1086b.C1088b;
import java.security.GeneralSecurityException;

/* renamed from: com.google.android.gms.internal.qe */
public final class C1113qe implements C1068ph<C1008ok> {
    C1113qe() {
    }

    /* renamed from: d */
    private static C1008ok m5621d(C1187sx sxVar) {
        try {
            return new C1128qt(C1032a.m5354a(sxVar).mo3171b().mo3317c());
        } catch (C1224ue unused) {
            throw new GeneralSecurityException("expected AesGcmKey proto");
        }
    }

    /* renamed from: a */
    public final /* synthetic */ Object mo3205a(C1187sx sxVar) {
        return m5621d(sxVar);
    }

    /* renamed from: a */
    public final /* synthetic */ Object mo3206a(C1231ul ulVar) {
        if (ulVar instanceof C1032a) {
            C1032a aVar = (C1032a) ulVar;
            C1150ro.m5692a(aVar.mo3170a(), 0);
            C1150ro.m5691a(aVar.mo3171b().mo3311a());
            return new C1128qt(aVar.mo3171b().mo3317c());
        }
        throw new GeneralSecurityException("expected AesGcmKey proto");
    }

    /* renamed from: a */
    public final String mo3207a() {
        return "type.googleapis.com/google.crypto.tink.AesGcmKey";
    }

    /* renamed from: b */
    public final C1231ul mo3208b(C1187sx sxVar) {
        try {
            return mo3209b((C1231ul) C1034b.m5371a(sxVar));
        } catch (C1224ue e) {
            throw new GeneralSecurityException("expected serialized AesGcmKeyFormat proto", e);
        }
    }

    /* renamed from: b */
    public final C1231ul mo3209b(C1231ul ulVar) {
        if (ulVar instanceof C1034b) {
            C1034b bVar = (C1034b) ulVar;
            C1150ro.m5691a(bVar.mo3176b());
            return C1032a.m5361c().mo3174a(C1187sx.m5747a(C1149rn.m5690a(bVar.mo3176b()))).mo3173a(bVar.mo3175a()).mo3172a(0).mo3384d();
        }
        throw new GeneralSecurityException("expected AesGcmKeyFormat proto");
    }

    /* renamed from: c */
    public final C1086b mo3210c(C1187sx sxVar) {
        return (C1086b) C1086b.m5518e().mo3239a("type.googleapis.com/google.crypto.tink.AesGcmKey").mo3238a(((C1032a) mo3208b(sxVar)).mo3288i()).mo3237a(C1088b.SYMMETRIC).mo3384d();
    }
}
