package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.qi */
final class C1117qi {

    /* renamed from: a */
    public static final int f4390a = 1;

    /* renamed from: b */
    public static final int f4391b = 2;

    /* renamed from: c */
    private static final /* synthetic */ int[] f4392c = {1, 2};
}
