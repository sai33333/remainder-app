package com.google.android.gms.internal;

import java.security.GeneralSecurityException;
import java.util.logging.Level;
import java.util.logging.Logger;

/* renamed from: com.google.android.gms.internal.qm */
public final class C1121qm {

    /* renamed from: a */
    private static final Logger f4399a = Logger.getLogger(C1121qm.class.getName());

    static {
        try {
            C1109qa.m5597a();
            C1125qq.m5657a();
        } catch (GeneralSecurityException e) {
            String valueOf = String.valueOf(e);
            StringBuilder sb = new StringBuilder(String.valueOf(valueOf).length() + 30);
            sb.append("cannot register key managers: ");
            sb.append(valueOf);
            f4399a.logp(Level.SEVERE, "com.google.crypto.tink.hybrid.HybridEncryptFactory", "<clinit>", sb.toString());
        }
    }

    /* renamed from: a */
    public static C1067pg m5647a(C1069pi piVar) {
        return new C1122qn(C1082pp.f4313a.mo3226a(piVar, null));
    }
}
