package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.qn */
final class C1122qn implements C1067pg {

    /* renamed from: a */
    private /* synthetic */ C1080pn f4400a;

    C1122qn(C1080pn pnVar) {
        this.f4400a = pnVar;
    }

    /* renamed from: a */
    public final byte[] mo3204a(byte[] bArr, byte[] bArr2) {
        return C1150ro.m5694a(this.f4400a.mo3221a().mo3225b(), ((C1067pg) this.f4400a.mo3221a().mo3224a()).mo3204a(bArr, bArr2));
    }
}
