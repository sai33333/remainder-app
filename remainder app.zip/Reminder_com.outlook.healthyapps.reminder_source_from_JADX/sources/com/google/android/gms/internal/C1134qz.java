package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.qz */
public final class C1134qz {

    /* renamed from: a */
    private final C1146rk f4417a;

    /* renamed from: b */
    private final C1146rk f4418b;

    public C1134qz(byte[] bArr, byte[] bArr2) {
        this.f4417a = C1146rk.m5686a(bArr);
        this.f4418b = C1146rk.m5686a(bArr2);
    }

    /* renamed from: a */
    public final byte[] mo3263a() {
        C1146rk rkVar = this.f4417a;
        if (rkVar == null) {
            return null;
        }
        return rkVar.mo3268a();
    }

    /* renamed from: b */
    public final byte[] mo3264b() {
        C1146rk rkVar = this.f4418b;
        if (rkVar == null) {
            return null;
        }
        return rkVar.mo3268a();
    }
}
