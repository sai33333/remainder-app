package com.google.android.gms.internal;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import java.util.Collections;
import java.util.List;

@arm
/* renamed from: com.google.android.gms.internal.r */
public final class C1135r extends C0940lx {
    public static final Creator<C1135r> CREATOR = new C1163s();

    /* renamed from: A */
    public final C0717dq f4419A;

    /* renamed from: B */
    public final List<String> f4420B;

    /* renamed from: C */
    public final List<String> f4421C;

    /* renamed from: D */
    public final boolean f4422D;

    /* renamed from: E */
    public final C1190t f4423E;

    /* renamed from: F */
    public final boolean f4424F;

    /* renamed from: G */
    public String f4425G;

    /* renamed from: H */
    public final List<String> f4426H;

    /* renamed from: I */
    public final boolean f4427I;

    /* renamed from: J */
    public final String f4428J;

    /* renamed from: K */
    public final C0725dy f4429K;

    /* renamed from: L */
    public final String f4430L;

    /* renamed from: M */
    public final boolean f4431M;

    /* renamed from: N */
    public final boolean f4432N;

    /* renamed from: O */
    public final boolean f4433O;

    /* renamed from: P */
    private C0970n f4434P;

    /* renamed from: Q */
    private int f4435Q;

    /* renamed from: R */
    private C0622ae f4436R;

    /* renamed from: S */
    private Bundle f4437S;

    /* renamed from: a */
    public final String f4438a;

    /* renamed from: b */
    public String f4439b;

    /* renamed from: c */
    public final List<String> f4440c;

    /* renamed from: d */
    public final int f4441d;

    /* renamed from: e */
    public final List<String> f4442e;

    /* renamed from: f */
    public final long f4443f;

    /* renamed from: g */
    public final boolean f4444g;

    /* renamed from: h */
    public final long f4445h;

    /* renamed from: i */
    public final List<String> f4446i;

    /* renamed from: j */
    public final long f4447j;

    /* renamed from: k */
    public final int f4448k;

    /* renamed from: l */
    public final String f4449l;

    /* renamed from: m */
    public final long f4450m;

    /* renamed from: n */
    public final String f4451n;

    /* renamed from: o */
    public final boolean f4452o;

    /* renamed from: p */
    public final String f4453p;

    /* renamed from: q */
    public final String f4454q;

    /* renamed from: r */
    public final boolean f4455r;

    /* renamed from: s */
    public final boolean f4456s;

    /* renamed from: t */
    public final boolean f4457t;

    /* renamed from: u */
    public final boolean f4458u;

    /* renamed from: v */
    public final boolean f4459v;

    /* renamed from: w */
    public String f4460w;

    /* renamed from: x */
    public final String f4461x;

    /* renamed from: y */
    public final boolean f4462y;

    /* renamed from: z */
    public final boolean f4463z;

    public C1135r(int i) {
        this(19, null, null, null, i, null, -1, false, -1, null, -1, -1, null, -1, null, false, null, null, false, false, false, true, false, null, null, null, false, false, null, null, null, false, null, false, null, null, false, null, null, null, true, false, null, false);
    }

    public C1135r(int i, long j) {
        this(19, null, null, null, i, null, -1, false, -1, null, j, -1, null, -1, null, false, null, null, false, false, false, true, false, null, null, null, false, false, null, null, null, false, null, false, null, null, false, null, null, null, true, false, null, false);
    }

    C1135r(int i, String str, String str2, List<String> list, int i2, List<String> list2, long j, boolean z, long j2, List<String> list3, long j3, int i3, String str3, long j4, String str4, boolean z2, String str5, String str6, boolean z3, boolean z4, boolean z5, boolean z6, boolean z7, C0622ae aeVar, String str7, String str8, boolean z8, boolean z9, C0717dq dqVar, List<String> list4, List<String> list5, boolean z10, C1190t tVar, boolean z11, String str9, List<String> list6, boolean z12, String str10, C0725dy dyVar, String str11, boolean z13, boolean z14, Bundle bundle, boolean z15) {
        this.f4435Q = i;
        this.f4438a = str;
        this.f4439b = str2;
        List<String> list7 = null;
        this.f4440c = list != null ? Collections.unmodifiableList(list) : null;
        this.f4441d = i2;
        this.f4442e = list2 != null ? Collections.unmodifiableList(list2) : null;
        this.f4443f = j;
        this.f4444g = z;
        this.f4445h = j2;
        if (list3 != null) {
            list7 = Collections.unmodifiableList(list3);
        }
        this.f4446i = list7;
        this.f4447j = j3;
        this.f4448k = i3;
        this.f4449l = str3;
        this.f4450m = j4;
        this.f4451n = str4;
        this.f4452o = z2;
        this.f4453p = str5;
        this.f4454q = str6;
        this.f4455r = z3;
        this.f4456s = z4;
        this.f4457t = z5;
        this.f4458u = z6;
        this.f4431M = z13;
        this.f4459v = z7;
        this.f4436R = aeVar;
        this.f4460w = str7;
        this.f4461x = str8;
        if (this.f4439b == null) {
            C0622ae aeVar2 = this.f4436R;
            if (aeVar2 != null) {
                C0638as asVar = (C0638as) aeVar2.mo2065a(C0638as.CREATOR);
                if (asVar != null && !TextUtils.isEmpty(asVar.f2835a)) {
                    this.f4439b = asVar.f2835a;
                }
            }
        }
        this.f4462y = z8;
        this.f4463z = z9;
        this.f4419A = dqVar;
        this.f4420B = list4;
        this.f4421C = list5;
        this.f4422D = z10;
        this.f4423E = tVar;
        this.f4424F = z11;
        this.f4425G = str9;
        this.f4426H = list6;
        this.f4427I = z12;
        this.f4428J = str10;
        this.f4429K = dyVar;
        this.f4430L = str11;
        this.f4432N = z14;
        this.f4437S = bundle;
        this.f4433O = z15;
    }

    public C1135r(C0970n nVar, String str, String str2, List<String> list, List<String> list2, long j, boolean z, long j2, List<String> list3, long j3, int i, String str3, long j4, String str4, String str5, boolean z2, boolean z3, boolean z4, boolean z5, boolean z6, String str6, boolean z7, boolean z8, C0717dq dqVar, List<String> list4, List<String> list5, boolean z9, C1190t tVar, boolean z10, String str7, List<String> list6, boolean z11, String str8, C0725dy dyVar, String str9, boolean z12, boolean z13, boolean z14) {
        this(19, str, str2, list, -2, list2, j, z, -1, list3, j3, i, str3, j4, str4, false, null, str5, z2, z3, z4, z5, false, null, null, str6, z7, z8, dqVar, list4, list5, z9, tVar, z10, str7, list6, z11, str8, dyVar, str9, z12, z13, null, z14);
        this.f4434P = nVar;
    }

    public C1135r(C0970n nVar, String str, String str2, List<String> list, List<String> list2, long j, boolean z, long j2, List<String> list3, long j3, int i, String str3, long j4, String str4, boolean z2, String str5, String str6, boolean z3, boolean z4, boolean z5, boolean z6, boolean z7, String str7, boolean z8, boolean z9, C0717dq dqVar, List<String> list4, List<String> list5, boolean z10, C1190t tVar, boolean z11, String str8, List<String> list6, boolean z12, String str9, C0725dy dyVar, String str10, boolean z13, boolean z14, boolean z15) {
        this(19, str, str2, list, -2, list2, j, z, j2, list3, j3, i, str3, j4, str4, z2, str5, str6, z3, z4, z5, z6, z7, null, null, str7, z8, z9, dqVar, list4, list5, z10, tVar, z11, str8, list6, z12, str9, dyVar, str10, z13, z14, null, z15);
        this.f4434P = nVar;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        C0970n nVar = this.f4434P;
        if (nVar != null && nVar.f3993a >= 9 && !TextUtils.isEmpty(this.f4439b)) {
            this.f4436R = new C0622ae((C0945mb) new C0638as(this.f4439b));
            this.f4439b = null;
        }
        int a = C0944ma.m5103a(parcel);
        C0944ma.m5106a(parcel, 1, this.f4435Q);
        C0944ma.m5111a(parcel, 2, this.f4438a, false);
        C0944ma.m5111a(parcel, 3, this.f4439b, false);
        C0944ma.m5119b(parcel, 4, this.f4440c, false);
        C0944ma.m5106a(parcel, 5, this.f4441d);
        C0944ma.m5119b(parcel, 6, this.f4442e, false);
        C0944ma.m5107a(parcel, 7, this.f4443f);
        C0944ma.m5113a(parcel, 8, this.f4444g);
        C0944ma.m5107a(parcel, 9, this.f4445h);
        C0944ma.m5119b(parcel, 10, this.f4446i, false);
        C0944ma.m5107a(parcel, 11, this.f4447j);
        C0944ma.m5106a(parcel, 12, this.f4448k);
        C0944ma.m5111a(parcel, 13, this.f4449l, false);
        C0944ma.m5107a(parcel, 14, this.f4450m);
        C0944ma.m5111a(parcel, 15, this.f4451n, false);
        C0944ma.m5113a(parcel, 18, this.f4452o);
        C0944ma.m5111a(parcel, 19, this.f4453p, false);
        C0944ma.m5111a(parcel, 21, this.f4454q, false);
        C0944ma.m5113a(parcel, 22, this.f4455r);
        C0944ma.m5113a(parcel, 23, this.f4456s);
        C0944ma.m5113a(parcel, 24, this.f4457t);
        C0944ma.m5113a(parcel, 25, this.f4458u);
        C0944ma.m5113a(parcel, 26, this.f4459v);
        C0944ma.m5110a(parcel, 28, (Parcelable) this.f4436R, i, false);
        C0944ma.m5111a(parcel, 29, this.f4460w, false);
        C0944ma.m5111a(parcel, 30, this.f4461x, false);
        C0944ma.m5113a(parcel, 31, this.f4462y);
        C0944ma.m5113a(parcel, 32, this.f4463z);
        C0944ma.m5110a(parcel, 33, (Parcelable) this.f4419A, i, false);
        C0944ma.m5119b(parcel, 34, this.f4420B, false);
        C0944ma.m5119b(parcel, 35, this.f4421C, false);
        C0944ma.m5113a(parcel, 36, this.f4422D);
        C0944ma.m5110a(parcel, 37, (Parcelable) this.f4423E, i, false);
        C0944ma.m5113a(parcel, 38, this.f4424F);
        C0944ma.m5111a(parcel, 39, this.f4425G, false);
        C0944ma.m5119b(parcel, 40, this.f4426H, false);
        C0944ma.m5113a(parcel, 42, this.f4427I);
        C0944ma.m5111a(parcel, 43, this.f4428J, false);
        C0944ma.m5110a(parcel, 44, (Parcelable) this.f4429K, i, false);
        C0944ma.m5111a(parcel, 45, this.f4430L, false);
        C0944ma.m5113a(parcel, 46, this.f4431M);
        C0944ma.m5113a(parcel, 47, this.f4432N);
        C0944ma.m5108a(parcel, 48, this.f4437S, false);
        C0944ma.m5113a(parcel, 49, this.f4433O);
        C0944ma.m5104a(parcel, a);
    }
}
