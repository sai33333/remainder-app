package com.google.android.gms.internal;

import java.nio.ByteBuffer;
import java.util.Arrays;

/* renamed from: com.google.android.gms.internal.ra */
public final class C1136ra implements C1008ok {

    /* renamed from: a */
    private final C1147rl f4464a;

    /* renamed from: b */
    private final C1078pl f4465b;

    /* renamed from: c */
    private final int f4466c;

    public C1136ra(C1147rl rlVar, C1078pl plVar, int i) {
        this.f4464a = rlVar;
        this.f4465b = plVar;
        this.f4466c = i;
    }

    /* renamed from: a */
    public final byte[] mo3143a(byte[] bArr, byte[] bArr2) {
        byte[] a = this.f4464a.mo3261a(bArr);
        byte[] copyOf = Arrays.copyOf(ByteBuffer.allocate(8).putLong(((long) bArr2.length) * 8).array(), 8);
        return C1150ro.m5694a(a, this.f4465b.mo3220a(C1150ro.m5694a(bArr2, a, copyOf)));
    }
}
