package com.google.android.gms.internal;

import com.google.android.gms.internal.C1138rc;
import java.security.GeneralSecurityException;
import java.security.KeyFactory;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.Provider;
import java.security.Security;
import java.security.Signature;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.Cipher;
import javax.crypto.KeyAgreement;
import javax.crypto.Mac;

/* renamed from: com.google.android.gms.internal.rb */
public class C1137rb<T_WRAPPER extends C1138rc<T_ENGINE>, T_ENGINE> {

    /* renamed from: a */
    public static final C1137rb<C1139rd, Cipher> f4467a = new C1137rb<>(new C1139rd());

    /* renamed from: b */
    public static final C1137rb<C1143rh, Mac> f4468b = new C1137rb<>(new C1143rh());

    /* renamed from: c */
    public static final C1137rb<C1140re, KeyAgreement> f4469c = new C1137rb<>(new C1140re());

    /* renamed from: d */
    public static final C1137rb<C1142rg, KeyPairGenerator> f4470d = new C1137rb<>(new C1142rg());

    /* renamed from: e */
    private static final Logger f4471e = Logger.getLogger(C1137rb.class.getName());

    /* renamed from: f */
    private static final List<Provider> f4472f;

    /* renamed from: g */
    private static C1137rb<C1145rj, Signature> f4473g = new C1137rb<>(new C1145rj());

    /* renamed from: h */
    private static C1137rb<C1144ri, MessageDigest> f4474h = new C1137rb<>(new C1144ri());

    /* renamed from: i */
    private static C1137rb<C1141rf, KeyFactory> f4475i = new C1137rb<>(new C1141rf());

    /* renamed from: j */
    private T_WRAPPER f4476j;

    /* renamed from: k */
    private List<Provider> f4477k = f4472f;

    /* renamed from: l */
    private boolean f4478l = true;

    static {
        if (C1150ro.m5693a()) {
            String[] strArr = {"GmsCore_OpenSSL", "AndroidOpenSSL"};
            ArrayList arrayList = new ArrayList();
            for (int i = 0; i < 2; i++) {
                String str = strArr[i];
                Provider provider = Security.getProvider(str);
                if (provider != null) {
                    arrayList.add(provider);
                } else {
                    f4471e.logp(Level.INFO, "com.google.crypto.tink.subtle.EngineFactory", "toProviderList", String.format("Provider %s not available", new Object[]{str}));
                }
            }
            f4472f = arrayList;
        } else {
            f4472f = new ArrayList();
        }
    }

    private C1137rb(T_WRAPPER t_wrapper) {
        this.f4476j = t_wrapper;
    }

    /* renamed from: a */
    private final boolean m5676a(String str, Provider provider) {
        try {
            this.f4476j.mo3267a(str, provider);
            return true;
        } catch (Exception unused) {
            return false;
        }
    }

    /* renamed from: a */
    public final T_ENGINE mo3266a(String str) {
        T_WRAPPER t_wrapper;
        Provider provider;
        Iterator it = this.f4477k.iterator();
        while (true) {
            if (it.hasNext()) {
                provider = (Provider) it.next();
                if (m5676a(str, provider)) {
                    t_wrapper = this.f4476j;
                    break;
                }
            } else if (this.f4478l) {
                t_wrapper = this.f4476j;
                provider = null;
            } else {
                throw new GeneralSecurityException("No good Provider found.");
            }
        }
        return t_wrapper.mo3267a(str, provider);
    }
}
