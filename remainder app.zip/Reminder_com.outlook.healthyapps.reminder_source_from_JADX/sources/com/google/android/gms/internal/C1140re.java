package com.google.android.gms.internal;

import java.security.Provider;
import javax.crypto.KeyAgreement;

/* renamed from: com.google.android.gms.internal.re */
public final class C1140re implements C1138rc<KeyAgreement> {
    /* renamed from: a */
    public final /* synthetic */ Object mo3267a(String str, Provider provider) {
        return provider == null ? KeyAgreement.getInstance(str) : KeyAgreement.getInstance(str, provider);
    }
}
