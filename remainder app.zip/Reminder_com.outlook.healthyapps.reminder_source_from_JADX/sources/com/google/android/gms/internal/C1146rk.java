package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.rk */
public final class C1146rk {

    /* renamed from: a */
    private final byte[] f4479a;

    private C1146rk(byte[] bArr, int i, int i2) {
        this.f4479a = new byte[i2];
        System.arraycopy(bArr, 0, this.f4479a, 0, i2);
    }

    /* renamed from: a */
    public static C1146rk m5686a(byte[] bArr) {
        if (bArr == null) {
            return null;
        }
        return new C1146rk(bArr, 0, bArr.length);
    }

    /* renamed from: a */
    public final byte[] mo3268a() {
        byte[] bArr = this.f4479a;
        byte[] bArr2 = new byte[bArr.length];
        System.arraycopy(bArr, 0, bArr2, 0, bArr.length);
        return bArr2;
    }
}
