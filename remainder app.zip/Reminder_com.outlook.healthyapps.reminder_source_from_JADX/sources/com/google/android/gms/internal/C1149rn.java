package com.google.android.gms.internal;

import java.security.SecureRandom;

/* renamed from: com.google.android.gms.internal.rn */
public final class C1149rn {

    /* renamed from: a */
    private static final SecureRandom f4484a = new SecureRandom();

    /* renamed from: a */
    public static byte[] m5690a(int i) {
        byte[] bArr = new byte[i];
        f4484a.nextBytes(bArr);
        return bArr;
    }
}
