package com.google.android.gms.internal;

import java.io.PrintWriter;

/* renamed from: com.google.android.gms.internal.rq */
abstract class C1153rq {

    /* renamed from: a */
    private static Throwable[] f4488a = new Throwable[0];

    C1153rq() {
    }

    /* renamed from: a */
    public abstract void mo3269a(Throwable th, PrintWriter printWriter);
}
