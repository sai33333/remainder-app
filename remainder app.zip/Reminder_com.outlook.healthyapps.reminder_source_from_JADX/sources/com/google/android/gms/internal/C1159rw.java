package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.rw */
public final class C1159rw extends C1177sn {
    public C1159rw(C1000oc ocVar, String str, String str2, C0932lp lpVar, int i, int i2) {
        super(ocVar, str, str2, lpVar, i, 5);
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public final void mo3179a() {
        this.f4523b.f3676d = Long.valueOf(-1);
        this.f4523b.f3677e = Long.valueOf(-1);
        int[] iArr = (int[]) this.f4524c.invoke(null, new Object[]{this.f4522a.mo3120a()});
        synchronized (this.f4523b) {
            this.f4523b.f3676d = Long.valueOf((long) iArr[0]);
            this.f4523b.f3677e = Long.valueOf((long) iArr[1]);
        }
    }
}
