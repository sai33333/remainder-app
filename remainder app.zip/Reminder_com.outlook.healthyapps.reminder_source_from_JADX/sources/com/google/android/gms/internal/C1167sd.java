package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.sd */
public final class C1167sd extends C1177sn {

    /* renamed from: d */
    private static volatile String f4504d;

    /* renamed from: e */
    private static final Object f4505e = new Object();

    public C1167sd(C1000oc ocVar, String str, String str2, C0932lp lpVar, int i, int i2) {
        super(ocVar, str, str2, lpVar, i, 1);
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public final void mo3179a() {
        this.f4523b.f3664a = "E";
        if (f4504d == null) {
            synchronized (f4505e) {
                if (f4504d == null) {
                    f4504d = (String) this.f4524c.invoke(null, new Object[0]);
                }
            }
        }
        synchronized (this.f4523b) {
            this.f4523b.f3664a = f4504d;
        }
    }
}
