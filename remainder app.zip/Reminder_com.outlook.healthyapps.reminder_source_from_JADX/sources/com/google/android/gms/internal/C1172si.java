package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.si */
public final class C1172si extends C1177sn {
    public C1172si(C1000oc ocVar, String str, String str2, C0932lp lpVar, int i, int i2) {
        super(ocVar, str, str2, lpVar, i, 48);
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public final void mo3179a() {
        C0932lp lpVar;
        Integer valueOf;
        this.f4523b.f3644E = Integer.valueOf(2);
        boolean booleanValue = ((Boolean) this.f4524c.invoke(null, new Object[]{this.f4522a.mo3126c()})).booleanValue();
        synchronized (this.f4523b) {
            if (booleanValue) {
                lpVar = this.f4523b;
                valueOf = Integer.valueOf(1);
            } else {
                lpVar = this.f4523b;
                valueOf = Integer.valueOf(0);
            }
            lpVar.f3644E = valueOf;
        }
    }
}
