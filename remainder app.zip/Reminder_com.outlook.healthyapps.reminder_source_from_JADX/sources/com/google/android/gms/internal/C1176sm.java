package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.sm */
final class C1176sm implements Runnable {

    /* renamed from: a */
    private /* synthetic */ aha f4520a;

    /* renamed from: b */
    private /* synthetic */ C1001od f4521b;

    C1176sm(C1001od odVar, aha aha) {
        this.f4521b = odVar;
        this.f4520a = aha;
    }

    public final void run() {
        try {
            this.f4521b.f4157c.put(this.f4520a);
        } catch (InterruptedException unused) {
        }
    }
}
