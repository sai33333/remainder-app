package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.sq */
public final class C1180sq {

    /* renamed from: a */
    private final byte[] f4532a = new byte[256];

    /* renamed from: b */
    private int f4533b;

    /* renamed from: c */
    private int f4534c;

    public C1180sq(byte[] bArr) {
        for (int i = 0; i < 256; i++) {
            this.f4532a[i] = (byte) i;
        }
        byte b = 0;
        for (int i2 = 0; i2 < 256; i2++) {
            byte[] bArr2 = this.f4532a;
            b = (b + bArr2[i2] + bArr[i2 % bArr.length]) & 255;
            byte b2 = bArr2[i2];
            bArr2[i2] = bArr2[b];
            bArr2[b] = b2;
        }
        this.f4533b = 0;
        this.f4534c = 0;
    }

    /* renamed from: a */
    public final void mo3287a(byte[] bArr) {
        int i = this.f4533b;
        int i2 = this.f4534c;
        for (int i3 = 0; i3 < bArr.length; i3++) {
            i = (i + 1) & 255;
            byte[] bArr2 = this.f4532a;
            i2 = (i2 + bArr2[i]) & 255;
            byte b = bArr2[i];
            bArr2[i] = bArr2[i2];
            bArr2[i2] = b;
            bArr[i3] = (byte) (bArr2[(bArr2[i] + bArr2[i2]) & 255] ^ bArr[i3]);
        }
        this.f4533b = i;
        this.f4534c = i2;
    }
}
