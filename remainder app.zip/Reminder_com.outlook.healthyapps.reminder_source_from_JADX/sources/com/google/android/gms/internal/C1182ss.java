package com.google.android.gms.internal;

import com.google.android.gms.internal.C1182ss;
import com.google.android.gms.internal.C1183st;
import java.io.IOException;

/* renamed from: com.google.android.gms.internal.ss */
public abstract class C1182ss<MessageType extends C1182ss<MessageType, BuilderType>, BuilderType extends C1183st<MessageType, BuilderType>> implements C1231ul {

    /* renamed from: b */
    private static boolean f4536b = false;

    /* renamed from: a */
    protected int f4537a = 0;

    /* renamed from: i */
    public final C1187sx mo3288i() {
        try {
            C1193tc b = C1187sx.m5751b(mo1911d());
            mo1910a(b.mo3331b());
            return b.mo3330a();
        } catch (IOException e) {
            String str = "ByteString";
            String name = getClass().getName();
            StringBuilder sb = new StringBuilder(String.valueOf(name).length() + 62 + String.valueOf(str).length());
            sb.append("Serializing ");
            sb.append(name);
            sb.append(" to a ");
            sb.append(str);
            sb.append(" threw an IOException (should never happen).");
            throw new RuntimeException(sb.toString(), e);
        }
    }

    /* renamed from: j */
    public final byte[] mo3289j() {
        try {
            byte[] bArr = new byte[mo1911d()];
            C1200tj a = C1200tj.m5817a(bArr);
            mo1910a(a);
            a.mo3360b();
            return bArr;
        } catch (IOException e) {
            String str = "byte array";
            String name = getClass().getName();
            StringBuilder sb = new StringBuilder(String.valueOf(name).length() + 62 + String.valueOf(str).length());
            sb.append("Serializing ");
            sb.append(name);
            sb.append(" to a ");
            sb.append(str);
            sb.append(" threw an IOException (should never happen).");
            throw new RuntimeException(sb.toString(), e);
        }
    }
}
