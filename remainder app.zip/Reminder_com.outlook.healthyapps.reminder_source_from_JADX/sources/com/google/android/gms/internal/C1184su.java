package com.google.android.gms.internal;

import com.google.android.gms.internal.C1231ul;

/* renamed from: com.google.android.gms.internal.su */
public abstract class C1184su<MessageType extends C1231ul> implements C1235up<MessageType> {

    /* renamed from: a */
    private static final C1205tm f4538a = C1205tm.m5874a();
}
