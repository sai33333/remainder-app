package com.google.android.gms.internal;

import java.util.AbstractList;
import java.util.Collection;
import java.util.List;
import java.util.RandomAccess;

/* renamed from: com.google.android.gms.internal.sv */
abstract class C1185sv<E> extends AbstractList<E> implements C1223ud<E> {

    /* renamed from: a */
    private boolean f4539a = true;

    C1185sv() {
    }

    /* renamed from: a */
    public final boolean mo3294a() {
        return this.f4539a;
    }

    public void add(int i, E e) {
        mo3300c();
        super.add(i, e);
    }

    public boolean add(E e) {
        mo3300c();
        return super.add(e);
    }

    public boolean addAll(int i, Collection<? extends E> collection) {
        mo3300c();
        return super.addAll(i, collection);
    }

    public boolean addAll(Collection<? extends E> collection) {
        mo3300c();
        return super.addAll(collection);
    }

    /* renamed from: b */
    public final void mo3299b() {
        this.f4539a = false;
    }

    /* access modifiers changed from: protected */
    /* renamed from: c */
    public final void mo3300c() {
        if (!this.f4539a) {
            throw new UnsupportedOperationException();
        }
    }

    public void clear() {
        mo3300c();
        super.clear();
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof List)) {
            return false;
        }
        if (!(obj instanceof RandomAccess)) {
            return super.equals(obj);
        }
        List list = (List) obj;
        int size = size();
        if (size != list.size()) {
            return false;
        }
        for (int i = 0; i < size; i++) {
            if (!get(i).equals(list.get(i))) {
                return false;
            }
        }
        return true;
    }

    public int hashCode() {
        int i = 1;
        for (int i2 = 0; i2 < size(); i2++) {
            i = (i * 31) + get(i2).hashCode();
        }
        return i;
    }

    public E remove(int i) {
        mo3300c();
        return super.remove(i);
    }

    public boolean remove(Object obj) {
        mo3300c();
        return super.remove(obj);
    }

    public boolean removeAll(Collection<?> collection) {
        mo3300c();
        return super.removeAll(collection);
    }

    public boolean retainAll(Collection<?> collection) {
        mo3300c();
        return super.retainAll(collection);
    }

    public E set(int i, E e) {
        mo3300c();
        return super.set(i, e);
    }
}
