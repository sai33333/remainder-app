package com.google.android.gms.internal;

import java.io.Serializable;
import java.util.Iterator;

/* renamed from: com.google.android.gms.internal.sx */
public abstract class C1187sx implements Serializable, Iterable<Byte> {

    /* renamed from: a */
    public static final C1187sx f4540a = new C1195te(C1220ua.f4607b);

    /* renamed from: b */
    private static final C1192tb f4541b;

    /* renamed from: c */
    private int f4542c = 0;

    static {
        boolean z;
        try {
            Class.forName("android.content.Context");
            z = true;
        } catch (ClassNotFoundException unused) {
            z = false;
        }
        f4541b = z ? new C1196tf(null) : new C1189sz(null);
    }

    C1187sx() {
    }

    /* renamed from: a */
    public static C1187sx m5746a(String str) {
        return new C1195te(str.getBytes(C1220ua.f4606a));
    }

    /* renamed from: a */
    public static C1187sx m5747a(byte[] bArr) {
        return m5748a(bArr, 0, bArr.length);
    }

    /* renamed from: a */
    public static C1187sx m5748a(byte[] bArr, int i, int i2) {
        return new C1195te(f4541b.mo3327a(bArr, i, i2));
    }

    /* renamed from: b */
    static int m5749b(int i, int i2, int i3) {
        int i4 = i2 - i;
        if ((i | i2 | i4 | (i3 - i2)) >= 0) {
            return i4;
        }
        if (i < 0) {
            StringBuilder sb = new StringBuilder(32);
            sb.append("Beginning index: ");
            sb.append(i);
            sb.append(" < 0");
            throw new IndexOutOfBoundsException(sb.toString());
        } else if (i2 < i) {
            StringBuilder sb2 = new StringBuilder(66);
            sb2.append("Beginning index larger than ending index: ");
            sb2.append(i);
            sb2.append(", ");
            sb2.append(i2);
            throw new IndexOutOfBoundsException(sb2.toString());
        } else {
            StringBuilder sb3 = new StringBuilder(37);
            sb3.append("End index: ");
            sb3.append(i2);
            sb3.append(" >= ");
            sb3.append(i3);
            throw new IndexOutOfBoundsException(sb3.toString());
        }
    }

    /* renamed from: b */
    static C1187sx m5750b(byte[] bArr) {
        return new C1195te(bArr);
    }

    /* renamed from: b */
    static C1193tc m5751b(int i) {
        return new C1193tc(i, null);
    }

    /* renamed from: a */
    public abstract byte mo3310a(int i);

    /* renamed from: a */
    public abstract int mo3311a();

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public abstract int mo3312a(int i, int i2, int i3);

    /* renamed from: a */
    public abstract C1187sx mo3313a(int i, int i2);

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public abstract void mo3314a(C1186sw swVar);

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public abstract void mo3315a(byte[] bArr, int i, int i2, int i3);

    /* renamed from: b */
    public final boolean mo3316b() {
        return mo3311a() == 0;
    }

    /* renamed from: c */
    public final byte[] mo3317c() {
        int a = mo3311a();
        if (a == 0) {
            return C1220ua.f4607b;
        }
        byte[] bArr = new byte[a];
        mo3315a(bArr, 0, 0, a);
        return bArr;
    }

    /* renamed from: d */
    public abstract C1197tg mo3318d();

    /* access modifiers changed from: protected */
    /* renamed from: e */
    public final int mo3319e() {
        return this.f4542c;
    }

    public abstract boolean equals(Object obj);

    public final int hashCode() {
        int i = this.f4542c;
        if (i == 0) {
            int a = mo3311a();
            i = mo3312a(a, 0, a);
            if (i == 0) {
                i = 1;
            }
            this.f4542c = i;
        }
        return i;
    }

    public /* synthetic */ Iterator iterator() {
        return new C1188sy(this);
    }

    public final String toString() {
        return String.format("<ByteString@%s size=%d>", new Object[]{Integer.toHexString(System.identityHashCode(this)), Integer.valueOf(mo3311a())});
    }
}
