package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.ta */
final class C1191ta extends C1195te {

    /* renamed from: c */
    private final int f4548c;

    /* renamed from: d */
    private final int f4549d;

    C1191ta(byte[] bArr, int i, int i2) {
        super(bArr);
        m5749b(i, i + i2, bArr.length);
        this.f4548c = i;
        this.f4549d = i2;
    }

    /* renamed from: a */
    public final byte mo3310a(int i) {
        int a = mo3311a();
        if (((a - (i + 1)) | i) >= 0) {
            return this.f4552b[this.f4548c + i];
        }
        if (i < 0) {
            StringBuilder sb = new StringBuilder(22);
            sb.append("Index < 0: ");
            sb.append(i);
            throw new ArrayIndexOutOfBoundsException(sb.toString());
        }
        StringBuilder sb2 = new StringBuilder(40);
        sb2.append("Index > length: ");
        sb2.append(i);
        sb2.append(", ");
        sb2.append(a);
        throw new ArrayIndexOutOfBoundsException(sb2.toString());
    }

    /* renamed from: a */
    public final int mo3311a() {
        return this.f4549d;
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public final void mo3315a(byte[] bArr, int i, int i2, int i3) {
        System.arraycopy(this.f4552b, mo3329f(), bArr, 0, i3);
    }

    /* access modifiers changed from: protected */
    /* renamed from: f */
    public final int mo3329f() {
        return this.f4548c;
    }
}
