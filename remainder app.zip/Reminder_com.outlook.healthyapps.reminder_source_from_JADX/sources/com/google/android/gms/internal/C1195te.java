package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.te */
class C1195te extends C1194td {

    /* renamed from: b */
    protected final byte[] f4552b;

    C1195te(byte[] bArr) {
        this.f4552b = bArr;
    }

    /* renamed from: a */
    public byte mo3310a(int i) {
        return this.f4552b[i];
    }

    /* renamed from: a */
    public int mo3311a() {
        return this.f4552b.length;
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public final int mo3312a(int i, int i2, int i3) {
        return C1220ua.m5927a(i, this.f4552b, mo3329f(), i3);
    }

    /* renamed from: a */
    public final C1187sx mo3313a(int i, int i2) {
        int b = m5749b(0, i2, mo3311a());
        return b == 0 ? C1187sx.f4540a : new C1191ta(this.f4552b, mo3329f(), b);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public final void mo3314a(C1186sw swVar) {
        swVar.mo3309a(this.f4552b, mo3329f(), mo3311a());
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public void mo3315a(byte[] bArr, int i, int i2, int i3) {
        System.arraycopy(this.f4552b, 0, bArr, 0, i3);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public final boolean mo3332a(C1187sx sxVar, int i, int i2) {
        if (i2 > sxVar.mo3311a()) {
            int a = mo3311a();
            StringBuilder sb = new StringBuilder(40);
            sb.append("Length too large: ");
            sb.append(i2);
            sb.append(a);
            throw new IllegalArgumentException(sb.toString());
        } else if (i2 > sxVar.mo3311a()) {
            int a2 = sxVar.mo3311a();
            StringBuilder sb2 = new StringBuilder(59);
            sb2.append("Ran off end of other: 0, ");
            sb2.append(i2);
            sb2.append(", ");
            sb2.append(a2);
            throw new IllegalArgumentException(sb2.toString());
        } else if (!(sxVar instanceof C1195te)) {
            return sxVar.mo3313a(0, i2).equals(mo3313a(0, i2));
        } else {
            C1195te teVar = (C1195te) sxVar;
            byte[] bArr = this.f4552b;
            byte[] bArr2 = teVar.f4552b;
            int f = mo3329f() + i2;
            int f2 = mo3329f();
            int f3 = teVar.mo3329f();
            while (f2 < f) {
                if (bArr[f2] != bArr2[f3]) {
                    return false;
                }
                f2++;
                f3++;
            }
            return true;
        }
    }

    /* renamed from: d */
    public final C1197tg mo3318d() {
        return C1197tg.m5784a(this.f4552b, mo3329f(), mo3311a(), true);
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof C1187sx) || mo3311a() != ((C1187sx) obj).mo3311a()) {
            return false;
        }
        if (mo3311a() == 0) {
            return true;
        }
        if (!(obj instanceof C1195te)) {
            return obj.equals(this);
        }
        C1195te teVar = (C1195te) obj;
        int e = mo3319e();
        int e2 = teVar.mo3319e();
        if (e == 0 || e2 == 0 || e == e2) {
            return mo3332a(teVar, 0, mo3311a());
        }
        return false;
    }

    /* access modifiers changed from: protected */
    /* renamed from: f */
    public int mo3329f() {
        return 0;
    }
}
