package com.google.android.gms.internal;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/* renamed from: com.google.android.gms.internal.tm */
public class C1205tm {

    /* renamed from: a */
    static final C1205tm f4573a = new C1205tm(true);

    /* renamed from: b */
    private static volatile boolean f4574b = false;

    /* renamed from: c */
    private static final Class<?> f4575c = m5875b();

    /* renamed from: d */
    private final Map<Object, Object> f4576d;

    C1205tm() {
        this.f4576d = new HashMap();
    }

    private C1205tm(boolean z) {
        this.f4576d = Collections.emptyMap();
    }

    /* renamed from: a */
    public static C1205tm m5874a() {
        return C1204tl.m5871a();
    }

    /* renamed from: b */
    private static Class<?> m5875b() {
        try {
            return Class.forName("com.google.protobuf.Extension");
        } catch (ClassNotFoundException unused) {
            return null;
        }
    }
}
