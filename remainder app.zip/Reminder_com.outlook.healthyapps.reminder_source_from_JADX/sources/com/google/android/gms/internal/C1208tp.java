package com.google.android.gms.internal;

import com.google.android.gms.internal.C1208tp;

/* renamed from: com.google.android.gms.internal.tp */
public interface C1208tp<T extends C1208tp<T>> extends Comparable<T> {
    /* renamed from: a */
    C1263vm mo3373a();

    /* renamed from: b */
    boolean mo3374b();
}
