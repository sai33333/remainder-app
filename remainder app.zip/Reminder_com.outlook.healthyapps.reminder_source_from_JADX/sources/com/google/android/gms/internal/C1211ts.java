package com.google.android.gms.internal;

import com.google.android.gms.internal.C1209tq;

/* renamed from: com.google.android.gms.internal.ts */
public final class C1211ts<T extends C1209tq<T, ?>> extends C1184su<T> {

    /* renamed from: a */
    private T f4588a;

    public C1211ts(T t) {
        this.f4588a = t;
    }
}
