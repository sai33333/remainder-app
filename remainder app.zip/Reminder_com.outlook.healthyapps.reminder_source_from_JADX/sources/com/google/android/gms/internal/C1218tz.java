package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.tz */
public interface C1218tz {
    /* renamed from: a */
    int mo3386a(boolean z, int i, boolean z2, int i2);

    /* renamed from: a */
    C1187sx mo3387a(boolean z, C1187sx sxVar, boolean z2, C1187sx sxVar2);

    /* renamed from: a */
    <T> C1223ud<T> mo3388a(C1223ud<T> udVar, C1223ud<T> udVar2);

    /* renamed from: a */
    <T extends C1231ul> T mo3389a(T t, T t2);

    /* renamed from: a */
    C1250vd mo3390a(C1250vd vdVar, C1250vd vdVar2);

    /* renamed from: a */
    String mo3391a(boolean z, String str, boolean z2, String str2);
}
