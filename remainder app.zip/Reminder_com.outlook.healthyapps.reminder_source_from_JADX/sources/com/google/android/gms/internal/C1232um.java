package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.um */
public interface C1232um extends C1233un, Cloneable {
    /* renamed from: a */
    C1232um mo3292a(C1231ul ulVar);

    /* renamed from: e */
    C1231ul mo3385e();
}
