package com.google.android.gms.internal;

import java.lang.Comparable;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

/* renamed from: com.google.android.gms.internal.ur */
class C1237ur<K extends Comparable<K>, V> extends AbstractMap<K, V> {

    /* renamed from: a */
    private final int f4620a;
    /* access modifiers changed from: private */

    /* renamed from: b */
    public List<C1242uw> f4621b;
    /* access modifiers changed from: private */

    /* renamed from: c */
    public Map<K, V> f4622c;

    /* renamed from: d */
    private boolean f4623d;

    /* renamed from: e */
    private volatile C1244uy f4624e;

    /* renamed from: f */
    private Map<K, V> f4625f;

    private C1237ur(int i) {
        this.f4620a = i;
        this.f4621b = Collections.emptyList();
        this.f4622c = Collections.emptyMap();
        this.f4625f = Collections.emptyMap();
    }

    /* synthetic */ C1237ur(int i, C1238us usVar) {
        this(i);
    }

    /* renamed from: a */
    private final int m5955a(K k) {
        int size = this.f4621b.size() - 1;
        if (size >= 0) {
            int compareTo = k.compareTo((Comparable) ((C1242uw) this.f4621b.get(size)).getKey());
            if (compareTo > 0) {
                return -(size + 2);
            }
            if (compareTo == 0) {
                return size;
            }
        }
        int i = 0;
        while (i <= size) {
            int i2 = (i + size) / 2;
            int compareTo2 = k.compareTo((Comparable) ((C1242uw) this.f4621b.get(i2)).getKey());
            if (compareTo2 < 0) {
                size = i2 - 1;
            } else if (compareTo2 <= 0) {
                return i2;
            } else {
                i = i2 + 1;
            }
        }
        return -(i + 1);
    }

    /* renamed from: a */
    static <FieldDescriptorType extends C1208tp<FieldDescriptorType>> C1237ur<FieldDescriptorType, Object> m5956a(int i) {
        return new C1238us(i);
    }

    /* access modifiers changed from: private */
    /* renamed from: c */
    public final V m5960c(int i) {
        m5962e();
        V value = ((C1242uw) this.f4621b.remove(i)).getValue();
        if (!this.f4622c.isEmpty()) {
            Iterator it = m5963f().entrySet().iterator();
            this.f4621b.add(new C1242uw(this, (Entry) it.next()));
            it.remove();
        }
        return value;
    }

    /* access modifiers changed from: private */
    /* renamed from: e */
    public final void m5962e() {
        if (this.f4623d) {
            throw new UnsupportedOperationException();
        }
    }

    /* renamed from: f */
    private final SortedMap<K, V> m5963f() {
        m5962e();
        if (this.f4622c.isEmpty() && !(this.f4622c instanceof TreeMap)) {
            this.f4622c = new TreeMap();
            this.f4625f = ((TreeMap) this.f4622c).descendingMap();
        }
        return (SortedMap) this.f4622c;
    }

    /* renamed from: a */
    public final V put(K k, V v) {
        m5962e();
        int a = m5955a(k);
        if (a >= 0) {
            return ((C1242uw) this.f4621b.get(a)).setValue(v);
        }
        m5962e();
        if (this.f4621b.isEmpty() && !(this.f4621b instanceof ArrayList)) {
            this.f4621b = new ArrayList(this.f4620a);
        }
        int i = -(a + 1);
        if (i >= this.f4620a) {
            return m5963f().put(k, v);
        }
        int size = this.f4621b.size();
        int i2 = this.f4620a;
        if (size == i2) {
            C1242uw uwVar = (C1242uw) this.f4621b.remove(i2 - 1);
            m5963f().put((Comparable) uwVar.getKey(), uwVar.getValue());
        }
        this.f4621b.add(i, new C1242uw(this, k, v));
        return null;
    }

    /* renamed from: a */
    public void mo3409a() {
        if (!this.f4623d) {
            this.f4622c = this.f4622c.isEmpty() ? Collections.emptyMap() : Collections.unmodifiableMap(this.f4622c);
            this.f4625f = this.f4625f.isEmpty() ? Collections.emptyMap() : Collections.unmodifiableMap(this.f4625f);
            this.f4623d = true;
        }
    }

    /* renamed from: b */
    public final Entry<K, V> mo3410b(int i) {
        return (Entry) this.f4621b.get(i);
    }

    /* renamed from: b */
    public final boolean mo3411b() {
        return this.f4623d;
    }

    /* renamed from: c */
    public final int mo3412c() {
        return this.f4621b.size();
    }

    public void clear() {
        m5962e();
        if (!this.f4621b.isEmpty()) {
            this.f4621b.clear();
        }
        if (!this.f4622c.isEmpty()) {
            this.f4622c.clear();
        }
    }

    public boolean containsKey(Object obj) {
        Comparable comparable = (Comparable) obj;
        return m5955a((K) comparable) >= 0 || this.f4622c.containsKey(comparable);
    }

    /* renamed from: d */
    public final Iterable<Entry<K, V>> mo3415d() {
        return this.f4622c.isEmpty() ? C1239ut.m5971a() : this.f4622c.entrySet();
    }

    public Set<Entry<K, V>> entrySet() {
        if (this.f4624e == null) {
            this.f4624e = new C1244uy(this, null);
        }
        return this.f4624e;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C1237ur)) {
            return super.equals(obj);
        }
        C1237ur urVar = (C1237ur) obj;
        int size = size();
        if (size != urVar.size()) {
            return false;
        }
        int c = mo3412c();
        if (c != urVar.mo3412c()) {
            return entrySet().equals(urVar.entrySet());
        }
        for (int i = 0; i < c; i++) {
            if (!mo3410b(i).equals(urVar.mo3410b(i))) {
                return false;
            }
        }
        if (c != size) {
            return this.f4622c.equals(urVar.f4622c);
        }
        return true;
    }

    public V get(Object obj) {
        Comparable comparable = (Comparable) obj;
        int a = m5955a((K) comparable);
        return a >= 0 ? ((C1242uw) this.f4621b.get(a)).getValue() : this.f4622c.get(comparable);
    }

    public int hashCode() {
        int i = 0;
        for (int i2 = 0; i2 < mo3412c(); i2++) {
            i += ((C1242uw) this.f4621b.get(i2)).hashCode();
        }
        return this.f4622c.size() > 0 ? i + this.f4622c.hashCode() : i;
    }

    public V remove(Object obj) {
        m5962e();
        Comparable comparable = (Comparable) obj;
        int a = m5955a((K) comparable);
        if (a >= 0) {
            return m5960c(a);
        }
        if (this.f4622c.isEmpty()) {
            return null;
        }
        return this.f4622c.remove(comparable);
    }

    public int size() {
        return this.f4621b.size() + this.f4622c.size();
    }
}
