package com.google.android.gms.internal;

import java.util.Iterator;

/* renamed from: com.google.android.gms.internal.uv */
final class C1241uv implements Iterable<Object> {
    C1241uv() {
    }

    public final Iterator<Object> iterator() {
        return C1239ut.f4626a;
    }
}
