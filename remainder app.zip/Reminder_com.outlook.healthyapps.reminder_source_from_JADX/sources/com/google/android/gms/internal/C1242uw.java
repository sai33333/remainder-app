package com.google.android.gms.internal;

import java.util.Map.Entry;

/* renamed from: com.google.android.gms.internal.uw */
final class C1242uw implements Comparable<C1242uw>, Entry<K, V> {

    /* renamed from: a */
    private final K f4628a;

    /* renamed from: b */
    private V f4629b;

    /* renamed from: c */
    private /* synthetic */ C1237ur f4630c;

    C1242uw(C1237ur urVar, K k, V v) {
        this.f4630c = urVar;
        this.f4628a = k;
        this.f4629b = v;
    }

    C1242uw(C1237ur urVar, Entry<K, V> entry) {
        this(urVar, (Comparable) entry.getKey(), entry.getValue());
    }

    /* renamed from: a */
    private static boolean m5973a(Object obj, Object obj2) {
        return obj == null ? obj2 == null : obj.equals(obj2);
    }

    public final /* synthetic */ int compareTo(Object obj) {
        return ((Comparable) getKey()).compareTo((Comparable) ((C1242uw) obj).getKey());
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof Entry)) {
            return false;
        }
        Entry entry = (Entry) obj;
        return m5973a(this.f4628a, entry.getKey()) && m5973a(this.f4629b, entry.getValue());
    }

    public final /* synthetic */ Object getKey() {
        return this.f4628a;
    }

    public final V getValue() {
        return this.f4629b;
    }

    public final int hashCode() {
        K k = this.f4628a;
        int i = 0;
        int hashCode = k == null ? 0 : k.hashCode();
        V v = this.f4629b;
        if (v != null) {
            i = v.hashCode();
        }
        return hashCode ^ i;
    }

    public final V setValue(V v) {
        this.f4630c.m5962e();
        V v2 = this.f4629b;
        this.f4629b = v;
        return v2;
    }

    public final String toString() {
        String valueOf = String.valueOf(this.f4628a);
        String valueOf2 = String.valueOf(this.f4629b);
        StringBuilder sb = new StringBuilder(String.valueOf(valueOf).length() + 1 + String.valueOf(valueOf2).length());
        sb.append(valueOf);
        sb.append("=");
        sb.append(valueOf2);
        return sb.toString();
    }
}
