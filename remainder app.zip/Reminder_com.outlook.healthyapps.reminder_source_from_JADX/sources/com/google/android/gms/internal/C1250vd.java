package com.google.android.gms.internal;

import com.google.android.gms.C0276a.C0278b;
import java.util.Arrays;

/* renamed from: com.google.android.gms.internal.vd */
public final class C1250vd {

    /* renamed from: a */
    private static final C1250vd f4638a = new C1250vd(0, new int[0], new Object[0], false);

    /* renamed from: b */
    private int f4639b;

    /* renamed from: c */
    private int[] f4640c;

    /* renamed from: d */
    private Object[] f4641d;

    /* renamed from: e */
    private int f4642e;

    /* renamed from: f */
    private boolean f4643f;

    private C1250vd() {
        this(0, new int[8], new Object[8], true);
    }

    private C1250vd(int i, int[] iArr, Object[] objArr, boolean z) {
        this.f4642e = -1;
        this.f4639b = i;
        this.f4640c = iArr;
        this.f4641d = objArr;
        this.f4643f = z;
    }

    /* renamed from: a */
    public static C1250vd m5984a() {
        return f4638a;
    }

    /* renamed from: a */
    private final C1250vd m5985a(C1197tg tgVar) {
        int a;
        do {
            a = tgVar.mo3333a();
            if (a == 0) {
                break;
            }
        } while (mo3448a(a, tgVar));
        return this;
    }

    /* renamed from: a */
    static C1250vd m5986a(C1250vd vdVar, C1250vd vdVar2) {
        int i = vdVar.f4639b + vdVar2.f4639b;
        int[] copyOf = Arrays.copyOf(vdVar.f4640c, i);
        System.arraycopy(vdVar2.f4640c, 0, copyOf, vdVar.f4639b, vdVar2.f4639b);
        Object[] copyOf2 = Arrays.copyOf(vdVar.f4641d, i);
        System.arraycopy(vdVar2.f4641d, 0, copyOf2, vdVar.f4639b, vdVar2.f4639b);
        return new C1250vd(i, copyOf, copyOf2, true);
    }

    /* renamed from: a */
    private void m5987a(int i, Object obj) {
        int i2 = this.f4639b;
        if (i2 == this.f4640c.length) {
            int i3 = this.f4639b + (i2 < 4 ? 8 : i2 >> 1);
            this.f4640c = Arrays.copyOf(this.f4640c, i3);
            this.f4641d = Arrays.copyOf(this.f4641d, i3);
        }
        int[] iArr = this.f4640c;
        int i4 = this.f4639b;
        iArr[i4] = i;
        this.f4641d[i4] = obj;
        this.f4639b = i4 + 1;
    }

    /* renamed from: b */
    static C1250vd m5988b() {
        return new C1250vd();
    }

    /* renamed from: a */
    public final void mo3446a(C1200tj tjVar) {
        for (int i = 0; i < this.f4639b; i++) {
            int i2 = this.f4640c[i];
            int i3 = i2 >>> 3;
            int i4 = i2 & 7;
            if (i4 != 5) {
                switch (i4) {
                    case C0278b.AdsAttrs_adSize /*0*/:
                        tjVar.mo3351a(i3, ((Long) this.f4641d[i]).longValue());
                        break;
                    case 1:
                        tjVar.mo3363b(i3, ((Long) this.f4641d[i]).longValue());
                        break;
                    case 2:
                        tjVar.mo3352a(i3, (C1187sx) this.f4641d[i]);
                        break;
                    case 3:
                        tjVar.mo3350a(i3, 3);
                        ((C1250vd) this.f4641d[i]).mo3446a(tjVar);
                        tjVar.mo3350a(i3, 4);
                        break;
                    default:
                        throw C1224ue.m5934c();
                }
            } else {
                tjVar.mo3368d(i3, ((Integer) this.f4641d[i]).intValue());
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public final void mo3447a(StringBuilder sb, int i) {
        for (int i2 = 0; i2 < this.f4639b; i2++) {
            C1234uo.m5952a(sb, i, String.valueOf(this.f4640c[i2] >>> 3), this.f4641d[i2]);
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public final boolean mo3448a(int i, C1197tg tgVar) {
        if (this.f4643f) {
            int i2 = i >>> 3;
            switch (i & 7) {
                case C0278b.AdsAttrs_adSize /*0*/:
                    m5987a(i, (Object) Long.valueOf(tgVar.mo3337b()));
                    return true;
                case 1:
                    m5987a(i, (Object) Long.valueOf(tgVar.mo3338c()));
                    return true;
                case 2:
                    m5987a(i, (Object) tgVar.mo3342f());
                    return true;
                case 3:
                    C1250vd vdVar = new C1250vd();
                    vdVar.m5985a(tgVar);
                    tgVar.mo3335a((i2 << 3) | 4);
                    m5987a(i, (Object) vdVar);
                    return true;
                case C1217ty.f4597d /*4*/:
                    return false;
                case C1217ty.f4598e /*5*/:
                    m5987a(i, (Object) Integer.valueOf(tgVar.mo3340d()));
                    return true;
                default:
                    throw C1224ue.m5934c();
            }
        } else {
            throw new UnsupportedOperationException();
        }
    }

    /* renamed from: c */
    public final void mo3449c() {
        this.f4643f = false;
    }

    /* renamed from: d */
    public final int mo3450d() {
        int f;
        int i = this.f4642e;
        if (i != -1) {
            return i;
        }
        int i2 = 0;
        for (int i3 = 0; i3 < this.f4639b; i3++) {
            int i4 = this.f4640c[i3];
            int i5 = i4 >>> 3;
            int i6 = i4 & 7;
            if (i6 != 5) {
                switch (i6) {
                    case C0278b.AdsAttrs_adSize /*0*/:
                        f = C1200tj.m5822c(i5, ((Long) this.f4641d[i3]).longValue());
                        break;
                    case 1:
                        f = C1200tj.m5825d(i5, ((Long) this.f4641d[i3]).longValue());
                        break;
                    case 2:
                        f = C1200tj.m5818b(i5, (C1187sx) this.f4641d[i3]);
                        break;
                    case 3:
                        f = (C1200tj.m5824d(i5) << 1) + ((C1250vd) this.f4641d[i3]).mo3450d();
                        break;
                    default:
                        throw new IllegalStateException(C1224ue.m5934c());
                }
            } else {
                f = C1200tj.m5828f(i5, ((Integer) this.f4641d[i3]).intValue());
            }
            i2 += f;
        }
        this.f4642e = i2;
        return i2;
    }

    public final boolean equals(Object obj) {
        boolean z;
        boolean z2;
        if (this == obj) {
            return true;
        }
        if (obj == null || !(obj instanceof C1250vd)) {
            return false;
        }
        C1250vd vdVar = (C1250vd) obj;
        int i = this.f4639b;
        if (i == vdVar.f4639b) {
            int[] iArr = this.f4640c;
            int[] iArr2 = vdVar.f4640c;
            int i2 = 0;
            while (true) {
                if (i2 >= i) {
                    z = true;
                    break;
                } else if (iArr[i2] != iArr2[i2]) {
                    z = false;
                    break;
                } else {
                    i2++;
                }
            }
            if (z) {
                Object[] objArr = this.f4641d;
                Object[] objArr2 = vdVar.f4641d;
                int i3 = this.f4639b;
                int i4 = 0;
                while (true) {
                    if (i4 >= i3) {
                        z2 = true;
                        break;
                    } else if (!objArr[i4].equals(objArr2[i4])) {
                        z2 = false;
                        break;
                    } else {
                        i4++;
                    }
                }
                return z2;
            }
        }
    }

    public final int hashCode() {
        return ((((this.f4639b + 527) * 31) + Arrays.hashCode(this.f4640c)) * 31) + Arrays.deepHashCode(this.f4641d);
    }
}
