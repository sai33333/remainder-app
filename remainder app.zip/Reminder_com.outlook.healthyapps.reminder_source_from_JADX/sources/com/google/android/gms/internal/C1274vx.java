package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.vx */
public final class C1274vx implements Cloneable {

    /* renamed from: a */
    private static final C1275vy f4719a = new C1275vy();

    /* renamed from: b */
    private boolean f4720b;

    /* renamed from: c */
    private int[] f4721c;

    /* renamed from: d */
    private C1275vy[] f4722d;

    /* renamed from: e */
    private int f4723e;

    C1274vx() {
        this(10);
    }

    private C1274vx(int i) {
        this.f4720b = false;
        int c = m6108c(i);
        this.f4721c = new int[c];
        this.f4722d = new C1275vy[c];
        this.f4723e = 0;
    }

    /* renamed from: c */
    private static int m6108c(int i) {
        int i2 = i << 2;
        int i3 = 4;
        while (true) {
            if (i3 >= 32) {
                break;
            }
            int i4 = (1 << i3) - 12;
            if (i2 <= i4) {
                i2 = i4;
                break;
            }
            i3++;
        }
        return i2 / 4;
    }

    /* renamed from: d */
    private final int m6109d(int i) {
        int i2 = this.f4723e - 1;
        int i3 = 0;
        while (i3 <= i2) {
            int i4 = (i3 + i2) >>> 1;
            int i5 = this.f4721c[i4];
            if (i5 < i) {
                i3 = i4 + 1;
            } else if (i5 <= i) {
                return i4;
            } else {
                i2 = i4 - 1;
            }
        }
        return ~i3;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public final int mo3499a() {
        return this.f4723e;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public final C1275vy mo3500a(int i) {
        int d = m6109d(i);
        if (d >= 0) {
            C1275vy[] vyVarArr = this.f4722d;
            if (vyVarArr[d] != f4719a) {
                return vyVarArr[d];
            }
        }
        return null;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public final void mo3501a(int i, C1275vy vyVar) {
        int d = m6109d(i);
        if (d >= 0) {
            this.f4722d[d] = vyVar;
            return;
        }
        int i2 = ~d;
        if (i2 < this.f4723e) {
            C1275vy[] vyVarArr = this.f4722d;
            if (vyVarArr[i2] == f4719a) {
                this.f4721c[i2] = i;
                vyVarArr[i2] = vyVar;
                return;
            }
        }
        int i3 = this.f4723e;
        if (i3 >= this.f4721c.length) {
            int c = m6108c(i3 + 1);
            int[] iArr = new int[c];
            C1275vy[] vyVarArr2 = new C1275vy[c];
            int[] iArr2 = this.f4721c;
            System.arraycopy(iArr2, 0, iArr, 0, iArr2.length);
            C1275vy[] vyVarArr3 = this.f4722d;
            System.arraycopy(vyVarArr3, 0, vyVarArr2, 0, vyVarArr3.length);
            this.f4721c = iArr;
            this.f4722d = vyVarArr2;
        }
        int i4 = this.f4723e;
        if (i4 - i2 != 0) {
            int[] iArr3 = this.f4721c;
            int i5 = i2 + 1;
            System.arraycopy(iArr3, i2, iArr3, i5, i4 - i2);
            C1275vy[] vyVarArr4 = this.f4722d;
            System.arraycopy(vyVarArr4, i2, vyVarArr4, i5, this.f4723e - i2);
        }
        this.f4721c[i2] = i;
        this.f4722d[i2] = vyVar;
        this.f4723e++;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public final C1275vy mo3502b(int i) {
        return this.f4722d[i];
    }

    public final /* synthetic */ Object clone() {
        int i = this.f4723e;
        C1274vx vxVar = new C1274vx(i);
        System.arraycopy(this.f4721c, 0, vxVar.f4721c, 0, i);
        for (int i2 = 0; i2 < i; i2++) {
            C1275vy[] vyVarArr = this.f4722d;
            if (vyVarArr[i2] != null) {
                vxVar.f4722d[i2] = (C1275vy) vyVarArr[i2].clone();
            }
        }
        vxVar.f4723e = i;
        return vxVar;
    }

    public final boolean equals(Object obj) {
        boolean z;
        boolean z2;
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof C1274vx)) {
            return false;
        }
        C1274vx vxVar = (C1274vx) obj;
        int i = this.f4723e;
        if (i != vxVar.f4723e) {
            return false;
        }
        int[] iArr = this.f4721c;
        int[] iArr2 = vxVar.f4721c;
        int i2 = 0;
        while (true) {
            if (i2 >= i) {
                z = true;
                break;
            } else if (iArr[i2] != iArr2[i2]) {
                z = false;
                break;
            } else {
                i2++;
            }
        }
        if (z) {
            C1275vy[] vyVarArr = this.f4722d;
            C1275vy[] vyVarArr2 = vxVar.f4722d;
            int i3 = this.f4723e;
            int i4 = 0;
            while (true) {
                if (i4 >= i3) {
                    z2 = true;
                    break;
                } else if (!vyVarArr[i4].equals(vyVarArr2[i4])) {
                    z2 = false;
                    break;
                } else {
                    i4++;
                }
            }
            if (z2) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        int i = 17;
        for (int i2 = 0; i2 < this.f4723e; i2++) {
            i = (((i * 31) + this.f4721c[i2]) * 31) + this.f4722d[i2].hashCode();
        }
        return i;
    }
}
