package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.w */
public abstract class C1277w extends C1179sp implements C1246v {
    public C1277w() {
        attachInterface(this, "com.google.android.gms.ads.internal.request.IAdRequestService");
    }

    /* JADX WARNING: type inference failed for: r1v0 */
    /* JADX WARNING: type inference failed for: r1v1, types: [com.google.android.gms.internal.ab] */
    /* JADX WARNING: type inference failed for: r1v3, types: [com.google.android.gms.internal.ad] */
    /* JADX WARNING: type inference failed for: r1v5, types: [com.google.android.gms.internal.ab] */
    /* JADX WARNING: type inference failed for: r1v6, types: [com.google.android.gms.internal.y] */
    /* JADX WARNING: type inference failed for: r1v8, types: [com.google.android.gms.internal.aa] */
    /* JADX WARNING: type inference failed for: r1v10, types: [com.google.android.gms.internal.y] */
    /* JADX WARNING: type inference failed for: r1v11 */
    /* JADX WARNING: type inference failed for: r1v12 */
    /* JADX WARNING: type inference failed for: r1v13 */
    /* JADX WARNING: type inference failed for: r1v14 */
    /* JADX WARNING: Multi-variable type inference failed. Error: jadx.core.utils.exceptions.JadxRuntimeException: No candidate types for var: r1v0
      assigns: [?[int, float, boolean, short, byte, char, OBJECT, ARRAY], com.google.android.gms.internal.aa, com.google.android.gms.internal.ad, com.google.android.gms.internal.ab, com.google.android.gms.internal.y]
      uses: [com.google.android.gms.internal.ab, com.google.android.gms.internal.y]
      mth insns count: 45
    	at jadx.core.dex.visitors.typeinference.TypeSearch.fillTypeCandidates(TypeSearch.java:237)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1540)
    	at jadx.core.dex.visitors.typeinference.TypeSearch.run(TypeSearch.java:53)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runMultiVariableSearch(TypeInferenceVisitor.java:99)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:92)
    	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:27)
    	at jadx.core.dex.visitors.DepthTraversal.lambda$visit$1(DepthTraversal.java:14)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1540)
    	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
    	at jadx.core.ProcessClass.process(ProcessClass.java:30)
    	at jadx.core.ProcessClass.lambda$processDependencies$0(ProcessClass.java:49)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1540)
    	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:49)
    	at jadx.core.ProcessClass.process(ProcessClass.java:35)
    	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:311)
    	at jadx.api.JavaClass.decompile(JavaClass.java:62)
    	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:217)
     */
    /* JADX WARNING: Unknown variable types count: 5 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onTransact(int r3, android.os.Parcel r4, android.os.Parcel r5, int r6) {
        /*
            r2 = this;
            boolean r6 = r2.zza(r3, r4, r5, r6)
            r0 = 1
            if (r6 == 0) goto L_0x0008
            return r0
        L_0x0008:
            r6 = 4
            r1 = 0
            if (r3 == r6) goto L_0x004d
            switch(r3) {
                case 1: goto L_0x003a;
                case 2: goto L_0x0011;
                default: goto L_0x000f;
            }
        L_0x000f:
            r3 = 0
            return r3
        L_0x0011:
            android.os.Parcelable$Creator<com.google.android.gms.internal.n> r3 = com.google.android.gms.internal.C0970n.CREATOR
            android.os.Parcelable r3 = com.google.android.gms.internal.C1181sr.m5730a(r4, r3)
            com.google.android.gms.internal.n r3 = (com.google.android.gms.internal.C0970n) r3
            android.os.IBinder r4 = r4.readStrongBinder()
            if (r4 != 0) goto L_0x0020
            goto L_0x0033
        L_0x0020:
            java.lang.String r6 = "com.google.android.gms.ads.internal.request.IAdResponseListener"
            android.os.IInterface r6 = r4.queryLocalInterface(r6)
            boolean r1 = r6 instanceof com.google.android.gms.internal.C1331y
            if (r1 == 0) goto L_0x002e
            r1 = r6
            com.google.android.gms.internal.y r1 = (com.google.android.gms.internal.C1331y) r1
            goto L_0x0033
        L_0x002e:
            com.google.android.gms.internal.aa r1 = new com.google.android.gms.internal.aa
            r1.<init>(r4)
        L_0x0033:
            r2.mo2565a(r3, r1)
        L_0x0036:
            r5.writeNoException()
            goto L_0x0073
        L_0x003a:
            android.os.Parcelable$Creator<com.google.android.gms.internal.n> r3 = com.google.android.gms.internal.C0970n.CREATOR
            android.os.Parcelable r3 = com.google.android.gms.internal.C1181sr.m5730a(r4, r3)
            com.google.android.gms.internal.n r3 = (com.google.android.gms.internal.C0970n) r3
            com.google.android.gms.internal.r r3 = r2.mo2563a(r3)
            r5.writeNoException()
            com.google.android.gms.internal.C1181sr.m5736b(r5, r3)
            goto L_0x0073
        L_0x004d:
            android.os.Parcelable$Creator<com.google.android.gms.internal.ah> r3 = com.google.android.gms.internal.C0625ah.CREATOR
            android.os.Parcelable r3 = com.google.android.gms.internal.C1181sr.m5730a(r4, r3)
            com.google.android.gms.internal.ah r3 = (com.google.android.gms.internal.C0625ah) r3
            android.os.IBinder r4 = r4.readStrongBinder()
            if (r4 != 0) goto L_0x005c
            goto L_0x006f
        L_0x005c:
            java.lang.String r6 = "com.google.android.gms.ads.internal.request.INonagonStreamingResponseListener"
            android.os.IInterface r6 = r4.queryLocalInterface(r6)
            boolean r1 = r6 instanceof com.google.android.gms.internal.C0616ab
            if (r1 == 0) goto L_0x006a
            r1 = r6
            com.google.android.gms.internal.ab r1 = (com.google.android.gms.internal.C0616ab) r1
            goto L_0x006f
        L_0x006a:
            com.google.android.gms.internal.ad r1 = new com.google.android.gms.internal.ad
            r1.<init>(r4)
        L_0x006f:
            r2.mo2564a(r3, r1)
            goto L_0x0036
        L_0x0073:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.C1277w.onTransact(int, android.os.Parcel, android.os.Parcel, int):boolean");
    }
}
