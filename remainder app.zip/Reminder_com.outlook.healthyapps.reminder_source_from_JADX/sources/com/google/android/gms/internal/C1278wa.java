package com.google.android.gms.internal;

import java.io.IOException;

/* renamed from: com.google.android.gms.internal.wa */
public final class C1278wa extends IOException {
    public C1278wa(String str) {
        super(str);
    }

    /* renamed from: a */
    static C1278wa m6120a() {
        return new C1278wa("While parsing a protocol message, the input ended unexpectedly in the middle of a field.  This could mean either than the input has been truncated or that an embedded message misreported its own length.");
    }

    /* renamed from: b */
    static C1278wa m6121b() {
        return new C1278wa("CodedInputStream encountered an embedded string or message which claimed to have negative size.");
    }

    /* renamed from: c */
    static C1278wa m6122c() {
        return new C1278wa("CodedInputStream encountered a malformed varint.");
    }

    /* renamed from: d */
    static C1278wa m6123d() {
        return new C1278wa("Protocol message had too many levels of nesting.  May be malicious.  Use CodedInputStream.setRecursionLimit() to increase the depth limit.");
    }
}
