package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.we */
public final class C1282we {

    /* renamed from: a */
    public static final int[] f4733a = new int[0];

    /* renamed from: b */
    public static final long[] f4734b = new long[0];

    /* renamed from: c */
    public static final float[] f4735c = new float[0];

    /* renamed from: d */
    public static final boolean[] f4736d = new boolean[0];

    /* renamed from: e */
    public static final String[] f4737e = new String[0];

    /* renamed from: f */
    public static final byte[][] f4738f = new byte[0][];

    /* renamed from: g */
    public static final byte[] f4739g = new byte[0];

    /* renamed from: h */
    private static int f4740h = 11;

    /* renamed from: i */
    private static int f4741i = 12;

    /* renamed from: j */
    private static int f4742j = 16;

    /* renamed from: k */
    private static int f4743k = 26;

    /* renamed from: l */
    private static double[] f4744l = new double[0];

    /* renamed from: a */
    public static final int m6138a(C1269vs vsVar, int i) {
        int l = vsVar.mo3478l();
        vsVar.mo3465b(i);
        int i2 = 1;
        while (vsVar.mo3459a() == i) {
            vsVar.mo3465b(i);
            i2++;
        }
        vsVar.mo3464b(l, i);
        return i2;
    }
}
