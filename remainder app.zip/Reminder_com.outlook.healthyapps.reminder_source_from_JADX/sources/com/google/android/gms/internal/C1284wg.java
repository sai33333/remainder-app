package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.wg */
public final class C1284wg extends C1272vv<C1284wg> {

    /* renamed from: a */
    public String f4761a;

    public C1284wg() {
        this.f4761a = null;
        this.f4714R = null;
        this.f4730S = -1;
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public final int mo1918a() {
        int a = super.mo1918a();
        String str = this.f4761a;
        return str != null ? a + C1270vt.m6081b(1, str) : a;
    }

    /* renamed from: a */
    public final /* synthetic */ C1279wb mo1919a(C1269vs vsVar) {
        while (true) {
            int a = vsVar.mo3459a();
            if (a == 0) {
                return this;
            }
            if (a == 10) {
                this.f4761a = vsVar.mo3470e();
            } else if (!super.mo3491a(vsVar, a)) {
                return this;
            }
        }
    }

    /* renamed from: a */
    public final void mo1920a(C1270vt vtVar) {
        String str = this.f4761a;
        if (str != null) {
            vtVar.mo3483a(1, str);
        }
        super.mo1920a(vtVar);
    }
}
