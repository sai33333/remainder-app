package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.wh */
public final class C1285wh extends C1272vv<C1285wh> {

    /* renamed from: c */
    private static volatile C1285wh[] f4762c;

    /* renamed from: a */
    public byte[] f4763a;

    /* renamed from: b */
    public byte[] f4764b;

    public C1285wh() {
        this.f4763a = null;
        this.f4764b = null;
        this.f4714R = null;
        this.f4730S = -1;
    }

    /* renamed from: b */
    public static C1285wh[] m6145b() {
        if (f4762c == null) {
            synchronized (C1276vz.f4728b) {
                if (f4762c == null) {
                    f4762c = new C1285wh[0];
                }
            }
        }
        return f4762c;
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public final int mo1918a() {
        int a = super.mo1918a() + C1270vt.m6082b(1, this.f4763a);
        byte[] bArr = this.f4764b;
        return bArr != null ? a + C1270vt.m6082b(2, bArr) : a;
    }

    /* renamed from: a */
    public final /* synthetic */ C1279wb mo1919a(C1269vs vsVar) {
        while (true) {
            int a = vsVar.mo3459a();
            if (a == 0) {
                return this;
            }
            if (a == 10) {
                this.f4763a = vsVar.mo3472f();
            } else if (a == 18) {
                this.f4764b = vsVar.mo3472f();
            } else if (!super.mo3491a(vsVar, a)) {
                return this;
            }
        }
    }

    /* renamed from: a */
    public final void mo1920a(C1270vt vtVar) {
        vtVar.mo3485a(1, this.f4763a);
        byte[] bArr = this.f4764b;
        if (bArr != null) {
            vtVar.mo3485a(2, bArr);
        }
        super.mo1920a(vtVar);
    }
}
