package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.wo */
public final class C1292wo extends C1272vv<C1292wo> {

    /* renamed from: a */
    public String f4795a;

    /* renamed from: b */
    public Long f4796b;

    /* renamed from: c */
    public Boolean f4797c;

    public C1292wo() {
        this.f4795a = null;
        this.f4796b = null;
        this.f4797c = null;
        this.f4714R = null;
        this.f4730S = -1;
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public final int mo1918a() {
        int a = super.mo1918a();
        String str = this.f4795a;
        if (str != null) {
            a += C1270vt.m6081b(1, str);
        }
        Long l = this.f4796b;
        if (l != null) {
            a += C1270vt.m6086c(2, l.longValue());
        }
        Boolean bool = this.f4797c;
        if (bool == null) {
            return a;
        }
        bool.booleanValue();
        return a + C1270vt.m6078b(3) + 1;
    }

    /* renamed from: a */
    public final /* synthetic */ C1279wb mo1919a(C1269vs vsVar) {
        while (true) {
            int a = vsVar.mo3459a();
            if (a == 0) {
                return this;
            }
            if (a == 10) {
                this.f4795a = vsVar.mo3470e();
            } else if (a == 16) {
                this.f4796b = Long.valueOf(vsVar.mo3463b());
            } else if (a == 24) {
                this.f4797c = Boolean.valueOf(vsVar.mo3469d());
            } else if (!super.mo3491a(vsVar, a)) {
                return this;
            }
        }
    }

    /* renamed from: a */
    public final void mo1920a(C1270vt vtVar) {
        String str = this.f4795a;
        if (str != null) {
            vtVar.mo3483a(1, str);
        }
        Long l = this.f4796b;
        if (l != null) {
            vtVar.mo3487b(2, l.longValue());
        }
        Boolean bool = this.f4797c;
        if (bool != null) {
            vtVar.mo3484a(3, bool.booleanValue());
        }
        super.mo1920a(vtVar);
    }
}
