package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.wr */
public interface C1295wr {
}
