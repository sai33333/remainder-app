package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;

/* renamed from: com.google.android.gms.internal.x */
public final class C1304x extends C1178so implements C1246v {
    C1304x(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.ads.internal.request.IAdRequestService");
    }

    /* renamed from: a */
    public final C1135r mo2563a(C0970n nVar) {
        Parcel j_ = mo3284j_();
        C1181sr.m5732a(j_, (Parcelable) nVar);
        Parcel a = mo3281a(1, j_);
        C1135r rVar = (C1135r) C1181sr.m5730a(a, C1135r.CREATOR);
        a.recycle();
        return rVar;
    }

    /* renamed from: a */
    public final void mo2564a(C0625ah ahVar, C0616ab abVar) {
        Parcel j_ = mo3284j_();
        C1181sr.m5732a(j_, (Parcelable) ahVar);
        C1181sr.m5731a(j_, (IInterface) abVar);
        mo3283b(4, j_);
    }

    /* renamed from: a */
    public final void mo2565a(C0970n nVar, C1331y yVar) {
        Parcel j_ = mo3284j_();
        C1181sr.m5732a(j_, (Parcelable) nVar);
        C1181sr.m5731a(j_, (IInterface) yVar);
        mo3283b(2, j_);
    }
}
