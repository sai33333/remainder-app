package com.google.android.gms.internal;

import android.view.View;

/* renamed from: com.google.android.gms.internal.xf */
public final class C1310xf implements C1344ym {

    /* renamed from: a */
    private afw f4839a;

    public C1310xf(afw afw) {
        this.f4839a = afw;
    }

    /* renamed from: a */
    public final View mo3561a() {
        afw afw = this.f4839a;
        if (afw != null) {
            return afw.mo2207g();
        }
        return null;
    }

    /* renamed from: b */
    public final boolean mo3562b() {
        return this.f4839a == null;
    }

    /* renamed from: c */
    public final C1344ym mo3563c() {
        return this;
    }
}
