package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.p017js.C0410j;
import org.json.JSONObject;

@arm
/* renamed from: com.google.android.gms.internal.xj */
public final class C1314xj implements C1327xw {
    /* access modifiers changed from: private */

    /* renamed from: a */
    public final C1306xb f4844a;

    /* renamed from: b */
    private final C0410j f4845b;

    /* renamed from: c */
    private final ajh f4846c = new C1315xk(this);

    /* renamed from: d */
    private final ajh f4847d = new C1316xl(this);

    /* renamed from: e */
    private final ajh f4848e = new C1317xm(this);

    public C1314xj(C1306xb xbVar, C0410j jVar) {
        this.f4844a = xbVar;
        this.f4845b = jVar;
        C0410j jVar2 = this.f4845b;
        jVar2.mo1498a("/updateActiveView", this.f4846c);
        jVar2.mo1498a("/untrackActiveViewUnit", this.f4847d);
        jVar2.mo1498a("/visibilityChanged", this.f4848e);
        String str = "Custom JS tracking ad unit: ";
        String valueOf = String.valueOf(this.f4844a.f4812a.mo3532d());
        C0759fe.m4729b(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
    }

    /* renamed from: a */
    public final void mo3565a(JSONObject jSONObject, boolean z) {
        if (!z) {
            this.f4845b.mo1502b("AFMA_updateActiveView", jSONObject);
        } else {
            this.f4844a.mo3552b((C1327xw) this);
        }
    }

    /* renamed from: a */
    public final boolean mo3566a() {
        return true;
    }

    /* renamed from: b */
    public final void mo3567b() {
        C0410j jVar = this.f4845b;
        jVar.mo1501b("/visibilityChanged", this.f4848e);
        jVar.mo1501b("/untrackActiveViewUnit", this.f4847d);
        jVar.mo1501b("/updateActiveView", this.f4846c);
    }
}
