package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.p017js.C0410j;
import org.json.JSONObject;

/* renamed from: com.google.android.gms.internal.xq */
final class C1321xq implements C0877jo<C0410j> {

    /* renamed from: a */
    private /* synthetic */ JSONObject f4862a;

    C1321xq(C1318xn xnVar, JSONObject jSONObject) {
        this.f4862a = jSONObject;
    }

    /* renamed from: a */
    public final /* synthetic */ void mo1464a(Object obj) {
        ((C0410j) obj).mo1502b("AFMA_updateActiveView", this.f4862a);
    }
}
