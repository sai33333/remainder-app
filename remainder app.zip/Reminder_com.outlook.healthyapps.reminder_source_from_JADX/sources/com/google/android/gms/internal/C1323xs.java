package com.google.android.gms.internal;

import java.util.Map;

/* renamed from: com.google.android.gms.internal.xs */
final class C1323xs implements ajh {

    /* renamed from: a */
    private /* synthetic */ C1318xn f4864a;

    C1323xs(C1318xn xnVar) {
        this.f4864a = xnVar;
    }

    /* renamed from: a */
    public final void mo1441a(C0885jw jwVar, Map<String, String> map) {
        if (this.f4864a.f4852a.mo3550a(map)) {
            this.f4864a.f4852a.mo3546a(jwVar, map);
        }
    }
}
