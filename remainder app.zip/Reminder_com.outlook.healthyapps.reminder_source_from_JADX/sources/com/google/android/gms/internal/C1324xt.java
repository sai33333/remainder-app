package com.google.android.gms.internal;

import java.util.Map;

/* renamed from: com.google.android.gms.internal.xt */
final class C1324xt implements ajh {

    /* renamed from: a */
    private /* synthetic */ C1318xn f4865a;

    C1324xt(C1318xn xnVar) {
        this.f4865a = xnVar;
    }

    /* renamed from: a */
    public final void mo1441a(C0885jw jwVar, Map<String, String> map) {
        if (this.f4865a.f4852a.mo3550a(map)) {
            this.f4865a.f4852a.mo3549a((C1327xw) this.f4865a, map);
        }
    }
}
