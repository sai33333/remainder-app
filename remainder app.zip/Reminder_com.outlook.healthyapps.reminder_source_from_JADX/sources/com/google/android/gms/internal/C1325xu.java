package com.google.android.gms.internal;

import java.util.Map;

/* renamed from: com.google.android.gms.internal.xu */
final class C1325xu implements ajh {

    /* renamed from: a */
    private /* synthetic */ C1318xn f4866a;

    C1325xu(C1318xn xnVar) {
        this.f4866a = xnVar;
    }

    /* renamed from: a */
    public final void mo1441a(C0885jw jwVar, Map<String, String> map) {
        if (this.f4866a.f4852a.mo3550a(map)) {
            this.f4866a.f4852a.mo3553b(map);
        }
    }
}
