package com.google.android.gms.internal;

import java.util.Map;

/* renamed from: com.google.android.gms.internal.xv */
final class C1326xv implements ajh {

    /* renamed from: a */
    private /* synthetic */ C1318xn f4867a;

    C1326xv(C1318xn xnVar) {
        this.f4867a = xnVar;
    }

    /* renamed from: a */
    public final void mo1441a(C0885jw jwVar, Map<String, String> map) {
        if (this.f4867a.f4852a.mo3550a(map)) {
            aiq.f2291n.mo1441a(jwVar, map);
        }
    }
}
