package com.google.android.gms.internal;

import org.json.JSONObject;

/* renamed from: com.google.android.gms.internal.xw */
public interface C1327xw {
    /* renamed from: a */
    void mo3565a(JSONObject jSONObject, boolean z);

    /* renamed from: a */
    boolean mo3566a();

    /* renamed from: b */
    void mo3567b();
}
