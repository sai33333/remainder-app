package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.yc */
public interface C1334yc {
    /* renamed from: a */
    void mo2681a(C1332ya yaVar);
}
