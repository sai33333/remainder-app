package com.google.android.gms.internal;

import android.app.Activity;
import android.app.Application.ActivityLifecycleCallbacks;
import android.os.Bundle;

/* renamed from: com.google.android.gms.internal.yj */
final class C1341yj implements C1343yl {

    /* renamed from: a */
    private /* synthetic */ Activity f4911a;

    /* renamed from: b */
    private /* synthetic */ Bundle f4912b;

    C1341yj(C1335yd ydVar, Activity activity, Bundle bundle) {
        this.f4911a = activity;
        this.f4912b = bundle;
    }

    /* renamed from: a */
    public final void mo3593a(ActivityLifecycleCallbacks activityLifecycleCallbacks) {
        activityLifecycleCallbacks.onActivitySaveInstanceState(this.f4911a, this.f4912b);
    }
}
