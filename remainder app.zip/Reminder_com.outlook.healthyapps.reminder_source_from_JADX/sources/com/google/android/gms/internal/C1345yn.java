package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.C0354ax;
import java.util.ArrayList;

@arm
/* renamed from: com.google.android.gms.internal.yn */
public final class C1345yn {

    /* renamed from: a */
    private final int f4914a;

    /* renamed from: b */
    private final int f4915b;

    /* renamed from: c */
    private final int f4916c;

    /* renamed from: d */
    private final C1359za f4917d;

    /* renamed from: e */
    private final C1369zk f4918e;

    /* renamed from: f */
    private final Object f4919f = new Object();

    /* renamed from: g */
    private ArrayList<String> f4920g = new ArrayList<>();

    /* renamed from: h */
    private ArrayList<String> f4921h = new ArrayList<>();

    /* renamed from: i */
    private ArrayList<C1356yy> f4922i = new ArrayList<>();

    /* renamed from: j */
    private int f4923j = 0;

    /* renamed from: k */
    private int f4924k = 0;

    /* renamed from: l */
    private int f4925l = 0;

    /* renamed from: m */
    private int f4926m;

    /* renamed from: n */
    private String f4927n = "";

    /* renamed from: o */
    private String f4928o = "";

    /* renamed from: p */
    private String f4929p = "";

    public C1345yn(int i, int i2, int i3, int i4, int i5, int i6, int i7) {
        this.f4914a = i;
        this.f4915b = i2;
        this.f4916c = i3;
        this.f4917d = new C1359za(i4);
        this.f4918e = new C1369zk(i5, i6, i7);
    }

    /* renamed from: a */
    private static String m6300a(ArrayList<String> arrayList, int i) {
        if (arrayList.isEmpty()) {
            return "";
        }
        StringBuffer stringBuffer = new StringBuffer();
        ArrayList arrayList2 = arrayList;
        int size = arrayList2.size();
        int i2 = 0;
        while (i2 < size) {
            Object obj = arrayList2.get(i2);
            i2++;
            stringBuffer.append((String) obj);
            stringBuffer.append(' ');
            if (stringBuffer.length() > 100) {
                break;
            }
        }
        stringBuffer.deleteCharAt(stringBuffer.length() - 1);
        String stringBuffer2 = stringBuffer.toString();
        return stringBuffer2.length() < 100 ? stringBuffer2 : stringBuffer2.substring(0, 100);
    }

    /* renamed from: c */
    private final void m6301c(String str, boolean z, float f, float f2, float f3, float f4) {
        if (str != null && str.length() >= this.f4916c) {
            synchronized (this.f4919f) {
                this.f4920g.add(str);
                this.f4923j += str.length();
                if (z) {
                    this.f4921h.add(str);
                    ArrayList<C1356yy> arrayList = this.f4922i;
                    C1356yy yyVar = new C1356yy(f, f2, f3, f4, this.f4921h.size() - 1);
                    arrayList.add(yyVar);
                }
            }
        }
    }

    /* renamed from: a */
    public final void mo3594a(int i) {
        this.f4924k = i;
    }

    /* renamed from: a */
    public final void mo3595a(String str, boolean z, float f, float f2, float f3, float f4) {
        m6301c(str, z, f, f2, f3, f4);
        synchronized (this.f4919f) {
            if (this.f4925l < 0) {
                C0759fe.m4729b("ActivityContent: negative number of WebViews.");
            }
            mo3605h();
        }
    }

    /* renamed from: a */
    public final boolean mo3596a() {
        boolean z;
        synchronized (this.f4919f) {
            z = this.f4925l == 0;
        }
        return z;
    }

    /* renamed from: b */
    public final String mo3597b() {
        return this.f4927n;
    }

    /* renamed from: b */
    public final void mo3598b(String str, boolean z, float f, float f2, float f3, float f4) {
        m6301c(str, z, f, f2, f3, f4);
    }

    /* renamed from: c */
    public final String mo3599c() {
        return this.f4928o;
    }

    /* renamed from: d */
    public final String mo3600d() {
        return this.f4929p;
    }

    /* renamed from: e */
    public final void mo3601e() {
        synchronized (this.f4919f) {
            this.f4926m -= 100;
        }
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof C1345yn)) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        String str = ((C1345yn) obj).f4927n;
        return str != null && str.equals(this.f4927n);
    }

    /* renamed from: f */
    public final void mo3603f() {
        synchronized (this.f4919f) {
            this.f4925l--;
        }
    }

    /* renamed from: g */
    public final void mo3604g() {
        synchronized (this.f4919f) {
            this.f4925l++;
        }
    }

    /* renamed from: h */
    public final void mo3605h() {
        synchronized (this.f4919f) {
            int i = (this.f4923j * this.f4914a) + (this.f4924k * this.f4915b);
            if (i > this.f4926m) {
                this.f4926m = i;
                if (((Boolean) C0354ax.m1551r().mo2079a(ael.f1819R)).booleanValue() && !C0354ax.m1542i().mo2748b()) {
                    this.f4927n = this.f4917d.mo3648a(this.f4920g);
                    this.f4928o = this.f4917d.mo3648a(this.f4921h);
                }
                if (((Boolean) C0354ax.m1551r().mo2079a(ael.f1821T)).booleanValue() && !C0354ax.m1542i().mo2750c()) {
                    this.f4929p = this.f4918e.mo3655a(this.f4921h, this.f4922i);
                }
            }
        }
    }

    public final int hashCode() {
        return this.f4927n.hashCode();
    }

    /* renamed from: i */
    public final int mo3607i() {
        return this.f4926m;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: j */
    public final int mo3608j() {
        return this.f4923j;
    }

    public final String toString() {
        int i = this.f4924k;
        int i2 = this.f4926m;
        int i3 = this.f4923j;
        String a = m6300a(this.f4920g, 100);
        String a2 = m6300a(this.f4921h, 100);
        String str = this.f4927n;
        String str2 = this.f4928o;
        String str3 = this.f4929p;
        StringBuilder sb = new StringBuilder(String.valueOf(a).length() + 165 + String.valueOf(a2).length() + String.valueOf(str).length() + String.valueOf(str2).length() + String.valueOf(str3).length());
        sb.append("ActivityContent fetchId: ");
        sb.append(i);
        sb.append(" score:");
        sb.append(i2);
        sb.append(" total_length:");
        sb.append(i3);
        sb.append("\n text: ");
        sb.append(a);
        sb.append("\n viewableText");
        sb.append(a2);
        sb.append("\n signture: ");
        sb.append(str);
        sb.append("\n viewableSignture: ");
        sb.append(str2);
        sb.append("\n viewableSignatureForVertical: ");
        sb.append(str3);
        return sb.toString();
    }
}
