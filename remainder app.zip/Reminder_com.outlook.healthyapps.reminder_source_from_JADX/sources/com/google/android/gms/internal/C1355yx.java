package com.google.android.gms.internal;

@arm
/* renamed from: com.google.android.gms.internal.yx */
final class C1355yx {

    /* renamed from: a */
    final int f4971a;

    /* renamed from: b */
    final int f4972b;

    C1355yx(C1351yt ytVar, int i, int i2) {
        this.f4971a = i;
        this.f4972b = i2;
    }
}
