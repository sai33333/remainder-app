package com.google.android.gms.internal;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Locale;
import java.util.PriorityQueue;

@arm
/* renamed from: com.google.android.gms.internal.za */
public final class C1359za {

    /* renamed from: a */
    private final int f4980a;

    /* renamed from: b */
    private final int f4981b;

    /* renamed from: c */
    private final int f4982c;

    /* renamed from: d */
    private final C1357yz f4983d = new C1364zf();

    public C1359za(int i) {
        this.f4981b = i;
        this.f4980a = 6;
        this.f4982c = 0;
    }

    /* renamed from: a */
    private final String m6350a(String str) {
        String[] split = str.split("\n");
        if (split.length == 0) {
            return "";
        }
        C1362zd zdVar = new C1362zd();
        PriorityQueue priorityQueue = new PriorityQueue(this.f4981b, new C1360zb(this));
        for (String a : split) {
            String[] a2 = C1363ze.m6357a(a, false);
            if (a2.length != 0) {
                C1366zh.m6363a(a2, this.f4981b, this.f4980a, priorityQueue);
            }
        }
        Iterator it = priorityQueue.iterator();
        while (it.hasNext()) {
            try {
                zdVar.mo3650a(this.f4983d.mo3646a(((C1367zi) it.next()).f4989b));
            } catch (IOException e) {
                C0759fe.m4730b("Error while writing hash to byteStream", e);
            }
        }
        return zdVar.toString();
    }

    /* renamed from: a */
    public final String mo3648a(ArrayList<String> arrayList) {
        StringBuffer stringBuffer = new StringBuffer();
        ArrayList arrayList2 = arrayList;
        int size = arrayList2.size();
        int i = 0;
        while (i < size) {
            Object obj = arrayList2.get(i);
            i++;
            stringBuffer.append(((String) obj).toLowerCase(Locale.US));
            stringBuffer.append(10);
        }
        return m6350a(stringBuffer.toString());
    }
}
