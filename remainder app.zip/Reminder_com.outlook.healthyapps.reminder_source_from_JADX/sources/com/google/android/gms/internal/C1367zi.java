package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.zi */
public final class C1367zi {

    /* renamed from: a */
    final long f4988a;

    /* renamed from: b */
    final String f4989b;

    /* renamed from: c */
    final int f4990c;

    C1367zi(long j, String str, int i) {
        this.f4988a = j;
        this.f4989b = str;
        this.f4990c = i;
    }

    public final boolean equals(Object obj) {
        if (obj != null && (obj instanceof C1367zi)) {
            C1367zi ziVar = (C1367zi) obj;
            if (ziVar.f4988a == this.f4988a && ziVar.f4990c == this.f4990c) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return (int) this.f4988a;
    }
}
