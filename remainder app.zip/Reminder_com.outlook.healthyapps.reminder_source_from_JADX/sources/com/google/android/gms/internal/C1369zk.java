package com.google.android.gms.internal;

import java.io.IOException;
import java.text.Normalizer;
import java.text.Normalizer.Form;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;

@arm
/* renamed from: com.google.android.gms.internal.zk */
public final class C1369zk {

    /* renamed from: a */
    private final C1357yz f4994a;

    /* renamed from: b */
    private final int f4995b;

    /* renamed from: c */
    private String f4996c;

    /* renamed from: d */
    private String f4997d;

    /* renamed from: e */
    private final boolean f4998e = false;

    /* renamed from: f */
    private final int f4999f;

    /* renamed from: g */
    private final int f5000g;

    public C1369zk(int i, int i2, int i3) {
        this.f4995b = i;
        if (i2 > 64 || i2 < 0) {
            this.f4999f = 64;
        } else {
            this.f4999f = i2;
        }
        if (i3 <= 0) {
            this.f5000g = 1;
        } else {
            this.f5000g = i3;
        }
        this.f4994a = new C1368zj(this.f4999f);
    }

    /* renamed from: a */
    private final boolean m6366a(String str, HashSet<String> hashSet) {
        boolean z;
        String[] split = str.split("\n");
        if (split.length == 0) {
            return true;
        }
        for (String str2 : split) {
            if (str2.indexOf("'") != -1) {
                StringBuilder sb = new StringBuilder(str2);
                boolean z2 = false;
                int i = 1;
                while (true) {
                    int i2 = i + 2;
                    if (i2 > sb.length()) {
                        break;
                    }
                    if (sb.charAt(i) == '\'') {
                        if (sb.charAt(i - 1) != ' ') {
                            int i3 = i + 1;
                            if ((sb.charAt(i3) == 's' || sb.charAt(i3) == 'S') && (i2 == sb.length() || sb.charAt(i2) == ' ')) {
                                sb.insert(i, ' ');
                                i = i2;
                                z2 = true;
                            }
                        }
                        sb.setCharAt(i, ' ');
                        z2 = true;
                    }
                    i++;
                }
                String sb2 = z2 ? sb.toString() : null;
                if (sb2 != null) {
                    this.f4997d = sb2;
                    str2 = sb2;
                }
            }
            String[] a = C1363ze.m6357a(str2, true);
            if (a.length >= this.f5000g) {
                for (int i4 = 0; i4 < a.length; i4++) {
                    String str3 = "";
                    int i5 = 0;
                    while (true) {
                        if (i5 >= this.f5000g) {
                            z = true;
                            break;
                        }
                        int i6 = i4 + i5;
                        if (i6 >= a.length) {
                            z = false;
                            break;
                        }
                        if (i5 > 0) {
                            str3 = String.valueOf(str3).concat(" ");
                        }
                        String valueOf = String.valueOf(str3);
                        String valueOf2 = String.valueOf(a[i6]);
                        str3 = valueOf2.length() != 0 ? valueOf.concat(valueOf2) : new String(valueOf);
                        i5++;
                    }
                    if (!z) {
                        break;
                    }
                    hashSet.add(str3);
                    if (hashSet.size() >= this.f4995b) {
                        return false;
                    }
                }
                if (hashSet.size() >= this.f4995b) {
                    return false;
                }
            }
        }
        return true;
    }

    /* renamed from: a */
    public final String mo3655a(ArrayList<String> arrayList, ArrayList<C1356yy> arrayList2) {
        Collections.sort(arrayList2, new C1370zl(this));
        HashSet hashSet = new HashSet();
        int i = 0;
        while (i < arrayList2.size() && m6366a(Normalizer.normalize((CharSequence) arrayList.get(((C1356yy) arrayList2.get(i)).mo3644e()), Form.NFKC).toLowerCase(Locale.US), hashSet)) {
            i++;
        }
        C1362zd zdVar = new C1362zd();
        this.f4996c = "";
        Iterator it = hashSet.iterator();
        while (it.hasNext()) {
            try {
                zdVar.mo3650a(this.f4994a.mo3646a((String) it.next()));
            } catch (IOException e) {
                C0759fe.m4730b("Error while writing hash to byteStream", e);
            }
        }
        return zdVar.toString();
    }
}
