package com.google.android.gms.internal;

@arm
/* renamed from: com.google.android.gms.internal.zm */
public final class C1371zm {

    /* renamed from: a */
    private final Object f5001a = new Object();

    /* renamed from: b */
    private boolean f5002b = false;
}
