package com.google.android.gms.internal;

import android.os.Bundle;
import android.os.DeadObjectException;
import com.google.android.gms.common.internal.C0561x;

/* renamed from: com.google.android.gms.internal.zq */
final class C1375zq implements C0561x {

    /* renamed from: a */
    private /* synthetic */ C1372zn f5010a;

    C1375zq(C1372zn znVar) {
        this.f5010a = znVar;
    }

    /* renamed from: a */
    public final void mo1874a(int i) {
        synchronized (this.f5010a.f5004b) {
            this.f5010a.f5007e = null;
            this.f5010a.f5004b.notifyAll();
        }
    }

    /* renamed from: a */
    public final void mo1875a(Bundle bundle) {
        synchronized (this.f5010a.f5004b) {
            try {
                if (this.f5010a.f5005c != null) {
                    this.f5010a.f5007e = this.f5010a.f5005c.mo3081q();
                }
            } catch (DeadObjectException e) {
                C0759fe.m4730b("Unable to obtain a cache service instance.", e);
                this.f5010a.m6374c();
            }
            this.f5010a.f5004b.notifyAll();
        }
    }
}
