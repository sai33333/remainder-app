package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable.Creator;

/* renamed from: com.google.android.gms.internal.zt */
public final class C1378zt implements Creator<C1377zs> {
    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        int a = C0941ly.m5082a(parcel);
        ParcelFileDescriptor parcelFileDescriptor = null;
        while (parcel.dataPosition() < a) {
            int readInt = parcel.readInt();
            if ((65535 & readInt) != 2) {
                C0941ly.m5086b(parcel, readInt);
            } else {
                parcelFileDescriptor = (ParcelFileDescriptor) C0941ly.m5084a(parcel, readInt, ParcelFileDescriptor.CREATOR);
            }
        }
        C0941ly.m5098m(parcel, a);
        return new C1377zs(parcelFileDescriptor);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new C1377zs[i];
    }
}
