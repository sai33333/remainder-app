package com.google.android.gms.internal;

public interface aae {
    /* renamed from: a */
    void mo1413a(aan aan);
}
