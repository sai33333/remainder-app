package com.google.android.gms.internal;

import java.io.IOException;

public final class aaf {

    /* renamed from: com.google.android.gms.internal.aaf$a */
    public static final class C0613a extends C1209tq<C0613a, C0614a> implements C1233un {
        /* access modifiers changed from: private */

        /* renamed from: d */
        public static final C0613a f1585d;

        /* renamed from: e */
        private static volatile C1235up<C0613a> f1586e;

        /* renamed from: com.google.android.gms.internal.aaf$a$a */
        public static final class C0614a extends C1210tr<C0613a, C0614a> implements C1233un {
            private C0614a() {
                super(C0613a.f1585d);
            }

            /* synthetic */ C0614a(aag aag) {
                this();
            }
        }

        /* renamed from: com.google.android.gms.internal.aaf$a$b */
        public enum C0615b implements C1221ub {
            UNKNOWN_EVENT_TYPE(0),
            AD_REQUEST(1),
            AD_LOADED(2),
            AD_FAILED_TO_LOAD(3),
            AD_FAILED_TO_LOAD_NO_FILL(4);
            

            /* renamed from: f */
            private static final C1222uc<C0615b> f1592f = null;

            /* renamed from: g */
            private final int f1594g;

            static {
                f1592f = new aah();
            }

            private C0615b(int i) {
                this.f1594g = i;
            }

            /* renamed from: a */
            public final int mo1912a() {
                return this.f1594g;
            }
        }

        static {
            C0613a aVar = new C0613a();
            f1585d = aVar;
            aVar.mo1909a(C1217ty.f4597d, (Object) null, (Object) null);
            aVar.f4583b.mo3449c();
        }

        private C0613a() {
        }

        /* access modifiers changed from: protected */
        /* renamed from: a */
        public final Object mo1909a(int i, Object obj, Object obj2) {
            switch (aag.f1595a[i - 1]) {
                case 1:
                    return new C0613a();
                case 2:
                    return f1585d;
                case 3:
                    return null;
                case C1217ty.f4597d /*4*/:
                    return new C0614a(null);
                case C1217ty.f4598e /*5*/:
                    return this;
                case C1217ty.f4599f /*6*/:
                    C1197tg tgVar = (C1197tg) obj;
                    boolean z = false;
                    while (!z) {
                        try {
                            int a = tgVar.mo3333a();
                            if (a == 0 || !mo3375a(a, tgVar)) {
                                z = true;
                            }
                        } catch (C1224ue e) {
                            throw new RuntimeException(e.mo3395a(this));
                        } catch (IOException e2) {
                            throw new RuntimeException(new C1224ue(e2.getMessage()).mo3395a(this));
                        }
                    }
                    break;
                case C1217ty.f4600g /*7*/:
                    break;
                case C1217ty.f4601h /*8*/:
                    if (f1586e == null) {
                        synchronized (C0613a.class) {
                            if (f1586e == null) {
                                f1586e = new C1211ts(f1585d);
                            }
                        }
                    }
                    return f1586e;
                default:
                    throw new UnsupportedOperationException();
            }
            return f1585d;
        }

        /* renamed from: a */
        public final void mo1910a(C1200tj tjVar) {
            this.f4583b.mo3446a(tjVar);
        }

        /* renamed from: d */
        public final int mo1911d() {
            int i = this.f4584c;
            if (i != -1) {
                return i;
            }
            int d = this.f4583b.mo3450d() + 0;
            this.f4584c = d;
            return d;
        }
    }
}
