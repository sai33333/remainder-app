package com.google.android.gms.internal;

@arm
public final class aaq extends abn {

    /* renamed from: a */
    private final aap f1612a;

    public aaq(aap aap) {
        this.f1612a = aap;
    }

    /* renamed from: a */
    public final void mo1921a() {
        this.f1612a.mo1074e();
    }
}
