package com.google.android.gms.internal;

import com.google.android.gms.ads.C0285a;

@arm
public final class aar extends abq {

    /* renamed from: a */
    private final C0285a f1613a;

    public aar(C0285a aVar) {
        this.f1613a = aVar;
    }

    /* renamed from: a */
    public final void mo1922a() {
        this.f1613a.mo992b();
    }

    /* renamed from: a */
    public final void mo1923a(int i) {
        this.f1613a.mo991a(i);
    }

    /* renamed from: b */
    public final void mo1924b() {
        this.f1613a.mo1073d();
    }

    /* renamed from: c */
    public final void mo1925c() {
        this.f1613a.mo990a();
    }

    /* renamed from: d */
    public final void mo1926d() {
        this.f1613a.mo1072c();
    }

    /* renamed from: e */
    public final void mo1927e() {
        this.f1613a.mo1074e();
    }

    /* renamed from: f */
    public final void mo1928f() {
        this.f1613a.mo1079f();
    }
}
