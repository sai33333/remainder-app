package com.google.android.gms.internal;

import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.util.DisplayMetrics;
import com.google.android.gms.ads.C0321d;
import com.google.android.gms.ads.C0491k;

@arm
public class aay extends C0940lx {
    public static final Creator<aay> CREATOR = new aaz();

    /* renamed from: a */
    public final String f1650a;

    /* renamed from: b */
    public final int f1651b;

    /* renamed from: c */
    public final int f1652c;

    /* renamed from: d */
    public final boolean f1653d;

    /* renamed from: e */
    public final int f1654e;

    /* renamed from: f */
    public final int f1655f;

    /* renamed from: g */
    public final aay[] f1656g;

    /* renamed from: h */
    public final boolean f1657h;

    /* renamed from: i */
    public final boolean f1658i;

    /* renamed from: j */
    public boolean f1659j;

    public aay() {
        this("interstitial_mb", 0, 0, true, 0, 0, null, false, false, false);
    }

    public aay(Context context, C0321d dVar) {
        this(context, new C0321d[]{dVar});
    }

    /* JADX WARNING: Removed duplicated region for block: B:22:0x007c  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public aay(android.content.Context r12, com.google.android.gms.ads.C0321d[] r13) {
        /*
            r11 = this;
            r11.<init>()
            r0 = 0
            r1 = r13[r0]
            r11.f1653d = r0
            boolean r2 = r1.mo1236c()
            r11.f1658i = r2
            boolean r2 = r11.f1658i
            if (r2 == 0) goto L_0x0021
            com.google.android.gms.ads.d r2 = com.google.android.gms.ads.C0321d.f827a
            int r2 = r2.mo1234b()
            r11.f1654e = r2
            com.google.android.gms.ads.d r2 = com.google.android.gms.ads.C0321d.f827a
            int r2 = r2.mo1232a()
            goto L_0x002b
        L_0x0021:
            int r2 = r1.mo1234b()
            r11.f1654e = r2
            int r2 = r1.mo1232a()
        L_0x002b:
            r11.f1651b = r2
            int r2 = r11.f1654e
            r3 = -1
            r4 = 1
            if (r2 != r3) goto L_0x0035
            r2 = r4
            goto L_0x0036
        L_0x0035:
            r2 = r0
        L_0x0036:
            int r3 = r11.f1651b
            r5 = -2
            if (r3 != r5) goto L_0x003d
            r3 = r4
            goto L_0x003e
        L_0x003d:
            r3 = r0
        L_0x003e:
            android.content.res.Resources r5 = r12.getResources()
            android.util.DisplayMetrics r5 = r5.getDisplayMetrics()
            if (r2 == 0) goto L_0x007f
            com.google.android.gms.internal.abj.m2380a()
            boolean r6 = com.google.android.gms.internal.C0851ip.m4719g(r12)
            if (r6 == 0) goto L_0x0065
            com.google.android.gms.internal.abj.m2380a()
            boolean r6 = com.google.android.gms.internal.C0851ip.m4720h(r12)
            if (r6 == 0) goto L_0x0065
            int r6 = r5.widthPixels
            com.google.android.gms.internal.abj.m2380a()
            int r7 = com.google.android.gms.internal.C0851ip.m4721i(r12)
            int r6 = r6 - r7
            goto L_0x0067
        L_0x0065:
            int r6 = r5.widthPixels
        L_0x0067:
            r11.f1655f = r6
            int r6 = r11.f1655f
            float r6 = (float) r6
            float r7 = r5.density
            float r6 = r6 / r7
            double r6 = (double) r6
            int r8 = (int) r6
            double r9 = (double) r8
            double r6 = r6 - r9
            r9 = 4576918229304087675(0x3f847ae147ae147b, double:0.01)
            int r6 = (r6 > r9 ? 1 : (r6 == r9 ? 0 : -1))
            if (r6 < 0) goto L_0x008c
            int r8 = r8 + 1
            goto L_0x008c
        L_0x007f:
            int r8 = r11.f1654e
            com.google.android.gms.internal.abj.m2380a()
            int r6 = r11.f1654e
            int r6 = com.google.android.gms.internal.C0851ip.m4703a(r5, r6)
            r11.f1655f = r6
        L_0x008c:
            if (r3 == 0) goto L_0x0093
            int r6 = m2349c(r5)
            goto L_0x0095
        L_0x0093:
            int r6 = r11.f1651b
        L_0x0095:
            com.google.android.gms.internal.abj.m2380a()
            int r5 = com.google.android.gms.internal.C0851ip.m4703a(r5, r6)
            r11.f1652c = r5
            if (r2 != 0) goto L_0x00af
            if (r3 == 0) goto L_0x00a3
            goto L_0x00af
        L_0x00a3:
            boolean r2 = r11.f1658i
            if (r2 == 0) goto L_0x00aa
            java.lang.String r1 = "320x50_mb"
            goto L_0x00ca
        L_0x00aa:
            java.lang.String r1 = r1.toString()
            goto L_0x00ca
        L_0x00af:
            r1 = 26
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>(r1)
            r2.append(r8)
            java.lang.String r1 = "x"
            r2.append(r1)
            r2.append(r6)
            java.lang.String r1 = "_as"
            r2.append(r1)
            java.lang.String r1 = r2.toString()
        L_0x00ca:
            r11.f1650a = r1
            int r1 = r13.length
            if (r1 <= r4) goto L_0x00e6
            int r1 = r13.length
            com.google.android.gms.internal.aay[] r1 = new com.google.android.gms.internal.aay[r1]
            r11.f1656g = r1
            r1 = r0
        L_0x00d5:
            int r2 = r13.length
            if (r1 >= r2) goto L_0x00e9
            com.google.android.gms.internal.aay[] r2 = r11.f1656g
            com.google.android.gms.internal.aay r3 = new com.google.android.gms.internal.aay
            r4 = r13[r1]
            r3.<init>(r12, r4)
            r2[r1] = r3
            int r1 = r1 + 1
            goto L_0x00d5
        L_0x00e6:
            r12 = 0
            r11.f1656g = r12
        L_0x00e9:
            r11.f1657h = r0
            r11.f1659j = r0
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.aay.<init>(android.content.Context, com.google.android.gms.ads.d[]):void");
    }

    public aay(aay aay, aay[] aayArr) {
        this(aay.f1650a, aay.f1651b, aay.f1652c, aay.f1653d, aay.f1654e, aay.f1655f, aayArr, aay.f1657h, aay.f1658i, aay.f1659j);
    }

    aay(String str, int i, int i2, boolean z, int i3, int i4, aay[] aayArr, boolean z2, boolean z3, boolean z4) {
        this.f1650a = str;
        this.f1651b = i;
        this.f1652c = i2;
        this.f1653d = z;
        this.f1654e = i3;
        this.f1655f = i4;
        this.f1656g = aayArr;
        this.f1657h = z2;
        this.f1658i = z3;
        this.f1659j = z4;
    }

    /* renamed from: a */
    public static int m2345a(DisplayMetrics displayMetrics) {
        return displayMetrics.widthPixels;
    }

    /* renamed from: a */
    public static aay m2346a() {
        aay aay = new aay("reward_mb", 0, 0, true, 0, 0, null, false, false, false);
        return aay;
    }

    /* renamed from: a */
    public static aay m2347a(Context context) {
        aay aay = new aay("320x50_mb", 0, 0, false, 0, 0, null, true, false, false);
        return aay;
    }

    /* renamed from: b */
    public static int m2348b(DisplayMetrics displayMetrics) {
        return (int) (((float) m2349c(displayMetrics)) * displayMetrics.density);
    }

    /* renamed from: c */
    private static int m2349c(DisplayMetrics displayMetrics) {
        int i = (int) (((float) displayMetrics.heightPixels) / displayMetrics.density);
        if (i <= 400) {
            return 32;
        }
        return i <= 720 ? 50 : 90;
    }

    /* renamed from: b */
    public final C0321d mo1938b() {
        return C0491k.m1978a(this.f1654e, this.f1651b, this.f1650a);
    }

    public void writeToParcel(Parcel parcel, int i) {
        int a = C0944ma.m5103a(parcel);
        C0944ma.m5111a(parcel, 2, this.f1650a, false);
        C0944ma.m5106a(parcel, 3, this.f1651b);
        C0944ma.m5106a(parcel, 4, this.f1652c);
        C0944ma.m5113a(parcel, 5, this.f1653d);
        C0944ma.m5106a(parcel, 6, this.f1654e);
        C0944ma.m5106a(parcel, 7, this.f1655f);
        C0944ma.m5115a(parcel, 8, (T[]) this.f1656g, i, false);
        C0944ma.m5113a(parcel, 9, this.f1657h);
        C0944ma.m5113a(parcel, 10, this.f1658i);
        C0944ma.m5113a(parcel, 11, this.f1659j);
        C0944ma.m5104a(parcel, a);
    }
}
