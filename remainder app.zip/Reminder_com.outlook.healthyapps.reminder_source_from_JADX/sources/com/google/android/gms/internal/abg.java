package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.common.C0571q;
import com.google.android.gms.p012a.C0282c;

final class abg extends C0617a<aca> {

    /* renamed from: a */
    private /* synthetic */ Context f1684a;

    /* renamed from: b */
    private /* synthetic */ aay f1685b;

    /* renamed from: c */
    private /* synthetic */ String f1686c;

    /* renamed from: d */
    private /* synthetic */ amx f1687d;

    /* renamed from: e */
    private /* synthetic */ abc f1688e;

    abg(abc abc, Context context, aay aay, String str, amx amx) {
        this.f1688e = abc;
        this.f1684a = context;
        this.f1685b = aay;
        this.f1686c = str;
        this.f1687d = amx;
        super();
    }

    /* renamed from: a */
    public final /* synthetic */ Object mo1947a() {
        aca a = this.f1688e.f1665c.mo1930a(this.f1684a, this.f1685b, this.f1686c, this.f1687d, 2);
        if (a != null) {
            return a;
        }
        abc.m2358a(this.f1684a, "interstitial");
        return new adn();
    }

    /* renamed from: a */
    public final /* synthetic */ Object mo1948a(acj acj) {
        return acj.createInterstitialAdManager(C0282c.m1239a(this.f1684a), this.f1685b, this.f1686c, this.f1687d, C0571q.f1529a);
    }
}
