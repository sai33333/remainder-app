package com.google.android.gms.internal;

import android.app.Activity;
import com.google.android.gms.p012a.C0282c;

final class abi extends C0617a<aox> {

    /* renamed from: a */
    private /* synthetic */ Activity f1693a;

    /* renamed from: b */
    private /* synthetic */ abc f1694b;

    abi(abc abc, Activity activity) {
        this.f1694b = abc;
        this.f1693a = activity;
        super();
    }

    /* renamed from: a */
    public final /* synthetic */ Object mo1947a() {
        aox a = this.f1694b.f1670h.mo2500a(this.f1693a);
        if (a != null) {
            return a;
        }
        abc.m2358a(this.f1693a, "ad_overlay");
        return null;
    }

    /* renamed from: a */
    public final /* synthetic */ Object mo1948a(acj acj) {
        return acj.createAdOverlay(C0282c.m1239a(this.f1693a));
    }
}
