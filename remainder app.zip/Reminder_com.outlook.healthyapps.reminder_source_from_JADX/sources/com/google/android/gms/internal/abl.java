package com.google.android.gms.internal;

import com.google.android.gms.ads.C0285a;

@arm
public class abl extends C0285a {

    /* renamed from: a */
    private final Object f1700a = new Object();

    /* renamed from: b */
    private C0285a f1701b;

    /* renamed from: a */
    public void mo990a() {
        synchronized (this.f1700a) {
            if (this.f1701b != null) {
                this.f1701b.mo990a();
            }
        }
    }

    /* renamed from: a */
    public void mo991a(int i) {
        synchronized (this.f1700a) {
            if (this.f1701b != null) {
                this.f1701b.mo991a(i);
            }
        }
    }

    /* renamed from: a */
    public final void mo1953a(C0285a aVar) {
        synchronized (this.f1700a) {
            this.f1701b = aVar;
        }
    }

    /* renamed from: b */
    public void mo992b() {
        synchronized (this.f1700a) {
            if (this.f1701b != null) {
                this.f1701b.mo992b();
            }
        }
    }

    /* renamed from: c */
    public void mo1072c() {
        synchronized (this.f1700a) {
            if (this.f1701b != null) {
                this.f1701b.mo1072c();
            }
        }
    }

    /* renamed from: d */
    public void mo1073d() {
        synchronized (this.f1700a) {
            if (this.f1701b != null) {
                this.f1701b.mo1073d();
            }
        }
    }
}
