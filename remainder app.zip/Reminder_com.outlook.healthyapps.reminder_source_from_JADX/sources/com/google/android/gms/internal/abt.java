package com.google.android.gms.internal;

public abstract class abt extends C1179sp implements abs {
    public abt() {
        attachInterface(this, "com.google.android.gms.ads.internal.client.IAdLoader");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x0031, code lost:
        r4.writeNoException();
        r4.writeString(r2);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0043, code lost:
        r4.writeNoException();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:13:0x0046, code lost:
        return true;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onTransact(int r2, android.os.Parcel r3, android.os.Parcel r4, int r5) {
        /*
            r1 = this;
            boolean r5 = r1.zza(r2, r3, r4, r5)
            r0 = 1
            if (r5 == 0) goto L_0x0008
            return r0
        L_0x0008:
            switch(r2) {
                case 1: goto L_0x0038;
                case 2: goto L_0x002d;
                case 3: goto L_0x0022;
                case 4: goto L_0x001d;
                case 5: goto L_0x000d;
                default: goto L_0x000b;
            }
        L_0x000b:
            r2 = 0
            return r2
        L_0x000d:
            android.os.Parcelable$Creator<com.google.android.gms.internal.aau> r2 = com.google.android.gms.internal.aau.CREATOR
            android.os.Parcelable r2 = com.google.android.gms.internal.C1181sr.m5730a(r3, r2)
            com.google.android.gms.internal.aau r2 = (com.google.android.gms.internal.aau) r2
            int r3 = r3.readInt()
            r1.mo1472a(r2, r3)
            goto L_0x0043
        L_0x001d:
            java.lang.String r2 = r1.mo1473b()
            goto L_0x0031
        L_0x0022:
            boolean r2 = r1.mo1474c()
            r4.writeNoException()
            com.google.android.gms.internal.C1181sr.m5733a(r4, r2)
            goto L_0x0046
        L_0x002d:
            java.lang.String r2 = r1.mo1470a()
        L_0x0031:
            r4.writeNoException()
            r4.writeString(r2)
            goto L_0x0046
        L_0x0038:
            android.os.Parcelable$Creator<com.google.android.gms.internal.aau> r2 = com.google.android.gms.internal.aau.CREATOR
            android.os.Parcelable r2 = com.google.android.gms.internal.C1181sr.m5730a(r3, r2)
            com.google.android.gms.internal.aau r2 = (com.google.android.gms.internal.aau) r2
            r1.mo1471a(r2)
        L_0x0043:
            r4.writeNoException()
        L_0x0046:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.abt.onTransact(int, android.os.Parcel, android.os.Parcel, int):boolean");
    }
}
