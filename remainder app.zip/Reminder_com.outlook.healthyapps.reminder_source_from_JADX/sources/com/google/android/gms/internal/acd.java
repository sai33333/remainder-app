package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.p012a.C0279a;
import com.google.android.gms.p012a.C0279a.C0280a;

public final class acd extends C1178so implements aca {
    acd(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.ads.internal.client.IAdManager");
    }

    /* renamed from: A */
    public final abp mo1280A() {
        abp abp;
        Parcel a = mo3281a(33, mo3284j_());
        IBinder readStrongBinder = a.readStrongBinder();
        if (readStrongBinder == null) {
            abp = null;
        } else {
            IInterface queryLocalInterface = readStrongBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IAdListener");
            abp = queryLocalInterface instanceof abp ? (abp) queryLocalInterface : new abr(readStrongBinder);
        }
        a.recycle();
        return abp;
    }

    /* renamed from: B */
    public final void mo1337B() {
        mo3283b(9, mo3284j_());
    }

    /* renamed from: a */
    public final String mo1377a() {
        Parcel a = mo3281a(18, mo3284j_());
        String readString = a.readString();
        a.recycle();
        return readString;
    }

    /* renamed from: a */
    public final void mo1285a(aay aay) {
        Parcel j_ = mo3284j_();
        C1181sr.m5732a(j_, (Parcelable) aay);
        mo3283b(13, j_);
    }

    /* renamed from: a */
    public final void mo1286a(abm abm) {
        Parcel j_ = mo3284j_();
        C1181sr.m5731a(j_, (IInterface) abm);
        mo3283b(20, j_);
    }

    /* renamed from: a */
    public final void mo1287a(abp abp) {
        Parcel j_ = mo3284j_();
        C1181sr.m5731a(j_, (IInterface) abp);
        mo3283b(7, j_);
    }

    /* renamed from: a */
    public final void mo1288a(acg acg) {
        Parcel j_ = mo3284j_();
        C1181sr.m5731a(j_, (IInterface) acg);
        mo3283b(8, j_);
    }

    /* renamed from: a */
    public final void mo1289a(acm acm) {
        Parcel j_ = mo3284j_();
        C1181sr.m5731a(j_, (IInterface) acm);
        mo3283b(21, j_);
    }

    /* renamed from: a */
    public final void mo1290a(ada ada) {
        Parcel j_ = mo3284j_();
        C1181sr.m5732a(j_, (Parcelable) ada);
        mo3283b(30, j_);
    }

    /* renamed from: a */
    public final void mo1291a(adt adt) {
        Parcel j_ = mo3284j_();
        C1181sr.m5732a(j_, (Parcelable) adt);
        mo3283b(29, j_);
    }

    /* renamed from: a */
    public final void mo1293a(aff aff) {
        Parcel j_ = mo3284j_();
        C1181sr.m5731a(j_, (IInterface) aff);
        mo3283b(19, j_);
    }

    /* renamed from: a */
    public final void mo1294a(ape ape) {
        Parcel j_ = mo3284j_();
        C1181sr.m5731a(j_, (IInterface) ape);
        mo3283b(14, j_);
    }

    /* renamed from: a */
    public final void mo1295a(apk apk, String str) {
        Parcel j_ = mo3284j_();
        C1181sr.m5731a(j_, (IInterface) apk);
        j_.writeString(str);
        mo3283b(15, j_);
    }

    /* renamed from: a */
    public final void mo1296a(C0689cp cpVar) {
        Parcel j_ = mo3284j_();
        C1181sr.m5731a(j_, (IInterface) cpVar);
        mo3283b(24, j_);
    }

    /* renamed from: a */
    public final void mo1300a(String str) {
        Parcel j_ = mo3284j_();
        j_.writeString(str);
        mo3283b(25, j_);
    }

    /* renamed from: a */
    public final void mo1303a(boolean z) {
        Parcel j_ = mo3284j_();
        C1181sr.m5733a(j_, z);
        mo3283b(22, j_);
    }

    /* renamed from: b */
    public final void mo1308b(boolean z) {
        Parcel j_ = mo3284j_();
        C1181sr.m5733a(j_, z);
        mo3283b(34, j_);
    }

    /* renamed from: b */
    public final boolean mo1309b(aau aau) {
        Parcel j_ = mo3284j_();
        C1181sr.m5732a(j_, (Parcelable) aau);
        Parcel a = mo3281a(4, j_);
        boolean a2 = C1181sr.m5734a(a);
        a.recycle();
        return a2;
    }

    /* renamed from: g */
    public final void mo1314g() {
        mo3283b(2, mo3284j_());
    }

    /* renamed from: g_ */
    public final String mo1382g_() {
        Parcel a = mo3281a(35, mo3284j_());
        String readString = a.readString();
        a.recycle();
        return readString;
    }

    /* renamed from: h */
    public final C0279a mo1315h() {
        Parcel a = mo3281a(1, mo3284j_());
        C0279a a2 = C0280a.m1238a(a.readStrongBinder());
        a.recycle();
        return a2;
    }

    /* renamed from: i */
    public final aay mo1316i() {
        Parcel a = mo3281a(12, mo3284j_());
        aay aay = (aay) C1181sr.m5730a(a, aay.CREATOR);
        a.recycle();
        return aay;
    }

    /* renamed from: j */
    public final boolean mo1317j() {
        Parcel a = mo3281a(3, mo3284j_());
        boolean a2 = C1181sr.m5734a(a);
        a.recycle();
        return a2;
    }

    /* renamed from: k */
    public final void mo1318k() {
        mo3283b(11, mo3284j_());
    }

    /* renamed from: l */
    public final void mo1319l() {
        mo3283b(5, mo3284j_());
    }

    /* renamed from: m */
    public final void mo1320m() {
        mo3283b(6, mo3284j_());
    }

    /* renamed from: n */
    public final void mo1321n() {
        mo3283b(10, mo3284j_());
    }

    /* renamed from: o */
    public final boolean mo1322o() {
        Parcel a = mo3281a(23, mo3284j_());
        boolean a2 = C1181sr.m5734a(a);
        a.recycle();
        return a2;
    }

    /* renamed from: p */
    public final acu mo1323p() {
        acu acu;
        Parcel a = mo3281a(26, mo3284j_());
        IBinder readStrongBinder = a.readStrongBinder();
        if (readStrongBinder == null) {
            acu = null;
        } else {
            IInterface queryLocalInterface = readStrongBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IVideoController");
            acu = queryLocalInterface instanceof acu ? (acu) queryLocalInterface : new acw(readStrongBinder);
        }
        a.recycle();
        return acu;
    }

    /* renamed from: y */
    public final String mo1332y() {
        Parcel a = mo3281a(31, mo3284j_());
        String readString = a.readString();
        a.recycle();
        return readString;
    }

    /* renamed from: z */
    public final acg mo1333z() {
        acg acg;
        Parcel a = mo3281a(32, mo3284j_());
        IBinder readStrongBinder = a.readStrongBinder();
        if (readStrongBinder == null) {
            acg = null;
        } else {
            IInterface queryLocalInterface = readStrongBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IAppEventListener");
            acg = queryLocalInterface instanceof acg ? (acg) queryLocalInterface : new aci(readStrongBinder);
        }
        a.recycle();
        return acg;
    }
}
