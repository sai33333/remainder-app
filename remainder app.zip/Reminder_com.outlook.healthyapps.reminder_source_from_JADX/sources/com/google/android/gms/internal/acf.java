package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.C0571q;
import com.google.android.gms.p012a.C0279a;

public final class acf extends C1178so implements ace {
    acf(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.ads.internal.client.IAdManagerCreator");
    }

    /* renamed from: a */
    public final IBinder mo1964a(C0279a aVar, aay aay, String str, amx amx, int i, int i2) {
        Parcel j_ = mo3284j_();
        C1181sr.m5731a(j_, (IInterface) aVar);
        C1181sr.m5732a(j_, (Parcelable) aay);
        j_.writeString(str);
        C1181sr.m5731a(j_, (IInterface) amx);
        j_.writeInt(C0571q.f1529a);
        j_.writeInt(i2);
        Parcel a = mo3281a(2, j_);
        IBinder readStrongBinder = a.readStrongBinder();
        a.recycle();
        return readStrongBinder;
    }
}
