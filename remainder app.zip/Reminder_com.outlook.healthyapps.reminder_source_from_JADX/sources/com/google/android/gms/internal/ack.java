package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import com.google.android.gms.p012a.C0279a.C0280a;

public abstract class ack extends C1179sp implements acj {
    public ack() {
        attachInterface(this, "com.google.android.gms.ads.internal.client.IClientApi");
    }

    public static acj asInterface(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IClientApi");
        return queryLocalInterface instanceof acj ? (acj) queryLocalInterface : new acl(iBinder);
    }

    public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
        IInterface iInterface;
        if (zza(i, parcel, parcel2, i2)) {
            return true;
        }
        switch (i) {
            case 1:
                iInterface = createBannerAdManager(C0280a.m1238a(parcel.readStrongBinder()), (aay) C1181sr.m5730a(parcel, aay.CREATOR), parcel.readString(), amy.m3488a(parcel.readStrongBinder()), parcel.readInt());
                break;
            case 2:
                iInterface = createInterstitialAdManager(C0280a.m1238a(parcel.readStrongBinder()), (aay) C1181sr.m5730a(parcel, aay.CREATOR), parcel.readString(), amy.m3488a(parcel.readStrongBinder()), parcel.readInt());
                break;
            case 3:
                iInterface = createAdLoaderBuilder(C0280a.m1238a(parcel.readStrongBinder()), parcel.readString(), amy.m3488a(parcel.readStrongBinder()), parcel.readInt());
                break;
            case C1217ty.f4597d /*4*/:
                iInterface = getMobileAdsSettingsManager(C0280a.m1238a(parcel.readStrongBinder()));
                break;
            case C1217ty.f4598e /*5*/:
                iInterface = createNativeAdViewDelegate(C0280a.m1238a(parcel.readStrongBinder()), C0280a.m1238a(parcel.readStrongBinder()));
                break;
            case C1217ty.f4599f /*6*/:
                iInterface = createRewardedVideoAd(C0280a.m1238a(parcel.readStrongBinder()), amy.m3488a(parcel.readStrongBinder()), parcel.readInt());
                break;
            case C1217ty.f4600g /*7*/:
                iInterface = createInAppPurchaseManager(C0280a.m1238a(parcel.readStrongBinder()));
                break;
            case C1217ty.f4601h /*8*/:
                iInterface = createAdOverlay(C0280a.m1238a(parcel.readStrongBinder()));
                break;
            case 9:
                iInterface = getMobileAdsSettingsManagerWithClientJarVersion(C0280a.m1238a(parcel.readStrongBinder()), parcel.readInt());
                break;
            case 10:
                iInterface = createSearchAdManager(C0280a.m1238a(parcel.readStrongBinder()), (aay) C1181sr.m5730a(parcel, aay.CREATOR), parcel.readString(), parcel.readInt());
                break;
            default:
                return false;
        }
        parcel2.writeNoException();
        C1181sr.m5731a(parcel2, iInterface);
        return true;
    }
}
