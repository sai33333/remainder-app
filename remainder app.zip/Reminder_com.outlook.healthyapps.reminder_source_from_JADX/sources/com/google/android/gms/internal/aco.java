package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.Parcel;

public final class aco extends C1178so implements acm {
    aco(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.ads.internal.client.ICorrelationIdProvider");
    }

    /* renamed from: a */
    public final long mo1952a() {
        Parcel a = mo3281a(1, mo3284j_());
        long readLong = a.readLong();
        a.recycle();
        return readLong;
    }
}
