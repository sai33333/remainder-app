package com.google.android.gms.internal;

import android.os.IInterface;

public interface acu extends IInterface {
    /* renamed from: a */
    void mo1969a();

    /* renamed from: a */
    void mo1970a(acx acx);

    /* renamed from: a */
    void mo1971a(boolean z);

    /* renamed from: b */
    void mo1972b();

    /* renamed from: c */
    boolean mo1973c();

    /* renamed from: d */
    int mo1974d();

    /* renamed from: e */
    float mo1975e();

    /* renamed from: f */
    float mo1976f();

    /* renamed from: g */
    float mo1977g();

    /* renamed from: h */
    acx mo1978h();

    /* renamed from: i */
    boolean mo1979i();
}
