package com.google.android.gms.internal;

import android.os.IInterface;

public interface acx extends IInterface {
    /* renamed from: a */
    void mo1981a();

    /* renamed from: a */
    void mo1982a(boolean z);

    /* renamed from: b */
    void mo1983b();

    /* renamed from: c */
    void mo1984c();

    /* renamed from: d */
    void mo1985d();
}
