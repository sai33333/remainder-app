package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;

public final class adb implements Creator<ada> {
    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        int a = C0941ly.m5082a(parcel);
        int i = 0;
        while (parcel.dataPosition() < a) {
            int readInt = parcel.readInt();
            if ((65535 & readInt) != 2) {
                C0941ly.m5086b(parcel, readInt);
            } else {
                i = C0941ly.m5089d(parcel, readInt);
            }
        }
        C0941ly.m5098m(parcel, a);
        return new ada(i);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new ada[i];
    }
}
