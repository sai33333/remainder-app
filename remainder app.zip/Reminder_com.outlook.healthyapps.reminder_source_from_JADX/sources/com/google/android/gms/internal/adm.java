package com.google.android.gms.internal;

import android.os.RemoteException;

final class adm implements Runnable {

    /* renamed from: a */
    private /* synthetic */ adl f1778a;

    adm(adl adl) {
        this.f1778a = adl;
    }

    public final void run() {
        if (this.f1778a.f1777a.f1776a != null) {
            try {
                this.f1778a.f1777a.f1776a.mo1923a(1);
            } catch (RemoteException e) {
                C0855it.m4732c("Could not notify onAdFailedToLoad event.", e);
            }
        }
    }
}
