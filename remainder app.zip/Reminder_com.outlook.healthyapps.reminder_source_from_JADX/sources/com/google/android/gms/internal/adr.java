package com.google.android.gms.internal;

import android.os.Parcel;

@arm
public final class adr extends aay {
    public adr(aay aay) {
        super(aay.f1650a, aay.f1651b, aay.f1652c, aay.f1653d, aay.f1654e, aay.f1655f, aay.f1656g, aay.f1657h, aay.f1658i, aay.f1659j);
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a = C0944ma.m5103a(parcel);
        C0944ma.m5111a(parcel, 2, this.f1650a, false);
        C0944ma.m5106a(parcel, 3, this.f1651b);
        C0944ma.m5106a(parcel, 6, this.f1654e);
        C0944ma.m5104a(parcel, a);
    }
}
