package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.ads.C0329i;

@arm
public final class adt extends C0940lx {
    public static final Creator<adt> CREATOR = new adu();

    /* renamed from: a */
    public final boolean f1783a;

    /* renamed from: b */
    public final boolean f1784b;

    public adt(C0329i iVar) {
        this(iVar.mo1268a(), iVar.mo1269b());
    }

    public adt(boolean z, boolean z2) {
        this.f1783a = z;
        this.f1784b = z2;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a = C0944ma.m5103a(parcel);
        C0944ma.m5113a(parcel, 2, this.f1783a);
        C0944ma.m5113a(parcel, 3, this.f1784b);
        C0944ma.m5104a(parcel, a);
    }
}
