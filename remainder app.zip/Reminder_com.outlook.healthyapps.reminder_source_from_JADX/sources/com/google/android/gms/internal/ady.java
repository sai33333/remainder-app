package com.google.android.gms.internal;

import android.text.TextUtils;

@arm
public final class ady {

    /* renamed from: a */
    private String f1786a;

    public ady() {
        this((String) ael.f1828a.mo2071b());
    }

    public ady(String str) {
        if (TextUtils.isEmpty(str)) {
            str = (String) ael.f1828a.mo2071b();
        }
        this.f1786a = str;
    }
}
