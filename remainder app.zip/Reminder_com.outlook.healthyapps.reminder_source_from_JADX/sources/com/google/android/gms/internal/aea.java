package com.google.android.gms.internal;

import java.util.List;

public interface aea {
    /* renamed from: a */
    List<String> mo2064a(List<String> list);
}
