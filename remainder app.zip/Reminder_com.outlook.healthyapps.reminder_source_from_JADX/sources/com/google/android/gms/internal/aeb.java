package com.google.android.gms.internal;

import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import com.google.android.gms.ads.internal.C0354ax;
import org.json.JSONObject;

@arm
public abstract class aeb<T> {

    /* renamed from: a */
    private final int f1790a;

    /* renamed from: b */
    private final String f1791b;

    /* renamed from: c */
    private final T f1792c;

    private aeb(int i, String str, T t) {
        this.f1790a = i;
        this.f1791b = str;
        this.f1792c = t;
        C0354ax.m1550q().mo2075a(this);
    }

    /* synthetic */ aeb(int i, String str, Object obj, aec aec) {
        this(i, str, obj);
    }

    /* renamed from: a */
    public static aeb<String> m2706a(int i, String str) {
        aeb<String> a = m2711a(i, str, (String) null);
        C0354ax.m1550q().mo2077b(a);
        return a;
    }

    /* renamed from: a */
    public static aeb<Float> m2707a(int i, String str, float f) {
        return new aef(i, str, Float.valueOf(0.0f));
    }

    /* renamed from: a */
    public static aeb<Integer> m2708a(int i, String str, int i2) {
        return new aed(i, str, Integer.valueOf(i2));
    }

    /* renamed from: a */
    public static aeb<Long> m2709a(int i, String str, long j) {
        return new aee(i, str, Long.valueOf(j));
    }

    /* renamed from: a */
    public static aeb<Boolean> m2710a(int i, String str, Boolean bool) {
        return new aec(i, str, bool);
    }

    /* renamed from: a */
    public static aeb<String> m2711a(int i, String str, String str2) {
        return new aeg(i, str, str2);
    }

    /* renamed from: b */
    public static aeb<String> m2712b(int i, String str) {
        aeb<String> a = m2711a(i, str, (String) null);
        C0354ax.m1550q().mo2078c(a);
        return a;
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public abstract T mo2067a(SharedPreferences sharedPreferences);

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public abstract T mo2068a(JSONObject jSONObject);

    /* renamed from: a */
    public final String mo2069a() {
        return this.f1791b;
    }

    /* renamed from: a */
    public abstract void mo2070a(Editor editor, T t);

    /* renamed from: b */
    public final T mo2071b() {
        return this.f1792c;
    }

    /* renamed from: c */
    public final int mo2072c() {
        return this.f1790a;
    }
}
