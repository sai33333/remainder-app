package com.google.android.gms.internal;

import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import org.json.JSONObject;

final class aee extends aeb<Long> {
    aee(int i, String str, Long l) {
        super(i, str, l, null);
    }

    /* renamed from: a */
    public final /* synthetic */ Object mo2067a(SharedPreferences sharedPreferences) {
        return Long.valueOf(sharedPreferences.getLong(mo2069a(), ((Long) mo2071b()).longValue()));
    }

    /* renamed from: a */
    public final /* synthetic */ Object mo2068a(JSONObject jSONObject) {
        return Long.valueOf(jSONObject.optLong(mo2069a(), ((Long) mo2071b()).longValue()));
    }

    /* renamed from: a */
    public final /* synthetic */ void mo2070a(Editor editor, Object obj) {
        editor.putLong(mo2069a(), ((Long) obj).longValue());
    }
}
