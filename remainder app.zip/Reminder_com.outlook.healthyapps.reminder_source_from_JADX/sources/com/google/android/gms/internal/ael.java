package com.google.android.gms.internal;

import android.content.Context;
import android.content.SharedPreferences.Editor;
import com.google.android.gms.ads.internal.C0354ax;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.json.JSONObject;

@arm
public final class ael {

    /* renamed from: A */
    public static final aeb<Boolean> f1802A = aeb.m2710a(1, "gads:memory_bundle:runtime_info", Boolean.valueOf(true));

    /* renamed from: B */
    public static final aeb<String> f1803B = aeb.m2711a(1, "gads:video:codec_query_mime_types", "");

    /* renamed from: C */
    public static final aeb<Integer> f1804C = aeb.m2708a(1, "gads:video:codec_query_minimum_version", 16);

    /* renamed from: D */
    public static final aeb<Boolean> f1805D = aeb.m2710a(0, "gads:looper_for_gms_client:enabled", Boolean.valueOf(true));

    /* renamed from: E */
    public static final aeb<Boolean> f1806E = aeb.m2710a(0, "gads:sw_ad_request_service:enabled", Boolean.valueOf(true));

    /* renamed from: F */
    public static final aeb<String> f1807F = aeb.m2711a(1, "gad:mraid:url_banner", "https://googleads.g.doubleclick.net/mads/static/mad/sdk/native/mraid/v2/mraid_app_banner.js");

    /* renamed from: G */
    public static final aeb<String> f1808G = aeb.m2711a(1, "gad:mraid:url_expanded_banner", "https://googleads.g.doubleclick.net/mads/static/mad/sdk/native/mraid/v2/mraid_app_expanded_banner.js");

    /* renamed from: H */
    public static final aeb<String> f1809H = aeb.m2711a(1, "gad:mraid:url_interstitial", "https://googleads.g.doubleclick.net/mads/static/mad/sdk/native/mraid/v2/mraid_app_interstitial.js");

    /* renamed from: I */
    public static final aeb<Boolean> f1810I = aeb.m2710a(0, "gads:enabled_sdk_csi", Boolean.valueOf(false));

    /* renamed from: J */
    public static final aeb<String> f1811J = aeb.m2711a(0, "gads:sdk_csi_server", "https://csi.gstatic.com/csi");

    /* renamed from: K */
    public static final aeb<Boolean> f1812K = aeb.m2710a(0, "gads:sdk_csi_write_to_file", Boolean.valueOf(false));

    /* renamed from: L */
    public static final aeb<Boolean> f1813L = aeb.m2710a(0, "gads:enable_content_fetching", Boolean.valueOf(true));

    /* renamed from: M */
    public static final aeb<Integer> f1814M = aeb.m2708a(0, "gads:content_length_weight", 1);

    /* renamed from: N */
    public static final aeb<Integer> f1815N = aeb.m2708a(0, "gads:content_age_weight", 1);

    /* renamed from: O */
    public static final aeb<Integer> f1816O = aeb.m2708a(0, "gads:min_content_len", 11);

    /* renamed from: P */
    public static final aeb<Integer> f1817P = aeb.m2708a(0, "gads:fingerprint_number", 10);

    /* renamed from: Q */
    public static final aeb<Integer> f1818Q = aeb.m2708a(0, "gads:sleep_sec", 10);

    /* renamed from: R */
    public static final aeb<Boolean> f1819R = aeb.m2710a(1, "gads:enable_content_url_hash", Boolean.valueOf(true));

    /* renamed from: S */
    public static final aeb<Integer> f1820S = aeb.m2708a(1, "gads:content_vertical_fingerprint_number", 100);

    /* renamed from: T */
    public static final aeb<Boolean> f1821T = aeb.m2710a(1, "gads:enable_content_vertical_hash", Boolean.valueOf(true));

    /* renamed from: U */
    public static final aeb<Integer> f1822U = aeb.m2708a(1, "gads:content_vertical_fingerprint_bits", 23);

    /* renamed from: V */
    public static final aeb<Integer> f1823V = aeb.m2708a(1, "gads:content_vertical_fingerprint_ngram", 3);

    /* renamed from: W */
    public static final aeb<String> f1824W = aeb.m2711a(1, "gads:content_fetch_view_tag_id", "googlebot");

    /* renamed from: X */
    public static final aeb<String> f1825X = aeb.m2711a(1, "gads:content_fetch_exclude_view_tag", "none");

    /* renamed from: Y */
    public static final aeb<Boolean> f1826Y = aeb.m2710a(0, "gad:app_index_enabled", Boolean.valueOf(true));

    /* renamed from: Z */
    public static final aeb<Boolean> f1827Z = aeb.m2710a(1, "gads:content_fetch_disable_get_title_from_webview", Boolean.valueOf(false));

    /* renamed from: a */
    public static final aeb<String> f1828a = aeb.m2711a(0, "gads:sdk_core_location", "https://googleads.g.doubleclick.net/mads/static/mad/sdk/native/sdk-core-v40.html");

    /* renamed from: aA */
    public static final aeb<Long> f1829aA = aeb.m2709a(1, "gads:adid_values_in_adrequest:timeout", 2000);

    /* renamed from: aB */
    public static final aeb<Boolean> f1830aB = aeb.m2710a(1, "gads:disable_adid_values_in_ms", Boolean.valueOf(false));

    /* renamed from: aC */
    public static final aeb<Boolean> f1831aC = aeb.m2710a(1, "gads:enable_ad_loader_manager", Boolean.valueOf(true));

    /* renamed from: aD */
    public static final aeb<Boolean> f1832aD = aeb.m2710a(1, "gads:ad_manager_enforce_arp_invariant:enabled", Boolean.valueOf(false));

    /* renamed from: aE */
    public static final aeb<Long> f1833aE = aeb.m2709a(1, "gads:ad_overlay:delay_page_close_timeout_ms", 5000);

    /* renamed from: aF */
    public static final aeb<Boolean> f1834aF = aeb.m2710a(1, "gads:interstitial_ad_immersive_mode", Boolean.valueOf(true));

    /* renamed from: aG */
    public static final aeb<Boolean> f1835aG = aeb.m2710a(1, "gads:unblock_custom_close_header", Boolean.valueOf(false));

    /* renamed from: aH */
    public static final aeb<Boolean> f1836aH = aeb.m2710a(1, "gads:interstitial_ad_pool:enabled", Boolean.valueOf(false));

    /* renamed from: aI */
    public static final aeb<Boolean> f1837aI = aeb.m2710a(1, "gads:interstitial_ad_pool:enabled_for_rewarded", Boolean.valueOf(false));

    /* renamed from: aJ */
    public static final aeb<String> f1838aJ = aeb.m2711a(1, "gads:interstitial_ad_pool:schema", "customTargeting");

    /* renamed from: aK */
    public static final aeb<String> f1839aK = aeb.m2711a(1, "gads:interstitial_ad_pool:request_exclusions", "com.google.ads.mediation.admob.AdMobAdapter/_ad");

    /* renamed from: aL */
    public static final aeb<Integer> f1840aL = aeb.m2708a(1, "gads:interstitial_ad_pool:max_pools", 3);

    /* renamed from: aM */
    public static final aeb<Integer> f1841aM = aeb.m2708a(1, "gads:interstitial_ad_pool:max_pool_depth", 2);

    /* renamed from: aN */
    public static final aeb<Integer> f1842aN = aeb.m2708a(1, "gads:interstitial_ad_pool:time_limit_sec", 1200);

    /* renamed from: aO */
    public static final aeb<String> f1843aO = aeb.m2711a(1, "gads:interstitial_ad_pool:ad_unit_exclusions", "(?!)");

    /* renamed from: aP */
    public static final aeb<Integer> f1844aP = aeb.m2708a(1, "gads:interstitial_ad_pool:top_off_latency_min_millis", 0);

    /* renamed from: aQ */
    public static final aeb<Integer> f1845aQ = aeb.m2708a(1, "gads:interstitial_ad_pool:top_off_latency_range_millis", 0);

    /* renamed from: aR */
    public static final aeb<Long> f1846aR = aeb.m2709a(1, "gads:interstitial_ad_pool:discard_thresholds", 0);

    /* renamed from: aS */
    public static final aeb<Long> f1847aS = aeb.m2709a(1, "gads:interstitial_ad_pool:miss_thresholds", 0);

    /* renamed from: aT */
    public static final aeb<Float> f1848aT = aeb.m2707a(1, "gads:interstitial_ad_pool:discard_asymptote", 0.0f);

    /* renamed from: aU */
    public static final aeb<Float> f1849aU = aeb.m2707a(1, "gads:interstitial_ad_pool:miss_asymptote", 0.0f);

    /* renamed from: aV */
    public static final aeb<String> f1850aV = aeb.m2711a(1, "gads:spherical_video:vertex_shader", "");

    /* renamed from: aW */
    public static final aeb<String> f1851aW = aeb.m2711a(1, "gads:spherical_video:fragment_shader", "");

    /* renamed from: aX */
    public static final aeb<Boolean> f1852aX = aeb.m2710a(0, "gads:log:verbose_enabled", Boolean.valueOf(false));

    /* renamed from: aY */
    public static final aeb<Boolean> f1853aY = aeb.m2710a(1, "gads:include_local_global_rectangles", Boolean.valueOf(false));

    /* renamed from: aZ */
    public static final aeb<Long> f1854aZ = aeb.m2709a(1, "gads:position_watcher:throttle_ms", 200);

    /* renamed from: aa */
    public static final aeb<Boolean> f1855aa = aeb.m2710a(0, "gads:app_index:without_content_info_present:enabled", Boolean.valueOf(true));

    /* renamed from: ab */
    public static final aeb<Long> f1856ab = aeb.m2709a(0, "gads:app_index:timeout_ms", 1000);

    /* renamed from: ac */
    public static final aeb<Boolean> f1857ac = aeb.m2710a(0, "gads:kitkat_interstitial_workaround:enabled", Boolean.valueOf(true));

    /* renamed from: ad */
    public static final aeb<Boolean> f1858ad = aeb.m2710a(0, "gads:interstitial_follow_url", Boolean.valueOf(true));

    /* renamed from: ae */
    public static final aeb<Boolean> f1859ae = aeb.m2710a(0, "gads:interstitial_follow_url:register_click", Boolean.valueOf(true));

    /* renamed from: af */
    public static final aeb<Boolean> f1860af = aeb.m2710a(0, "gads:ad_key_enabled", Boolean.valueOf(false));

    /* renamed from: ag */
    public static final aeb<Boolean> f1861ag = aeb.m2710a(1, "gads:sai:enabled", Boolean.valueOf(false));

    /* renamed from: ah */
    public static final aeb<Boolean> f1862ah = aeb.m2710a(1, "gads:sai:banner_ad_enabled", Boolean.valueOf(true));

    /* renamed from: ai */
    public static final aeb<Boolean> f1863ai = aeb.m2710a(1, "gads:sai:native_ad_enabled", Boolean.valueOf(true));

    /* renamed from: aj */
    public static final aeb<Boolean> f1864aj = aeb.m2710a(1, "gads:sai:interstitial_ad_enabled", Boolean.valueOf(true));

    /* renamed from: ak */
    public static final aeb<Boolean> f1865ak = aeb.m2710a(1, "gads:sai:rewardedvideo_ad_enabled", Boolean.valueOf(true));

    /* renamed from: al */
    public static final aeb<String> f1866al = aeb.m2711a(1, "gads:sai:click_ping_schema", "[\"/aclk\",\"/pcs/click\"]");

    /* renamed from: am */
    public static final aeb<String> f1867am = aeb.m2711a(1, "gads:sai:impression_ping_schema", "[\"/adview\"]");

    /* renamed from: an */
    public static final aeb<Boolean> f1868an = aeb.m2710a(1, "gads:sai:click_gmsg_enabled", Boolean.valueOf(true));

    /* renamed from: ao */
    public static final aeb<Boolean> f1869ao = aeb.m2710a(1, "gads:sai:using_macro:enabled", Boolean.valueOf(false));

    /* renamed from: ap */
    public static final aeb<String> f1870ap = aeb.m2711a(1, "gads:sai:ad_event_id_macro_name", "[gw_fbsaeid]");

    /* renamed from: aq */
    public static final aeb<Long> f1871aq = aeb.m2709a(1, "gads:sai:timeout_ms", 100);

    /* renamed from: ar */
    public static final aeb<Integer> f1872ar = aeb.m2708a(1, "gads:sai:scion_thread_pool_size", 5);

    /* renamed from: as */
    public static final aeb<Boolean> f1873as = aeb.m2710a(1, "gads:webview_recycle:enabled", Boolean.valueOf(false));

    /* renamed from: at */
    public static final aeb<Boolean> f1874at = aeb.m2710a(1, "gads:webview:ignore_over_scroll", Boolean.valueOf(true));

    /* renamed from: au */
    public static final aeb<Boolean> f1875au = aeb.m2710a(1, "gads:rewarded:adapter_initialization_enabled", Boolean.valueOf(false));

    /* renamed from: av */
    public static final aeb<Long> f1876av = aeb.m2709a(1, "gads:rewarded:adapter_timeout_ms", 20000);

    /* renamed from: aw */
    public static final aeb<Boolean> f1877aw = aeb.m2710a(1, "gads:app_activity_tracker:enabled", Boolean.valueOf(true));

    /* renamed from: ax */
    public static final aeb<Long> f1878ax = aeb.m2709a(1, "gads:app_activity_tracker:notify_background_listeners_delay_ms", 500);

    /* renamed from: ay */
    public static final aeb<Long> f1879ay = aeb.m2709a(1, "gads:app_activity_tracker:app_session_timeout_ms", TimeUnit.MINUTES.toMillis(5));

    /* renamed from: az */
    public static final aeb<Boolean> f1880az = aeb.m2710a(1, "gads:adid_values_in_adrequest:enabled", Boolean.valueOf(false));

    /* renamed from: b */
    public static final aeb<Boolean> f1881b = aeb.m2710a(0, "gads:sdk_crash_report_enabled", Boolean.valueOf(false));

    /* renamed from: bA */
    public static final aeb<Boolean> f1882bA = aeb.m2710a(1, "gads:gestures:check_initialization_thread:enabled", Boolean.valueOf(false));

    /* renamed from: bB */
    public static final aeb<Boolean> f1883bB = aeb.m2710a(1, "gads:gestures:get_query_in_non_ui_thread:enabled", Boolean.valueOf(true));

    /* renamed from: bC */
    public static final aeb<Boolean> f1884bC = aeb.m2710a(0, "gass:enabled", Boolean.valueOf(true));

    /* renamed from: bD */
    public static final aeb<Boolean> f1885bD = aeb.m2710a(0, "gass:enable_int_signal", Boolean.valueOf(true));

    /* renamed from: bE */
    public static final aeb<Boolean> f1886bE = aeb.m2710a(0, "gass:enable_ad_attestation_signal", Boolean.valueOf(true));

    /* renamed from: bF */
    public static final aeb<Boolean> f1887bF = aeb.m2710a(0, "gads:support_screen_shot", Boolean.valueOf(true));

    /* renamed from: bG */
    public static final aeb<Boolean> f1888bG = aeb.m2710a(0, "gads:use_get_drawing_cache_for_screenshot:enabled", Boolean.valueOf(true));

    /* renamed from: bH */
    public static final aeb<String> f1889bH = aeb.m2711a(1, "gads:sdk_core_constants:caps", "");

    /* renamed from: bI */
    public static final aeb<Long> f1890bI = aeb.m2709a(0, "gads:js_flags:update_interval", TimeUnit.HOURS.toMillis(12));

    /* renamed from: bJ */
    public static final aeb<Boolean> f1891bJ = aeb.m2710a(0, "gads:js_flags:mf", Boolean.valueOf(false));

    /* renamed from: bK */
    public static final aeb<Boolean> f1892bK = aeb.m2710a(0, "gads:custom_render:ping_on_ad_rendered", Boolean.valueOf(false));

    /* renamed from: bL */
    public static final aeb<String> f1893bL = aeb.m2711a(1, "gads:native:engine_url_with_protocol", "https://googleads.g.doubleclick.net/mads/static/mad/sdk/native/native_ads.html");

    /* renamed from: bM */
    public static final aeb<String> f1894bM = aeb.m2711a(1, "gads:native:video_url_with_protocol", "https://imasdk.googleapis.com/admob/sdkloader/native_video.html");

    /* renamed from: bN */
    public static final aeb<Boolean> f1895bN = aeb.m2710a(1, "gads:singleton_webview_native", Boolean.valueOf(false));

    /* renamed from: bO */
    public static final aeb<Boolean> f1896bO = aeb.m2710a(1, "gads:native_initialize_webview_request_time", Boolean.valueOf(false));

    /* renamed from: bP */
    public static final aeb<Boolean> f1897bP = aeb.m2710a(1, "gads:enable_untrack_view_native", Boolean.valueOf(true));

    /* renamed from: bQ */
    public static final aeb<Boolean> f1898bQ = aeb.m2710a(1, "gads:ignore_untrack_view_google_native", Boolean.valueOf(true));

    /* renamed from: bR */
    public static final aeb<Boolean> f1899bR = aeb.m2710a(1, "gads:reset_listeners_preparead_native", Boolean.valueOf(true));

    /* renamed from: bS */
    public static final aeb<Integer> f1900bS = aeb.m2708a(1, "gads:native_video_load_timeout", 10);

    /* renamed from: bT */
    public static final aeb<String> f1901bT = aeb.m2711a(1, "gads:ad_choices_content_description", "Ad Choices Icon");

    /* renamed from: bU */
    public static final aeb<Boolean> f1902bU = aeb.m2710a(1, "gads:clamp_native_video_player_dimensions", Boolean.valueOf(true));

    /* renamed from: bV */
    public static final aeb<Boolean> f1903bV = aeb.m2710a(1, "gads:enable_store_active_view_state", Boolean.valueOf(false));

    /* renamed from: bW */
    public static final aeb<Boolean> f1904bW = aeb.m2710a(1, "gads:fluid_ad:use_wrap_content_height", Boolean.valueOf(false));

    /* renamed from: bX */
    public static final aeb<Boolean> f1905bX = aeb.m2710a(0, "gads:method_tracing:enabled", Boolean.valueOf(false));

    /* renamed from: bY */
    public static final aeb<Long> f1906bY = aeb.m2709a(0, "gads:method_tracing:duration_ms", 30000);

    /* renamed from: bZ */
    public static final aeb<Integer> f1907bZ = aeb.m2708a(0, "gads:method_tracing:count", 5);

    /* renamed from: ba */
    public static final aeb<Boolean> f1908ba = aeb.m2710a(1, "gads:include_lock_screen_apps_for_visibility", Boolean.valueOf(true));

    /* renamed from: bb */
    public static final aeb<Boolean> f1909bb = aeb.m2710a(0, "gads:device_info_caching:enabled", Boolean.valueOf(true));

    /* renamed from: bc */
    public static final aeb<Long> f1910bc = aeb.m2709a(0, "gads:device_info_caching_expiry_ms:expiry", 300000);

    /* renamed from: bd */
    public static final aeb<Boolean> f1911bd = aeb.m2710a(0, "gads:gen204_signals:enabled", Boolean.valueOf(false));

    /* renamed from: be */
    public static final aeb<Boolean> f1912be = aeb.m2710a(0, "gads:webview:error_reporting_enabled", Boolean.valueOf(false));

    /* renamed from: bf */
    public static final aeb<Boolean> f1913bf = aeb.m2710a(1, "gads:gmsg:disable_back_button:enabled", Boolean.valueOf(true));

    /* renamed from: bg */
    public static final aeb<Boolean> f1914bg = aeb.m2710a(0, "gads:gmsg:video_meta:enabled", Boolean.valueOf(true));

    /* renamed from: bh */
    public static final aeb<Long> f1915bh = aeb.m2709a(1, "gads:network:network_prediction_timeout_ms", 2000);

    /* renamed from: bi */
    public static final aeb<Boolean> f1916bi = aeb.m2710a(0, "gads:mediation:dynamite_first:admobadapter", Boolean.valueOf(true));

    /* renamed from: bj */
    public static final aeb<Boolean> f1917bj = aeb.m2710a(0, "gads:mediation:dynamite_first:adurladapter", Boolean.valueOf(true));

    /* renamed from: bk */
    public static final aeb<Boolean> f1918bk = aeb.m2710a(1, "gads:bypass_adrequest_service_for_inlined_mediation", Boolean.valueOf(true));

    /* renamed from: bl */
    public static final aeb<Long> f1919bl = aeb.m2709a(0, "gads:resolve_future:default_timeout_ms", 30000);

    /* renamed from: bm */
    public static final aeb<Long> f1920bm = aeb.m2709a(0, "gads:ad_loader:timeout_ms", 60000);

    /* renamed from: bn */
    public static final aeb<Long> f1921bn = aeb.m2709a(0, "gads:rendering:timeout_ms", 60000);

    /* renamed from: bo */
    public static final aeb<Boolean> f1922bo = aeb.m2710a(0, "gads:adshield:enable_adshield_instrumentation", Boolean.valueOf(false));

    /* renamed from: bp */
    public static final aeb<Long> f1923bp = aeb.m2709a(1, "gads:gestures:task_timeout", 2000);

    /* renamed from: bq */
    public static final aeb<Boolean> f1924bq = aeb.m2710a(1, "gads:gestures:orn_caching:enabled", Boolean.valueOf(true));

    /* renamed from: br */
    public static final aeb<Boolean> f1925br = aeb.m2710a(1, "gads:gestures:oc:enabled", Boolean.valueOf(false));

    /* renamed from: bs */
    public static final aeb<Integer> f1926bs = aeb.m2708a(1, "gads:gestures:ts", 1);

    /* renamed from: bt */
    public static final aeb<Boolean> f1927bt = aeb.m2710a(1, "gads:gestures:td:enabled", Boolean.valueOf(false));

    /* renamed from: bu */
    public static final aeb<Boolean> f1928bu = aeb.m2710a(1, "gads:gestures:tdvs:enabled", Boolean.valueOf(false));

    /* renamed from: bv */
    public static final aeb<Boolean> f1929bv = aeb.m2710a(1, "gads:gestures:tuvs:enabled", Boolean.valueOf(false));

    /* renamed from: bw */
    public static final aeb<Boolean> f1930bw = aeb.m2710a(1, "gads:gestures:tvvs:enabled", Boolean.valueOf(false));

    /* renamed from: bx */
    public static final aeb<Boolean> f1931bx = aeb.m2710a(1, "gads:gestures:vd:enabled", Boolean.valueOf(false));

    /* renamed from: by */
    public static final aeb<String> f1932by = aeb.m2711a(1, "gads:gestures:pk", "");

    /* renamed from: bz */
    public static final aeb<Boolean> f1933bz = aeb.m2710a(1, "gads:gestures:bs:enabled", Boolean.valueOf(true));

    /* renamed from: c */
    public static final aeb<Boolean> f1934c = aeb.m2710a(0, "gads:sdk_crash_report_full_stacktrace", Boolean.valueOf(false));

    /* renamed from: cA */
    public static final aeb<String> f1935cA = aeb.m2711a(1, "gads:drx_debug:send_debug_data_url", "https://www.google.com/dfp/sendDebugData");

    /* renamed from: cB */
    public static final aeb<Integer> f1936cB = aeb.m2708a(1, "gads:drx_debug:timeout_ms", 5000);

    /* renamed from: cC */
    public static final aeb<Integer> f1937cC = aeb.m2708a(1, "gad:pixel_dp_comparision_multiplier", 1);

    /* renamed from: cD */
    public static final aeb<Boolean> f1938cD = aeb.m2710a(1, "gad:interstitial_for_multi_window", Boolean.valueOf(false));

    /* renamed from: cE */
    public static final aeb<Boolean> f1939cE = aeb.m2710a(1, "gad:interstitial_ad_stay_active_in_multi_window", Boolean.valueOf(false));

    /* renamed from: cF */
    public static final aeb<Integer> f1940cF = aeb.m2708a(1, "gad:interstitial:close_button_padding_dip", 0);

    /* renamed from: cG */
    public static final aeb<Boolean> f1941cG = aeb.m2710a(1, "gads:clearcut_logging:enabled", Boolean.valueOf(false));

    /* renamed from: cH */
    public static final aeb<Integer> f1942cH = aeb.m2708a(1, "gads:clearcut_messageTime:ms", 60000);

    /* renamed from: cI */
    public static final aeb<Boolean> f1943cI = aeb.m2710a(0, "gad:force_local_ad_request_service:enabled", Boolean.valueOf(false));

    /* renamed from: cJ */
    public static final aeb<Integer> f1944cJ = aeb.m2708a(1, "gad:http_redirect_max_count:times", 8);

    /* renamed from: cK */
    public static final aeb<Long> f1945cK = aeb.m2709a(1, "gads:mobius_linking:sdk_side_cooldown_time_threshold:ms", 3600000);

    /* renamed from: cL */
    private static aeb<String> f1946cL = aeb.m2706a(0, "gads:sdk_core_experiment_id");

    /* renamed from: cM */
    private static aeb<Boolean> f1947cM = aeb.m2710a(0, "gads:request_builder:singleton_webview", Boolean.valueOf(false));

    /* renamed from: cN */
    private static aeb<String> f1948cN = aeb.m2706a(0, "gads:request_builder:singleton_webview_experiment_id");

    /* renamed from: cO */
    private static aeb<Boolean> f1949cO = aeb.m2710a(0, "gads:sdk_use_dynamic_module", Boolean.valueOf(true));

    /* renamed from: cP */
    private static aeb<String> f1950cP = aeb.m2706a(0, "gads:sdk_use_dynamic_module_experiment_id");

    /* renamed from: cQ */
    private static aeb<String> f1951cQ = aeb.m2706a(0, "gads:block_autoclicks_experiment_id");

    /* renamed from: cR */
    private static aeb<String> f1952cR = aeb.m2706a(0, "gads:spam_app_context:experiment_id");

    /* renamed from: cS */
    private static aeb<Integer> f1953cS = aeb.m2708a(1, "gads:http_url_connection_factory:timeout_millis", 10000);

    /* renamed from: cT */
    private static aeb<String> f1954cT = aeb.m2706a(0, "gads:video_stream_cache:experiment_id");

    /* renamed from: cU */
    private static aeb<Boolean> f1955cU = aeb.m2710a(0, "gads:ad_id_app_context:enabled", Boolean.valueOf(false));

    /* renamed from: cV */
    private static aeb<Float> f1956cV = aeb.m2707a(0, "gads:ad_id_app_context:ping_ratio", 0.0f);

    /* renamed from: cW */
    private static aeb<String> f1957cW = aeb.m2706a(0, "gads:ad_id_app_context:experiment_id");

    /* renamed from: cX */
    private static aeb<String> f1958cX = aeb.m2706a(0, "gads:ad_id_use_shared_preference:experiment_id");

    /* renamed from: cY */
    private static aeb<Boolean> f1959cY = aeb.m2710a(0, "gads:ad_id_use_shared_preference:enabled", Boolean.valueOf(false));

    /* renamed from: cZ */
    private static aeb<Float> f1960cZ = aeb.m2707a(0, "gads:ad_id_use_shared_preference:ping_ratio", 0.0f);

    /* renamed from: ca */
    public static final aeb<Integer> f1961ca = aeb.m2708a(0, "gads:method_tracing:filesize", 134217728);

    /* renamed from: cb */
    public static final aeb<Long> f1962cb = aeb.m2709a(1, "gads:auto_location_timeout", 2000);

    /* renamed from: cc */
    public static final aeb<Boolean> f1963cc = aeb.m2710a(1, "gads:fetch_app_settings_using_cld:enabled", Boolean.valueOf(false));

    /* renamed from: cd */
    public static final aeb<Long> f1964cd = aeb.m2709a(1, "gads:fetch_app_settings_using_cld:refresh_interval_ms", 7200000);

    /* renamed from: ce */
    public static final aeb<String> f1965ce = aeb.m2711a(0, "gads:afs:csa_webview_gmsg_ad_failed", "gmsg://noAdLoaded");

    /* renamed from: cf */
    public static final aeb<String> f1966cf = aeb.m2711a(0, "gads:afs:csa_webview_gmsg_script_load_failed", "gmsg://scriptLoadFailed");

    /* renamed from: cg */
    public static final aeb<String> f1967cg = aeb.m2711a(0, "gads:afs:csa_webview_gmsg_ad_loaded", "gmsg://adResized");

    /* renamed from: ch */
    public static final aeb<String> f1968ch = aeb.m2711a(0, "gads:afs:csa_webview_static_file_path", "/afs/ads/i/webview.html");

    /* renamed from: ci */
    public static final aeb<String> f1969ci = aeb.m2711a(0, "gads:afs:csa_webview_custom_domain_param_key", "csa_customDomain");

    /* renamed from: cj */
    public static final aeb<Long> f1970cj = aeb.m2709a(0, "gads:afs:csa_webview_adshield_timeout_ms", 1000);

    /* renamed from: ck */
    public static final aeb<Long> f1971ck = aeb.m2709a(1, "gads:parental_controls:timeout", 2000);

    /* renamed from: cl */
    public static final aeb<Boolean> f1972cl = aeb.m2710a(0, "gads:safe_browsing:debug", Boolean.valueOf(false));

    /* renamed from: cm */
    public static final aeb<Boolean> f1973cm = aeb.m2710a(0, "gads:webview_cookie:enabled", Boolean.valueOf(true));

    /* renamed from: cn */
    public static final aeb<Boolean> f1974cn = aeb.m2710a(1, "gads:cache:bind_on_foreground", Boolean.valueOf(false));

    /* renamed from: co */
    public static final aeb<Boolean> f1975co = aeb.m2710a(1, "gads:cache:bind_on_init", Boolean.valueOf(false));

    /* renamed from: cp */
    public static final aeb<Boolean> f1976cp = aeb.m2710a(1, "gads:cache:bind_on_request", Boolean.valueOf(false));

    /* renamed from: cq */
    public static final aeb<Long> f1977cq = aeb.m2709a(1, "gads:cache:bind_on_request_keep_alive", TimeUnit.SECONDS.toMillis(30));

    /* renamed from: cr */
    public static final aeb<Boolean> f1978cr = aeb.m2710a(1, "gads:cache:use_cache_data_source", Boolean.valueOf(false));

    /* renamed from: cs */
    public static final aeb<Boolean> f1979cs = aeb.m2710a(1, "gads:chrome_custom_tabs:enabled", Boolean.valueOf(true));

    /* renamed from: ct */
    public static final aeb<Boolean> f1980ct = aeb.m2710a(1, "gads:chrome_custom_tabs_browser:enabled", Boolean.valueOf(false));

    /* renamed from: cu */
    public static final aeb<Boolean> f1981cu = aeb.m2710a(1, "gads:chrome_custom_tabs:disabled", Boolean.valueOf(false));

    /* renamed from: cv */
    public static final aeb<Boolean> f1982cv = aeb.m2710a(1, "gads:drx_in_app_preview:enabled", Boolean.valueOf(true));

    /* renamed from: cw */
    public static final aeb<Boolean> f1983cw = aeb.m2710a(1, "gads:drx_debug_signals:enabled", Boolean.valueOf(true));

    /* renamed from: cx */
    public static final aeb<String> f1984cx = aeb.m2711a(1, "gads:drx_debug:debug_device_linking_url", "https://www.google.com/dfp/linkDevice");

    /* renamed from: cy */
    public static final aeb<String> f1985cy = aeb.m2711a(1, "gads:drx_debug:in_app_preview_status_url", "https://www.google.com/dfp/inAppPreview");

    /* renamed from: cz */
    public static final aeb<String> f1986cz = aeb.m2711a(1, "gads:drx_debug:debug_signal_status_url", "https://www.google.com/dfp/debugSignals");

    /* renamed from: d */
    public static final aeb<String> f1987d = aeb.m2711a(0, "gads:sdk_crash_report_class_prefix", "com.google.");

    /* renamed from: dA */
    private static aeb<String> f1988dA = aeb.m2706a(1, "gads:singleton_webview_native:experiment_id");

    /* renamed from: dB */
    private static aeb<Boolean> f1989dB = aeb.m2710a(1, "gads:auto_location_for_coarse_permission", Boolean.valueOf(false));

    /* renamed from: dC */
    private static aeb<String> f1990dC = aeb.m2712b(1, "gads:auto_location_for_coarse_permission:experiment_id");

    /* renamed from: dD */
    private static aeb<String> f1991dD = aeb.m2712b(1, "gads:auto_location_timeout:experiment_id");

    /* renamed from: dE */
    private static aeb<Long> f1992dE = aeb.m2709a(1, "gads:auto_location_interval", -1);

    /* renamed from: dF */
    private static aeb<String> f1993dF = aeb.m2712b(1, "gads:auto_location_interval:experiment_id");

    /* renamed from: dG */
    private static aeb<String> f1994dG = aeb.m2706a(1, "gads:fetch_app_settings_using_cld:enabled:experiment_id");

    /* renamed from: dH */
    private static aeb<String> f1995dH = aeb.m2706a(0, "gads:afs:csa:experiment_id");

    /* renamed from: dI */
    private static aeb<Boolean> f1996dI = aeb.m2710a(0, "gads:afs:csa_ad_manager_enabled", Boolean.valueOf(true));

    /* renamed from: dJ */
    private static aeb<Boolean> f1997dJ = aeb.m2710a(1, "gads:parental_controls:send_from_client", Boolean.valueOf(true));

    /* renamed from: dK */
    private static aeb<Boolean> f1998dK = aeb.m2710a(1, "gads:parental_controls:cache_results", Boolean.valueOf(true));

    /* renamed from: dL */
    private static aeb<String> f1999dL = aeb.m2711a(0, "gads:safe_browsing:api_key", "AIzaSyDRKQ9d6kfsoZT2lUnZcZnBYvH69HExNPE");

    /* renamed from: dM */
    private static aeb<Long> f2000dM = aeb.m2709a(0, "gads:safe_browsing:safety_net:delay_ms", 2000);

    /* renamed from: dN */
    private static aeb<Integer> f2001dN = aeb.m2708a(1, "gads:cache:ad_request_timeout_millis", 250);

    /* renamed from: dO */
    private static aeb<Integer> f2002dO = aeb.m2708a(1, "gads:cache:max_concurrent_downloads", 10);

    /* renamed from: dP */
    private static aeb<Long> f2003dP = aeb.m2709a(1, "gads:cache:javascript_timeout_millis", 5000);

    /* renamed from: dQ */
    private static aeb<Boolean> f2004dQ = aeb.m2710a(1, "gads:cache:connection_per_read", Boolean.valueOf(false));

    /* renamed from: dR */
    private static aeb<Long> f2005dR = aeb.m2709a(1, "gads:cache:connection_timeout", 5000);

    /* renamed from: dS */
    private static aeb<Long> f2006dS = aeb.m2709a(1, "gads:cache:read_only_connection_timeout", 5000);

    /* renamed from: dT */
    private static aeb<Boolean> f2007dT = aeb.m2710a(1, "gads:clearcut_abtest:enabled", Boolean.valueOf(false));

    /* renamed from: dU */
    private static aeb<Boolean> f2008dU = aeb.m2710a(0, "gads:nonagon:red_button", Boolean.valueOf(false));

    /* renamed from: dV */
    private static aeb<Boolean> f2009dV = aeb.m2710a(1, "gads:nonagon:banner:enabled", Boolean.valueOf(false));

    /* renamed from: dW */
    private static aeb<String> f2010dW = aeb.m2711a(1, "gads:nonagon:banner:ad_unit_exclusions", "(?!)");

    /* renamed from: dX */
    private static aeb<Boolean> f2011dX = aeb.m2710a(1, "gads:nonagon:interstitial:enabled", Boolean.valueOf(false));

    /* renamed from: dY */
    private static aeb<String> f2012dY = aeb.m2711a(1, "gads:nonagon:interstitial:ad_unit_exclusions", "(?!)");

    /* renamed from: dZ */
    private static aeb<Boolean> f2013dZ = aeb.m2710a(1, "gads:nonagon:rewardedvideo:enabled", Boolean.valueOf(false));

    /* renamed from: da */
    private static aeb<String> f2014da = aeb.m2712b(0, "gads:looper_for_gms_client:experiment_id");

    /* renamed from: db */
    private static aeb<Boolean> f2015db = aeb.m2710a(0, "gads:sw_dynamite:enabled", Boolean.valueOf(true));

    /* renamed from: dc */
    private static aeb<String> f2016dc = aeb.m2706a(0, "gads:app_index:experiment_id");

    /* renamed from: dd */
    private static aeb<String> f2017dd = aeb.m2706a(0, "gads:kitkat_interstitial_workaround:experiment_id");

    /* renamed from: de */
    private static aeb<String> f2018de = aeb.m2706a(0, "gads:interstitial_follow_url:experiment_id");

    /* renamed from: df */
    private static aeb<Boolean> f2019df = aeb.m2710a(0, "gads:analytics_enabled", Boolean.valueOf(true));

    /* renamed from: dg */
    private static aeb<Integer> f2020dg = aeb.m2708a(0, "gads:webview_cache_version", 0);

    /* renamed from: dh */
    private static aeb<String> f2021dh = aeb.m2712b(0, "gads:pan:experiment_id");

    /* renamed from: di */
    private static aeb<Boolean> f2022di = aeb.m2710a(0, "gads:ad_serving:enabled", Boolean.valueOf(true));

    /* renamed from: dj */
    private static aeb<Boolean> f2023dj = aeb.m2710a(1, "gads:impression_optimization_enabled", Boolean.valueOf(false));

    /* renamed from: dk */
    private static aeb<String> f2024dk = aeb.m2711a(1, "gads:banner_ad_pool:schema", "customTargeting");

    /* renamed from: dl */
    private static aeb<Integer> f2025dl = aeb.m2708a(1, "gads:banner_ad_pool:max_queues", 3);

    /* renamed from: dm */
    private static aeb<Integer> f2026dm = aeb.m2708a(1, "gads:banner_ad_pool:max_pools", 3);

    /* renamed from: dn */
    private static aeb<Integer> f2027dn = aeb.m2708a(1, "gads:heap_wastage:bytes", 0);

    /* renamed from: do */
    private static aeb<Boolean> f2028do = aeb.m2710a(0, "gads:adid_reporting:enabled", Boolean.valueOf(false));

    /* renamed from: dp */
    private static aeb<Boolean> f2029dp = aeb.m2710a(0, "gads:ad_settings_page_reporting:enabled", Boolean.valueOf(false));

    /* renamed from: dq */
    private static aeb<Boolean> f2030dq = aeb.m2710a(0, "gads:adid_info_gmscore_upgrade_reporting:enabled", Boolean.valueOf(false));

    /* renamed from: dr */
    private static aeb<Boolean> f2031dr = aeb.m2710a(0, "gads:request_pkg:enabled", Boolean.valueOf(true));

    /* renamed from: ds */
    private static aeb<String> f2032ds = aeb.m2706a(0, "gads:gmsg:video_meta:experiment_id");

    /* renamed from: dt */
    private static aeb<Long> f2033dt = aeb.m2709a(1, "gads:network:cache_prediction_duration_s", 300);

    /* renamed from: du */
    private static aeb<Boolean> f2034du = aeb.m2710a(0, "gads:adid_notification:first_party_check:enabled", Boolean.valueOf(true));

    /* renamed from: dv */
    private static aeb<Boolean> f2035dv = aeb.m2710a(0, "gads:edu_device_helper:enabled", Boolean.valueOf(true));

    /* renamed from: dw */
    private static aeb<String> f2036dw = aeb.m2706a(0, "gads:use_get_drawing_cache_for_screenshot:experiment_id");

    /* renamed from: dx */
    private static aeb<String> f2037dx = aeb.m2706a(1, "gads:sdk_core_constants:experiment_id");

    /* renamed from: dy */
    private static aeb<String> f2038dy = aeb.m2711a(0, "gads:native:engine_url", "//googleads.g.doubleclick.net/mads/static/mad/sdk/native/native_ads.html");

    /* renamed from: dz */
    private static aeb<String> f2039dz = aeb.m2711a(1, "gads:native:video_url", "//imasdk.googleapis.com/admob/sdkloader/native_video.html");

    /* renamed from: e */
    public static final aeb<Boolean> f2040e = aeb.m2710a(0, "gads:block_autoclicks", Boolean.valueOf(false));

    /* renamed from: ea */
    private static aeb<Boolean> f2041ea = aeb.m2710a(1, "gads:nonagon:mobile_ads_setting_manager:enabled", Boolean.valueOf(false));

    /* renamed from: eb */
    private static aeb<String> f2042eb = aeb.m2711a(1, "gads:nonagon:rewardedvideo:ad_unit_exclusions", "(?!)");

    /* renamed from: ec */
    private static aeb<Boolean> f2043ec = aeb.m2710a(1, "gads:nonagon:nativead:enabled", Boolean.valueOf(false));

    /* renamed from: ed */
    private static aeb<String> f2044ed = aeb.m2711a(1, "gads:nonagon:nativead:ad_unit_exclusions", "(?!)");

    /* renamed from: ee */
    private static aeb<Boolean> f2045ee = aeb.m2710a(1, "gads:nonagon:service:enabled", Boolean.valueOf(false));

    /* renamed from: ef */
    private static byte[] f2046ef;

    /* renamed from: f */
    public static final aeb<Boolean> f2047f = aeb.m2710a(1, "gads:spam_app_context:enabled", Boolean.valueOf(false));

    /* renamed from: g */
    public static final aeb<String> f2048g = aeb.m2711a(1, "gads:video_exo_player:version", "1");

    /* renamed from: h */
    public static final aeb<Integer> f2049h = aeb.m2708a(1, "gads:video_exo_player:connect_timeout", 8000);

    /* renamed from: i */
    public static final aeb<Integer> f2050i = aeb.m2708a(1, "gads:video_exo_player:read_timeout", 8000);

    /* renamed from: j */
    public static final aeb<Integer> f2051j = aeb.m2708a(1, "gads:video_exo_player:loading_check_interval", 1048576);

    /* renamed from: k */
    public static final aeb<Integer> f2052k = aeb.m2708a(1, "gads:video_stream_cache:limit_count", 5);

    /* renamed from: l */
    public static final aeb<Integer> f2053l = aeb.m2708a(1, "gads:video_stream_cache:limit_space", 8388608);

    /* renamed from: m */
    public static final aeb<Integer> f2054m = aeb.m2708a(1, "gads:video_stream_exo_cache:buffer_size", 8388608);

    /* renamed from: n */
    public static final aeb<Long> f2055n = aeb.m2709a(1, "gads:video_stream_cache:limit_time_sec", 300);

    /* renamed from: o */
    public static final aeb<Long> f2056o = aeb.m2709a(1, "gads:video_stream_cache:notify_interval_millis", 125);

    /* renamed from: p */
    public static final aeb<Integer> f2057p = aeb.m2708a(1, "gads:video_stream_cache:connect_timeout_millis", 10000);

    /* renamed from: q */
    public static final aeb<Boolean> f2058q = aeb.m2710a(0, "gads:video:metric_reporting_enabled", Boolean.valueOf(false));

    /* renamed from: r */
    public static final aeb<String> f2059r = aeb.m2711a(1, "gads:video:metric_frame_hash_times", "");

    /* renamed from: s */
    public static final aeb<Long> f2060s = aeb.m2709a(1, "gads:video:metric_frame_hash_time_leniency", 500);

    /* renamed from: t */
    public static final aeb<Boolean> f2061t = aeb.m2710a(1, "gads:video:force_watermark", Boolean.valueOf(false));

    /* renamed from: u */
    public static final aeb<Long> f2062u = aeb.m2709a(1, "gads:video:surface_update_min_spacing_ms", 1000);

    /* renamed from: v */
    public static final aeb<Boolean> f2063v = aeb.m2710a(1, "gads:video:spinner:enabled", Boolean.valueOf(false));

    /* renamed from: w */
    public static final aeb<Integer> f2064w = aeb.m2708a(1, "gads:video:spinner:scale", 4);

    /* renamed from: x */
    public static final aeb<Long> f2065x = aeb.m2709a(1, "gads:video:spinner:jank_threshold_ms", 50);

    /* renamed from: y */
    public static final aeb<Boolean> f2066y = aeb.m2710a(1, "gads:video:aggressive_media_codec_release", Boolean.valueOf(false));

    /* renamed from: z */
    public static final aeb<Boolean> f2067z = aeb.m2710a(1, "gads:memory_bundle:debug_info", Boolean.valueOf(false));

    /* renamed from: a */
    public static List<String> m2743a() {
        return C0354ax.m1550q().mo2073a();
    }

    /* renamed from: a */
    public static void m2744a(Context context) {
        C0846ik.m4690a(new aem(context));
        int intValue = ((Integer) C0354ax.m1551r().mo2079a(f2027dn)).intValue();
        if (intValue > 0 && f2046ef == null) {
            f2046ef = new byte[intValue];
        }
    }

    /* renamed from: a */
    public static void m2745a(Context context, int i, JSONObject jSONObject) {
        C0354ax.m1549p();
        Editor edit = context.getSharedPreferences("google_ads_flags", 0).edit();
        C0354ax.m1550q().mo2074a(edit, 1, jSONObject);
        C0354ax.m1549p();
        edit.commit();
    }

    /* renamed from: b */
    public static List<String> m2746b() {
        return C0354ax.m1550q().mo2076b();
    }
}
