package com.google.android.gms.internal;

import android.content.Context;
import android.os.Build.VERSION;
import com.google.android.gms.ads.internal.C0354ax;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.Future;

@arm
public final class aen {

    /* renamed from: a */
    private boolean f2069a;

    /* renamed from: b */
    private String f2070b;

    /* renamed from: c */
    private Map<String, String> f2071c;

    /* renamed from: d */
    private Context f2072d = null;

    /* renamed from: e */
    private String f2073e = null;

    public aen(Context context, String str) {
        this.f2072d = context;
        this.f2073e = str;
        this.f2069a = ((Boolean) C0354ax.m1551r().mo2079a(ael.f1810I)).booleanValue();
        this.f2070b = (String) C0354ax.m1551r().mo2079a(ael.f1811J);
        this.f2071c = new LinkedHashMap();
        this.f2071c.put("s", "gmob_sdk");
        this.f2071c.put("v", "3");
        this.f2071c.put("os", VERSION.RELEASE);
        this.f2071c.put("sdk", VERSION.SDK);
        C0354ax.m1538e();
        this.f2071c.put("device", C0796go.m4524c());
        this.f2071c.put("app", context.getApplicationContext() != null ? context.getApplicationContext().getPackageName() : context.getPackageName());
        Map<String, String> map = this.f2071c;
        String str2 = "is_lite_sdk";
        C0354ax.m1538e();
        map.put(str2, C0796go.m4544k(context) ? "1" : "0");
        Future a = C0354ax.m1548o().mo2587a(this.f2072d);
        try {
            a.get();
            this.f2071c.put("network_coarse", Integer.toString(((C0659bm) a.get()).f2961n));
            this.f2071c.put("network_fine", Integer.toString(((C0659bm) a.get()).f2962o));
        } catch (Exception e) {
            C0354ax.m1542i().mo2742a((Throwable) e, "CsiConfiguration.CsiConfiguration");
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public final boolean mo2083a() {
        return this.f2069a;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public final String mo2084b() {
        return this.f2070b;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public final Context mo2085c() {
        return this.f2072d;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: d */
    public final String mo2086d() {
        return this.f2073e;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: e */
    public final Map<String, String> mo2087e() {
        return this.f2071c;
    }
}
