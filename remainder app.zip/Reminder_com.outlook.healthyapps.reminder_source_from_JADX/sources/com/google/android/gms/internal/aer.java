package com.google.android.gms.internal;

@arm
public final class aer {
    /* renamed from: a */
    public static aew m2759a(aez aez) {
        if (aez == null) {
            return null;
        }
        return aez.mo2100a();
    }

    /* renamed from: a */
    public static boolean m2760a(aez aez, aew aew, String... strArr) {
        if (aez == null || aew == null) {
            return false;
        }
        return aez.mo2106a(aew, strArr);
    }
}
