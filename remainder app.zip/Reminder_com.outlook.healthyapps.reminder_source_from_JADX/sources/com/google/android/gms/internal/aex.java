package com.google.android.gms.internal;

import java.util.HashMap;
import java.util.Map;

@arm
public final class aex {

    /* renamed from: a */
    private final Map<String, aew> f2090a = new HashMap();

    /* renamed from: b */
    private final aez f2091b;

    public aex(aez aez) {
        this.f2091b = aez;
    }

    /* renamed from: a */
    public final aez mo2097a() {
        return this.f2091b;
    }

    /* renamed from: a */
    public final void mo2098a(String str, aew aew) {
        this.f2090a.put(str, aew);
    }

    /* renamed from: a */
    public final void mo2099a(String str, String str2, long j) {
        aez aez = this.f2091b;
        aew aew = (aew) this.f2090a.get(str2);
        String[] strArr = {str};
        if (!(aez == null || aew == null)) {
            aez.mo2105a(aew, j, strArr);
        }
        Map<String, aew> map = this.f2090a;
        aez aez2 = this.f2091b;
        map.put(str, aez2 == null ? null : aez2.mo2101a(j));
    }
}
