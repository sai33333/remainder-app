package com.google.android.gms.internal;

import android.text.TextUtils;
import com.google.android.gms.ads.internal.C0354ax;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

@arm
public final class aez {

    /* renamed from: a */
    private boolean f2097a;

    /* renamed from: b */
    private final List<aew> f2098b = new LinkedList();

    /* renamed from: c */
    private final Map<String, String> f2099c = new LinkedHashMap();

    /* renamed from: d */
    private final Object f2100d = new Object();

    /* renamed from: e */
    private String f2101e;

    /* renamed from: f */
    private aew f2102f;

    /* renamed from: g */
    private aez f2103g;

    public aez(boolean z, String str, String str2) {
        this.f2097a = z;
        this.f2099c.put("action", str);
        this.f2099c.put("ad_format", str2);
    }

    /* renamed from: a */
    public final aew mo2100a() {
        return mo2101a(C0354ax.m1544k().mo1883b());
    }

    /* renamed from: a */
    public final aew mo2101a(long j) {
        if (!this.f2097a) {
            return null;
        }
        return new aew(j, null, null);
    }

    /* renamed from: a */
    public final void mo2102a(aez aez) {
        synchronized (this.f2100d) {
            this.f2103g = aez;
        }
    }

    /* renamed from: a */
    public final void mo2103a(String str) {
        if (this.f2097a) {
            synchronized (this.f2100d) {
                this.f2101e = str;
            }
        }
    }

    /* renamed from: a */
    public final void mo2104a(String str, String str2) {
        if (this.f2097a && !TextUtils.isEmpty(str2)) {
            aeo f = C0354ax.m1542i().mo2754f();
            if (f != null) {
                synchronized (this.f2100d) {
                    aes a = f.mo2088a(str);
                    Map<String, String> map = this.f2099c;
                    map.put(str, a.mo2093a((String) map.get(str), str2));
                }
            }
        }
    }

    /* renamed from: a */
    public final boolean mo2105a(aew aew, long j, String... strArr) {
        synchronized (this.f2100d) {
            for (String aew2 : strArr) {
                this.f2098b.add(new aew(j, aew2, aew));
            }
        }
        return true;
    }

    /* renamed from: a */
    public final boolean mo2106a(aew aew, String... strArr) {
        if (!this.f2097a || aew == null) {
            return false;
        }
        return mo2105a(aew, C0354ax.m1544k().mo1883b(), strArr);
    }

    /* renamed from: b */
    public final void mo2107b() {
        synchronized (this.f2100d) {
            this.f2102f = mo2100a();
        }
    }

    /* renamed from: c */
    public final String mo2108c() {
        String sb;
        StringBuilder sb2 = new StringBuilder();
        synchronized (this.f2100d) {
            for (aew aew : this.f2098b) {
                long a = aew.mo2094a();
                String b = aew.mo2095b();
                aew c = aew.mo2096c();
                if (c != null && a > 0) {
                    long a2 = a - c.mo2094a();
                    sb2.append(b);
                    sb2.append('.');
                    sb2.append(a2);
                    sb2.append(',');
                }
            }
            this.f2098b.clear();
            if (!TextUtils.isEmpty(this.f2101e)) {
                sb2.append(this.f2101e);
            } else if (sb2.length() > 0) {
                sb2.setLength(sb2.length() - 1);
            }
            sb = sb2.toString();
        }
        return sb;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: d */
    public final Map<String, String> mo2109d() {
        synchronized (this.f2100d) {
            aeo f = C0354ax.m1542i().mo2754f();
            if (f != null) {
                if (this.f2103g != null) {
                    Map<String, String> a = f.mo2089a(this.f2099c, this.f2103g.mo2109d());
                    return a;
                }
            }
            Map<String, String> map = this.f2099c;
            return map;
        }
    }

    /* renamed from: e */
    public final aew mo2110e() {
        aew aew;
        synchronized (this.f2100d) {
            aew = this.f2102f;
        }
        return aew;
    }
}
