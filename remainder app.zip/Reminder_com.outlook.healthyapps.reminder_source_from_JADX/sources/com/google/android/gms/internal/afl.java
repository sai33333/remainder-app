package com.google.android.gms.internal;

import android.graphics.Color;
import java.util.ArrayList;
import java.util.List;

@arm
public final class afl extends ags {

    /* renamed from: a */
    private static final int f2114a = Color.rgb(12, 174, 206);

    /* renamed from: b */
    private static final int f2115b;

    /* renamed from: c */
    private static int f2116c;

    /* renamed from: d */
    private static int f2117d = f2114a;

    /* renamed from: e */
    private final String f2118e;

    /* renamed from: f */
    private final List<afn> f2119f = new ArrayList();

    /* renamed from: g */
    private final List<agv> f2120g = new ArrayList();

    /* renamed from: h */
    private final int f2121h;

    /* renamed from: i */
    private final int f2122i;

    /* renamed from: j */
    private final int f2123j;

    /* renamed from: k */
    private final int f2124k;

    /* renamed from: l */
    private final int f2125l;

    /* renamed from: m */
    private final boolean f2126m;

    static {
        int rgb = Color.rgb(204, 204, 204);
        f2115b = rgb;
        f2116c = rgb;
    }

    public afl(String str, List<afn> list, Integer num, Integer num2, Integer num3, int i, int i2, boolean z) {
        this.f2118e = str;
        if (list != null) {
            for (int i3 = 0; i3 < list.size(); i3++) {
                afn afn = (afn) list.get(i3);
                this.f2119f.add(afn);
                this.f2120g.add(afn);
            }
        }
        this.f2121h = num != null ? num.intValue() : f2116c;
        this.f2122i = num2 != null ? num2.intValue() : f2117d;
        this.f2123j = num3 != null ? num3.intValue() : 12;
        this.f2124k = i;
        this.f2125l = i2;
        this.f2126m = z;
    }

    /* renamed from: a */
    public final String mo2122a() {
        return this.f2118e;
    }

    /* renamed from: b */
    public final List<agv> mo2123b() {
        return this.f2120g;
    }

    /* renamed from: c */
    public final List<afn> mo2124c() {
        return this.f2119f;
    }

    /* renamed from: d */
    public final int mo2125d() {
        return this.f2121h;
    }

    /* renamed from: e */
    public final int mo2126e() {
        return this.f2122i;
    }

    /* renamed from: f */
    public final int mo2127f() {
        return this.f2123j;
    }

    /* renamed from: g */
    public final int mo2128g() {
        return this.f2124k;
    }

    /* renamed from: h */
    public final int mo2129h() {
        return this.f2125l;
    }

    /* renamed from: i */
    public final boolean mo2130i() {
        return this.f2126m;
    }
}
