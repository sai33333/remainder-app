package com.google.android.gms.internal;

import android.support.p005v4.p008c.C0165h;
import android.view.View;
import android.widget.FrameLayout;
import com.google.android.gms.p012a.C0279a;
import com.google.android.gms.p012a.C0282c;
import java.util.Arrays;
import java.util.List;

@arm
public final class afs extends aho implements afy {

    /* renamed from: a */
    private final afl f2164a;

    /* renamed from: b */
    private final String f2165b;

    /* renamed from: c */
    private final C0165h<String, afn> f2166c;

    /* renamed from: d */
    private final C0165h<String, String> f2167d;

    /* renamed from: e */
    private acu f2168e;

    /* renamed from: f */
    private View f2169f;

    /* renamed from: g */
    private final Object f2170g = new Object();

    /* renamed from: h */
    private afw f2171h;

    public afs(String str, C0165h<String, afn> hVar, C0165h<String, String> hVar2, afl afl, acu acu, View view) {
        this.f2165b = str;
        this.f2166c = hVar;
        this.f2167d = hVar2;
        this.f2164a = afl;
        this.f2168e = acu;
        this.f2169f = view;
    }

    /* renamed from: a */
    public final String mo2175a(String str) {
        return (String) this.f2167d.get(str);
    }

    /* renamed from: a */
    public final List<String> mo2176a() {
        String[] strArr = new String[(this.f2166c.size() + this.f2167d.size())];
        int i = 0;
        int i2 = 0;
        int i3 = 0;
        while (i2 < this.f2166c.size()) {
            strArr[i3] = (String) this.f2166c.mo688b(i2);
            i2++;
            i3++;
        }
        while (i < this.f2167d.size()) {
            strArr[i3] = (String) this.f2167d.mo688b(i);
            i++;
            i3++;
        }
        return Arrays.asList(strArr);
    }

    /* renamed from: a */
    public final void mo2137a(afw afw) {
        synchronized (this.f2170g) {
            this.f2171h = afw;
        }
    }

    /* renamed from: a */
    public final boolean mo2177a(C0279a aVar) {
        if (this.f2171h == null) {
            C0855it.m4731c("Attempt to call renderVideoInMediaView before ad initialized.");
            return false;
        } else if (this.f2169f == null) {
            return false;
        } else {
            FrameLayout frameLayout = (FrameLayout) C0282c.m1240a(aVar);
            this.f2171h.mo2201a((View) frameLayout, (afu) new aft(this));
            return true;
        }
    }

    /* renamed from: b */
    public final C0279a mo2178b() {
        return C0282c.m1239a(this.f2171h);
    }

    /* renamed from: b */
    public final agv mo2179b(String str) {
        return (agv) this.f2166c.get(str);
    }

    /* renamed from: c */
    public final acu mo2180c() {
        return this.f2168e;
    }

    /* renamed from: c */
    public final void mo2181c(String str) {
        synchronized (this.f2170g) {
            if (this.f2171h == null) {
                C0855it.m4731c("Attempt to call performClick before ad initialized.");
            } else {
                this.f2171h.mo2202a(null, str, null, null, null);
            }
        }
    }

    /* renamed from: d */
    public final void mo2182d() {
        synchronized (this.f2170g) {
            if (this.f2171h == null) {
                C0855it.m4731c("Attempt to perform recordImpression before ad initialized.");
            } else {
                this.f2171h.mo2188a((View) null, null);
            }
        }
    }

    /* renamed from: e */
    public final C0279a mo2183e() {
        return C0282c.m1239a(this.f2171h.mo2208h().getApplicationContext());
    }

    /* renamed from: f */
    public final void mo2184f() {
        this.f2171h = null;
        this.f2168e = null;
        this.f2169f = null;
    }

    /* renamed from: k */
    public final String mo2149k() {
        return "3";
    }

    /* renamed from: l */
    public final String mo2150l() {
        return this.f2165b;
    }

    /* renamed from: m */
    public final afl mo2151m() {
        return this.f2164a;
    }

    /* renamed from: o */
    public final View mo2153o() {
        return this.f2169f;
    }
}
