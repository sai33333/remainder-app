package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.RemoteException;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import com.google.android.gms.common.internal.C0557t;
import com.google.android.gms.p012a.C0279a;
import com.google.android.gms.p012a.C0282c;
import java.lang.ref.WeakReference;
import java.util.Map;

@arm
public final class afv extends agb {

    /* renamed from: b */
    private ank f2173b;

    /* renamed from: c */
    private ann f2174c;

    /* renamed from: d */
    private final afx f2175d;

    /* renamed from: e */
    private afw f2176e;

    /* renamed from: f */
    private boolean f2177f;

    /* renamed from: g */
    private Object f2178g;

    private afv(Context context, afx afx, C0992nv nvVar, afy afy) {
        super(context, afx, null, nvVar, null, afy, null, null);
        this.f2177f = false;
        this.f2178g = new Object();
        this.f2175d = afx;
    }

    public afv(Context context, afx afx, C0992nv nvVar, ank ank, afy afy) {
        this(context, afx, nvVar, afy);
        this.f2173b = ank;
    }

    public afv(Context context, afx afx, C0992nv nvVar, ann ann, afy afy) {
        this(context, afx, nvVar, afy);
        this.f2174c = ann;
    }

    /* renamed from: a */
    public final View mo2187a(OnClickListener onClickListener, boolean z) {
        C0279a aVar;
        synchronized (this.f2178g) {
            if (this.f2176e != null) {
                View a = this.f2176e.mo2187a(onClickListener, z);
                return a;
            }
            try {
                if (this.f2173b != null) {
                    aVar = this.f2173b.mo2440n();
                } else {
                    if (this.f2174c != null) {
                        aVar = this.f2174c.mo2458k();
                    }
                    aVar = null;
                }
            } catch (RemoteException e) {
                C0759fe.m4732c("Failed to call getAdChoicesContent", e);
            }
            if (aVar == null) {
                return null;
            }
            View view = (View) C0282c.m1240a(aVar);
            return view;
        }
    }

    /* renamed from: a */
    public final void mo2188a(View view, Map<String, WeakReference<View>> map) {
        afx afx;
        C0557t.m2153b("recordImpression must be called on the main UI thread.");
        synchronized (this.f2178g) {
            this.f2179a = true;
            if (this.f2176e != null) {
                this.f2176e.mo2188a(view, map);
                this.f2175d.mo2209T();
            } else {
                try {
                    if (this.f2173b != null && !this.f2173b.mo2436j()) {
                        this.f2173b.mo2435i();
                        afx = this.f2175d;
                    } else if (this.f2174c != null && !this.f2174c.mo2455h()) {
                        this.f2174c.mo2454g();
                        afx = this.f2175d;
                    }
                    afx.mo2209T();
                } catch (RemoteException e) {
                    C0759fe.m4732c("Failed to call recordImpression", e);
                }
            }
        }
    }

    /* renamed from: a */
    public final void mo2189a(View view, Map<String, WeakReference<View>> map, Bundle bundle, View view2) {
        C0557t.m2153b("performClick must be called on the main UI thread.");
        synchronized (this.f2178g) {
            if (this.f2176e != null) {
                this.f2176e.mo2189a(view, map, bundle, view2);
                this.f2175d.mo2210e();
            } else {
                try {
                    if (this.f2173b != null && !this.f2173b.mo2437k()) {
                        this.f2173b.mo2425a(C0282c.m1239a(view));
                        this.f2175d.mo2210e();
                    }
                    if (this.f2174c != null && !this.f2174c.mo2456i()) {
                        this.f2174c.mo2446a(C0282c.m1239a(view));
                        this.f2175d.mo2210e();
                    }
                } catch (RemoteException e) {
                    C0759fe.m4732c("Failed to call performClick", e);
                }
            }
        }
    }

    /* renamed from: a */
    public final void mo2190a(View view, Map<String, WeakReference<View>> map, OnTouchListener onTouchListener, OnClickListener onClickListener) {
        synchronized (this.f2178g) {
            this.f2177f = true;
            try {
                if (this.f2173b != null) {
                    this.f2173b.mo2427b(C0282c.m1239a(view));
                } else if (this.f2174c != null) {
                    this.f2174c.mo2448b(C0282c.m1239a(view));
                }
            } catch (RemoteException e) {
                C0759fe.m4732c("Failed to call prepareAd", e);
            }
            this.f2177f = false;
        }
    }

    /* renamed from: a */
    public final void mo2191a(afw afw) {
        synchronized (this.f2178g) {
            this.f2176e = afw;
        }
    }

    /* renamed from: a */
    public final boolean mo2192a() {
        synchronized (this.f2178g) {
            if (this.f2176e != null) {
                boolean a = this.f2176e.mo2192a();
                return a;
            }
            boolean K = this.f2175d.mo1346K();
            return K;
        }
    }

    /* renamed from: b */
    public final void mo2193b(View view, Map<String, WeakReference<View>> map) {
        synchronized (this.f2178g) {
            try {
                if (this.f2173b != null) {
                    this.f2173b.mo2429c(C0282c.m1239a(view));
                } else if (this.f2174c != null) {
                    this.f2174c.mo2450c(C0282c.m1239a(view));
                }
            } catch (RemoteException e) {
                C0759fe.m4732c("Failed to call untrackView", e);
            }
        }
    }

    /* renamed from: b */
    public final boolean mo2194b() {
        boolean z;
        synchronized (this.f2178g) {
            z = this.f2177f;
        }
        return z;
    }

    /* renamed from: c */
    public final afw mo2195c() {
        afw afw;
        synchronized (this.f2178g) {
            afw = this.f2176e;
        }
        return afw;
    }

    /* renamed from: d */
    public final C0885jw mo2196d() {
        return null;
    }

    /* renamed from: e */
    public final void mo2197e() {
    }

    /* renamed from: f */
    public final void mo2198f() {
    }
}
