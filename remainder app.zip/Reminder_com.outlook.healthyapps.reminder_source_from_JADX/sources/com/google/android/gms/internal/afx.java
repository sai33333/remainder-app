package com.google.android.gms.internal;

public interface afx {
    /* renamed from: I */
    void mo1344I();

    /* renamed from: K */
    boolean mo1346K();

    /* renamed from: T */
    void mo2209T();

    /* renamed from: a */
    void mo1350a(afu afu);

    /* renamed from: a */
    void mo1351a(afw afw);

    /* renamed from: b */
    ahx mo1354b(String str);

    /* renamed from: e */
    void mo2210e();

    /* renamed from: u */
    void mo2211u();

    /* renamed from: v */
    void mo2212v();

    /* renamed from: x */
    void mo2213x();

    /* renamed from: y */
    String mo1332y();
}
