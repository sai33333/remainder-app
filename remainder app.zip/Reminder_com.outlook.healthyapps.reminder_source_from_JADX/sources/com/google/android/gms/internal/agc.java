package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.p017js.C0410j;
import org.json.JSONObject;

final class agc extends aqj {

    /* renamed from: a */
    private /* synthetic */ JSONObject f2191a;

    agc(agb agb, JSONObject jSONObject) {
        this.f2191a = jSONObject;
    }

    /* renamed from: a */
    public final void mo2219a(C0410j jVar) {
        jVar.mo1502b("google.afma.nativeAds.handleClickGmsg", this.f2191a);
    }
}
