package com.google.android.gms.internal;

import android.view.View;
import android.widget.FrameLayout;

final class agp implements Runnable {

    /* renamed from: a */
    private /* synthetic */ agb f2225a;

    /* renamed from: b */
    private /* synthetic */ ago f2226b;

    agp(ago ago, agb agb) {
        this.f2226b = ago;
        this.f2225a = agb;
    }

    public final void run() {
        C0885jw jwVar;
        try {
            jwVar = this.f2225a.mo2196d();
        } catch (Exception e) {
            C0759fe.m4730b("Error obtaining overlay.", e);
            jwVar = null;
        }
        if (!(jwVar == null || this.f2226b.f2215a == null)) {
            FrameLayout frameLayout = this.f2226b.f2215a;
            if (jwVar != null) {
                frameLayout.addView((View) jwVar);
            } else {
                throw null;
            }
        }
        this.f2226b.m2984a(this.f2225a);
    }
}
