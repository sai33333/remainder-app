package com.google.android.gms.internal;

import android.net.Uri;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import com.google.android.gms.p012a.C0279a;

public abstract class agw extends C1179sp implements agv {
    public agw() {
        attachInterface(this, "com.google.android.gms.ads.internal.formats.client.INativeAdImage");
    }

    /* renamed from: a */
    public static agv m3002a(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.formats.client.INativeAdImage");
        return queryLocalInterface instanceof agv ? (agv) queryLocalInterface : new agx(iBinder);
    }

    public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
        if (zza(i, parcel, parcel2, i2)) {
            return true;
        }
        switch (i) {
            case 1:
                C0279a a = mo2132a();
                parcel2.writeNoException();
                C1181sr.m5731a(parcel2, (IInterface) a);
                break;
            case 2:
                Uri b = mo2133b();
                parcel2.writeNoException();
                C1181sr.m5736b(parcel2, b);
                break;
            case 3:
                double c = mo2134c();
                parcel2.writeNoException();
                parcel2.writeDouble(c);
                break;
            default:
                return false;
        }
        return true;
    }
}
