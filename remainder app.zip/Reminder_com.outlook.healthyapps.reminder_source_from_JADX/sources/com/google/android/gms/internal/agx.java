package com.google.android.gms.internal;

import android.net.Uri;
import android.os.IBinder;
import android.os.Parcel;
import com.google.android.gms.p012a.C0279a;
import com.google.android.gms.p012a.C0279a.C0280a;

public final class agx extends C1178so implements agv {
    agx(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.ads.internal.formats.client.INativeAdImage");
    }

    /* renamed from: a */
    public final C0279a mo2132a() {
        Parcel a = mo3281a(1, mo3284j_());
        C0279a a2 = C0280a.m1238a(a.readStrongBinder());
        a.recycle();
        return a2;
    }

    /* renamed from: b */
    public final Uri mo2133b() {
        Parcel a = mo3281a(2, mo3284j_());
        Uri uri = (Uri) C1181sr.m5730a(a, Uri.CREATOR);
        a.recycle();
        return uri;
    }

    /* renamed from: c */
    public final double mo2134c() {
        Parcel a = mo3281a(3, mo3284j_());
        double readDouble = a.readDouble();
        a.recycle();
        return readDouble;
    }
}
