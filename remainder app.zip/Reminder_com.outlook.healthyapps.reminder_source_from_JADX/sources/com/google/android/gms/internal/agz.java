package com.google.android.gms.internal;

import android.os.IInterface;
import com.google.android.gms.p012a.C0279a;

public interface agz extends IInterface {
    /* renamed from: a */
    C0279a mo2223a(String str);

    /* renamed from: a */
    void mo2224a();

    /* renamed from: a */
    void mo2225a(C0279a aVar);

    /* renamed from: a */
    void mo2226a(C0279a aVar, int i);

    /* renamed from: a */
    void mo2227a(String str, C0279a aVar);
}
