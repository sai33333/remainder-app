package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import com.google.android.gms.p012a.C0279a;
import com.google.android.gms.p012a.C0279a.C0280a;

public final class ahc extends C1178so implements agz {
    ahc(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.ads.internal.formats.client.INativeAdViewDelegate");
    }

    /* renamed from: a */
    public final C0279a mo2223a(String str) {
        Parcel j_ = mo3284j_();
        j_.writeString(str);
        Parcel a = mo3281a(2, j_);
        C0279a a2 = C0280a.m1238a(a.readStrongBinder());
        a.recycle();
        return a2;
    }

    /* renamed from: a */
    public final void mo2224a() {
        mo3283b(4, mo3284j_());
    }

    /* renamed from: a */
    public final void mo2225a(C0279a aVar) {
        Parcel j_ = mo3284j_();
        C1181sr.m5731a(j_, (IInterface) aVar);
        mo3283b(3, j_);
    }

    /* renamed from: a */
    public final void mo2226a(C0279a aVar, int i) {
        Parcel j_ = mo3284j_();
        C1181sr.m5731a(j_, (IInterface) aVar);
        j_.writeInt(i);
        mo3283b(5, j_);
    }

    /* renamed from: a */
    public final void mo2227a(String str, C0279a aVar) {
        Parcel j_ = mo3284j_();
        j_.writeString(str);
        C1181sr.m5731a(j_, (IInterface) aVar);
        mo3283b(1, j_);
    }
}
