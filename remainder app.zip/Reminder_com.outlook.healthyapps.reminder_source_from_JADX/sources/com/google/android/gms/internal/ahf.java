package com.google.android.gms.internal;

import android.os.Bundle;
import android.os.IInterface;
import com.google.android.gms.p012a.C0279a;
import java.util.List;

public interface ahf extends IInterface {
    /* renamed from: a */
    String mo2135a();

    /* renamed from: a */
    void mo2136a(Bundle bundle);

    /* renamed from: b */
    List mo2138b();

    /* renamed from: b */
    boolean mo2139b(Bundle bundle);

    /* renamed from: c */
    String mo2140c();

    /* renamed from: c */
    void mo2141c(Bundle bundle);

    /* renamed from: d */
    agv mo2142d();

    /* renamed from: e */
    String mo2143e();

    /* renamed from: f */
    double mo2144f();

    /* renamed from: g */
    String mo2145g();

    /* renamed from: h */
    String mo2146h();

    /* renamed from: i */
    acu mo2147i();

    /* renamed from: j */
    C0279a mo2148j();

    /* renamed from: n */
    Bundle mo2152n();

    /* renamed from: p */
    C0279a mo2154p();

    /* renamed from: q */
    String mo2155q();

    /* renamed from: r */
    agr mo2156r();

    /* renamed from: s */
    void mo2157s();
}
