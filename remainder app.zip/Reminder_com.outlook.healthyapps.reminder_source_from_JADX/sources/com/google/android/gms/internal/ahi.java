package com.google.android.gms.internal;

import android.os.RemoteException;
import com.google.android.gms.ads.C0327h;
import com.google.android.gms.ads.p014b.C0295c.C0296a;
import com.google.android.gms.ads.p014b.C0295c.C0297b;
import com.google.android.gms.ads.p014b.C0301f;
import com.google.android.gms.p012a.C0279a;
import java.util.ArrayList;
import java.util.List;

@arm
public final class ahi extends C0301f {

    /* renamed from: a */
    private final ahf f2256a;

    /* renamed from: b */
    private final List<C0297b> f2257b = new ArrayList();

    /* renamed from: c */
    private final agy f2258c;

    /* renamed from: d */
    private final C0327h f2259d = new C0327h();

    /* renamed from: e */
    private final C0296a f2260e;

    /* JADX WARNING: Removed duplicated region for block: B:17:0x004a A[Catch:{ RemoteException -> 0x0055 }] */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x007a A[Catch:{ RemoteException -> 0x0087 }] */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x0020 A[SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public ahi(com.google.android.gms.internal.ahf r5) {
        /*
            r4 = this;
            r4.<init>()
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            r4.f2257b = r0
            com.google.android.gms.ads.h r0 = new com.google.android.gms.ads.h
            r0.<init>()
            r4.f2259d = r0
            r4.f2256a = r5
            r5 = 0
            com.google.android.gms.internal.ahf r0 = r4.f2256a     // Catch:{ RemoteException -> 0x0055 }
            java.util.List r0 = r0.mo2138b()     // Catch:{ RemoteException -> 0x0055 }
            if (r0 == 0) goto L_0x005b
            java.util.Iterator r0 = r0.iterator()     // Catch:{ RemoteException -> 0x0055 }
        L_0x0020:
            boolean r1 = r0.hasNext()     // Catch:{ RemoteException -> 0x0055 }
            if (r1 == 0) goto L_0x005b
            java.lang.Object r1 = r0.next()     // Catch:{ RemoteException -> 0x0055 }
            boolean r2 = r1 instanceof android.os.IBinder     // Catch:{ RemoteException -> 0x0055 }
            if (r2 == 0) goto L_0x0047
            android.os.IBinder r1 = (android.os.IBinder) r1     // Catch:{ RemoteException -> 0x0055 }
            if (r1 == 0) goto L_0x0047
            java.lang.String r2 = "com.google.android.gms.ads.internal.formats.client.INativeAdImage"
            android.os.IInterface r2 = r1.queryLocalInterface(r2)     // Catch:{ RemoteException -> 0x0055 }
            boolean r3 = r2 instanceof com.google.android.gms.internal.agv     // Catch:{ RemoteException -> 0x0055 }
            if (r3 == 0) goto L_0x0040
            r1 = r2
            com.google.android.gms.internal.agv r1 = (com.google.android.gms.internal.agv) r1     // Catch:{ RemoteException -> 0x0055 }
            goto L_0x0048
        L_0x0040:
            com.google.android.gms.internal.agx r2 = new com.google.android.gms.internal.agx     // Catch:{ RemoteException -> 0x0055 }
            r2.<init>(r1)     // Catch:{ RemoteException -> 0x0055 }
            r1 = r2
            goto L_0x0048
        L_0x0047:
            r1 = r5
        L_0x0048:
            if (r1 == 0) goto L_0x0020
            java.util.List<com.google.android.gms.ads.b.c$b> r2 = r4.f2257b     // Catch:{ RemoteException -> 0x0055 }
            com.google.android.gms.internal.agy r3 = new com.google.android.gms.internal.agy     // Catch:{ RemoteException -> 0x0055 }
            r3.<init>(r1)     // Catch:{ RemoteException -> 0x0055 }
            r2.add(r3)     // Catch:{ RemoteException -> 0x0055 }
            goto L_0x0020
        L_0x0055:
            r0 = move-exception
            java.lang.String r1 = "Failed to get image."
            com.google.android.gms.internal.C0855it.m4730b(r1, r0)
        L_0x005b:
            com.google.android.gms.internal.ahf r0 = r4.f2256a     // Catch:{ RemoteException -> 0x0069 }
            com.google.android.gms.internal.agv r0 = r0.mo2142d()     // Catch:{ RemoteException -> 0x0069 }
            if (r0 == 0) goto L_0x006f
            com.google.android.gms.internal.agy r1 = new com.google.android.gms.internal.agy     // Catch:{ RemoteException -> 0x0069 }
            r1.<init>(r0)     // Catch:{ RemoteException -> 0x0069 }
            goto L_0x0070
        L_0x0069:
            r0 = move-exception
            java.lang.String r1 = "Failed to get image."
            com.google.android.gms.internal.C0855it.m4730b(r1, r0)
        L_0x006f:
            r1 = r5
        L_0x0070:
            r4.f2258c = r1
            com.google.android.gms.internal.ahf r0 = r4.f2256a     // Catch:{ RemoteException -> 0x0087 }
            com.google.android.gms.internal.agr r0 = r0.mo2156r()     // Catch:{ RemoteException -> 0x0087 }
            if (r0 == 0) goto L_0x008d
            com.google.android.gms.internal.agu r0 = new com.google.android.gms.internal.agu     // Catch:{ RemoteException -> 0x0087 }
            com.google.android.gms.internal.ahf r1 = r4.f2256a     // Catch:{ RemoteException -> 0x0087 }
            com.google.android.gms.internal.agr r1 = r1.mo2156r()     // Catch:{ RemoteException -> 0x0087 }
            r0.<init>(r1)     // Catch:{ RemoteException -> 0x0087 }
            r5 = r0
            goto L_0x008d
        L_0x0087:
            r0 = move-exception
            java.lang.String r1 = "Failed to get attribution info."
            com.google.android.gms.internal.C0855it.m4730b(r1, r0)
        L_0x008d:
            r4.f2260e = r5
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.ahi.<init>(com.google.android.gms.internal.ahf):void");
    }

    /* access modifiers changed from: private */
    /* renamed from: k */
    public final C0279a mo1160a() {
        try {
            return this.f2256a.mo2148j();
        } catch (RemoteException e) {
            C0855it.m4730b("Failed to retrieve native ad engine.", e);
            return null;
        }
    }

    /* renamed from: b */
    public final CharSequence mo1185b() {
        try {
            return this.f2256a.mo2135a();
        } catch (RemoteException e) {
            C0855it.m4730b("Failed to get headline.", e);
            return null;
        }
    }

    /* renamed from: c */
    public final List<C0297b> mo1186c() {
        return this.f2257b;
    }

    /* renamed from: d */
    public final CharSequence mo1187d() {
        try {
            return this.f2256a.mo2140c();
        } catch (RemoteException e) {
            C0855it.m4730b("Failed to get body.", e);
            return null;
        }
    }

    /* renamed from: e */
    public final C0297b mo1188e() {
        return this.f2258c;
    }

    /* renamed from: f */
    public final CharSequence mo1189f() {
        try {
            return this.f2256a.mo2143e();
        } catch (RemoteException e) {
            C0855it.m4730b("Failed to get call to action.", e);
            return null;
        }
    }

    /* renamed from: g */
    public final Double mo1190g() {
        try {
            double f = this.f2256a.mo2144f();
            if (f == -1.0d) {
                return null;
            }
            return Double.valueOf(f);
        } catch (RemoteException e) {
            C0855it.m4730b("Failed to get star rating.", e);
            return null;
        }
    }

    /* renamed from: h */
    public final CharSequence mo1191h() {
        try {
            return this.f2256a.mo2145g();
        } catch (RemoteException e) {
            C0855it.m4730b("Failed to get store", e);
            return null;
        }
    }

    /* renamed from: i */
    public final CharSequence mo1192i() {
        try {
            return this.f2256a.mo2146h();
        } catch (RemoteException e) {
            C0855it.m4730b("Failed to get price.", e);
            return null;
        }
    }

    /* renamed from: j */
    public final C0327h mo1193j() {
        try {
            if (this.f2256a.mo2147i() != null) {
                this.f2259d.mo1262a(this.f2256a.mo2147i());
            }
        } catch (RemoteException e) {
            C0855it.m4730b("Exception occurred while getting video controller", e);
        }
        return this.f2259d;
    }
}
