package com.google.android.gms.internal;

final class aib implements Runnable {

    /* renamed from: a */
    private /* synthetic */ String f2270a;

    /* renamed from: b */
    private /* synthetic */ long f2271b;

    /* renamed from: c */
    private /* synthetic */ aha f2272c;

    aib(aha aha, String str, long j) {
        this.f2272c = aha;
        this.f2270a = str;
        this.f2271b = j;
    }

    public final void run() {
        this.f2272c.f2243a.mo1960a(this.f2270a, this.f2271b);
        this.f2272c.f2243a.mo1959a(toString());
    }
}
