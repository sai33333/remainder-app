package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

public final class aid extends C1178so implements aia {
    aid(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.ads.internal.formats.client.IOnCustomTemplateAdLoadedListener");
    }

    /* renamed from: a */
    public final void mo2271a(ahn ahn) {
        Parcel j_ = mo3284j_();
        C1181sr.m5731a(j_, (IInterface) ahn);
        mo3283b(1, j_);
    }
}
