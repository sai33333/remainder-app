package com.google.android.gms.internal;

import com.google.android.gms.ads.p014b.C0301f.C0302a;

@arm
public final class aii extends ahs {

    /* renamed from: a */
    private final C0302a f2273a;

    public aii(C0302a aVar) {
        this.f2273a = aVar;
    }

    /* renamed from: a */
    public final void mo2263a(ahf ahf) {
        this.f2273a.mo1075a(new ahi(ahf));
    }
}
