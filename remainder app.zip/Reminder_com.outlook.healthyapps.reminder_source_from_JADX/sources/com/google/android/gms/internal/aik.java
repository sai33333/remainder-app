package com.google.android.gms.internal;

import com.google.android.gms.ads.p014b.C0305h.C0306a;

@arm
public final class aik extends ahy {

    /* renamed from: a */
    private final C0306a f2275a;

    public aik(C0306a aVar) {
        this.f2275a = aVar;
    }

    /* renamed from: a */
    public final void mo2267a(ahn ahn, String str) {
        this.f2275a.mo1078a(ahq.m3153a(ahn), str);
    }
}
