package com.google.android.gms.internal;

import java.util.Map;

final class aiu implements ajh {
    aiu() {
    }

    /* renamed from: a */
    public final void mo1441a(C0885jw jwVar, Map<String, String> map) {
        String str = (String) map.get("action");
        if ("pause".equals(str)) {
            jwVar.mo1375h_();
            return;
        }
        if ("resume".equals(str)) {
            jwVar.mo1376i_();
        }
    }
}
