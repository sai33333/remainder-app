package com.google.android.gms.internal;

import java.util.Map;

final class ajd implements ajh {
    ajd() {
    }

    /* renamed from: a */
    public final void mo1441a(C0885jw jwVar, Map<String, String> map) {
        jwVar.mo2944b("1".equals(map.get("custom_close")));
    }
}
