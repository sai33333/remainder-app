package com.google.android.gms.internal;

import java.util.Map;

@arm
public interface ajh {
    /* renamed from: a */
    void mo1441a(C0885jw jwVar, Map<String, String> map);
}
