package com.google.android.gms.internal;

import java.util.Map;
import org.json.JSONObject;

final class ajj implements Runnable {

    /* renamed from: a */
    final /* synthetic */ C0885jw f2319a;

    /* renamed from: b */
    private /* synthetic */ Map f2320b;

    /* renamed from: c */
    private /* synthetic */ aji f2321c;

    ajj(aji aji, Map map, C0885jw jwVar) {
        this.f2321c = aji;
        this.f2320b = map;
        this.f2319a = jwVar;
    }

    public final void run() {
        C0759fe.m4729b("Received Http request.");
        JSONObject a = this.f2321c.mo2277a((String) this.f2320b.get("http_request"));
        if (a == null) {
            C0759fe.m4731c("Response should not be null.");
        } else {
            C0796go.f3327a.post(new ajk(this, a));
        }
    }
}
