package com.google.android.gms.internal;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Future;
import org.json.JSONException;
import org.json.JSONObject;

@arm
public final class ajr implements ajh {

    /* renamed from: a */
    private HashMap<String, C0871ji<JSONObject>> f2338a = new HashMap<>();

    /* renamed from: a */
    public final Future<JSONObject> mo2293a(String str) {
        C0871ji jiVar = new C0871ji();
        this.f2338a.put(str, jiVar);
        return jiVar;
    }

    /* renamed from: a */
    public final void mo1441a(C0885jw jwVar, Map<String, String> map) {
        String str = (String) map.get("request_id");
        String str2 = (String) map.get("fetched_ad");
        C0759fe.m4729b("Received ad from the cache.");
        C0871ji jiVar = (C0871ji) this.f2338a.get(str);
        if (jiVar == null) {
            C0759fe.m4731c("Could not find the ad request for the corresponding ad response.");
            return;
        }
        try {
            jiVar.mo2904b(new JSONObject(str2));
        } catch (JSONException e) {
            C0759fe.m4730b("Failed constructing JSON object from value passed from javascript", e);
            jiVar.mo2904b(null);
        } finally {
            this.f2338a.remove(str);
        }
    }

    /* renamed from: b */
    public final void mo2294b(String str) {
        C0871ji jiVar = (C0871ji) this.f2338a.get(str);
        if (jiVar == null) {
            C0759fe.m4731c("Could not find the ad request for the corresponding ad response.");
            return;
        }
        if (!jiVar.isDone()) {
            jiVar.cancel(true);
        }
        this.f2338a.remove(str);
    }
}
