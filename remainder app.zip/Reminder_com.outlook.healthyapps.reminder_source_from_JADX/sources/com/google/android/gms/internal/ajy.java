package com.google.android.gms.internal;

import android.text.TextUtils;
import java.util.Map;

@arm
public final class ajy implements ajh {

    /* renamed from: a */
    private final ajz f2347a;

    public ajy(ajz ajz) {
        this.f2347a = ajz;
    }

    /* renamed from: a */
    public final void mo1441a(C0885jw jwVar, Map<String, String> map) {
        String str = (String) map.get("action");
        if ("grant".equals(str)) {
            C0717dq dqVar = null;
            try {
                int parseInt = Integer.parseInt((String) map.get("amount"));
                String str2 = (String) map.get("type");
                if (!TextUtils.isEmpty(str2)) {
                    dqVar = new C0717dq(str2, parseInt);
                }
            } catch (NumberFormatException e) {
                C0759fe.m4732c("Unable to parse reward amount.", e);
            }
            this.f2347a.mo1531b(dqVar);
            return;
        }
        if ("video_start".equals(str)) {
            this.f2347a.mo1529E();
        }
    }
}
