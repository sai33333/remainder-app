package com.google.android.gms.internal;

import android.content.Context;
import android.graphics.Color;
import android.os.Build.VERSION;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.MotionEvent;
import com.google.android.gms.ads.internal.C0354ax;
import com.google.android.gms.ads.internal.overlay.C0454b;
import com.google.android.gms.ads.internal.overlay.C0470r;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.json.JSONObject;

@arm
public final class aka implements ajh {

    /* renamed from: a */
    private boolean f2350a;

    /* renamed from: a */
    private static int m3246a(Context context, Map<String, String> map, String str, int i) {
        String str2 = (String) map.get(str);
        if (str2 == null) {
            return i;
        }
        try {
            abj.m2380a();
            return C0851ip.m4702a(context, Integer.parseInt(str2));
        } catch (NumberFormatException unused) {
            StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 34 + String.valueOf(str2).length());
            sb.append("Could not parse ");
            sb.append(str);
            sb.append(" in a video GMSG: ");
            sb.append(str2);
            C0759fe.m4734e(sb.toString());
            return i;
        }
    }

    /* renamed from: a */
    private static void m3247a(C0454b bVar, Map<String, String> map) {
        String str = (String) map.get("minBufferMs");
        String str2 = (String) map.get("maxBufferMs");
        String str3 = (String) map.get("bufferForPlaybackMs");
        String str4 = (String) map.get("bufferForPlaybackAfterRebufferMs");
        if (str != null) {
            try {
                Integer.parseInt(str);
            } catch (NumberFormatException unused) {
                C0759fe.m4734e(String.format("Could not parse buffer parameters in loadControl video GMSG: (%s, %s)", new Object[]{str, str2}));
                return;
            }
        }
        if (str2 != null) {
            Integer.parseInt(str2);
        }
        if (str3 != null) {
            Integer.parseInt(str3);
        }
        if (str4 != null) {
            Integer.parseInt(str4);
        }
    }

    /* renamed from: a */
    public final void mo1441a(C0885jw jwVar, Map<String, String> map) {
        int i;
        String str = (String) map.get("action");
        if (str == null) {
            C0759fe.m4734e("Action missing from video GMSG.");
            return;
        }
        if (C0759fe.m4728a(3)) {
            JSONObject jSONObject = new JSONObject(map);
            jSONObject.remove("google.afma.Notify_dt");
            String jSONObject2 = jSONObject.toString();
            StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 13 + String.valueOf(jSONObject2).length());
            sb.append("Video GMSG: ");
            sb.append(str);
            sb.append(" ");
            sb.append(jSONObject2);
            C0759fe.m4729b(sb.toString());
        }
        if ("background".equals(str)) {
            String str2 = (String) map.get("color");
            if (TextUtils.isEmpty(str2)) {
                C0759fe.m4734e("Color parameter missing from color video GMSG.");
                return;
            }
            try {
                jwVar.setBackgroundColor(Color.parseColor(str2));
            } catch (IllegalArgumentException unused) {
                C0759fe.m4734e("Invalid color parameter in video GMSG.");
            }
        } else {
            int i2 = 0;
            if ("decoderProps".equals(str)) {
                String str3 = (String) map.get("mimeTypes");
                if (str3 == null) {
                    C0759fe.m4734e("No MIME types specified for decoder properties inspection.");
                    C0454b.m1859a(jwVar, "missingMimeTypes");
                } else if (VERSION.SDK_INT < 16) {
                    C0759fe.m4734e("Video decoder properties available on API versions >= 16.");
                    C0454b.m1859a(jwVar, "deficientApiVersion");
                } else {
                    HashMap hashMap = new HashMap();
                    String[] split = str3.split(",");
                    int length = split.length;
                    while (i2 < length) {
                        String str4 = split[i2];
                        hashMap.put(str4, C0849in.m4693a(str4.trim()));
                        i2++;
                    }
                    C0454b.m1860a(jwVar, (Map<String, List<Map<String, Object>>>) hashMap);
                }
            } else {
                C0884jv x = jwVar.mo2987x();
                if (x == null) {
                    C0759fe.m4734e("Could not get underlay container for a video GMSG.");
                    return;
                }
                boolean equals = "new".equals(str);
                boolean equals2 = "position".equals(str);
                if (equals || equals2) {
                    Context context = jwVar.getContext();
                    int a = m3246a(context, map, "x", 0);
                    int a2 = m3246a(context, map, "y", 0);
                    int a3 = m3246a(context, map, "w", -1);
                    int a4 = m3246a(context, map, "h", -1);
                    if (((Boolean) C0354ax.m1551r().mo2079a(ael.f1902bU)).booleanValue()) {
                        a3 = Math.min(a3, jwVar.getMeasuredWidth() - a);
                        i = Math.min(a4, jwVar.getMeasuredHeight() - a2);
                    } else {
                        i = a4;
                    }
                    try {
                        i2 = Integer.parseInt((String) map.get("player"));
                    } catch (NumberFormatException unused2) {
                    }
                    int i3 = i2;
                    boolean parseBoolean = Boolean.parseBoolean((String) map.get("spherical"));
                    if (!equals || x.mo2917a() != null) {
                        x.mo2918a(a, a2, a3, i);
                        return;
                    }
                    x.mo2919a(a, a2, a3, i, i3, parseBoolean, new C0470r((String) map.get("flags")));
                    C0454b a5 = x.mo2917a();
                    if (a5 != null) {
                        m3247a(a5, map);
                    }
                    return;
                }
                C0454b a6 = x.mo2917a();
                if (a6 == null) {
                    C0454b.m1858a(jwVar);
                } else if ("click".equals(str)) {
                    Context context2 = jwVar.getContext();
                    int a7 = m3246a(context2, map, "x", 0);
                    int a8 = m3246a(context2, map, "y", 0);
                    long uptimeMillis = SystemClock.uptimeMillis();
                    MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 0, (float) a7, (float) a8, 0);
                    a6.mo1600a(obtain);
                    obtain.recycle();
                } else if ("currentTime".equals(str)) {
                    String str5 = (String) map.get("time");
                    if (str5 == null) {
                        C0759fe.m4734e("Time parameter missing from currentTime video GMSG.");
                        return;
                    }
                    try {
                        a6.mo1598a((int) (Float.parseFloat(str5) * 1000.0f));
                    } catch (NumberFormatException unused3) {
                        String str6 = "Could not parse time parameter from currentTime video GMSG: ";
                        String valueOf = String.valueOf(str5);
                        C0759fe.m4734e(valueOf.length() != 0 ? str6.concat(valueOf) : new String(str6));
                    }
                } else if ("hide".equals(str)) {
                    a6.setVisibility(4);
                } else if ("load".equals(str)) {
                    a6.mo1595a();
                } else if ("loadControl".equals(str)) {
                    m3247a(a6, map);
                } else if ("muted".equals(str)) {
                    if (Boolean.parseBoolean((String) map.get("muted"))) {
                        a6.mo1604d();
                    } else {
                        a6.mo1605e();
                    }
                } else if ("pause".equals(str)) {
                    a6.mo1602b();
                } else if ("play".equals(str)) {
                    a6.mo1603c();
                } else if ("show".equals(str)) {
                    a6.setVisibility(0);
                } else if ("src".equals(str)) {
                    a6.mo1601a((String) map.get("src"));
                } else if ("touchMove".equals(str)) {
                    Context context3 = jwVar.getContext();
                    a6.mo1597a((float) m3246a(context3, map, "dx", 0), (float) m3246a(context3, map, "dy", 0));
                    if (!this.f2350a) {
                        jwVar.mo2961j().mo1563p();
                        this.f2350a = true;
                    }
                } else if ("volume".equals(str)) {
                    String str7 = (String) map.get("volume");
                    if (str7 == null) {
                        C0759fe.m4734e("Level parameter missing from volume video GMSG.");
                        return;
                    }
                    try {
                        a6.mo1596a(Float.parseFloat(str7));
                    } catch (NumberFormatException unused4) {
                        String str8 = "Could not parse volume parameter from volume video GMSG: ";
                        String valueOf2 = String.valueOf(str7);
                        C0759fe.m4734e(valueOf2.length() != 0 ? str8.concat(valueOf2) : new String(str8));
                    }
                } else if ("watermark".equals(str)) {
                    a6.mo1606f();
                } else {
                    String str9 = "Unknown video action: ";
                    String valueOf3 = String.valueOf(str);
                    C0759fe.m4734e(valueOf3.length() != 0 ? str9.concat(valueOf3) : new String(str9));
                }
            }
        }
    }
}
