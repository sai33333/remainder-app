package com.google.android.gms.internal;

import android.os.Handler;
import android.os.Looper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;

public final class akb {

    /* renamed from: a */
    private AtomicInteger f2351a;

    /* renamed from: b */
    private final Map<String, Queue<aha<?>>> f2352b;

    /* renamed from: c */
    private final Set<aha<?>> f2353c;

    /* renamed from: d */
    private final PriorityBlockingQueue<aha<?>> f2354d;

    /* renamed from: e */
    private final PriorityBlockingQueue<aha<?>> f2355e;

    /* renamed from: f */
    private final C0936lt f2356f;

    /* renamed from: g */
    private final acc f2357g;

    /* renamed from: h */
    private final aoa f2358h;

    /* renamed from: i */
    private add[] f2359i;

    /* renamed from: j */
    private C1001od f2360j;

    /* renamed from: k */
    private List<Object> f2361k;

    public akb(C0936lt ltVar, acc acc) {
        this(ltVar, acc, 4);
    }

    private akb(C0936lt ltVar, acc acc, int i) {
        this(ltVar, acc, 4, new C1361zc(new Handler(Looper.getMainLooper())));
    }

    private akb(C0936lt ltVar, acc acc, int i, aoa aoa) {
        this.f2351a = new AtomicInteger();
        this.f2352b = new HashMap();
        this.f2353c = new HashSet();
        this.f2354d = new PriorityBlockingQueue<>();
        this.f2355e = new PriorityBlockingQueue<>();
        this.f2361k = new ArrayList();
        this.f2356f = ltVar;
        this.f2357g = acc;
        this.f2359i = new add[4];
        this.f2358h = aoa;
    }

    /* renamed from: a */
    public final <T> aha<T> mo2297a(aha<T> aha) {
        aha.mo2237a(this);
        synchronized (this.f2353c) {
            this.f2353c.add(aha);
        }
        aha.mo2236a(this.f2351a.incrementAndGet());
        aha.mo2242a("add-to-queue");
        if (!aha.mo2252i()) {
            this.f2355e.add(aha);
            return aha;
        }
        synchronized (this.f2352b) {
            String f = aha.mo2250f();
            if (this.f2352b.containsKey(f)) {
                Queue queue = (Queue) this.f2352b.get(f);
                if (queue == null) {
                    queue = new LinkedList();
                }
                queue.add(aha);
                this.f2352b.put(f, queue);
                if (C0618ac.f1702a) {
                    C0618ac.m2436a("Request for cacheKey=%s is in flight, putting on hold.", f);
                }
            } else {
                this.f2352b.put(f, null);
                this.f2354d.add(aha);
            }
        }
        return aha;
    }

    /* renamed from: a */
    public final void mo2298a() {
        C1001od odVar = this.f2360j;
        if (odVar != null) {
            odVar.mo3138a();
        }
        int i = 0;
        while (true) {
            add[] addArr = this.f2359i;
            if (i >= addArr.length) {
                break;
            }
            if (addArr[i] != null) {
                addArr[i].mo2007a();
            }
            i++;
        }
        this.f2360j = new C1001od(this.f2354d, this.f2355e, this.f2356f, this.f2358h);
        this.f2360j.start();
        for (int i2 = 0; i2 < this.f2359i.length; i2++) {
            add add = new add(this.f2355e, this.f2357g, this.f2356f, this.f2358h);
            this.f2359i[i2] = add;
            add.start();
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public final <T> void mo2299b(aha<T> aha) {
        synchronized (this.f2353c) {
            this.f2353c.remove(aha);
        }
        synchronized (this.f2361k) {
            Iterator it = this.f2361k.iterator();
            while (it.hasNext()) {
                it.next();
            }
        }
        if (aha.mo2252i()) {
            synchronized (this.f2352b) {
                String f = aha.mo2250f();
                Queue queue = (Queue) this.f2352b.remove(f);
                if (queue != null) {
                    if (C0618ac.f1702a) {
                        C0618ac.m2436a("Releasing %d waiting requests for cacheKey=%s.", Integer.valueOf(queue.size()), f);
                    }
                    this.f2354d.addAll(queue);
                }
            }
        }
    }
}
