package com.google.android.gms.internal;

import android.text.TextUtils;
import com.google.android.gms.ads.internal.C0354ax;
import java.util.Map;

@arm
final class akc implements ajh {
    akc() {
    }

    /* renamed from: a */
    public final void mo1441a(C0885jw jwVar, Map<String, String> map) {
        if (((Boolean) C0354ax.m1551r().mo2079a(ael.f1914bg)).booleanValue()) {
            C0905kp A = jwVar.mo2922A();
            if (A == null) {
                try {
                    C0905kp kpVar = new C0905kp(jwVar, Float.parseFloat((String) map.get("duration")), "1".equals(map.get("customControlsAllowed")));
                    jwVar.mo2936a(kpVar);
                    A = kpVar;
                } catch (NullPointerException | NumberFormatException e) {
                    C0759fe.m4730b("Unable to parse videoMeta message.", e);
                    C0354ax.m1542i().mo2742a(e, "VideoMetaGmsgHandler.onGmsg");
                    return;
                }
            }
            boolean equals = "1".equals(map.get("muted"));
            float parseFloat = Float.parseFloat((String) map.get("currentTime"));
            int parseInt = Integer.parseInt((String) map.get("playbackState"));
            if (parseInt < 0 || 3 < parseInt) {
                parseInt = 0;
            }
            String str = (String) map.get("aspectRatio");
            float parseFloat2 = TextUtils.isEmpty(str) ? 0.0f : Float.parseFloat(str);
            if (C0759fe.m4728a(3)) {
                StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 79);
                sb.append("Video Meta GMSG: isMuted : ");
                sb.append(equals);
                sb.append(" , playbackState : ");
                sb.append(parseInt);
                sb.append(" , aspectRatio : ");
                sb.append(str);
                C0759fe.m4729b(sb.toString());
            }
            A.mo3049a(parseFloat, parseInt, equals, parseFloat2);
        }
    }
}
