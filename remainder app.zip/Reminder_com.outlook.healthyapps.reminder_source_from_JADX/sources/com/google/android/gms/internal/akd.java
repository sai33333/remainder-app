package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.C0354ax;

@arm
public final class akd extends C0757fc {

    /* renamed from: a */
    final C0885jw f2362a;

    /* renamed from: b */
    final akg f2363b;

    /* renamed from: c */
    private final String f2364c;

    akd(C0885jw jwVar, akg akg, String str) {
        this.f2362a = jwVar;
        this.f2363b = akg;
        this.f2364c = str;
        C0354ax.m1530B().mo2302a(this);
    }

    /* renamed from: a */
    public final void mo1567a() {
        try {
            this.f2363b.mo2308a(this.f2364c);
        } finally {
            C0796go.f3327a.post(new ake(this));
        }
    }

    /* renamed from: b */
    public final void mo1568b() {
        this.f2363b.mo2305a();
    }
}
