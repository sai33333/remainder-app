package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.C0354ax;

final class ake implements Runnable {

    /* renamed from: a */
    private /* synthetic */ akd f2365a;

    ake(akd akd) {
        this.f2365a = akd;
    }

    public final void run() {
        C0354ax.m1530B().mo2303b(this.f2365a);
    }
}
