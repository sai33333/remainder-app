package com.google.android.gms.internal;

import android.content.Context;
import android.os.Handler;
import com.google.android.gms.ads.internal.C0354ax;
import java.lang.ref.WeakReference;
import java.util.Map;

@arm
public abstract class akg {

    /* renamed from: a */
    protected Context f2367a;

    /* renamed from: b */
    private String f2368b;

    /* renamed from: c */
    private WeakReference<C0885jw> f2369c;

    public akg(C0885jw jwVar) {
        this.f2367a = jwVar.getContext();
        this.f2368b = C0354ax.m1538e().mo2796a(this.f2367a, jwVar.mo2973p().f3448a);
        this.f2369c = new WeakReference<>(jwVar);
    }

    /* access modifiers changed from: private */
    /* renamed from: a */
    public final void m3262a(String str, Map<String, String> map) {
        C0885jw jwVar = (C0885jw) this.f2369c.get();
        if (jwVar != null) {
            jwVar.mo2938a(str, map);
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: b */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.String m3263b(java.lang.String r2) {
        /*
            java.lang.String r0 = "internal"
            int r1 = r2.hashCode()
            switch(r1) {
                case -1396664534: goto L_0x0067;
                case -1347010958: goto L_0x005d;
                case -918817863: goto L_0x0053;
                case -659376217: goto L_0x0049;
                case -642208130: goto L_0x003f;
                case -354048396: goto L_0x0034;
                case -32082395: goto L_0x0029;
                case 96784904: goto L_0x001f;
                case 580119100: goto L_0x0015;
                case 725497484: goto L_0x000b;
                default: goto L_0x0009;
            }
        L_0x0009:
            goto L_0x0071
        L_0x000b:
            java.lang.String r1 = "noCacheDir"
            boolean r2 = r2.equals(r1)
            if (r2 == 0) goto L_0x0071
            r2 = 4
            goto L_0x0072
        L_0x0015:
            java.lang.String r1 = "expireFailed"
            boolean r2 = r2.equals(r1)
            if (r2 == 0) goto L_0x0071
            r2 = 5
            goto L_0x0072
        L_0x001f:
            java.lang.String r1 = "error"
            boolean r2 = r2.equals(r1)
            if (r2 == 0) goto L_0x0071
            r2 = 0
            goto L_0x0072
        L_0x0029:
            java.lang.String r1 = "externalAbort"
            boolean r2 = r2.equals(r1)
            if (r2 == 0) goto L_0x0071
            r2 = 9
            goto L_0x0072
        L_0x0034:
            java.lang.String r1 = "sizeExceeded"
            boolean r2 = r2.equals(r1)
            if (r2 == 0) goto L_0x0071
            r2 = 8
            goto L_0x0072
        L_0x003f:
            java.lang.String r1 = "playerFailed"
            boolean r2 = r2.equals(r1)
            if (r2 == 0) goto L_0x0071
            r2 = 1
            goto L_0x0072
        L_0x0049:
            java.lang.String r1 = "contentLengthMissing"
            boolean r2 = r2.equals(r1)
            if (r2 == 0) goto L_0x0071
            r2 = 3
            goto L_0x0072
        L_0x0053:
            java.lang.String r1 = "downloadTimeout"
            boolean r2 = r2.equals(r1)
            if (r2 == 0) goto L_0x0071
            r2 = 7
            goto L_0x0072
        L_0x005d:
            java.lang.String r1 = "inProgress"
            boolean r2 = r2.equals(r1)
            if (r2 == 0) goto L_0x0071
            r2 = 2
            goto L_0x0072
        L_0x0067:
            java.lang.String r1 = "badUrl"
            boolean r2 = r2.equals(r1)
            if (r2 == 0) goto L_0x0071
            r2 = 6
            goto L_0x0072
        L_0x0071:
            r2 = -1
        L_0x0072:
            switch(r2) {
                case 0: goto L_0x007f;
                case 1: goto L_0x007f;
                case 2: goto L_0x007f;
                case 3: goto L_0x007f;
                case 4: goto L_0x007c;
                case 5: goto L_0x007c;
                case 6: goto L_0x0079;
                case 7: goto L_0x0079;
                case 8: goto L_0x0076;
                case 9: goto L_0x0076;
                default: goto L_0x0075;
            }
        L_0x0075:
            goto L_0x0081
        L_0x0076:
            java.lang.String r0 = "policy"
            goto L_0x0081
        L_0x0079:
            java.lang.String r0 = "network"
            goto L_0x0081
        L_0x007c:
            java.lang.String r0 = "io"
            goto L_0x0081
        L_0x007f:
            java.lang.String r0 = "internal"
        L_0x0081:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.akg.m3263b(java.lang.String):java.lang.String");
    }

    /* renamed from: a */
    public abstract void mo2305a();

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public final void mo2306a(String str, String str2, int i) {
        C0851ip.f3439a.post(new aki(this, str, str2, i));
    }

    /* renamed from: a */
    public final void mo2307a(String str, String str2, String str3, String str4) {
        Handler handler = C0851ip.f3439a;
        akj akj = new akj(this, str, str2, str3, str4);
        handler.post(akj);
    }

    /* renamed from: a */
    public abstract boolean mo2308a(String str);
}
