package com.google.android.gms.internal;

import android.text.TextUtils;
import java.util.HashMap;
import java.util.Map;

final class akj implements Runnable {

    /* renamed from: a */
    private /* synthetic */ String f2380a;

    /* renamed from: b */
    private /* synthetic */ String f2381b;

    /* renamed from: c */
    private /* synthetic */ String f2382c;

    /* renamed from: d */
    private /* synthetic */ String f2383d;

    /* renamed from: e */
    private /* synthetic */ akg f2384e;

    akj(akg akg, String str, String str2, String str3, String str4) {
        this.f2384e = akg;
        this.f2380a = str;
        this.f2381b = str2;
        this.f2382c = str3;
        this.f2383d = str4;
    }

    public final void run() {
        HashMap hashMap = new HashMap();
        hashMap.put("event", "precacheCanceled");
        hashMap.put("src", this.f2380a);
        if (!TextUtils.isEmpty(this.f2381b)) {
            hashMap.put("cachedSrc", this.f2381b);
        }
        hashMap.put("type", akg.m3263b(this.f2382c));
        hashMap.put("reason", this.f2382c);
        if (!TextUtils.isEmpty(this.f2383d)) {
            hashMap.put("message", this.f2383d);
        }
        this.f2384e.m3262a("onPrecacheEvent", (Map<String, String>) hashMap);
    }
}
