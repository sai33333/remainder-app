package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.overlay.C0470r;

public interface akl {
    /* renamed from: a */
    akg mo2276a(C0885jw jwVar, int i, String str, C0470r rVar);
}
