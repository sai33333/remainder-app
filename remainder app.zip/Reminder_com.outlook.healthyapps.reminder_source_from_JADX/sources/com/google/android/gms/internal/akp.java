package com.google.android.gms.internal;

final class akp extends abq {

    /* renamed from: a */
    private /* synthetic */ ako f2395a;

    akp(ako ako) {
        this.f2395a = ako;
    }

    /* renamed from: a */
    public final void mo1922a() {
        this.f2395a.f2394a.add(new akq(this));
    }

    /* renamed from: a */
    public final void mo1923a(int i) {
        this.f2395a.f2394a.add(new akr(this, i));
        C0759fe.m4411a("Pooled interstitial failed to load.");
    }

    /* renamed from: b */
    public final void mo1924b() {
        this.f2395a.f2394a.add(new aks(this));
    }

    /* renamed from: c */
    public final void mo1925c() {
        this.f2395a.f2394a.add(new akt(this));
        C0759fe.m4411a("Pooled interstitial loaded.");
    }

    /* renamed from: d */
    public final void mo1926d() {
        this.f2395a.f2394a.add(new aku(this));
    }

    /* renamed from: e */
    public final void mo1927e() {
        this.f2395a.f2394a.add(new akw(this));
    }

    /* renamed from: f */
    public final void mo1928f() {
        this.f2395a.f2394a.add(new akv(this));
    }
}
