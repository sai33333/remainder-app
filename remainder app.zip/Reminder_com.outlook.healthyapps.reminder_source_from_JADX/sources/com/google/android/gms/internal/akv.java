package com.google.android.gms.internal;

final class akv implements aln {
    akv(akp akp) {
    }

    /* renamed from: a */
    public final void mo2317a(alo alo) {
        if (alo.f2415a != null) {
            alo.f2415a.mo1928f();
        }
    }
}
