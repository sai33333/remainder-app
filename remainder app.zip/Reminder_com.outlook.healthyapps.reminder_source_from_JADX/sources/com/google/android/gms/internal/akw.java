package com.google.android.gms.internal;

final class akw implements aln {
    akw(akp akp) {
    }

    /* renamed from: a */
    public final void mo2317a(alo alo) {
        if (alo.f2415a != null) {
            alo.f2415a.mo1927e();
        }
    }
}
