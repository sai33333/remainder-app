package com.google.android.gms.internal;

final class akx extends ach {

    /* renamed from: a */
    private /* synthetic */ ako f2397a;

    akx(ako ako) {
        this.f2397a = ako;
    }

    /* renamed from: a */
    public final void mo1942a(String str, String str2) {
        this.f2397a.f2394a.add(new aky(this, str, str2));
    }
}
