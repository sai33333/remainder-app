package com.google.android.gms.internal;

final class aky implements aln {

    /* renamed from: a */
    private /* synthetic */ String f2398a;

    /* renamed from: b */
    private /* synthetic */ String f2399b;

    aky(akx akx, String str, String str2) {
        this.f2398a = str;
        this.f2399b = str2;
    }

    /* renamed from: a */
    public final void mo2317a(alo alo) {
        if (alo.f2416b != null) {
            alo.f2416b.mo1942a(this.f2398a, this.f2399b);
        }
    }
}
