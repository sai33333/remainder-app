package com.google.android.gms.internal;

final class ald implements aln {
    ald(alb alb) {
    }

    /* renamed from: a */
    public final void mo2317a(alo alo) {
        if (alo.f2418d != null) {
            alo.f2418d.mo1921a();
        }
    }
}
