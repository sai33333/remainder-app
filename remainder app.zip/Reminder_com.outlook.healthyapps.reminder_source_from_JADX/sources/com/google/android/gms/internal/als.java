package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.C0354ax;
import com.google.android.gms.ads.internal.C0371bn;
import java.util.Arrays;

@arm
final class als {

    /* renamed from: a */
    private final Object[] f2425a;

    als(aau aau, String str, int i) {
        this.f2425a = C0371bn.m1623a((String) C0354ax.m1551r().mo2079a(ael.f1838aJ), aau, str, i, null);
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof als)) {
            return false;
        }
        return Arrays.equals(this.f2425a, ((als) obj).f2425a);
    }

    public final int hashCode() {
        return Arrays.hashCode(this.f2425a);
    }

    public final String toString() {
        String arrays = Arrays.toString(this.f2425a);
        StringBuilder sb = new StringBuilder(String.valueOf(arrays).length() + 24);
        sb.append("[InterstitialAdPoolKey ");
        sb.append(arrays);
        sb.append("]");
        return sb.toString();
    }
}
