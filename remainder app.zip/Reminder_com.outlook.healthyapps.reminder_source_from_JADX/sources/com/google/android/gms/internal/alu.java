package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.C0354ax;
import com.google.android.gms.ads.internal.C0430n;

final class alu {

    /* renamed from: a */
    C0430n f2431a;

    /* renamed from: b */
    aau f2432b;

    /* renamed from: c */
    ako f2433c;

    /* renamed from: d */
    long f2434d;

    /* renamed from: e */
    boolean f2435e;

    /* renamed from: f */
    boolean f2436f;

    /* renamed from: g */
    private /* synthetic */ alt f2437g;

    alu(alt alt, akn akn) {
        this.f2437g = alt;
        this.f2431a = akn.mo2314b(alt.f2428c);
        this.f2433c = new ako();
        ako ako = this.f2433c;
        C0430n nVar = this.f2431a;
        nVar.mo1287a((abp) new akp(ako));
        nVar.mo1288a((acg) new akx(ako));
        nVar.mo1293a((aff) new akz(ako));
        nVar.mo1286a((abm) new alb(ako));
        nVar.mo1296a((C0689cp) new ale(ako));
    }

    alu(alt alt, akn akn, aau aau) {
        this(alt, akn);
        this.f2432b = aau;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public final boolean mo2347a() {
        if (this.f2435e) {
            return false;
        }
        aau aau = this.f2432b;
        if (aau == null) {
            aau = this.f2437g.f2427b;
        }
        this.f2436f = this.f2431a.mo1309b(alr.m3329b(aau));
        this.f2435e = true;
        this.f2434d = C0354ax.m1544k().mo1882a();
        return true;
    }
}
