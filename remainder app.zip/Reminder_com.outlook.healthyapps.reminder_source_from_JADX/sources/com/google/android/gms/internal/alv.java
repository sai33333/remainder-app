package com.google.android.gms.internal;

import android.os.Bundle;

@arm
public final class alv {

    /* renamed from: a */
    private static alv f2438a = new alv();

    /* renamed from: b */
    private int f2439b;

    /* renamed from: c */
    private int f2440c;

    /* renamed from: d */
    private int f2441d;

    /* renamed from: e */
    private int f2442e;

    /* renamed from: f */
    private int f2443f;

    /* renamed from: a */
    public static alv m3353a() {
        return f2438a;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public final void mo2348a(int i) {
        this.f2439b += i;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public final void mo2349b() {
        this.f2440c++;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public final void mo2350c() {
        this.f2441d++;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: d */
    public final void mo2351d() {
        this.f2442e++;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: e */
    public final void mo2352e() {
        this.f2443f++;
    }

    /* renamed from: f */
    public final int mo2353f() {
        return this.f2440c;
    }

    /* renamed from: g */
    public final int mo2354g() {
        return this.f2441d;
    }

    /* renamed from: h */
    public final int mo2355h() {
        return this.f2442e;
    }

    /* renamed from: i */
    public final int mo2356i() {
        return this.f2443f;
    }

    /* renamed from: j */
    public final Bundle mo2357j() {
        Bundle bundle = new Bundle();
        bundle.putInt("ipl", this.f2439b);
        bundle.putInt("ipds", this.f2440c);
        bundle.putInt("ipde", this.f2441d);
        bundle.putInt("iph", this.f2442e);
        bundle.putInt("ipm", this.f2443f);
        return bundle;
    }
}
