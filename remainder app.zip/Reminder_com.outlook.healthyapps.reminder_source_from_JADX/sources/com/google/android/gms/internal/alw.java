package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.ads.internal.C0354ax;
import com.google.android.gms.ads.internal.C0377bt;
import com.google.android.gms.ads.internal.C0430n;
import com.google.android.gms.p012a.C0279a;

@arm
public final class alw extends acb {

    /* renamed from: a */
    private final String f2444a;

    /* renamed from: b */
    private boolean f2445b;

    /* renamed from: c */
    private final akn f2446c;

    /* renamed from: d */
    private C0430n f2447d;

    /* renamed from: e */
    private final alo f2448e;

    public alw(Context context, String str, amx amx, C0857iv ivVar, C0377bt btVar) {
        this(str, new akn(context, amx, ivVar, btVar));
    }

    private alw(String str, akn akn) {
        this.f2444a = str;
        this.f2446c = akn;
        this.f2448e = new alo();
        C0354ax.m1553t().mo2331a(akn);
    }

    /* renamed from: c */
    private final void m3364c() {
        if (this.f2447d == null) {
            this.f2447d = this.f2446c.mo2313a(this.f2444a);
            this.f2448e.mo2327a(this.f2447d);
        }
    }

    /* renamed from: A */
    public final abp mo1280A() {
        throw new IllegalStateException("getIAdListener not implemented");
    }

    /* renamed from: B */
    public final void mo1337B() {
        C0430n nVar = this.f2447d;
        if (nVar != null) {
            nVar.mo1308b(this.f2445b);
            this.f2447d.mo1337B();
            return;
        }
        C0759fe.m4734e("Interstitial ad must be loaded before showInterstitial().");
    }

    /* renamed from: a */
    public final String mo1377a() {
        C0430n nVar = this.f2447d;
        if (nVar != null) {
            return nVar.mo1377a();
        }
        return null;
    }

    /* renamed from: a */
    public final void mo1285a(aay aay) {
        C0430n nVar = this.f2447d;
        if (nVar != null) {
            nVar.mo1285a(aay);
        }
    }

    /* renamed from: a */
    public final void mo1286a(abm abm) {
        alo alo = this.f2448e;
        alo.f2418d = abm;
        C0430n nVar = this.f2447d;
        if (nVar != null) {
            alo.mo2327a(nVar);
        }
    }

    /* renamed from: a */
    public final void mo1287a(abp abp) {
        alo alo = this.f2448e;
        alo.f2415a = abp;
        C0430n nVar = this.f2447d;
        if (nVar != null) {
            alo.mo2327a(nVar);
        }
    }

    /* renamed from: a */
    public final void mo1288a(acg acg) {
        alo alo = this.f2448e;
        alo.f2416b = acg;
        C0430n nVar = this.f2447d;
        if (nVar != null) {
            alo.mo2327a(nVar);
        }
    }

    /* renamed from: a */
    public final void mo1289a(acm acm) {
        m3364c();
        C0430n nVar = this.f2447d;
        if (nVar != null) {
            nVar.mo1289a(acm);
        }
    }

    /* renamed from: a */
    public final void mo1290a(ada ada) {
        throw new IllegalStateException("Unused method");
    }

    /* renamed from: a */
    public final void mo1291a(adt adt) {
        throw new IllegalStateException("getVideoController not implemented for interstitials");
    }

    /* renamed from: a */
    public final void mo1293a(aff aff) {
        alo alo = this.f2448e;
        alo.f2417c = aff;
        C0430n nVar = this.f2447d;
        if (nVar != null) {
            alo.mo2327a(nVar);
        }
    }

    /* renamed from: a */
    public final void mo1294a(ape ape) {
        C0759fe.m4734e("setInAppPurchaseListener is deprecated and should not be called.");
    }

    /* renamed from: a */
    public final void mo1295a(apk apk, String str) {
        C0759fe.m4734e("setPlayStorePurchaseParams is deprecated and should not be called.");
    }

    /* renamed from: a */
    public final void mo1296a(C0689cp cpVar) {
        alo alo = this.f2448e;
        alo.f2419e = cpVar;
        C0430n nVar = this.f2447d;
        if (nVar != null) {
            alo.mo2327a(nVar);
        }
    }

    /* renamed from: a */
    public final void mo1300a(String str) {
    }

    /* renamed from: a */
    public final void mo1303a(boolean z) {
        m3364c();
        C0430n nVar = this.f2447d;
        if (nVar != null) {
            nVar.mo1303a(z);
        }
    }

    /* renamed from: b */
    public final void mo1308b(boolean z) {
        this.f2445b = z;
    }

    /* renamed from: b */
    public final boolean mo1309b(aau aau) {
        if (!alr.m3325a(aau).contains("gw")) {
            m3364c();
        }
        if (alr.m3325a(aau).contains("_skipMediation")) {
            m3364c();
        }
        if (aau.f1623j != null) {
            m3364c();
        }
        C0430n nVar = this.f2447d;
        if (nVar != null) {
            return nVar.mo1309b(aau);
        }
        alr t = C0354ax.m1553t();
        if (alr.m3325a(aau).contains("_ad")) {
            t.mo2332b(aau, this.f2444a);
        }
        alu a = t.mo2329a(aau, this.f2444a);
        if (a != null) {
            if (!a.f2435e) {
                a.mo2347a();
                alv.m3353a().mo2352e();
            } else {
                alv.m3353a().mo2351d();
            }
            this.f2447d = a.f2431a;
            a.f2433c.mo2316a(this.f2448e);
            this.f2448e.mo2327a(this.f2447d);
            return a.f2436f;
        }
        m3364c();
        alv.m3353a().mo2352e();
        return this.f2447d.mo1309b(aau);
    }

    /* renamed from: g */
    public final void mo1314g() {
        C0430n nVar = this.f2447d;
        if (nVar != null) {
            nVar.mo1314g();
        }
    }

    /* renamed from: g_ */
    public final String mo1382g_() {
        C0430n nVar = this.f2447d;
        if (nVar != null) {
            return nVar.mo1382g_();
        }
        return null;
    }

    /* renamed from: h */
    public final C0279a mo1315h() {
        C0430n nVar = this.f2447d;
        if (nVar != null) {
            return nVar.mo1315h();
        }
        return null;
    }

    /* renamed from: i */
    public final aay mo1316i() {
        C0430n nVar = this.f2447d;
        if (nVar != null) {
            return nVar.mo1316i();
        }
        return null;
    }

    /* renamed from: j */
    public final boolean mo1317j() {
        C0430n nVar = this.f2447d;
        return nVar != null && nVar.mo1317j();
    }

    /* renamed from: k */
    public final void mo1318k() {
        C0430n nVar = this.f2447d;
        if (nVar != null) {
            nVar.mo1318k();
        } else {
            C0759fe.m4734e("Interstitial ad must be loaded before pingManualTrackingUrl().");
        }
    }

    /* renamed from: l */
    public final void mo1319l() {
        C0430n nVar = this.f2447d;
        if (nVar != null) {
            nVar.mo1319l();
        }
    }

    /* renamed from: m */
    public final void mo1320m() {
        C0430n nVar = this.f2447d;
        if (nVar != null) {
            nVar.mo1320m();
        }
    }

    /* renamed from: n */
    public final void mo1321n() {
        C0430n nVar = this.f2447d;
        if (nVar != null) {
            nVar.mo1321n();
        }
    }

    /* renamed from: o */
    public final boolean mo1322o() {
        C0430n nVar = this.f2447d;
        return nVar != null && nVar.mo1322o();
    }

    /* renamed from: p */
    public final acu mo1323p() {
        throw new IllegalStateException("getVideoController not implemented for interstitials");
    }

    /* renamed from: y */
    public final String mo1332y() {
        throw new IllegalStateException("getAdUnitId not implemented");
    }

    /* renamed from: z */
    public final acg mo1333z() {
        throw new IllegalStateException("getIAppEventListener not implemented");
    }
}
