package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.C0354ax;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

@arm
public final class amh {

    /* renamed from: a */
    public final String f2463a;

    /* renamed from: b */
    public final String f2464b;

    /* renamed from: c */
    public final List<String> f2465c;

    /* renamed from: d */
    public final String f2466d;

    /* renamed from: e */
    public final String f2467e;

    /* renamed from: f */
    public final List<String> f2468f;

    /* renamed from: g */
    public final List<String> f2469g;

    /* renamed from: h */
    public final List<String> f2470h;

    /* renamed from: i */
    public final List<String> f2471i;

    /* renamed from: j */
    public final String f2472j;

    /* renamed from: k */
    public final List<String> f2473k;

    /* renamed from: l */
    public final List<String> f2474l;

    /* renamed from: m */
    public final String f2475m;

    /* renamed from: n */
    public final String f2476n;

    /* renamed from: o */
    public final String f2477o;

    /* renamed from: p */
    public final List<String> f2478p;

    /* renamed from: q */
    public final String f2479q;

    /* renamed from: r */
    private String f2480r;

    public amh(String str, String str2, List<String> list, String str3, String str4, List<String> list2, List<String> list3, List<String> list4, String str5, String str6, List<String> list5, List<String> list6, String str7, String str8, String str9, List<String> list7, String str10, List<String> list8, String str11) {
        this.f2463a = str;
        this.f2464b = null;
        this.f2465c = list;
        this.f2466d = null;
        this.f2467e = null;
        this.f2468f = list2;
        this.f2469g = list3;
        this.f2470h = list4;
        this.f2472j = str5;
        this.f2473k = list5;
        this.f2474l = list6;
        this.f2475m = null;
        this.f2476n = null;
        this.f2477o = null;
        this.f2478p = null;
        this.f2479q = null;
        this.f2471i = list8;
        this.f2480r = null;
    }

    public amh(JSONObject jSONObject) {
        List<String> list;
        this.f2464b = jSONObject.optString("id");
        JSONArray jSONArray = jSONObject.getJSONArray("adapters");
        ArrayList arrayList = new ArrayList(jSONArray.length());
        for (int i = 0; i < jSONArray.length(); i++) {
            arrayList.add(jSONArray.getString(i));
        }
        this.f2465c = Collections.unmodifiableList(arrayList);
        this.f2466d = jSONObject.optString("allocation_id", null);
        C0354ax.m1558y();
        this.f2468f = amq.m3463a(jSONObject, "clickurl");
        C0354ax.m1558y();
        this.f2469g = amq.m3463a(jSONObject, "imp_urls");
        C0354ax.m1558y();
        this.f2471i = amq.m3463a(jSONObject, "fill_urls");
        C0354ax.m1558y();
        this.f2473k = amq.m3463a(jSONObject, "video_start_urls");
        C0354ax.m1558y();
        this.f2474l = amq.m3463a(jSONObject, "video_complete_urls");
        JSONObject optJSONObject = jSONObject.optJSONObject("ad");
        if (optJSONObject != null) {
            C0354ax.m1558y();
            list = amq.m3463a(optJSONObject, "manual_impression_urls");
        } else {
            list = null;
        }
        this.f2470h = list;
        this.f2463a = optJSONObject != null ? optJSONObject.toString() : null;
        JSONObject optJSONObject2 = jSONObject.optJSONObject("data");
        this.f2472j = optJSONObject2 != null ? optJSONObject2.toString() : null;
        this.f2467e = optJSONObject2 != null ? optJSONObject2.optString("class_name") : null;
        this.f2475m = jSONObject.optString("html_template", null);
        this.f2476n = jSONObject.optString("ad_base_url", null);
        JSONObject optJSONObject3 = jSONObject.optJSONObject("assets");
        this.f2477o = optJSONObject3 != null ? optJSONObject3.toString() : null;
        C0354ax.m1558y();
        this.f2478p = amq.m3463a(jSONObject, "template_ids");
        JSONObject optJSONObject4 = jSONObject.optJSONObject("ad_loader_options");
        this.f2479q = optJSONObject4 != null ? optJSONObject4.toString() : null;
        this.f2480r = jSONObject.optString("response_type", null);
    }

    /* renamed from: a */
    public final boolean mo2366a() {
        return "banner".equalsIgnoreCase(this.f2480r);
    }

    /* renamed from: b */
    public final boolean mo2367b() {
        return "native".equalsIgnoreCase(this.f2480r);
    }
}
