package com.google.android.gms.internal;

import android.os.RemoteException;
import com.google.ads.mediation.AdUrlAdapter;
import com.google.ads.mediation.C0262b;
import com.google.ads.mediation.C0271e;
import com.google.ads.mediation.C0274f;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.mediation.C0493b;
import com.google.android.gms.ads.mediation.customevent.C0499a;
import com.google.android.gms.ads.mediation.customevent.C0501c;
import com.google.android.gms.ads.mediation.customevent.CustomEventAdapter;
import java.util.Map;

@arm
public final class amw extends amy {

    /* renamed from: a */
    private Map<Class<? extends Object>, Object> f2564a;

    /* renamed from: c */
    private final <NETWORK_EXTRAS extends C0274f, SERVER_PARAMETERS extends C0271e> ana m3481c(String str) {
        try {
            Class cls = Class.forName(str, false, amw.class.getClassLoader());
            if (C0262b.class.isAssignableFrom(cls)) {
                C0262b bVar = (C0262b) cls.newInstance();
                return new anx(bVar, (C0274f) this.f2564a.get(bVar.getAdditionalParametersType()));
            } else if (C0493b.class.isAssignableFrom(cls)) {
                return new ans((C0493b) cls.newInstance());
            } else {
                StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 64);
                sb.append("Could not instantiate mediation adapter: ");
                sb.append(str);
                sb.append(" (not a valid adapter).");
                C0855it.m4734e(sb.toString());
                throw new RemoteException();
            }
        } catch (Throwable unused) {
            return m3482d(str);
        }
    }

    /* renamed from: d */
    private final ana m3482d(String str) {
        try {
            C0855it.m4729b("Reflection failed, retrying using direct instantiation");
            if ("com.google.ads.mediation.admob.AdMobAdapter".equals(str)) {
                return new ans(new AdMobAdapter());
            }
            if ("com.google.ads.mediation.AdUrlAdapter".equals(str)) {
                return new ans(new AdUrlAdapter());
            }
            if ("com.google.android.gms.ads.mediation.customevent.CustomEventAdapter".equals(str)) {
                return new ans(new CustomEventAdapter());
            }
            if ("com.google.ads.mediation.customevent.CustomEventAdapter".equals(str)) {
                com.google.ads.mediation.customevent.CustomEventAdapter customEventAdapter = new com.google.ads.mediation.customevent.CustomEventAdapter();
                return new anx(customEventAdapter, (C0501c) this.f2564a.get(customEventAdapter.getAdditionalParametersType()));
            }
            throw new RemoteException();
        } catch (Throwable th) {
            StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 43);
            sb.append("Could not instantiate mediation adapter: ");
            sb.append(str);
            sb.append(". ");
            C0855it.m4732c(sb.toString(), th);
        }
    }

    /* renamed from: a */
    public final ana mo2390a(String str) {
        return m3481c(str);
    }

    /* renamed from: a */
    public final void mo2391a(Map<Class<? extends Object>, Object> map) {
        this.f2564a = map;
    }

    /* renamed from: b */
    public final boolean mo2392b(String str) {
        try {
            return C0499a.class.isAssignableFrom(Class.forName(str, false, amw.class.getClassLoader()));
        } catch (Throwable unused) {
            StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 80);
            sb.append("Could not load custom event implementation class: ");
            sb.append(str);
            sb.append(", assuming old implementation.");
            C0855it.m4734e(sb.toString());
            return false;
        }
    }
}
