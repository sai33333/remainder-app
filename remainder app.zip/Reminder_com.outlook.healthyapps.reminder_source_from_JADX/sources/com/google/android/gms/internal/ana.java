package com.google.android.gms.internal;

import android.os.Bundle;
import android.os.IInterface;
import com.google.android.gms.p012a.C0279a;
import java.util.List;

public interface ana extends IInterface {
    /* renamed from: a */
    C0279a mo2394a();

    /* renamed from: a */
    void mo2395a(C0279a aVar);

    /* renamed from: a */
    void mo2396a(C0279a aVar, aau aau, String str, and and);

    /* renamed from: a */
    void mo2397a(C0279a aVar, aau aau, String str, C0713dm dmVar, String str2);

    /* renamed from: a */
    void mo2398a(C0279a aVar, aau aau, String str, String str2, and and);

    /* renamed from: a */
    void mo2399a(C0279a aVar, aau aau, String str, String str2, and and, agm agm, List<String> list);

    /* renamed from: a */
    void mo2400a(C0279a aVar, aay aay, aau aau, String str, and and);

    /* renamed from: a */
    void mo2401a(C0279a aVar, aay aay, aau aau, String str, String str2, and and);

    /* renamed from: a */
    void mo2402a(C0279a aVar, C0713dm dmVar, List<String> list);

    /* renamed from: a */
    void mo2403a(aau aau, String str);

    /* renamed from: a */
    void mo2404a(aau aau, String str, String str2);

    /* renamed from: a */
    void mo2405a(boolean z);

    /* renamed from: b */
    void mo2406b();

    /* renamed from: c */
    void mo2407c();

    /* renamed from: d */
    void mo2408d();

    /* renamed from: e */
    void mo2409e();

    /* renamed from: f */
    void mo2410f();

    /* renamed from: g */
    boolean mo2411g();

    /* renamed from: h */
    ank mo2412h();

    /* renamed from: i */
    ann mo2413i();

    /* renamed from: j */
    Bundle mo2414j();

    /* renamed from: k */
    Bundle mo2415k();

    /* renamed from: l */
    Bundle mo2416l();

    /* renamed from: m */
    boolean mo2417m();

    /* renamed from: n */
    ahn mo2418n();

    /* renamed from: o */
    acu mo2419o();
}
