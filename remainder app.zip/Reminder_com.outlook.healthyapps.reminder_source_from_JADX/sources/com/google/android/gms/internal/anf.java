package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

public abstract class anf extends C1179sp implements and {
    public anf() {
        attachInterface(this, "com.google.android.gms.ads.internal.mediation.client.IMediationAdapterListener");
    }

    public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
        anh anh;
        if (zza(i, parcel, parcel2, i2)) {
            return true;
        }
        switch (i) {
            case 1:
                mo2368a();
                break;
            case 2:
                mo2375b();
                break;
            case 3:
                mo2369a(parcel.readInt());
                break;
            case C1217ty.f4597d /*4*/:
                mo2376c();
                break;
            case C1217ty.f4598e /*5*/:
                mo2377d();
                break;
            case C1217ty.f4599f /*6*/:
                mo2378e();
                break;
            case C1217ty.f4600g /*7*/:
                IBinder readStrongBinder = parcel.readStrongBinder();
                if (readStrongBinder == null) {
                    anh = null;
                } else {
                    IInterface queryLocalInterface = readStrongBinder.queryLocalInterface("com.google.android.gms.ads.internal.mediation.client.IMediationResponseMetadata");
                    anh = queryLocalInterface instanceof anh ? (anh) queryLocalInterface : new anj(readStrongBinder);
                }
                mo2373a(anh);
                break;
            case C1217ty.f4601h /*8*/:
                mo2379f();
                break;
            case 9:
                mo2374a(parcel.readString(), parcel.readString());
                break;
            case 10:
                mo2370a(aho.m3141a(parcel.readStrongBinder()), parcel.readString());
                break;
            case 11:
                mo2380g();
                break;
            default:
                return false;
        }
        parcel2.writeNoException();
        return true;
    }
}
