package com.google.android.gms.internal;

import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import com.google.android.gms.p012a.C0279a;
import com.google.android.gms.p012a.C0279a.C0280a;
import java.util.ArrayList;
import java.util.List;

public final class anm extends C1178so implements ank {
    anm(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.ads.internal.mediation.client.INativeAppInstallAdMapper");
    }

    /* renamed from: a */
    public final String mo2424a() {
        Parcel a = mo3281a(2, mo3284j_());
        String readString = a.readString();
        a.recycle();
        return readString;
    }

    /* renamed from: a */
    public final void mo2425a(C0279a aVar) {
        Parcel j_ = mo3284j_();
        C1181sr.m5731a(j_, (IInterface) aVar);
        mo3283b(11, j_);
    }

    /* renamed from: b */
    public final List mo2426b() {
        Parcel a = mo3281a(3, mo3284j_());
        ArrayList b = C1181sr.m5735b(a);
        a.recycle();
        return b;
    }

    /* renamed from: b */
    public final void mo2427b(C0279a aVar) {
        Parcel j_ = mo3284j_();
        C1181sr.m5731a(j_, (IInterface) aVar);
        mo3283b(12, j_);
    }

    /* renamed from: c */
    public final String mo2428c() {
        Parcel a = mo3281a(4, mo3284j_());
        String readString = a.readString();
        a.recycle();
        return readString;
    }

    /* renamed from: c */
    public final void mo2429c(C0279a aVar) {
        Parcel j_ = mo3284j_();
        C1181sr.m5731a(j_, (IInterface) aVar);
        mo3283b(16, j_);
    }

    /* renamed from: d */
    public final agv mo2430d() {
        Parcel a = mo3281a(5, mo3284j_());
        agv a2 = agw.m3002a(a.readStrongBinder());
        a.recycle();
        return a2;
    }

    /* renamed from: e */
    public final String mo2431e() {
        Parcel a = mo3281a(6, mo3284j_());
        String readString = a.readString();
        a.recycle();
        return readString;
    }

    /* renamed from: f */
    public final double mo2432f() {
        Parcel a = mo3281a(7, mo3284j_());
        double readDouble = a.readDouble();
        a.recycle();
        return readDouble;
    }

    /* renamed from: g */
    public final String mo2433g() {
        Parcel a = mo3281a(8, mo3284j_());
        String readString = a.readString();
        a.recycle();
        return readString;
    }

    /* renamed from: h */
    public final String mo2434h() {
        Parcel a = mo3281a(9, mo3284j_());
        String readString = a.readString();
        a.recycle();
        return readString;
    }

    /* renamed from: i */
    public final void mo2435i() {
        mo3283b(10, mo3284j_());
    }

    /* renamed from: j */
    public final boolean mo2436j() {
        Parcel a = mo3281a(13, mo3284j_());
        boolean a2 = C1181sr.m5734a(a);
        a.recycle();
        return a2;
    }

    /* renamed from: k */
    public final boolean mo2437k() {
        Parcel a = mo3281a(14, mo3284j_());
        boolean a2 = C1181sr.m5734a(a);
        a.recycle();
        return a2;
    }

    /* renamed from: l */
    public final Bundle mo2438l() {
        Parcel a = mo3281a(15, mo3284j_());
        Bundle bundle = (Bundle) C1181sr.m5730a(a, Bundle.CREATOR);
        a.recycle();
        return bundle;
    }

    /* renamed from: m */
    public final acu mo2439m() {
        Parcel a = mo3281a(17, mo3284j_());
        acu a2 = acv.m2541a(a.readStrongBinder());
        a.recycle();
        return a2;
    }

    /* renamed from: n */
    public final C0279a mo2440n() {
        Parcel a = mo3281a(18, mo3284j_());
        C0279a a2 = C0280a.m1238a(a.readStrongBinder());
        a.recycle();
        return a2;
    }

    /* renamed from: o */
    public final agr mo2441o() {
        Parcel a = mo3281a(19, mo3284j_());
        agr a2 = ags.m2996a(a.readStrongBinder());
        a.recycle();
        return a2;
    }

    /* renamed from: p */
    public final C0279a mo2442p() {
        Parcel a = mo3281a(20, mo3284j_());
        C0279a a2 = C0280a.m1238a(a.readStrongBinder());
        a.recycle();
        return a2;
    }

    /* renamed from: q */
    public final C0279a mo2443q() {
        Parcel a = mo3281a(21, mo3284j_());
        C0279a a2 = C0280a.m1238a(a.readStrongBinder());
        a.recycle();
        return a2;
    }
}
