package com.google.android.gms.internal;

import android.os.RemoteException;
import com.google.ads.C0252a.C0253a;

final class anz implements Runnable {

    /* renamed from: a */
    private /* synthetic */ C0253a f2595a;

    /* renamed from: b */
    private /* synthetic */ any f2596b;

    anz(any any, C0253a aVar) {
        this.f2596b = any;
        this.f2595a = aVar;
    }

    public final void run() {
        try {
            this.f2596b.f2594a.mo2369a(aoc.m3797a(this.f2595a));
        } catch (RemoteException e) {
            C0855it.m4732c("Could not call onAdFailedToLoad.", e);
        }
    }
}
