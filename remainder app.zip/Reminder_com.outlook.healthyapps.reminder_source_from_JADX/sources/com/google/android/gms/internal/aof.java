package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.C0354ax;
import com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel;
import com.google.android.gms.ads.internal.overlay.C0448ap;

final class aof implements Runnable {

    /* renamed from: a */
    private /* synthetic */ AdOverlayInfoParcel f2603a;

    /* renamed from: b */
    private /* synthetic */ zzwh f2604b;

    aof(zzwh zzwh, AdOverlayInfoParcel adOverlayInfoParcel) {
        this.f2604b = zzwh;
        this.f2603a = adOverlayInfoParcel;
    }

    public final void run() {
        C0354ax.m1536c();
        C0448ap.m1834a(this.f2604b.f5021a, this.f2603a, true);
    }
}
