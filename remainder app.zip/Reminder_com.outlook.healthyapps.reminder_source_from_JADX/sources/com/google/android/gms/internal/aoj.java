package com.google.android.gms.internal;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import com.google.android.gms.ads.internal.C0354ax;
import com.google.android.gms.common.util.C0575c;
import java.util.Set;

@arm
public final class aoj extends aot {

    /* renamed from: a */
    private static Set<String> f2614a = C0575c.m2235a("top-left", "top-right", "top-center", "center", "bottom-left", "bottom-right", "bottom-center");

    /* renamed from: b */
    private String f2615b = "top-right";

    /* renamed from: c */
    private boolean f2616c = true;

    /* renamed from: d */
    private int f2617d = 0;

    /* renamed from: e */
    private int f2618e = 0;

    /* renamed from: f */
    private int f2619f = -1;

    /* renamed from: g */
    private int f2620g = 0;

    /* renamed from: h */
    private int f2621h = 0;

    /* renamed from: i */
    private int f2622i = -1;

    /* renamed from: j */
    private final Object f2623j = new Object();

    /* renamed from: k */
    private final C0885jw f2624k;

    /* renamed from: l */
    private final Activity f2625l;

    /* renamed from: m */
    private aay f2626m;

    /* renamed from: n */
    private ImageView f2627n;

    /* renamed from: o */
    private LinearLayout f2628o;

    /* renamed from: p */
    private aou f2629p;

    /* renamed from: q */
    private PopupWindow f2630q;

    /* renamed from: r */
    private RelativeLayout f2631r;

    /* renamed from: s */
    private ViewGroup f2632s;

    public aoj(C0885jw jwVar, aou aou) {
        super(jwVar, "resize");
        this.f2624k = jwVar;
        this.f2625l = jwVar.mo2950e();
        this.f2629p = aou;
    }

    /* renamed from: b */
    private final void m3809b(int i, int i2) {
        mo2494a(i, i2 - C0354ax.m1538e().mo2807c(this.f2625l)[0], this.f2622i, this.f2619f);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:34:0x008d, code lost:
        r5 = r9.f2618e + r9.f2621h;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:38:0x00ae, code lost:
        r5 = ((r9.f2618e + r9.f2621h) + r9.f2619f) - 50;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:42:0x00e1, code lost:
        if (r0 < 0) goto L_0x00fa;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:44:0x00e4, code lost:
        if ((r0 + 50) > r3) goto L_0x00fa;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:46:0x00e8, code lost:
        if (r5 < r1[0]) goto L_0x00fa;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:48:0x00ed, code lost:
        if ((r5 + 50) <= r1[1]) goto L_0x00f0;
     */
    /* JADX WARNING: Removed duplicated region for block: B:55:0x00fd  */
    /* JADX WARNING: Removed duplicated region for block: B:57:0x00ff  */
    /* renamed from: b */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private final int[] m3810b() {
        /*
            r9 = this;
            com.google.android.gms.internal.go r0 = com.google.android.gms.ads.internal.C0354ax.m1538e()
            android.app.Activity r1 = r9.f2625l
            int[] r0 = r0.mo2806b(r1)
            com.google.android.gms.internal.go r1 = com.google.android.gms.ads.internal.C0354ax.m1538e()
            android.app.Activity r2 = r9.f2625l
            int[] r1 = r1.mo2807c(r2)
            r2 = 0
            r3 = r0[r2]
            r4 = 1
            r0 = r0[r4]
            int r5 = r9.f2622i
            r6 = 2
            r7 = 50
            if (r5 < r7) goto L_0x00f5
            if (r5 <= r3) goto L_0x0025
            goto L_0x00f5
        L_0x0025:
            int r8 = r9.f2619f
            if (r8 < r7) goto L_0x00f2
            if (r8 <= r0) goto L_0x002d
            goto L_0x00f2
        L_0x002d:
            if (r8 != r0) goto L_0x0035
            if (r5 != r3) goto L_0x0035
            java.lang.String r0 = "Cannot resize to a full-screen ad."
            goto L_0x00f7
        L_0x0035:
            boolean r0 = r9.f2616c
            if (r0 == 0) goto L_0x00f0
            java.lang.String r0 = r9.f2615b
            r5 = -1
            int r8 = r0.hashCode()
            switch(r8) {
                case -1364013995: goto L_0x0076;
                case -1012429441: goto L_0x006c;
                case -655373719: goto L_0x0062;
                case 1163912186: goto L_0x0058;
                case 1288627767: goto L_0x004e;
                case 1755462605: goto L_0x0044;
                default: goto L_0x0043;
            }
        L_0x0043:
            goto L_0x0080
        L_0x0044:
            java.lang.String r8 = "top-center"
            boolean r0 = r0.equals(r8)
            if (r0 == 0) goto L_0x0080
            r0 = r4
            goto L_0x0081
        L_0x004e:
            java.lang.String r8 = "bottom-center"
            boolean r0 = r0.equals(r8)
            if (r0 == 0) goto L_0x0080
            r0 = 4
            goto L_0x0081
        L_0x0058:
            java.lang.String r8 = "bottom-right"
            boolean r0 = r0.equals(r8)
            if (r0 == 0) goto L_0x0080
            r0 = 5
            goto L_0x0081
        L_0x0062:
            java.lang.String r8 = "bottom-left"
            boolean r0 = r0.equals(r8)
            if (r0 == 0) goto L_0x0080
            r0 = 3
            goto L_0x0081
        L_0x006c:
            java.lang.String r8 = "top-left"
            boolean r0 = r0.equals(r8)
            if (r0 == 0) goto L_0x0080
            r0 = r2
            goto L_0x0081
        L_0x0076:
            java.lang.String r8 = "center"
            boolean r0 = r0.equals(r8)
            if (r0 == 0) goto L_0x0080
            r0 = r6
            goto L_0x0081
        L_0x0080:
            r0 = r5
        L_0x0081:
            switch(r0) {
                case 0: goto L_0x00db;
                case 1: goto L_0x00cf;
                case 2: goto L_0x00b8;
                case 3: goto L_0x00a9;
                case 4: goto L_0x009d;
                case 5: goto L_0x0093;
                default: goto L_0x0084;
            }
        L_0x0084:
            int r0 = r9.f2617d
            int r5 = r9.f2620g
            int r0 = r0 + r5
            int r5 = r9.f2622i
            int r0 = r0 + r5
            int r0 = r0 - r7
        L_0x008d:
            int r5 = r9.f2618e
            int r8 = r9.f2621h
            int r5 = r5 + r8
            goto L_0x00e1
        L_0x0093:
            int r0 = r9.f2617d
            int r5 = r9.f2620g
            int r0 = r0 + r5
            int r5 = r9.f2622i
            int r0 = r0 + r5
            int r0 = r0 - r7
            goto L_0x00ae
        L_0x009d:
            int r0 = r9.f2617d
            int r5 = r9.f2620g
            int r0 = r0 + r5
            int r5 = r9.f2622i
            int r5 = r5 / r6
            int r0 = r0 + r5
            int r0 = r0 + -25
            goto L_0x00ae
        L_0x00a9:
            int r0 = r9.f2617d
            int r5 = r9.f2620g
            int r0 = r0 + r5
        L_0x00ae:
            int r5 = r9.f2618e
            int r8 = r9.f2621h
            int r5 = r5 + r8
            int r8 = r9.f2619f
            int r5 = r5 + r8
            int r5 = r5 - r7
            goto L_0x00e1
        L_0x00b8:
            int r0 = r9.f2617d
            int r5 = r9.f2620g
            int r0 = r0 + r5
            int r5 = r9.f2622i
            int r5 = r5 / r6
            int r0 = r0 + r5
            int r0 = r0 + -25
            int r5 = r9.f2618e
            int r8 = r9.f2621h
            int r5 = r5 + r8
            int r8 = r9.f2619f
            int r8 = r8 / r6
            int r5 = r5 + r8
            int r5 = r5 + -25
            goto L_0x00e1
        L_0x00cf:
            int r0 = r9.f2617d
            int r5 = r9.f2620g
            int r0 = r0 + r5
            int r5 = r9.f2622i
            int r5 = r5 / r6
            int r0 = r0 + r5
            int r0 = r0 + -25
            goto L_0x008d
        L_0x00db:
            int r0 = r9.f2617d
            int r5 = r9.f2620g
            int r0 = r0 + r5
            goto L_0x008d
        L_0x00e1:
            if (r0 < 0) goto L_0x00fa
            int r0 = r0 + r7
            if (r0 > r3) goto L_0x00fa
            r0 = r1[r2]
            if (r5 < r0) goto L_0x00fa
            int r5 = r5 + r7
            r0 = r1[r4]
            if (r5 <= r0) goto L_0x00f0
            goto L_0x00fa
        L_0x00f0:
            r0 = r4
            goto L_0x00fb
        L_0x00f2:
            java.lang.String r0 = "Height is too small or too large."
            goto L_0x00f7
        L_0x00f5:
            java.lang.String r0 = "Width is too small or too large."
        L_0x00f7:
            com.google.android.gms.internal.C0759fe.m4734e(r0)
        L_0x00fa:
            r0 = r2
        L_0x00fb:
            if (r0 != 0) goto L_0x00ff
            r0 = 0
            return r0
        L_0x00ff:
            boolean r0 = r9.f2616c
            if (r0 == 0) goto L_0x0114
            int[] r0 = new int[r6]
            int r1 = r9.f2617d
            int r3 = r9.f2620g
            int r1 = r1 + r3
            r0[r2] = r1
            int r1 = r9.f2618e
            int r2 = r9.f2621h
            int r1 = r1 + r2
            r0[r4] = r1
            return r0
        L_0x0114:
            com.google.android.gms.internal.go r0 = com.google.android.gms.ads.internal.C0354ax.m1538e()
            android.app.Activity r1 = r9.f2625l
            int[] r0 = r0.mo2806b(r1)
            com.google.android.gms.internal.go r1 = com.google.android.gms.ads.internal.C0354ax.m1538e()
            android.app.Activity r3 = r9.f2625l
            int[] r1 = r1.mo2807c(r3)
            r0 = r0[r2]
            int r3 = r9.f2617d
            int r5 = r9.f2620g
            int r3 = r3 + r5
            int r5 = r9.f2618e
            int r7 = r9.f2621h
            int r5 = r5 + r7
            if (r3 >= 0) goto L_0x0138
            r0 = r2
            goto L_0x0141
        L_0x0138:
            int r7 = r9.f2622i
            int r8 = r3 + r7
            if (r8 <= r0) goto L_0x0140
            int r0 = r0 - r7
            goto L_0x0141
        L_0x0140:
            r0 = r3
        L_0x0141:
            r3 = r1[r2]
            if (r5 >= r3) goto L_0x0148
            r5 = r1[r2]
            goto L_0x0154
        L_0x0148:
            int r3 = r9.f2619f
            int r7 = r5 + r3
            r8 = r1[r4]
            if (r7 <= r8) goto L_0x0154
            r1 = r1[r4]
            int r5 = r1 - r3
        L_0x0154:
            int[] r1 = new int[r6]
            r1[r2] = r0
            r1[r4] = r5
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.aoj.m3810b():int[]");
    }

    /* renamed from: a */
    public final void mo2477a(int i, int i2) {
        this.f2617d = i;
        this.f2618e = i2;
    }

    /* renamed from: a */
    public final void mo2478a(int i, int i2, boolean z) {
        synchronized (this.f2623j) {
            this.f2617d = i;
            this.f2618e = i2;
            if (this.f2630q != null && z) {
                int[] b = m3810b();
                if (b != null) {
                    PopupWindow popupWindow = this.f2630q;
                    abj.m2380a();
                    int a = C0851ip.m4702a((Context) this.f2625l, b[0]);
                    abj.m2380a();
                    popupWindow.update(a, C0851ip.m4702a((Context) this.f2625l, b[1]), this.f2630q.getWidth(), this.f2630q.getHeight());
                    m3809b(b[0], b[1]);
                } else {
                    mo2480a(true);
                }
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:108:0x0246, code lost:
        r4.addRule(11);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:110:0x024d, code lost:
        r4.addRule(14);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:112:0x0254, code lost:
        r4.addRule(9);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:116:0x0266, code lost:
        r12.f2628o.setOnClickListener(new com.google.android.gms.internal.aok(r12));
        r12.f2628o.setContentDescription("Close button");
        r12.f2631r.addView(r12.f2628o, r4);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:118:?, code lost:
        r4 = r12.f2630q;
        r13 = r13.getDecorView();
        com.google.android.gms.internal.abj.m2380a();
        r5 = com.google.android.gms.internal.C0851ip.m4702a((android.content.Context) r12.f2625l, r3[0]);
        com.google.android.gms.internal.abj.m2380a();
        r4.showAtLocation(r13, 0, r5, com.google.android.gms.internal.C0851ip.m4702a((android.content.Context) r12.f2625l, r3[1]));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:120:?, code lost:
        r13 = r3[0];
        r4 = r3[1];
     */
    /* JADX WARNING: Code restructure failed: missing block: B:121:0x02a3, code lost:
        if (r12.f2629p == null) goto L_0x02ae;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:122:0x02a5, code lost:
        r12.f2629p.mo1435a(r13, r4, r12.f2622i, r12.f2619f);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:123:0x02ae, code lost:
        r12.f2624k.mo2934a(new com.google.android.gms.internal.aay((android.content.Context) r12.f2625l, new com.google.android.gms.ads.C0321d(r12.f2622i, r12.f2619f)));
        m3809b(r3[0], r3[1]);
        mo2499c("resized");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:125:0x02d0, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:126:0x02d1, code lost:
        r13 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:127:0x02d2, code lost:
        r1 = "Cannot show popup window: ";
        r13 = java.lang.String.valueOf(r13.getMessage());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:128:0x02e0, code lost:
        if (r13.length() != 0) goto L_0x02e2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:129:0x02e2, code lost:
        r13 = r1.concat(r13);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:130:0x02e7, code lost:
        r13 = new java.lang.String(r1);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:131:0x02ec, code lost:
        mo2496a(r13);
        r13 = r12.f2631r;
        r1 = r12.f2624k;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:132:0x02f3, code lost:
        if (r1 != null) goto L_0x02f5;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:133:0x02f5, code lost:
        r13.removeView((android.view.View) r1);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:134:0x02fc, code lost:
        if (r12.f2632s != null) goto L_0x02fe;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:135:0x02fe, code lost:
        r12.f2632s.removeView(r12.f2627n);
        r13 = r12.f2632s;
        r1 = r12.f2624k;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:136:0x0309, code lost:
        if (r1 != null) goto L_0x030b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:137:0x030b, code lost:
        r13.addView((android.view.View) r1);
        r12.f2624k.mo2934a(r12.f2626m);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:138:0x0318, code lost:
        throw null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:140:0x031a, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:141:0x031b, code lost:
        throw null;
     */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo2479a(java.util.Map<java.lang.String, java.lang.String> r13) {
        /*
            r12 = this;
            java.lang.Object r0 = r12.f2623j
            monitor-enter(r0)
            android.app.Activity r1 = r12.f2625l     // Catch:{ all -> 0x032d }
            if (r1 != 0) goto L_0x000e
            java.lang.String r13 = "Not an activity context. Cannot resize."
            r12.mo2496a(r13)     // Catch:{ all -> 0x032d }
            monitor-exit(r0)     // Catch:{ all -> 0x032d }
            return
        L_0x000e:
            com.google.android.gms.internal.jw r1 = r12.f2624k     // Catch:{ all -> 0x032d }
            com.google.android.gms.internal.aay r1 = r1.mo2963l()     // Catch:{ all -> 0x032d }
            if (r1 != 0) goto L_0x001d
            java.lang.String r13 = "Webview is not yet available, size is not set."
            r12.mo2496a(r13)     // Catch:{ all -> 0x032d }
            monitor-exit(r0)     // Catch:{ all -> 0x032d }
            return
        L_0x001d:
            com.google.android.gms.internal.jw r1 = r12.f2624k     // Catch:{ all -> 0x032d }
            com.google.android.gms.internal.aay r1 = r1.mo2963l()     // Catch:{ all -> 0x032d }
            boolean r1 = r1.f1653d     // Catch:{ all -> 0x032d }
            if (r1 == 0) goto L_0x002e
            java.lang.String r13 = "Is interstitial. Cannot resize an interstitial."
            r12.mo2496a(r13)     // Catch:{ all -> 0x032d }
            monitor-exit(r0)     // Catch:{ all -> 0x032d }
            return
        L_0x002e:
            com.google.android.gms.internal.jw r1 = r12.f2624k     // Catch:{ all -> 0x032d }
            boolean r1 = r1.mo2974q()     // Catch:{ all -> 0x032d }
            if (r1 == 0) goto L_0x003d
            java.lang.String r13 = "Cannot resize an expanded banner."
            r12.mo2496a(r13)     // Catch:{ all -> 0x032d }
            monitor-exit(r0)     // Catch:{ all -> 0x032d }
            return
        L_0x003d:
            java.lang.String r1 = "width"
            java.lang.Object r1 = r13.get(r1)     // Catch:{ all -> 0x032d }
            java.lang.CharSequence r1 = (java.lang.CharSequence) r1     // Catch:{ all -> 0x032d }
            boolean r1 = android.text.TextUtils.isEmpty(r1)     // Catch:{ all -> 0x032d }
            if (r1 != 0) goto L_0x005c
            com.google.android.gms.ads.internal.C0354ax.m1538e()     // Catch:{ all -> 0x032d }
            java.lang.String r1 = "width"
            java.lang.Object r1 = r13.get(r1)     // Catch:{ all -> 0x032d }
            java.lang.String r1 = (java.lang.String) r1     // Catch:{ all -> 0x032d }
            int r1 = com.google.android.gms.internal.C0796go.m4515b(r1)     // Catch:{ all -> 0x032d }
            r12.f2622i = r1     // Catch:{ all -> 0x032d }
        L_0x005c:
            java.lang.String r1 = "height"
            java.lang.Object r1 = r13.get(r1)     // Catch:{ all -> 0x032d }
            java.lang.CharSequence r1 = (java.lang.CharSequence) r1     // Catch:{ all -> 0x032d }
            boolean r1 = android.text.TextUtils.isEmpty(r1)     // Catch:{ all -> 0x032d }
            if (r1 != 0) goto L_0x007b
            com.google.android.gms.ads.internal.C0354ax.m1538e()     // Catch:{ all -> 0x032d }
            java.lang.String r1 = "height"
            java.lang.Object r1 = r13.get(r1)     // Catch:{ all -> 0x032d }
            java.lang.String r1 = (java.lang.String) r1     // Catch:{ all -> 0x032d }
            int r1 = com.google.android.gms.internal.C0796go.m4515b(r1)     // Catch:{ all -> 0x032d }
            r12.f2619f = r1     // Catch:{ all -> 0x032d }
        L_0x007b:
            java.lang.String r1 = "offsetX"
            java.lang.Object r1 = r13.get(r1)     // Catch:{ all -> 0x032d }
            java.lang.CharSequence r1 = (java.lang.CharSequence) r1     // Catch:{ all -> 0x032d }
            boolean r1 = android.text.TextUtils.isEmpty(r1)     // Catch:{ all -> 0x032d }
            if (r1 != 0) goto L_0x009a
            com.google.android.gms.ads.internal.C0354ax.m1538e()     // Catch:{ all -> 0x032d }
            java.lang.String r1 = "offsetX"
            java.lang.Object r1 = r13.get(r1)     // Catch:{ all -> 0x032d }
            java.lang.String r1 = (java.lang.String) r1     // Catch:{ all -> 0x032d }
            int r1 = com.google.android.gms.internal.C0796go.m4515b(r1)     // Catch:{ all -> 0x032d }
            r12.f2620g = r1     // Catch:{ all -> 0x032d }
        L_0x009a:
            java.lang.String r1 = "offsetY"
            java.lang.Object r1 = r13.get(r1)     // Catch:{ all -> 0x032d }
            java.lang.CharSequence r1 = (java.lang.CharSequence) r1     // Catch:{ all -> 0x032d }
            boolean r1 = android.text.TextUtils.isEmpty(r1)     // Catch:{ all -> 0x032d }
            if (r1 != 0) goto L_0x00b9
            com.google.android.gms.ads.internal.C0354ax.m1538e()     // Catch:{ all -> 0x032d }
            java.lang.String r1 = "offsetY"
            java.lang.Object r1 = r13.get(r1)     // Catch:{ all -> 0x032d }
            java.lang.String r1 = (java.lang.String) r1     // Catch:{ all -> 0x032d }
            int r1 = com.google.android.gms.internal.C0796go.m4515b(r1)     // Catch:{ all -> 0x032d }
            r12.f2621h = r1     // Catch:{ all -> 0x032d }
        L_0x00b9:
            java.lang.String r1 = "allowOffscreen"
            java.lang.Object r1 = r13.get(r1)     // Catch:{ all -> 0x032d }
            java.lang.CharSequence r1 = (java.lang.CharSequence) r1     // Catch:{ all -> 0x032d }
            boolean r1 = android.text.TextUtils.isEmpty(r1)     // Catch:{ all -> 0x032d }
            if (r1 != 0) goto L_0x00d5
            java.lang.String r1 = "allowOffscreen"
            java.lang.Object r1 = r13.get(r1)     // Catch:{ all -> 0x032d }
            java.lang.String r1 = (java.lang.String) r1     // Catch:{ all -> 0x032d }
            boolean r1 = java.lang.Boolean.parseBoolean(r1)     // Catch:{ all -> 0x032d }
            r12.f2616c = r1     // Catch:{ all -> 0x032d }
        L_0x00d5:
            java.lang.String r1 = "customClosePosition"
            java.lang.Object r13 = r13.get(r1)     // Catch:{ all -> 0x032d }
            java.lang.String r13 = (java.lang.String) r13     // Catch:{ all -> 0x032d }
            boolean r1 = android.text.TextUtils.isEmpty(r13)     // Catch:{ all -> 0x032d }
            if (r1 != 0) goto L_0x00e5
            r12.f2615b = r13     // Catch:{ all -> 0x032d }
        L_0x00e5:
            int r13 = r12.f2622i     // Catch:{ all -> 0x032d }
            r1 = 1
            r2 = 0
            if (r13 < 0) goto L_0x00f1
            int r13 = r12.f2619f     // Catch:{ all -> 0x032d }
            if (r13 < 0) goto L_0x00f1
            r13 = r1
            goto L_0x00f2
        L_0x00f1:
            r13 = r2
        L_0x00f2:
            if (r13 != 0) goto L_0x00fb
            java.lang.String r13 = "Invalid width and height options. Cannot resize."
            r12.mo2496a(r13)     // Catch:{ all -> 0x032d }
            monitor-exit(r0)     // Catch:{ all -> 0x032d }
            return
        L_0x00fb:
            android.app.Activity r13 = r12.f2625l     // Catch:{ all -> 0x032d }
            android.view.Window r13 = r13.getWindow()     // Catch:{ all -> 0x032d }
            if (r13 == 0) goto L_0x0326
            android.view.View r3 = r13.getDecorView()     // Catch:{ all -> 0x032d }
            if (r3 != 0) goto L_0x010b
            goto L_0x0326
        L_0x010b:
            int[] r3 = r12.m3810b()     // Catch:{ all -> 0x032d }
            if (r3 != 0) goto L_0x0118
            java.lang.String r13 = "Resize location out of screen or close button is not visible."
            r12.mo2496a(r13)     // Catch:{ all -> 0x032d }
            monitor-exit(r0)     // Catch:{ all -> 0x032d }
            return
        L_0x0118:
            com.google.android.gms.internal.abj.m2380a()     // Catch:{ all -> 0x032d }
            android.app.Activity r4 = r12.f2625l     // Catch:{ all -> 0x032d }
            int r5 = r12.f2622i     // Catch:{ all -> 0x032d }
            int r4 = com.google.android.gms.internal.C0851ip.m4702a(r4, r5)     // Catch:{ all -> 0x032d }
            com.google.android.gms.internal.abj.m2380a()     // Catch:{ all -> 0x032d }
            android.app.Activity r5 = r12.f2625l     // Catch:{ all -> 0x032d }
            int r6 = r12.f2619f     // Catch:{ all -> 0x032d }
            int r5 = com.google.android.gms.internal.C0851ip.m4702a(r5, r6)     // Catch:{ all -> 0x032d }
            com.google.android.gms.internal.jw r6 = r12.f2624k     // Catch:{ all -> 0x032d }
            r7 = 0
            if (r6 == 0) goto L_0x0325
            android.view.View r6 = (android.view.View) r6     // Catch:{ all -> 0x032d }
            android.view.ViewParent r6 = r6.getParent()     // Catch:{ all -> 0x032d }
            if (r6 == 0) goto L_0x031e
            boolean r8 = r6 instanceof android.view.ViewGroup     // Catch:{ all -> 0x032d }
            if (r8 == 0) goto L_0x031e
            r8 = r6
            android.view.ViewGroup r8 = (android.view.ViewGroup) r8     // Catch:{ all -> 0x032d }
            com.google.android.gms.internal.jw r9 = r12.f2624k     // Catch:{ all -> 0x032d }
            if (r9 == 0) goto L_0x031d
            android.view.View r9 = (android.view.View) r9     // Catch:{ all -> 0x032d }
            r8.removeView(r9)     // Catch:{ all -> 0x032d }
            android.widget.PopupWindow r8 = r12.f2630q     // Catch:{ all -> 0x032d }
            if (r8 != 0) goto L_0x017f
            android.view.ViewGroup r6 = (android.view.ViewGroup) r6     // Catch:{ all -> 0x032d }
            r12.f2632s = r6     // Catch:{ all -> 0x032d }
            com.google.android.gms.ads.internal.C0354ax.m1538e()     // Catch:{ all -> 0x032d }
            com.google.android.gms.internal.jw r6 = r12.f2624k     // Catch:{ all -> 0x032d }
            if (r6 == 0) goto L_0x017e
            android.view.View r6 = (android.view.View) r6     // Catch:{ all -> 0x032d }
            android.graphics.Bitmap r6 = com.google.android.gms.internal.C0796go.m4482a(r6)     // Catch:{ all -> 0x032d }
            android.widget.ImageView r8 = new android.widget.ImageView     // Catch:{ all -> 0x032d }
            android.app.Activity r9 = r12.f2625l     // Catch:{ all -> 0x032d }
            r8.<init>(r9)     // Catch:{ all -> 0x032d }
            r12.f2627n = r8     // Catch:{ all -> 0x032d }
            android.widget.ImageView r8 = r12.f2627n     // Catch:{ all -> 0x032d }
            r8.setImageBitmap(r6)     // Catch:{ all -> 0x032d }
            com.google.android.gms.internal.jw r6 = r12.f2624k     // Catch:{ all -> 0x032d }
            com.google.android.gms.internal.aay r6 = r6.mo2963l()     // Catch:{ all -> 0x032d }
            r12.f2626m = r6     // Catch:{ all -> 0x032d }
            android.view.ViewGroup r6 = r12.f2632s     // Catch:{ all -> 0x032d }
            android.widget.ImageView r8 = r12.f2627n     // Catch:{ all -> 0x032d }
            r6.addView(r8)     // Catch:{ all -> 0x032d }
            goto L_0x0184
        L_0x017e:
            throw r7     // Catch:{ all -> 0x032d }
        L_0x017f:
            android.widget.PopupWindow r6 = r12.f2630q     // Catch:{ all -> 0x032d }
            r6.dismiss()     // Catch:{ all -> 0x032d }
        L_0x0184:
            android.widget.RelativeLayout r6 = new android.widget.RelativeLayout     // Catch:{ all -> 0x032d }
            android.app.Activity r8 = r12.f2625l     // Catch:{ all -> 0x032d }
            r6.<init>(r8)     // Catch:{ all -> 0x032d }
            r12.f2631r = r6     // Catch:{ all -> 0x032d }
            android.widget.RelativeLayout r6 = r12.f2631r     // Catch:{ all -> 0x032d }
            r6.setBackgroundColor(r2)     // Catch:{ all -> 0x032d }
            android.widget.RelativeLayout r6 = r12.f2631r     // Catch:{ all -> 0x032d }
            android.view.ViewGroup$LayoutParams r8 = new android.view.ViewGroup$LayoutParams     // Catch:{ all -> 0x032d }
            r8.<init>(r4, r5)     // Catch:{ all -> 0x032d }
            r6.setLayoutParams(r8)     // Catch:{ all -> 0x032d }
            com.google.android.gms.ads.internal.C0354ax.m1538e()     // Catch:{ all -> 0x032d }
            android.widget.RelativeLayout r6 = r12.f2631r     // Catch:{ all -> 0x032d }
            android.widget.PopupWindow r4 = com.google.android.gms.internal.C0796go.m4486a(r6, r4, r5, r2)     // Catch:{ all -> 0x032d }
            r12.f2630q = r4     // Catch:{ all -> 0x032d }
            android.widget.PopupWindow r4 = r12.f2630q     // Catch:{ all -> 0x032d }
            r4.setOutsideTouchable(r1)     // Catch:{ all -> 0x032d }
            android.widget.PopupWindow r4 = r12.f2630q     // Catch:{ all -> 0x032d }
            r4.setTouchable(r1)     // Catch:{ all -> 0x032d }
            android.widget.PopupWindow r4 = r12.f2630q     // Catch:{ all -> 0x032d }
            boolean r5 = r12.f2616c     // Catch:{ all -> 0x032d }
            if (r5 != 0) goto L_0x01b9
            r5 = r1
            goto L_0x01ba
        L_0x01b9:
            r5 = r2
        L_0x01ba:
            r4.setClippingEnabled(r5)     // Catch:{ all -> 0x032d }
            android.widget.RelativeLayout r4 = r12.f2631r     // Catch:{ all -> 0x032d }
            com.google.android.gms.internal.jw r5 = r12.f2624k     // Catch:{ all -> 0x032d }
            if (r5 == 0) goto L_0x031c
            android.view.View r5 = (android.view.View) r5     // Catch:{ all -> 0x032d }
            r6 = -1
            r4.addView(r5, r6, r6)     // Catch:{ all -> 0x032d }
            android.widget.LinearLayout r4 = new android.widget.LinearLayout     // Catch:{ all -> 0x032d }
            android.app.Activity r5 = r12.f2625l     // Catch:{ all -> 0x032d }
            r4.<init>(r5)     // Catch:{ all -> 0x032d }
            r12.f2628o = r4     // Catch:{ all -> 0x032d }
            android.widget.RelativeLayout$LayoutParams r4 = new android.widget.RelativeLayout$LayoutParams     // Catch:{ all -> 0x032d }
            com.google.android.gms.internal.abj.m2380a()     // Catch:{ all -> 0x032d }
            android.app.Activity r5 = r12.f2625l     // Catch:{ all -> 0x032d }
            r8 = 50
            int r5 = com.google.android.gms.internal.C0851ip.m4702a(r5, r8)     // Catch:{ all -> 0x032d }
            com.google.android.gms.internal.abj.m2380a()     // Catch:{ all -> 0x032d }
            android.app.Activity r9 = r12.f2625l     // Catch:{ all -> 0x032d }
            int r8 = com.google.android.gms.internal.C0851ip.m4702a(r9, r8)     // Catch:{ all -> 0x032d }
            r4.<init>(r5, r8)     // Catch:{ all -> 0x032d }
            java.lang.String r5 = r12.f2615b     // Catch:{ all -> 0x032d }
            int r8 = r5.hashCode()     // Catch:{ all -> 0x032d }
            switch(r8) {
                case -1364013995: goto L_0x0227;
                case -1012429441: goto L_0x021d;
                case -655373719: goto L_0x0213;
                case 1163912186: goto L_0x0209;
                case 1288627767: goto L_0x01ff;
                case 1755462605: goto L_0x01f5;
                default: goto L_0x01f4;
            }     // Catch:{ all -> 0x032d }
        L_0x01f4:
            goto L_0x0231
        L_0x01f5:
            java.lang.String r8 = "top-center"
            boolean r5 = r5.equals(r8)     // Catch:{ all -> 0x032d }
            if (r5 == 0) goto L_0x0231
            r5 = r1
            goto L_0x0232
        L_0x01ff:
            java.lang.String r8 = "bottom-center"
            boolean r5 = r5.equals(r8)     // Catch:{ all -> 0x032d }
            if (r5 == 0) goto L_0x0231
            r5 = 4
            goto L_0x0232
        L_0x0209:
            java.lang.String r8 = "bottom-right"
            boolean r5 = r5.equals(r8)     // Catch:{ all -> 0x032d }
            if (r5 == 0) goto L_0x0231
            r5 = 5
            goto L_0x0232
        L_0x0213:
            java.lang.String r8 = "bottom-left"
            boolean r5 = r5.equals(r8)     // Catch:{ all -> 0x032d }
            if (r5 == 0) goto L_0x0231
            r5 = 3
            goto L_0x0232
        L_0x021d:
            java.lang.String r8 = "top-left"
            boolean r5 = r5.equals(r8)     // Catch:{ all -> 0x032d }
            if (r5 == 0) goto L_0x0231
            r5 = r2
            goto L_0x0232
        L_0x0227:
            java.lang.String r8 = "center"
            boolean r5 = r5.equals(r8)     // Catch:{ all -> 0x032d }
            if (r5 == 0) goto L_0x0231
            r5 = 2
            goto L_0x0232
        L_0x0231:
            r5 = r6
        L_0x0232:
            r6 = 14
            r8 = 9
            r9 = 11
            r10 = 12
            r11 = 10
            switch(r5) {
                case 0: goto L_0x0262;
                case 1: goto L_0x025e;
                case 2: goto L_0x0258;
                case 3: goto L_0x0251;
                case 4: goto L_0x024a;
                case 5: goto L_0x0243;
                default: goto L_0x023f;
            }     // Catch:{ all -> 0x032d }
        L_0x023f:
            r4.addRule(r11)     // Catch:{ all -> 0x032d }
            goto L_0x0246
        L_0x0243:
            r4.addRule(r10)     // Catch:{ all -> 0x032d }
        L_0x0246:
            r4.addRule(r9)     // Catch:{ all -> 0x032d }
            goto L_0x0266
        L_0x024a:
            r4.addRule(r10)     // Catch:{ all -> 0x032d }
        L_0x024d:
            r4.addRule(r6)     // Catch:{ all -> 0x032d }
            goto L_0x0266
        L_0x0251:
            r4.addRule(r10)     // Catch:{ all -> 0x032d }
        L_0x0254:
            r4.addRule(r8)     // Catch:{ all -> 0x032d }
            goto L_0x0266
        L_0x0258:
            r5 = 13
            r4.addRule(r5)     // Catch:{ all -> 0x032d }
            goto L_0x0266
        L_0x025e:
            r4.addRule(r11)     // Catch:{ all -> 0x032d }
            goto L_0x024d
        L_0x0262:
            r4.addRule(r11)     // Catch:{ all -> 0x032d }
            goto L_0x0254
        L_0x0266:
            android.widget.LinearLayout r5 = r12.f2628o     // Catch:{ all -> 0x032d }
            com.google.android.gms.internal.aok r6 = new com.google.android.gms.internal.aok     // Catch:{ all -> 0x032d }
            r6.<init>(r12)     // Catch:{ all -> 0x032d }
            r5.setOnClickListener(r6)     // Catch:{ all -> 0x032d }
            android.widget.LinearLayout r5 = r12.f2628o     // Catch:{ all -> 0x032d }
            java.lang.String r6 = "Close button"
            r5.setContentDescription(r6)     // Catch:{ all -> 0x032d }
            android.widget.RelativeLayout r5 = r12.f2631r     // Catch:{ all -> 0x032d }
            android.widget.LinearLayout r6 = r12.f2628o     // Catch:{ all -> 0x032d }
            r5.addView(r6, r4)     // Catch:{ all -> 0x032d }
            android.widget.PopupWindow r4 = r12.f2630q     // Catch:{ RuntimeException -> 0x02d1 }
            android.view.View r13 = r13.getDecorView()     // Catch:{ RuntimeException -> 0x02d1 }
            com.google.android.gms.internal.abj.m2380a()     // Catch:{ RuntimeException -> 0x02d1 }
            android.app.Activity r5 = r12.f2625l     // Catch:{ RuntimeException -> 0x02d1 }
            r6 = r3[r2]     // Catch:{ RuntimeException -> 0x02d1 }
            int r5 = com.google.android.gms.internal.C0851ip.m4702a(r5, r6)     // Catch:{ RuntimeException -> 0x02d1 }
            com.google.android.gms.internal.abj.m2380a()     // Catch:{ RuntimeException -> 0x02d1 }
            android.app.Activity r6 = r12.f2625l     // Catch:{ RuntimeException -> 0x02d1 }
            r8 = r3[r1]     // Catch:{ RuntimeException -> 0x02d1 }
            int r6 = com.google.android.gms.internal.C0851ip.m4702a(r6, r8)     // Catch:{ RuntimeException -> 0x02d1 }
            r4.showAtLocation(r13, r2, r5, r6)     // Catch:{ RuntimeException -> 0x02d1 }
            r13 = r3[r2]     // Catch:{ all -> 0x032d }
            r4 = r3[r1]     // Catch:{ all -> 0x032d }
            com.google.android.gms.internal.aou r5 = r12.f2629p     // Catch:{ all -> 0x032d }
            if (r5 == 0) goto L_0x02ae
            com.google.android.gms.internal.aou r5 = r12.f2629p     // Catch:{ all -> 0x032d }
            int r6 = r12.f2622i     // Catch:{ all -> 0x032d }
            int r7 = r12.f2619f     // Catch:{ all -> 0x032d }
            r5.mo1435a(r13, r4, r6, r7)     // Catch:{ all -> 0x032d }
        L_0x02ae:
            com.google.android.gms.internal.jw r13 = r12.f2624k     // Catch:{ all -> 0x032d }
            com.google.android.gms.internal.aay r4 = new com.google.android.gms.internal.aay     // Catch:{ all -> 0x032d }
            android.app.Activity r5 = r12.f2625l     // Catch:{ all -> 0x032d }
            com.google.android.gms.ads.d r6 = new com.google.android.gms.ads.d     // Catch:{ all -> 0x032d }
            int r7 = r12.f2622i     // Catch:{ all -> 0x032d }
            int r8 = r12.f2619f     // Catch:{ all -> 0x032d }
            r6.<init>(r7, r8)     // Catch:{ all -> 0x032d }
            r4.<init>(r5, r6)     // Catch:{ all -> 0x032d }
            r13.mo2934a(r4)     // Catch:{ all -> 0x032d }
            r13 = r3[r2]     // Catch:{ all -> 0x032d }
            r1 = r3[r1]     // Catch:{ all -> 0x032d }
            r12.m3809b(r13, r1)     // Catch:{ all -> 0x032d }
            java.lang.String r13 = "resized"
            r12.mo2499c(r13)     // Catch:{ all -> 0x032d }
            monitor-exit(r0)     // Catch:{ all -> 0x032d }
            return
        L_0x02d1:
            r13 = move-exception
            java.lang.String r1 = "Cannot show popup window: "
            java.lang.String r13 = r13.getMessage()     // Catch:{ all -> 0x032d }
            java.lang.String r13 = java.lang.String.valueOf(r13)     // Catch:{ all -> 0x032d }
            int r2 = r13.length()     // Catch:{ all -> 0x032d }
            if (r2 == 0) goto L_0x02e7
            java.lang.String r13 = r1.concat(r13)     // Catch:{ all -> 0x032d }
            goto L_0x02ec
        L_0x02e7:
            java.lang.String r13 = new java.lang.String     // Catch:{ all -> 0x032d }
            r13.<init>(r1)     // Catch:{ all -> 0x032d }
        L_0x02ec:
            r12.mo2496a(r13)     // Catch:{ all -> 0x032d }
            android.widget.RelativeLayout r13 = r12.f2631r     // Catch:{ all -> 0x032d }
            com.google.android.gms.internal.jw r1 = r12.f2624k     // Catch:{ all -> 0x032d }
            if (r1 == 0) goto L_0x031b
            android.view.View r1 = (android.view.View) r1     // Catch:{ all -> 0x032d }
            r13.removeView(r1)     // Catch:{ all -> 0x032d }
            android.view.ViewGroup r13 = r12.f2632s     // Catch:{ all -> 0x032d }
            if (r13 == 0) goto L_0x0319
            android.view.ViewGroup r13 = r12.f2632s     // Catch:{ all -> 0x032d }
            android.widget.ImageView r1 = r12.f2627n     // Catch:{ all -> 0x032d }
            r13.removeView(r1)     // Catch:{ all -> 0x032d }
            android.view.ViewGroup r13 = r12.f2632s     // Catch:{ all -> 0x032d }
            com.google.android.gms.internal.jw r1 = r12.f2624k     // Catch:{ all -> 0x032d }
            if (r1 == 0) goto L_0x0318
            android.view.View r1 = (android.view.View) r1     // Catch:{ all -> 0x032d }
            r13.addView(r1)     // Catch:{ all -> 0x032d }
            com.google.android.gms.internal.jw r13 = r12.f2624k     // Catch:{ all -> 0x032d }
            com.google.android.gms.internal.aay r1 = r12.f2626m     // Catch:{ all -> 0x032d }
            r13.mo2934a(r1)     // Catch:{ all -> 0x032d }
            goto L_0x0319
        L_0x0318:
            throw r7     // Catch:{ all -> 0x032d }
        L_0x0319:
            monitor-exit(r0)     // Catch:{ all -> 0x032d }
            return
        L_0x031b:
            throw r7     // Catch:{ all -> 0x032d }
        L_0x031c:
            throw r7     // Catch:{ all -> 0x032d }
        L_0x031d:
            throw r7     // Catch:{ all -> 0x032d }
        L_0x031e:
            java.lang.String r13 = "Webview is detached, probably in the middle of a resize or expand."
            r12.mo2496a(r13)     // Catch:{ all -> 0x032d }
            monitor-exit(r0)     // Catch:{ all -> 0x032d }
            return
        L_0x0325:
            throw r7     // Catch:{ all -> 0x032d }
        L_0x0326:
            java.lang.String r13 = "Activity context is not ready, cannot get window or decor view."
            r12.mo2496a(r13)     // Catch:{ all -> 0x032d }
            monitor-exit(r0)     // Catch:{ all -> 0x032d }
            return
        L_0x032d:
            r13 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x032d }
            throw r13
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.aoj.mo2479a(java.util.Map):void");
    }

    /* renamed from: a */
    public final void mo2480a(boolean z) {
        synchronized (this.f2623j) {
            if (this.f2630q != null) {
                this.f2630q.dismiss();
                RelativeLayout relativeLayout = this.f2631r;
                C0885jw jwVar = this.f2624k;
                if (jwVar != null) {
                    relativeLayout.removeView((View) jwVar);
                    if (this.f2632s != null) {
                        this.f2632s.removeView(this.f2627n);
                        ViewGroup viewGroup = this.f2632s;
                        C0885jw jwVar2 = this.f2624k;
                        if (jwVar2 != null) {
                            viewGroup.addView((View) jwVar2);
                            this.f2624k.mo2934a(this.f2626m);
                        } else {
                            throw null;
                        }
                    }
                    if (z) {
                        mo2499c("default");
                        if (this.f2629p != null) {
                            this.f2629p.mo1433F();
                        }
                    }
                    this.f2630q = null;
                    this.f2631r = null;
                    this.f2632s = null;
                    this.f2628o = null;
                } else {
                    throw null;
                }
            }
        }
    }

    /* renamed from: a */
    public final boolean mo2481a() {
        boolean z;
        synchronized (this.f2623j) {
            z = this.f2630q != null;
        }
        return z;
    }
}
