package com.google.android.gms.internal;

import org.json.JSONException;
import org.json.JSONObject;

@arm
public final class aop {

    /* renamed from: a */
    private final boolean f2643a;

    /* renamed from: b */
    private final boolean f2644b;

    /* renamed from: c */
    private final boolean f2645c;

    /* renamed from: d */
    private final boolean f2646d;

    /* renamed from: e */
    private final boolean f2647e;

    private aop(aor aor) {
        this.f2643a = aor.f2648a;
        this.f2644b = aor.f2649b;
        this.f2645c = aor.f2650c;
        this.f2646d = aor.f2651d;
        this.f2647e = aor.f2652e;
    }

    /* renamed from: a */
    public final JSONObject mo2487a() {
        try {
            return new JSONObject().put("sms", this.f2643a).put("tel", this.f2644b).put("calendar", this.f2645c).put("storePicture", this.f2646d).put("inlineVideo", this.f2647e);
        } catch (JSONException e) {
            C0759fe.m4730b("Error occured while obtaining the MRAID capabilities.", e);
            return null;
        }
    }
}
