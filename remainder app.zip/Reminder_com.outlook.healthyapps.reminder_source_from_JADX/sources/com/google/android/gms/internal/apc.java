package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;

@arm
public final class apc implements apd {
    /* renamed from: a */
    public final C0865jc<Bundle> mo2506a(Context context) {
        return C0860iy.m4737a(new Bundle());
    }
}
