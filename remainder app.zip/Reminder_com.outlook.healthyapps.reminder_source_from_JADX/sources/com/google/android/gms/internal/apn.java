package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.ads.internal.C0354ax;
import com.google.android.gms.common.internal.C0557t;
import java.util.concurrent.atomic.AtomicBoolean;

@arm
public abstract class apn implements C0813he<Void>, C0891kb {

    /* renamed from: a */
    protected final Context f2668a;

    /* renamed from: b */
    protected final C0885jw f2669b;

    /* renamed from: c */
    protected C1135r f2670c;

    /* renamed from: d */
    private apu f2671d;

    /* renamed from: e */
    private C0744eq f2672e;

    /* renamed from: f */
    private Runnable f2673f;

    /* renamed from: g */
    private Object f2674g = new Object();
    /* access modifiers changed from: private */

    /* renamed from: h */
    public AtomicBoolean f2675h = new AtomicBoolean(true);

    protected apn(Context context, C0744eq eqVar, C0885jw jwVar, apu apu) {
        this.f2668a = context;
        this.f2672e = eqVar;
        this.f2670c = this.f2672e.f3177b;
        this.f2669b = jwVar;
        this.f2671d = apu;
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public abstract void mo2510a();

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public void mo2511a(int i) {
        int i2 = i;
        if (i2 != -2) {
            this.f2670c = new C1135r(i2, this.f2670c.f4447j);
        }
        this.f2669b.mo2947d();
        apu apu = this.f2671d;
        C0970n nVar = this.f2672e.f3176a;
        C0743ep epVar = r1;
        apu apu2 = apu;
        C0743ep epVar2 = new C0743ep(nVar.f3996c, this.f2669b, this.f2670c.f4440c, i, this.f2670c.f4442e, this.f2670c.f4446i, this.f2670c.f4448k, this.f2670c.f4447j, nVar.f4002i, this.f2670c.f4444g, null, null, null, null, null, this.f2670c.f4445h, this.f2672e.f3179d, this.f2670c.f4443f, this.f2672e.f3181f, this.f2670c.f4450m, this.f2670c.f4451n, this.f2672e.f3183h, null, this.f2670c.f4419A, this.f2670c.f4420B, this.f2670c.f4421C, this.f2670c.f4422D, this.f2670c.f4423E, null, this.f2670c.f4426H, this.f2670c.f4430L, this.f2672e.f3184i, this.f2672e.f3177b.f4433O);
        apu2.mo1307b(epVar);
    }

    /* renamed from: a */
    public final void mo1511a(C0885jw jwVar, boolean z) {
        C0759fe.m4729b("WebView finished loading.");
        int i = 0;
        if (this.f2675h.getAndSet(false)) {
            if (z) {
                i = -2;
            }
            mo2511a(i);
            C0796go.f3327a.removeCallbacks(this.f2673f);
        }
    }

    /* renamed from: c */
    public void mo2512c() {
        if (this.f2675h.getAndSet(false)) {
            this.f2669b.stopLoading();
            C0354ax.m1540g();
            C0801gt.m4561a(this.f2669b);
            mo2511a(-1);
            C0796go.f3327a.removeCallbacks(this.f2673f);
        }
    }

    /* renamed from: d */
    public final /* synthetic */ Object mo2513d() {
        C0557t.m2153b("Webview render task needs to be called on UI thread.");
        this.f2673f = new apo(this);
        C0796go.f3327a.postDelayed(this.f2673f, ((Long) C0354ax.m1551r().mo2079a(ael.f1921bn)).longValue());
        mo2510a();
        return null;
    }
}
