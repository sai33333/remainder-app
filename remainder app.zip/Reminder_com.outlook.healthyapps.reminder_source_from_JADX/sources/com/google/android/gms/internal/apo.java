package com.google.android.gms.internal;

final class apo implements Runnable {

    /* renamed from: a */
    private /* synthetic */ apn f2676a;

    apo(apn apn) {
        this.f2676a = apn;
    }

    public final void run() {
        if (this.f2676a.f2675h.get()) {
            C0759fe.m4731c("Timed out waiting for WebView to finish loading.");
            this.f2676a.mo2512c();
        }
    }
}
