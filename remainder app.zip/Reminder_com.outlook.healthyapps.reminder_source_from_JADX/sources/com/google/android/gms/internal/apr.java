package com.google.android.gms.internal;

final class apr implements Runnable {

    /* renamed from: a */
    private /* synthetic */ C0743ep f2684a;

    /* renamed from: b */
    private /* synthetic */ C0635app f2685b;

    apr(C0635app app2, C0743ep epVar) {
        this.f2685b = app2;
        this.f2684a = epVar;
    }

    public final void run() {
        synchronized (this.f2685b.f2679c) {
            C0635app app2 = this.f2685b;
            app2.f2677a.mo1307b(this.f2684a);
        }
    }
}
