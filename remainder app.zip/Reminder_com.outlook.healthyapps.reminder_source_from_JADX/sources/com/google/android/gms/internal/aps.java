package com.google.android.gms.internal;

public final class aps extends Exception {

    /* renamed from: a */
    private final int f2686a;

    public aps(String str, int i) {
        super(str);
        this.f2686a = i;
    }

    /* renamed from: a */
    public final int mo2519a() {
        return this.f2686a;
    }
}
