package com.google.android.gms.internal;

@arm
public final class apt {
    /* JADX WARNING: type inference failed for: r7v0, types: [com.google.android.gms.internal.he, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r7v1, types: [com.google.android.gms.internal.apw] */
    /* JADX WARNING: type inference failed for: r0v4, types: [com.google.android.gms.internal.aqc] */
    /* JADX WARNING: type inference failed for: r7v3, types: [com.google.android.gms.internal.apv] */
    /* JADX WARNING: type inference failed for: r7v4, types: [com.google.android.gms.internal.apz] */
    /* JADX WARNING: type inference failed for: r0v13, types: [com.google.android.gms.internal.aqa] */
    /* JADX WARNING: type inference failed for: r7v6 */
    /* JADX WARNING: type inference failed for: r0v14, types: [com.google.android.gms.internal.aqc] */
    /* JADX WARNING: type inference failed for: r7v7 */
    /* JADX WARNING: type inference failed for: r7v8 */
    /* JADX WARNING: type inference failed for: r0v15, types: [com.google.android.gms.internal.aqa] */
    /* JADX WARNING: Multi-variable type inference failed. Error: jadx.core.utils.exceptions.JadxRuntimeException: No candidate types for var: r7v6
      assigns: [com.google.android.gms.internal.aqc, com.google.android.gms.internal.aqa]
      uses: [java.lang.Object, com.google.android.gms.internal.he, com.google.android.gms.internal.aqc, com.google.android.gms.internal.aqa]
      mth insns count: 60
    	at jadx.core.dex.visitors.typeinference.TypeSearch.fillTypeCandidates(TypeSearch.java:237)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1540)
    	at jadx.core.dex.visitors.typeinference.TypeSearch.run(TypeSearch.java:53)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runMultiVariableSearch(TypeInferenceVisitor.java:99)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:92)
    	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:27)
    	at jadx.core.dex.visitors.DepthTraversal.lambda$visit$1(DepthTraversal.java:14)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1540)
    	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
    	at jadx.core.ProcessClass.process(ProcessClass.java:30)
    	at jadx.core.ProcessClass.lambda$processDependencies$0(ProcessClass.java:49)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1540)
    	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:49)
    	at jadx.core.ProcessClass.process(ProcessClass.java:35)
    	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:311)
    	at jadx.api.JavaClass.decompile(JavaClass.java:62)
    	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:217)
     */
    /* JADX WARNING: Unknown variable types count: 6 */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static com.google.android.gms.internal.C0813he m3891a(android.content.Context r8, com.google.android.gms.ads.internal.C0330a r9, com.google.android.gms.internal.C0744eq r10, com.google.android.gms.internal.C0992nv r11, com.google.android.gms.internal.C0885jw r12, com.google.android.gms.internal.amx r13, com.google.android.gms.internal.apu r14, com.google.android.gms.internal.aez r15) {
        /*
            com.google.android.gms.internal.r r2 = r10.f3177b
            boolean r4 = r2.f4444g
            if (r4 == 0) goto L_0x0013
            com.google.android.gms.internal.aqa r7 = new com.google.android.gms.internal.aqa
            r0 = r7
            r1 = r8
            r2 = r10
            r3 = r13
            r4 = r14
            r5 = r15
            r6 = r12
            r0.<init>(r1, r2, r3, r4, r5, r6)
            goto L_0x006c
        L_0x0013:
            boolean r4 = r2.f4456s
            if (r4 != 0) goto L_0x0050
            boolean r4 = r9 instanceof com.google.android.gms.ads.internal.C0335ae
            if (r4 == 0) goto L_0x001c
            goto L_0x0050
        L_0x001c:
            com.google.android.gms.internal.aeb<java.lang.Boolean> r0 = com.google.android.gms.internal.ael.f1857ac
            com.google.android.gms.internal.aej r2 = com.google.android.gms.ads.internal.C0354ax.m1551r()
            java.lang.Object r0 = r2.mo2079a(r0)
            java.lang.Boolean r0 = (java.lang.Boolean) r0
            boolean r0 = r0.booleanValue()
            if (r0 == 0) goto L_0x004a
            boolean r0 = com.google.android.gms.common.util.C0580h.m2253d()
            if (r0 == 0) goto L_0x004a
            boolean r0 = com.google.android.gms.common.util.C0580h.m2255f()
            if (r0 != 0) goto L_0x004a
            if (r12 == 0) goto L_0x004a
            com.google.android.gms.internal.aay r0 = r12.mo2963l()
            boolean r0 = r0.f1653d
            if (r0 == 0) goto L_0x004a
            com.google.android.gms.internal.apz r7 = new com.google.android.gms.internal.apz
            r7.<init>(r8, r10, r12, r14)
            goto L_0x006c
        L_0x004a:
            com.google.android.gms.internal.apv r7 = new com.google.android.gms.internal.apv
            r7.<init>(r8, r10, r12, r14)
            goto L_0x006c
        L_0x0050:
            boolean r2 = r2.f4456s
            if (r2 == 0) goto L_0x0067
            boolean r2 = r9 instanceof com.google.android.gms.ads.internal.C0335ae
            if (r2 == 0) goto L_0x0067
            com.google.android.gms.internal.aqc r7 = new com.google.android.gms.internal.aqc
            r2 = r9
            com.google.android.gms.ads.internal.ae r2 = (com.google.android.gms.ads.internal.C0335ae) r2
            r0 = r7
            r1 = r8
            r3 = r10
            r4 = r11
            r5 = r14
            r6 = r15
            r0.<init>(r1, r2, r3, r4, r5, r6)
            goto L_0x006c
        L_0x0067:
            com.google.android.gms.internal.apw r7 = new com.google.android.gms.internal.apw
            r7.<init>(r10, r14)
        L_0x006c:
            java.lang.String r0 = "AdRenderer: "
            java.lang.Class r1 = r7.getClass()
            java.lang.String r1 = r1.getName()
            java.lang.String r1 = java.lang.String.valueOf(r1)
            int r2 = r1.length()
            if (r2 == 0) goto L_0x0085
            java.lang.String r0 = r0.concat(r1)
            goto L_0x008b
        L_0x0085:
            java.lang.String r1 = new java.lang.String
            r1.<init>(r0)
            r0 = r1
        L_0x008b:
            com.google.android.gms.internal.C0759fe.m4729b(r0)
            r7.mo2513d()
            return r7
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.apt.m3891a(android.content.Context, com.google.android.gms.ads.internal.a, com.google.android.gms.internal.eq, com.google.android.gms.internal.nv, com.google.android.gms.internal.jw, com.google.android.gms.internal.amx, com.google.android.gms.internal.apu, com.google.android.gms.internal.aez):com.google.android.gms.internal.he");
    }
}
