package com.google.android.gms.internal;

import android.content.Context;

@arm
public class apv extends apn implements C0891kb {
    apv(Context context, C0744eq eqVar, C0885jw jwVar, apu apu) {
        super(context, eqVar, jwVar, apu);
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public final void mo2510a() {
        if (this.f2670c.f4441d == -2) {
            this.f2669b.mo2967m().mo2996a((C0891kb) this);
            mo2520b();
            C0759fe.m4729b("Loading HTML in WebView.");
            this.f2669b.loadDataWithBaseURL(this.f2670c.f4438a, this.f2670c.f4439b, "text/html", "UTF-8", null);
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: b */
    public void mo2520b() {
    }
}
