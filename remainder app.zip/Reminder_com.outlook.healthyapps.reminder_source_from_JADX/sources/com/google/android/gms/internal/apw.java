package com.google.android.gms.internal;

@arm
public final class apw extends C0757fc {
    /* access modifiers changed from: private */

    /* renamed from: a */
    public final apu f2687a;

    /* renamed from: b */
    private final C1135r f2688b = this.f2689c.f3177b;

    /* renamed from: c */
    private final C0744eq f2689c;

    public apw(C0744eq eqVar, apu apu) {
        this.f2689c = eqVar;
        this.f2687a = apu;
    }

    /* renamed from: a */
    public final void mo1567a() {
        C0743ep epVar = r1;
        C0743ep epVar2 = new C0743ep(this.f2689c.f3176a.f3996c, null, null, 0, null, null, this.f2688b.f4448k, this.f2688b.f4447j, this.f2689c.f3176a.f4002i, false, null, null, null, null, null, this.f2688b.f4445h, this.f2689c.f3179d, this.f2688b.f4443f, this.f2689c.f3181f, this.f2688b.f4450m, this.f2688b.f4451n, this.f2689c.f3183h, null, null, null, null, this.f2689c.f3177b.f4422D, this.f2689c.f3177b.f4423E, null, null, null, this.f2689c.f3184i, this.f2689c.f3177b.f4433O);
        C0796go.f3327a.post(new apy(this, epVar));
    }

    /* renamed from: b */
    public final void mo1568b() {
    }
}
