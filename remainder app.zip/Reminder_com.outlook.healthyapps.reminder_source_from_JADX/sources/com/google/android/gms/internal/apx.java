package com.google.android.gms.internal;

public class apx extends C0646b {
    public apx() {
    }

    public apx(aey aey) {
        super(aey);
    }
}
