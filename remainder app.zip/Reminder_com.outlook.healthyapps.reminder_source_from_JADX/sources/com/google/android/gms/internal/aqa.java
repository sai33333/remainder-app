package com.google.android.gms.internal;

import android.content.Context;
import android.text.TextUtils;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.C0276a.C0278b;
import java.util.Iterator;
import java.util.List;
import org.json.JSONObject;

@arm
public final class aqa extends C0635app {

    /* renamed from: g */
    protected amo f2695g;

    /* renamed from: h */
    private amx f2696h;

    /* renamed from: i */
    private amg f2697i;

    /* renamed from: j */
    private ami f2698j;

    /* renamed from: k */
    private final aez f2699k;
    /* access modifiers changed from: private */

    /* renamed from: l */
    public final C0885jw f2700l;
    /* access modifiers changed from: private */

    /* renamed from: m */
    public boolean f2701m;

    aqa(Context context, C0744eq eqVar, amx amx, apu apu, aez aez, C0885jw jwVar) {
        super(context, eqVar, apu);
        this.f2696h = amx;
        this.f2698j = eqVar.f3178c;
        this.f2699k = aez;
        this.f2700l = jwVar;
    }

    /* renamed from: a */
    private static String m3904a(List<amo> list) {
        String str = "";
        if (list == null) {
            return str.toString();
        }
        Iterator it = list.iterator();
        while (true) {
            int i = 0;
            if (!it.hasNext()) {
                return str.substring(0, Math.max(0, str.length() - 1));
            }
            amo amo = (amo) it.next();
            if (!(amo == null || amo.f2525b == null || TextUtils.isEmpty(amo.f2525b.f2466d))) {
                String valueOf = String.valueOf(str);
                String str2 = amo.f2525b.f2466d;
                switch (amo.f2524a) {
                    case -1:
                        i = 4;
                        break;
                    case C0278b.AdsAttrs_adSize /*0*/:
                        break;
                    case 1:
                        i = 1;
                        break;
                    case 3:
                        i = 2;
                        break;
                    case C1217ty.f4597d /*4*/:
                        i = 3;
                        break;
                    case C1217ty.f4598e /*5*/:
                        i = 5;
                        break;
                    default:
                        i = 6;
                        break;
                }
                long j = amo.f2530g;
                StringBuilder sb = new StringBuilder(String.valueOf(str2).length() + 33);
                sb.append(str2);
                sb.append(".");
                sb.append(i);
                sb.append(".");
                sb.append(j);
                String sb2 = sb.toString();
                StringBuilder sb3 = new StringBuilder(String.valueOf(valueOf).length() + 1 + String.valueOf(sb2).length());
                sb3.append(valueOf);
                sb3.append(sb2);
                sb3.append("_");
                str = sb3.toString();
            }
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public final C0743ep mo2515a(int i) {
        C0970n nVar = this.f2681e.f3176a;
        aau aau = nVar.f3996c;
        C0885jw jwVar = this.f2700l;
        List<String> list = this.f2682f.f4440c;
        List<String> list2 = this.f2682f.f4442e;
        List<String> list3 = this.f2682f.f4446i;
        int i2 = this.f2682f.f4448k;
        long j = this.f2682f.f4447j;
        String str = nVar.f4002i;
        boolean z = this.f2682f.f4444g;
        amo amo = this.f2695g;
        amh amh = amo != null ? amo.f2525b : null;
        amo amo2 = this.f2695g;
        ana ana = amo2 != null ? amo2.f2526c : null;
        amo amo3 = this.f2695g;
        String name = amo3 != null ? amo3.f2527d : AdMobAdapter.class.getName();
        ami ami = this.f2698j;
        amo amo4 = this.f2695g;
        amk amk = amo4 != null ? amo4.f2528e : null;
        amh amh2 = amh;
        ana ana2 = ana;
        long j2 = this.f2682f.f4445h;
        aay aay = this.f2681e.f3179d;
        long j3 = j2;
        long j4 = this.f2682f.f4443f;
        long j5 = this.f2681e.f3181f;
        long j6 = this.f2682f.f4450m;
        String str2 = this.f2682f.f4451n;
        JSONObject jSONObject = this.f2681e.f3183h;
        C0717dq dqVar = this.f2682f.f4419A;
        List<String> list4 = this.f2682f.f4420B;
        List<String> list5 = this.f2682f.f4421C;
        ami ami2 = this.f2698j;
        boolean z2 = ami2 != null ? ami2.f2494n : false;
        C1190t tVar = this.f2682f.f4423E;
        amg amg = this.f2697i;
        C1190t tVar2 = tVar;
        long j7 = j6;
        C0743ep epVar = new C0743ep(aau, jwVar, list, i, list2, list3, i2, j, str, z, amh2, ana2, name, ami, amk, j3, aay, j4, j5, j7, str2, jSONObject, null, dqVar, list4, list5, z2, tVar2, amg != null ? m3904a(amg.mo2365b()) : null, this.f2682f.f4426H, this.f2682f.f4430L, this.f2681e.f3184i, this.f2682f.f4433O);
        return epVar;
    }

    /* JADX WARNING: type inference failed for: r0v3, types: [com.google.android.gms.internal.amg] */
    /* JADX WARNING: type inference failed for: r17v0, types: [com.google.android.gms.internal.amu] */
    /* JADX WARNING: type inference failed for: r4v4, types: [com.google.android.gms.internal.amr] */
    /* JADX WARNING: type inference failed for: r17v1, types: [com.google.android.gms.internal.amu] */
    /* JADX WARNING: type inference failed for: r4v5, types: [com.google.android.gms.internal.amr] */
    /* access modifiers changed from: protected */
    /* JADX WARNING: Multi-variable type inference failed. Error: jadx.core.utils.exceptions.JadxRuntimeException: No candidate types for var: r17v1, types: [com.google.android.gms.internal.amu]
      assigns: [com.google.android.gms.internal.amu, com.google.android.gms.internal.amr]
      uses: [com.google.android.gms.internal.amu, com.google.android.gms.internal.amg, com.google.android.gms.internal.amr]
      mth insns count: 145
    	at jadx.core.dex.visitors.typeinference.TypeSearch.fillTypeCandidates(TypeSearch.java:237)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1540)
    	at jadx.core.dex.visitors.typeinference.TypeSearch.run(TypeSearch.java:53)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runMultiVariableSearch(TypeInferenceVisitor.java:99)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:92)
    	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:27)
    	at jadx.core.dex.visitors.DepthTraversal.lambda$visit$1(DepthTraversal.java:14)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1540)
    	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
    	at jadx.core.ProcessClass.process(ProcessClass.java:30)
    	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:311)
    	at jadx.api.JavaClass.decompile(JavaClass.java:62)
    	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:217)
     */
    /* JADX WARNING: Removed duplicated region for block: B:16:0x00a7  */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x00d2  */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x00ef  */
    /* JADX WARNING: Removed duplicated region for block: B:28:0x00f8  */
    /* JADX WARNING: Unknown variable types count: 3 */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo2516a(long r31) {
        /*
            r30 = this;
            r1 = r30
            java.lang.Object r2 = r1.f2680d
            monitor-enter(r2)
            com.google.android.gms.internal.ami r0 = r1.f2698j     // Catch:{ all -> 0x0168 }
            int r0 = r0.f2492l     // Catch:{ all -> 0x0168 }
            r3 = -1
            if (r0 == r3) goto L_0x003d
            com.google.android.gms.internal.amr r0 = new com.google.android.gms.internal.amr     // Catch:{ all -> 0x0168 }
            android.content.Context r5 = r1.f2678b     // Catch:{ all -> 0x0168 }
            com.google.android.gms.internal.eq r3 = r1.f2681e     // Catch:{ all -> 0x0168 }
            com.google.android.gms.internal.n r6 = r3.f3176a     // Catch:{ all -> 0x0168 }
            com.google.android.gms.internal.amx r7 = r1.f2696h     // Catch:{ all -> 0x0168 }
            com.google.android.gms.internal.ami r8 = r1.f2698j     // Catch:{ all -> 0x0168 }
            com.google.android.gms.internal.r r3 = r1.f2682f     // Catch:{ all -> 0x0168 }
            boolean r9 = r3.f4456s     // Catch:{ all -> 0x0168 }
            com.google.android.gms.internal.r r3 = r1.f2682f     // Catch:{ all -> 0x0168 }
            boolean r10 = r3.f4463z     // Catch:{ all -> 0x0168 }
            com.google.android.gms.internal.r r3 = r1.f2682f     // Catch:{ all -> 0x0168 }
            java.lang.String r11 = r3.f4428J     // Catch:{ all -> 0x0168 }
            com.google.android.gms.internal.aeb<java.lang.Long> r3 = com.google.android.gms.internal.ael.f1921bn     // Catch:{ all -> 0x0168 }
            com.google.android.gms.internal.aej r4 = com.google.android.gms.ads.internal.C0354ax.m1551r()     // Catch:{ all -> 0x0168 }
            java.lang.Object r3 = r4.mo2079a(r3)     // Catch:{ all -> 0x0168 }
            java.lang.Long r3 = (java.lang.Long) r3     // Catch:{ all -> 0x0168 }
            long r14 = r3.longValue()     // Catch:{ all -> 0x0168 }
            r16 = 2
            r4 = r0
            r12 = r31
            r4.<init>(r5, r6, r7, r8, r9, r10, r11, r12, r14, r16)     // Catch:{ all -> 0x0168 }
            goto L_0x007e
        L_0x003d:
            com.google.android.gms.internal.amu r0 = new com.google.android.gms.internal.amu     // Catch:{ all -> 0x0168 }
            android.content.Context r3 = r1.f2678b     // Catch:{ all -> 0x0168 }
            com.google.android.gms.internal.eq r4 = r1.f2681e     // Catch:{ all -> 0x0168 }
            com.google.android.gms.internal.n r4 = r4.f3176a     // Catch:{ all -> 0x0168 }
            com.google.android.gms.internal.amx r5 = r1.f2696h     // Catch:{ all -> 0x0168 }
            com.google.android.gms.internal.ami r6 = r1.f2698j     // Catch:{ all -> 0x0168 }
            com.google.android.gms.internal.r r7 = r1.f2682f     // Catch:{ all -> 0x0168 }
            boolean r7 = r7.f4456s     // Catch:{ all -> 0x0168 }
            com.google.android.gms.internal.r r8 = r1.f2682f     // Catch:{ all -> 0x0168 }
            boolean r8 = r8.f4463z     // Catch:{ all -> 0x0168 }
            com.google.android.gms.internal.r r9 = r1.f2682f     // Catch:{ all -> 0x0168 }
            java.lang.String r9 = r9.f4428J     // Catch:{ all -> 0x0168 }
            com.google.android.gms.internal.aeb<java.lang.Long> r10 = com.google.android.gms.internal.ael.f1921bn     // Catch:{ all -> 0x0168 }
            com.google.android.gms.internal.aej r11 = com.google.android.gms.ads.internal.C0354ax.m1551r()     // Catch:{ all -> 0x0168 }
            java.lang.Object r10 = r11.mo2079a(r10)     // Catch:{ all -> 0x0168 }
            java.lang.Long r10 = (java.lang.Long) r10     // Catch:{ all -> 0x0168 }
            long r27 = r10.longValue()     // Catch:{ all -> 0x0168 }
            com.google.android.gms.internal.aez r10 = r1.f2699k     // Catch:{ all -> 0x0168 }
            r17 = r0
            r18 = r3
            r19 = r4
            r20 = r5
            r21 = r6
            r22 = r7
            r23 = r8
            r24 = r9
            r25 = r31
            r29 = r10
            r17.<init>(r18, r19, r20, r21, r22, r23, r24, r25, r27, r29)     // Catch:{ all -> 0x0168 }
        L_0x007e:
            r1.f2697i = r0     // Catch:{ all -> 0x0168 }
            monitor-exit(r2)     // Catch:{ all -> 0x0168 }
            java.util.ArrayList r0 = new java.util.ArrayList
            com.google.android.gms.internal.ami r2 = r1.f2698j
            java.util.List<com.google.android.gms.internal.amh> r2 = r2.f2481a
            r0.<init>(r2)
            com.google.android.gms.internal.eq r2 = r1.f2681e
            com.google.android.gms.internal.n r2 = r2.f3176a
            com.google.android.gms.internal.aau r2 = r2.f3996c
            android.os.Bundle r2 = r2.f1626m
            java.lang.String r3 = "com.google.ads.mediation.admob.AdMobAdapter"
            r4 = 0
            if (r2 == 0) goto L_0x00a4
            android.os.Bundle r2 = r2.getBundle(r3)
            if (r2 == 0) goto L_0x00a4
            java.lang.String r5 = "_skipMediation"
            boolean r2 = r2.getBoolean(r5)
            goto L_0x00a5
        L_0x00a4:
            r2 = r4
        L_0x00a5:
            if (r2 == 0) goto L_0x00c3
            java.util.ListIterator r2 = r0.listIterator()
        L_0x00ab:
            boolean r5 = r2.hasNext()
            if (r5 == 0) goto L_0x00c3
            java.lang.Object r5 = r2.next()
            com.google.android.gms.internal.amh r5 = (com.google.android.gms.internal.amh) r5
            java.util.List<java.lang.String> r5 = r5.f2465c
            boolean r5 = r5.contains(r3)
            if (r5 != 0) goto L_0x00ab
            r2.remove()
            goto L_0x00ab
        L_0x00c3:
            com.google.android.gms.internal.amg r2 = r1.f2697i
            com.google.android.gms.internal.amo r0 = r2.mo2363a(r0)
            r1.f2695g = r0
            com.google.android.gms.internal.amo r0 = r1.f2695g
            int r0 = r0.f2524a
            switch(r0) {
                case 0: goto L_0x00f8;
                case 1: goto L_0x00ef;
                default: goto L_0x00d2;
            }
        L_0x00d2:
            com.google.android.gms.internal.aps r0 = new com.google.android.gms.internal.aps
            com.google.android.gms.internal.amo r2 = r1.f2695g
            int r2 = r2.f2524a
            r3 = 40
            java.lang.StringBuilder r5 = new java.lang.StringBuilder
            r5.<init>(r3)
            java.lang.String r3 = "Unexpected mediation result: "
            r5.append(r3)
            r5.append(r2)
            java.lang.String r2 = r5.toString()
            r0.<init>(r2, r4)
            throw r0
        L_0x00ef:
            com.google.android.gms.internal.aps r0 = new com.google.android.gms.internal.aps
            r2 = 3
            java.lang.String r3 = "No fill from any mediation ad networks."
            r0.<init>(r3, r2)
            throw r0
        L_0x00f8:
            com.google.android.gms.internal.amo r0 = r1.f2695g
            com.google.android.gms.internal.amh r0 = r0.f2525b
            if (r0 == 0) goto L_0x0167
            com.google.android.gms.internal.amo r0 = r1.f2695g
            com.google.android.gms.internal.amh r0 = r0.f2525b
            java.lang.String r0 = r0.f2475m
            if (r0 == 0) goto L_0x0167
            java.util.concurrent.CountDownLatch r0 = new java.util.concurrent.CountDownLatch
            r2 = 1
            r0.<init>(r2)
            android.os.Handler r2 = com.google.android.gms.internal.C0796go.f3327a
            com.google.android.gms.internal.aqb r3 = new com.google.android.gms.internal.aqb
            r3.<init>(r1, r0)
            r2.post(r3)
            r2 = 10
            java.util.concurrent.TimeUnit r5 = java.util.concurrent.TimeUnit.SECONDS     // Catch:{ InterruptedException -> 0x0141 }
            r0.await(r2, r5)     // Catch:{ InterruptedException -> 0x0141 }
            java.lang.Object r2 = r1.f2680d
            monitor-enter(r2)
            boolean r0 = r1.f2701m     // Catch:{ all -> 0x013e }
            if (r0 == 0) goto L_0x0136
            com.google.android.gms.internal.jw r0 = r1.f2700l     // Catch:{ all -> 0x013e }
            boolean r0 = r0.mo2976s()     // Catch:{ all -> 0x013e }
            if (r0 != 0) goto L_0x012e
            monitor-exit(r2)     // Catch:{ all -> 0x013e }
            return
        L_0x012e:
            com.google.android.gms.internal.aps r0 = new com.google.android.gms.internal.aps     // Catch:{ all -> 0x013e }
            java.lang.String r3 = "Assets not loaded, web view is destroyed"
            r0.<init>(r3, r4)     // Catch:{ all -> 0x013e }
            throw r0     // Catch:{ all -> 0x013e }
        L_0x0136:
            com.google.android.gms.internal.aps r0 = new com.google.android.gms.internal.aps     // Catch:{ all -> 0x013e }
            java.lang.String r3 = "View could not be prepared"
            r0.<init>(r3, r4)     // Catch:{ all -> 0x013e }
            throw r0     // Catch:{ all -> 0x013e }
        L_0x013e:
            r0 = move-exception
            monitor-exit(r2)     // Catch:{ all -> 0x013e }
            throw r0
        L_0x0141:
            r0 = move-exception
            com.google.android.gms.internal.aps r2 = new com.google.android.gms.internal.aps
            java.lang.String r0 = java.lang.String.valueOf(r0)
            java.lang.String r3 = java.lang.String.valueOf(r0)
            int r3 = r3.length()
            int r3 = r3 + 38
            java.lang.StringBuilder r5 = new java.lang.StringBuilder
            r5.<init>(r3)
            java.lang.String r3 = "Interrupted while waiting for latch : "
            r5.append(r3)
            r5.append(r0)
            java.lang.String r0 = r5.toString()
            r2.<init>(r0, r4)
            throw r2
        L_0x0167:
            return
        L_0x0168:
            r0 = move-exception
            monitor-exit(r2)     // Catch:{ all -> 0x0168 }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.aqa.mo2516a(long):void");
    }

    /* renamed from: b */
    public final void mo1568b() {
        synchronized (this.f2680d) {
            super.mo1568b();
            if (this.f2697i != null) {
                this.f2697i.mo2364a();
            }
        }
    }
}
