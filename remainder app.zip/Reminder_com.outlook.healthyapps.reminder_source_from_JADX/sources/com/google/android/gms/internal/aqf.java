package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.p017js.C0410j;

final class aqf implements C0877jo<C0410j> {

    /* renamed from: a */
    private /* synthetic */ aqj f2726a;

    aqf(aqe aqe, aqj aqj) {
        this.f2726a = aqj;
    }

    /* renamed from: a */
    public final /* synthetic */ void mo1464a(Object obj) {
        this.f2726a.mo2219a((C0410j) obj);
    }
}
