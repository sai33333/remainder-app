package com.google.android.gms.internal;

final class aqg implements C0875jm {

    /* renamed from: a */
    private /* synthetic */ aqj f2727a;

    aqg(aqe aqe, aqj aqj) {
        this.f2727a = aqj;
    }

    /* renamed from: a */
    public final void mo1486a() {
        this.f2727a.mo2529a();
    }
}
