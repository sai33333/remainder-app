package com.google.android.gms.internal;

final class aqn implements Runnable {

    /* renamed from: a */
    private /* synthetic */ C0871ji f2751a;

    /* renamed from: b */
    private /* synthetic */ String f2752b;

    /* renamed from: c */
    private /* synthetic */ aqk f2753c;

    aqn(aqk aqk, C0871ji jiVar, String str) {
        this.f2753c = aqk;
        this.f2751a = jiVar;
        this.f2752b = str;
    }

    public final void run() {
        this.f2751a.mo2904b((aia) this.f2753c.f2733d.mo1343H().get(this.f2752b));
    }
}
