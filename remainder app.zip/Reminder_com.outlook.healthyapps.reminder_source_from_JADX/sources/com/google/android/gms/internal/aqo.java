package com.google.android.gms.internal;

import java.util.Map;

final class aqo implements ajh {

    /* renamed from: a */
    private /* synthetic */ afs f2754a;

    /* renamed from: b */
    private /* synthetic */ aqk f2755b;

    aqo(aqk aqk, afs afs) {
        this.f2755b = aqk;
        this.f2754a = afs;
    }

    /* renamed from: a */
    public final void mo1441a(C0885jw jwVar, Map<String, String> map) {
        this.f2755b.m3928a((ahn) this.f2754a, (String) map.get("asset"));
    }
}
