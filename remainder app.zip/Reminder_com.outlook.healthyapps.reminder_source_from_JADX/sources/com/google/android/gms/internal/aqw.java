package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.C0354ax;
import java.lang.ref.WeakReference;
import org.json.JSONObject;

final class aqw implements Runnable {

    /* renamed from: a */
    final /* synthetic */ JSONObject f2786a;

    /* renamed from: b */
    final /* synthetic */ C0871ji f2787b;

    /* renamed from: c */
    final /* synthetic */ aqv f2788c;

    aqw(aqv aqv, JSONObject jSONObject, C0871ji jiVar) {
        this.f2788c = aqv;
        this.f2786a = jSONObject;
        this.f2787b = jiVar;
    }

    public final void run() {
        try {
            C0885jw a = this.f2788c.mo2545a();
            this.f2788c.f2780f.mo1352a(a);
            WeakReference weakReference = new WeakReference(a);
            a.mo2967m().mo2993a(this.f2788c.m3955a(weakReference), this.f2788c.m3962b(weakReference));
            this.f2788c.m3959a(a);
            a.mo2967m().mo2997a((C0892kc) new aqx(this, a));
            a.mo2967m().mo2996a((C0891kb) new aqz(this));
            a.loadUrl((String) C0354ax.m1551r().mo2079a(ael.f1894bM));
        } catch (Exception e) {
            C0759fe.m4732c("Exception occurred while getting video view", e);
            this.f2787b.mo2904b(null);
        }
    }
}
