package com.google.android.gms.internal;

import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import java.lang.ref.WeakReference;

final class arc implements OnGlobalLayoutListener {

    /* renamed from: a */
    private /* synthetic */ WeakReference f2794a;

    /* renamed from: b */
    private /* synthetic */ aqv f2795b;

    arc(aqv aqv, WeakReference weakReference) {
        this.f2795b = aqv;
        this.f2794a = weakReference;
    }

    public final void onGlobalLayout() {
        this.f2795b.m3960a(this.f2794a, false);
    }
}
