package com.google.android.gms.internal;

import android.view.ViewTreeObserver.OnScrollChangedListener;
import java.lang.ref.WeakReference;

final class ard implements OnScrollChangedListener {

    /* renamed from: a */
    private /* synthetic */ WeakReference f2796a;

    /* renamed from: b */
    private /* synthetic */ aqv f2797b;

    ard(aqv aqv, WeakReference weakReference) {
        this.f2797b = aqv;
        this.f2796a = weakReference;
    }

    public final void onScrollChanged() {
        this.f2797b.m3960a(this.f2796a, true);
    }
}
