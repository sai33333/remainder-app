package com.google.android.gms.internal;

import android.os.Bundle;
import android.view.View;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONObject;

@arm
public final class are implements aqt<afo> {

    /* renamed from: a */
    private final boolean f2798a;

    /* renamed from: b */
    private final boolean f2799b;

    public are(boolean z, boolean z2) {
        this.f2798a = z;
        this.f2799b = z2;
    }

    /* renamed from: a */
    public final /* synthetic */ afy mo2544a(aqk aqk, JSONObject jSONObject) {
        View view;
        aqk aqk2 = aqk;
        JSONObject jSONObject2 = jSONObject;
        List<C0865jc> a = aqk.mo2533a(jSONObject, "images", false, this.f2798a, this.f2799b);
        C0865jc a2 = aqk2.mo2532a(jSONObject2, "app_icon", true, this.f2798a);
        C0865jc a3 = aqk2.mo2531a(jSONObject2, "video");
        C0865jc a4 = aqk.mo2530a(jSONObject);
        ArrayList arrayList = new ArrayList();
        for (C0865jc jcVar : a) {
            arrayList.add((afn) jcVar.get());
        }
        C0885jw a5 = aqk.m3926a(a3);
        String string = jSONObject2.getString("headline");
        String string2 = jSONObject2.getString("body");
        agv agv = (agv) a2.get();
        String string3 = jSONObject2.getString("call_to_action");
        double optDouble = jSONObject2.optDouble("rating", -1.0d);
        String optString = jSONObject2.optString("store");
        String optString2 = jSONObject2.optString("price");
        afl afl = (afl) a4.get();
        Bundle bundle = new Bundle();
        acu A = a5 != null ? a5.mo2922A() : null;
        if (a5 == null) {
            view = null;
        } else if (a5 != null) {
            view = (View) a5;
        } else {
            throw null;
        }
        afo afo = new afo(string, arrayList, string2, agv, string3, optDouble, optString, optString2, afl, bundle, A, view, null, null);
        return afo;
    }
}
