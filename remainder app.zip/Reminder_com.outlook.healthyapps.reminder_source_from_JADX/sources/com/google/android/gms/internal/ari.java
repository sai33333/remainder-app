package com.google.android.gms.internal;

import java.lang.Thread.UncaughtExceptionHandler;

final class ari implements UncaughtExceptionHandler {

    /* renamed from: a */
    private /* synthetic */ UncaughtExceptionHandler f2810a;

    /* renamed from: b */
    private /* synthetic */ arh f2811b;

    ari(arh arh, UncaughtExceptionHandler uncaughtExceptionHandler) {
        this.f2811b = arh;
        this.f2810a = uncaughtExceptionHandler;
    }

    public final void uncaughtException(Thread thread, Throwable th) {
        try {
            this.f2811b.mo2550a(thread, th);
            UncaughtExceptionHandler uncaughtExceptionHandler = this.f2810a;
            if (uncaughtExceptionHandler != null) {
                uncaughtExceptionHandler.uncaughtException(thread, th);
            }
        } catch (Throwable th2) {
            UncaughtExceptionHandler uncaughtExceptionHandler2 = this.f2810a;
            if (uncaughtExceptionHandler2 != null) {
                uncaughtExceptionHandler2.uncaughtException(thread, th);
            }
            throw th2;
        }
    }
}
