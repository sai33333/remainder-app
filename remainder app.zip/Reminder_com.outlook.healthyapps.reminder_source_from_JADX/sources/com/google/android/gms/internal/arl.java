package com.google.android.gms.internal;

public final class arl implements ark {
    /* renamed from: a */
    public final void mo2551a(Throwable th, String str) {
    }
}
