package com.google.android.gms.internal;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.text.TextUtils;
import android.webkit.CookieManager;
import com.google.android.gms.ads.internal.C0354ax;
import com.google.android.gms.internal.aaf.C0613a.C0615b;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;

@arm
public final class arp extends C0757fc implements C0754f {

    /* renamed from: a */
    C0813he f2814a;

    /* renamed from: b */
    private final aro f2815b;
    /* access modifiers changed from: private */

    /* renamed from: c */
    public final C0997o f2816c;
    /* access modifiers changed from: private */

    /* renamed from: d */
    public final Object f2817d = new Object();

    /* renamed from: e */
    private final Context f2818e;

    /* renamed from: f */
    private final aac f2819f;

    /* renamed from: g */
    private final aai f2820g;

    /* renamed from: h */
    private C0970n f2821h;
    /* access modifiers changed from: private */

    /* renamed from: i */
    public Runnable f2822i;

    /* renamed from: j */
    private C1135r f2823j;

    /* renamed from: k */
    private ami f2824k;

    public arp(Context context, C0997o oVar, aro aro, aai aai) {
        aac aac;
        aae aae;
        this.f2815b = aro;
        this.f2818e = context;
        this.f2816c = oVar;
        this.f2820g = aai;
        this.f2819f = new aac(this.f2820g, ((Boolean) C0354ax.m1551r().mo2079a(ael.f1941cG)).booleanValue());
        this.f2819f.mo1906a((aae) new arq(this));
        aao aao = new aao();
        aao.f1609a = Integer.valueOf(this.f2816c.f4114j.f3449b);
        aao.f1610b = Integer.valueOf(this.f2816c.f4114j.f3450c);
        aao.f1611c = Integer.valueOf(this.f2816c.f4114j.f3451d ? 0 : 2);
        this.f2819f.mo1906a((aae) new arr(aao));
        if (this.f2816c.f4110f != null) {
            this.f2819f.mo1906a((aae) new ars(this));
        }
        aay aay = this.f2816c.f4107c;
        if (aay.f1653d && "interstitial_mb".equals(aay.f1650a)) {
            aac = this.f2819f;
            aae = art.f2828a;
        } else if (aay.f1653d && "reward_mb".equals(aay.f1650a)) {
            aac = this.f2819f;
            aae = aru.f2829a;
        } else if (aay.f1657h || aay.f1653d) {
            aac = this.f2819f;
            aae = arw.f2831a;
        } else {
            aac = this.f2819f;
            aae = arv.f2830a;
        }
        aac.mo1906a(aae);
        this.f2819f.mo1907a(C0615b.AD_REQUEST);
    }

    /* renamed from: a */
    private final aay m3981a(C0970n nVar) {
        aay[] aayArr;
        C0970n nVar2 = this.f2821h;
        if ((nVar2 == null || nVar2.f3988V == null || this.f2821h.f3988V.size() <= 1) ? false : true) {
            ami ami = this.f2824k;
            if (ami != null && !ami.f2498r) {
                return null;
            }
        }
        if (this.f2823j.f4462y) {
            for (aay aay : nVar.f3997d.f1656g) {
                if (aay.f1658i) {
                    return new aay(aay, nVar.f3997d.f1656g);
                }
            }
        }
        if (this.f2823j.f4449l != null) {
            String[] split = this.f2823j.f4449l.split("x");
            if (split.length != 2) {
                String str = "Invalid ad size format from the ad response: ";
                String valueOf = String.valueOf(this.f2823j.f4449l);
                throw new C0673c(valueOf.length() != 0 ? str.concat(valueOf) : new String(str), 0);
            }
            try {
                int parseInt = Integer.parseInt(split[0]);
                int parseInt2 = Integer.parseInt(split[1]);
                aay[] aayArr2 = nVar.f3997d.f1656g;
                int length = aayArr2.length;
                for (int i = 0; i < length; i++) {
                    aay aay2 = aayArr2[i];
                    float f = this.f2818e.getResources().getDisplayMetrics().density;
                    int i2 = aay2.f1654e == -1 ? (int) (((float) aay2.f1655f) / f) : aay2.f1654e;
                    int i3 = aay2.f1651b == -2 ? (int) (((float) aay2.f1652c) / f) : aay2.f1651b;
                    if (parseInt == i2 && parseInt2 == i3 && !aay2.f1658i) {
                        return new aay(aay2, nVar.f3997d.f1656g);
                    }
                }
                String str2 = "The ad size from the ad response was not one of the requested sizes: ";
                String valueOf2 = String.valueOf(this.f2823j.f4449l);
                throw new C0673c(valueOf2.length() != 0 ? str2.concat(valueOf2) : new String(str2), 0);
            } catch (NumberFormatException unused) {
                String str3 = "Invalid ad size number from the ad response: ";
                String valueOf3 = String.valueOf(this.f2823j.f4449l);
                throw new C0673c(valueOf3.length() != 0 ? str3.concat(valueOf3) : new String(str3), 0);
            }
        } else {
            throw new C0673c("The ad response must specify one of the supported ad sizes.", 0);
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: a */
    public final void m3983a(int i, String str) {
        int i2 = i;
        if (i2 == 3 || i2 == -1) {
            C0759fe.m4733d(str);
        } else {
            C0759fe.m4734e(str);
        }
        C1135r rVar = this.f2823j;
        if (rVar == null) {
            this.f2823j = new C1135r(i);
        } else {
            this.f2823j = new C1135r(i, rVar.f4447j);
        }
        C0970n nVar = this.f2821h;
        if (nVar == null) {
            nVar = new C0970n(this.f2816c, -1, null, null, null);
        }
        C0970n nVar2 = nVar;
        C1135r rVar2 = this.f2823j;
        C0744eq eqVar = new C0744eq(nVar2, rVar2, this.f2824k, (aay) null, i, -1, rVar2.f4450m, (JSONObject) null, this.f2819f);
        this.f2815b.mo1298a(eqVar);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public final C0813he mo2554a(C0857iv ivVar, C0874jl<C0970n> jlVar) {
        Context context = this.f2818e;
        if (new C0727e(context).mo2680a(ivVar)) {
            C0759fe.m4729b("Fetching ad response from local ad request service.");
            C0889k kVar = new C0889k(context, jlVar, this);
            kVar.mo2513d();
            return kVar;
        }
        C0759fe.m4729b("Fetching ad response from remote ad request service.");
        abj.m2380a();
        if (C0851ip.m4715c(context)) {
            return new C0916l(context, ivVar, jlVar, this);
        }
        C0759fe.m4734e("Failed to connect to remote ad request service.");
        return null;
    }

    /* renamed from: a */
    public final void mo1567a() {
        C0759fe.m4729b("AdLoaderBackgroundTask started.");
        this.f2822i = new arx(this);
        C0796go.f3327a.postDelayed(this.f2822i, ((Long) C0354ax.m1551r().mo2079a(ael.f1920bm)).longValue());
        long b = C0354ax.m1544k().mo1883b();
        if (((Boolean) C0354ax.m1551r().mo2079a(ael.f1918bk)).booleanValue() && this.f2816c.f4106b.f1616c != null) {
            String string = this.f2816c.f4106b.f1616c.getString("_ad");
            if (string != null) {
                C0970n nVar = new C0970n(this.f2816c, b, null, null, null);
                this.f2821h = nVar;
                mo2556a(C0651be.m4011a(this.f2818e, this.f2821h, string));
                return;
            }
        }
        C0878jp jpVar = new C0878jp();
        C0790gi.m4479a((Runnable) new ary(this, jpVar));
        String g = C0354ax.m1532D().mo2697g(this.f2818e);
        String h = C0354ax.m1532D().mo2699h(this.f2818e);
        String i = C0354ax.m1532D().mo2700i(this.f2818e);
        C0354ax.m1532D().mo2696f(this.f2818e, i);
        C0970n nVar2 = new C0970n(this.f2816c, b, g, h, i);
        this.f2821h = nVar2;
        jpVar.mo1495a(this.f2821h);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public final /* synthetic */ void mo2555a(aan aan) {
        aan.f1607b.f1604a = this.f2816c.f4110f.packageName;
    }

    /* renamed from: a */
    public final void mo2556a(C1135r rVar) {
        JSONObject jSONObject;
        SharedPreferences sharedPreferences;
        HashSet hashSet;
        C0759fe.m4729b("Received ad response.");
        this.f2823j = rVar;
        long b = C0354ax.m1544k().mo1883b();
        synchronized (this.f2817d) {
            this.f2814a = null;
        }
        C0354ax.m1542i().mo2745b(this.f2818e, this.f2823j.f4424F);
        if (((Boolean) C0354ax.m1551r().mo2079a(ael.f1836aH)).booleanValue()) {
            if (this.f2823j.f4432N) {
                C0354ax.m1542i();
                Context context = this.f2818e;
                String str = this.f2821h.f3998e;
                sharedPreferences = context.getSharedPreferences("admob", 0);
                Set stringSet = sharedPreferences.getStringSet("never_pool_slots", Collections.emptySet());
                if (!stringSet.contains(str)) {
                    hashSet = new HashSet(stringSet);
                    hashSet.add(str);
                }
            } else {
                C0354ax.m1542i();
                Context context2 = this.f2818e;
                String str2 = this.f2821h.f3998e;
                sharedPreferences = context2.getSharedPreferences("admob", 0);
                Set stringSet2 = sharedPreferences.getStringSet("never_pool_slots", Collections.emptySet());
                if (stringSet2.contains(str2)) {
                    hashSet = new HashSet(stringSet2);
                    hashSet.remove(str2);
                }
            }
            Editor edit = sharedPreferences.edit();
            edit.putStringSet("never_pool_slots", hashSet);
            edit.apply();
        }
        try {
            if (this.f2823j.f4441d != -2) {
                if (this.f2823j.f4441d != -3) {
                    int i = this.f2823j.f4441d;
                    StringBuilder sb = new StringBuilder(66);
                    sb.append("There was a problem getting an ad response. ErrorCode: ");
                    sb.append(i);
                    throw new C0673c(sb.toString(), this.f2823j.f4441d);
                }
            }
            if (this.f2823j.f4441d != -3) {
                if (!TextUtils.isEmpty(this.f2823j.f4439b)) {
                    C0354ax.m1542i().mo2735a(this.f2818e, this.f2823j.f4457t);
                    if (this.f2823j.f4444g) {
                        this.f2824k = new ami(this.f2823j.f4439b);
                        C0354ax.m1542i().mo2749c(this.f2824k.f2487g);
                    } else {
                        C0354ax.m1542i().mo2749c(this.f2823j.f4427I);
                    }
                    if (!TextUtils.isEmpty(this.f2823j.f4425G)) {
                        if (((Boolean) C0354ax.m1551r().mo2079a(ael.f1973cm)).booleanValue()) {
                            C0759fe.m4729b("Received cookie from server. Setting webview cookie in CookieManager.");
                            CookieManager c = C0354ax.m1540g().mo2828c(this.f2818e);
                            if (c != null) {
                                c.setCookie("googleads.g.doubleclick.net", this.f2823j.f4425G);
                            }
                        }
                    }
                } else {
                    throw new C0673c("No fill from ad server.", 3);
                }
            }
            aay a = this.f2821h.f3997d.f1656g != null ? m3981a(this.f2821h) : null;
            C0354ax.m1542i().mo2744a(this.f2823j.f4458u);
            C0354ax.m1542i().mo2747b(this.f2823j.f4431M);
            if (!TextUtils.isEmpty(this.f2823j.f4454q)) {
                try {
                    jSONObject = new JSONObject(this.f2823j.f4454q);
                } catch (Exception e) {
                    C0759fe.m4730b("Error parsing the JSON for Active View.", e);
                }
                C0970n nVar = this.f2821h;
                C1135r rVar2 = this.f2823j;
                C0744eq eqVar = new C0744eq(nVar, rVar2, this.f2824k, a, -2, b, rVar2.f4450m, jSONObject, this.f2819f);
                this.f2815b.mo1298a(eqVar);
                C0796go.f3327a.removeCallbacks(this.f2822i);
            }
            jSONObject = null;
            C0970n nVar2 = this.f2821h;
            C1135r rVar22 = this.f2823j;
            C0744eq eqVar2 = new C0744eq(nVar2, rVar22, this.f2824k, a, -2, b, rVar22.f4450m, jSONObject, this.f2819f);
            this.f2815b.mo1298a(eqVar2);
        } catch (JSONException e2) {
            C0759fe.m4730b("Could not parse mediation config.", e2);
            String str3 = "Could not parse mediation config: ";
            String valueOf = String.valueOf(this.f2823j.f4439b);
            throw new C0673c(valueOf.length() != 0 ? str3.concat(valueOf) : new String(str3), 0);
        } catch (C0673c e3) {
            m3983a(e3.mo2591a(), e3.getMessage());
        }
        C0796go.f3327a.removeCallbacks(this.f2822i);
    }

    /* renamed from: b */
    public final void mo1568b() {
        synchronized (this.f2817d) {
            if (this.f2814a != null) {
                this.f2814a.mo2512c();
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public final /* synthetic */ void mo2557b(aan aan) {
        aan.f1606a = this.f2816c.f4126v;
    }
}
