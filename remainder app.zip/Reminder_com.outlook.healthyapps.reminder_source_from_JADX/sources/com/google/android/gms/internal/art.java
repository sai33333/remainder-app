package com.google.android.gms.internal;

final /* synthetic */ class art implements aae {

    /* renamed from: a */
    static final aae f2828a = new art();

    private art() {
    }

    /* renamed from: a */
    public final void mo1413a(aan aan) {
        aan.f1608c.f1603a = Integer.valueOf(3);
    }
}
