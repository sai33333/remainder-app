package p011c;

/* renamed from: c.e */
public interface C0251e {
    /* renamed from: a */
    void mo965a();
}
