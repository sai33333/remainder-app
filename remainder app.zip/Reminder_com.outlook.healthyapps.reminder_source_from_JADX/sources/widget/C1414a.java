package widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService.RemoteViewsFactory;
import com.outlook.healthyapps.reminder.R;
import java.util.ArrayList;
import p010b.C0238a;
import p011c.C0239a;
import p020e.C1386a;

@SuppressLint({"NewApi"})
/* renamed from: widget.a */
public class C1414a implements RemoteViewsFactory {

    /* renamed from: a */
    private C0238a f5110a;

    /* renamed from: b */
    private ArrayList<C1386a> f5111b;

    /* renamed from: c */
    private Context f5112c = null;

    /* renamed from: d */
    private C0239a f5113d;

    public C1414a(Context context, Intent intent) {
        this.f5112c = context;
        this.f5110a = new C0238a(this.f5112c);
        this.f5113d = new C0239a(this.f5112c);
    }

    public int getCount() {
        return this.f5111b.size();
    }

    public long getItemId(int i) {
        return (long) i;
    }

    public RemoteViews getLoadingView() {
        return null;
    }

    public RemoteViews getViewAt(int i) {
        String str;
        StringBuilder sb;
        String str2;
        StringBuilder sb2;
        RemoteViews remoteViews = new RemoteViews(this.f5112c.getPackageName(), R.layout.widget_item_listview);
        remoteViews.setTextViewText(R.id.wDescription, ((C1386a) this.f5111b.get(i)).mo3693b());
        if (((C1386a) this.f5111b.get(i)).mo3707j().contains(",") || ((C1386a) this.f5111b.get(i)).mo3707j().contains("except")) {
            sb = new StringBuilder();
            sb.append(this.f5113d.mo1021a(((C1386a) this.f5111b.get(i)).mo3703f()));
            str = " ;\n";
        } else {
            sb = new StringBuilder();
            sb.append(this.f5113d.mo1021a(((C1386a) this.f5111b.get(i)).mo3703f()));
            str = " ;   ";
        }
        sb.append(str);
        sb.append(((C1386a) this.f5111b.get(i)).mo3707j());
        remoteViews.setTextViewText(R.id.wDateAndTime, sb.toString());
        if (((C1386a) this.f5111b.get(i)).mo3693b().contains("[No Title]")) {
            sb2 = new StringBuilder();
            sb2.append("Select this reminder. ");
            str2 = ((C1386a) this.f5111b.get(i)).mo3693b().replace("[", "").replace("]", "");
        } else {
            sb2 = new StringBuilder();
            sb2.append("Select this reminder. ");
            str2 = ((C1386a) this.f5111b.get(i)).mo3693b();
        }
        sb2.append(str2);
        remoteViews.setContentDescription(R.id.wDescription, sb2.toString());
        StringBuilder sb3 = new StringBuilder();
        sb3.append(". Scheduled at ");
        sb3.append(this.f5113d.mo1021a(((C1386a) this.f5111b.get(i)).mo3703f()));
        sb3.append(". Repeat ");
        sb3.append(((C1386a) this.f5111b.get(i)).mo3707j());
        remoteViews.setContentDescription(R.id.wDateAndTime, sb3.toString());
        Intent intent = new Intent();
        intent.setAction("_VIEW");
        intent.putExtra("bID", ((C1386a) this.f5111b.get(i)).mo3687a());
        intent.putExtra("bTITLE", ((C1386a) this.f5111b.get(i)).mo3693b());
        intent.putExtra("bRPT_DESC", ((C1386a) this.f5111b.get(i)).mo3707j());
        intent.putExtra("bRPT_TYPE", ((C1386a) this.f5111b.get(i)).mo3704g());
        intent.putExtra("bSTART_DATE", ((C1386a) this.f5111b.get(i)).mo3702e());
        intent.putExtra("bNEXT_RUN", ((C1386a) this.f5111b.get(i)).mo3703f());
        remoteViews.setOnClickFillInIntent(R.id.wLvItem, intent);
        return remoteViews;
    }

    public int getViewTypeCount() {
        return 1;
    }

    public boolean hasStableIds() {
        return true;
    }

    public void onCreate() {
        this.f5111b = this.f5110a.mo1016e();
    }

    public void onDataSetChanged() {
        this.f5111b = this.f5110a.mo1016e();
    }

    public void onDestroy() {
    }
}
