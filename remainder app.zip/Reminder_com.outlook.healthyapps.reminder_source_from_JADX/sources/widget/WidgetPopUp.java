package widget;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import app.Activity_Create;
import com.outlook.healthyapps.reminder.R;
import p010b.C0238a;
import p011c.C0239a;
import p011c.C0240b;
import p022g.C1404a;

public class WidgetPopUp extends Activity {
    /* access modifiers changed from: private */

    /* renamed from: a */
    public Context f5100a;
    /* access modifiers changed from: private */

    /* renamed from: b */
    public int f5101b = 0;
    /* access modifiers changed from: private */

    /* renamed from: c */
    public C0238a f5102c;

    /* renamed from: d */
    private C0240b f5103d;

    /* renamed from: e */
    private C1404a f5104e = new C1404a();

    /* renamed from: f */
    private C0239a f5105f;

    /* renamed from: g */
    private TextView f5106g;

    public void onCreate(Bundle bundle) {
        C0240b bVar = this.f5103d;
        C0240b.m1189b(this);
        super.onCreate(bundle);
        setContentView(R.layout.layout_dialog_listview);
        getWindow().setFlags(1024, 1024);
        getWindow().setBackgroundDrawable(new ColorDrawable(0));
        try {
            this.f5106g = (TextView) findViewById(R.id.txtViewMsg);
            this.f5106g.setMovementMethod(new ScrollingMovementMethod());
            this.f5100a = getApplicationContext();
            this.f5105f = new C0239a(this.f5100a);
            Bundle extras = getIntent().getExtras();
            this.f5101b = extras.getInt("bID");
            String string = extras.getString("bRPT_TYPE");
            String string2 = extras.getString("bRPT_DESC");
            String string3 = extras.getString("bTITLE");
            String a = this.f5105f.mo1021a(extras.getLong("bSTART_DATE"));
            String a2 = this.f5105f.mo1021a(extras.getLong("bNEXT_RUN"));
            C1404a aVar = this.f5104e;
            if (string.equals("NA")) {
                TextView textView = (TextView) findViewById(R.id.txtViewDate);
                StringBuilder sb = new StringBuilder();
                sb.append("Scheduled at ");
                sb.append(a);
                textView.setText(sb.toString());
                ((TextView) findViewById(R.id.txtViewNextRun)).setVisibility(8);
            } else {
                TextView textView2 = (TextView) findViewById(R.id.txtViewDate);
                StringBuilder sb2 = new StringBuilder();
                sb2.append("Start Date  ::  ");
                sb2.append(a);
                textView2.setText(sb2.toString());
                TextView textView3 = (TextView) findViewById(R.id.txtViewNextRun);
                StringBuilder sb3 = new StringBuilder();
                sb3.append("Next Run  ::  ");
                sb3.append(a2);
                textView3.setText(sb3.toString());
            }
            this.f5106g.setText(string3);
            TextView textView4 = (TextView) findViewById(R.id.txtViewRptDesc);
            StringBuilder sb4 = new StringBuilder();
            sb4.append("Repeat  ::  ");
            sb4.append(string2);
            textView4.setText(sb4.toString());
            if (this.f5106g.getText().toString().contains("[No Title]")) {
                this.f5106g.setContentDescription(this.f5106g.getText().toString().replace("[", "").replace("]", ""));
            }
            ((Button) findViewById(R.id.btnCancel)).setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    WidgetPopUp.this.finish();
                }
            });
            ((Button) findViewById(R.id.btnEdit)).setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    Intent intent = new Intent(WidgetPopUp.this, Activity_Create.class);
                    intent.putExtra("bID", WidgetPopUp.this.f5101b);
                    WidgetPopUp.this.startActivity(intent);
                    WidgetPopUp.this.finish();
                }
            });
            ((Button) findViewById(R.id.btnDelete)).setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    WidgetPopUp widgetPopUp = WidgetPopUp.this;
                    widgetPopUp.f5102c = new C0238a(widgetPopUp.f5100a);
                    WidgetPopUp.this.f5102c.mo1010b(WidgetPopUp.this.f5101b);
                    WidgetPopUp.this.finish();
                    Toast.makeText(WidgetPopUp.this.f5100a, "Reminder deleted", 0).show();
                }
            });
        } catch (Exception unused) {
            finish();
            Toast.makeText(this.f5100a, "Sorry! This reminder is already deleted.", 0).show();
        }
    }

    public void onPause() {
        super.onPause();
        finish();
    }
}
