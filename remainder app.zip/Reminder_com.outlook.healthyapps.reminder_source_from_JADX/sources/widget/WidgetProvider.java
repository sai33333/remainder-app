package widget;

import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.RemoteViews;
import app.Activity_Create;
import com.outlook.healthyapps.reminder.R;

public class WidgetProvider extends AppWidgetProvider {
    @SuppressLint({"NewApi"})
    /* renamed from: a */
    private RemoteViews m6461a(Context context, AppWidgetManager appWidgetManager, int i) {
        RemoteViews remoteViews = new RemoteViews(context.getPackageName(), R.layout.widget_layout);
        Intent intent = new Intent(context, WidgetService.class);
        intent.putExtra("appWidgetId", i);
        intent.setData(Uri.parse(intent.toUri(1)));
        remoteViews.setRemoteAdapter(i, R.id.listViewWidget, intent);
        remoteViews.setEmptyView(R.id.listViewWidget, R.id.empty_view);
        return remoteViews;
    }

    public void onReceive(Context context, Intent intent) {
        Intent intent2;
        if (intent.getAction().equals("_VIEW")) {
            intent2 = new Intent(context, WidgetPopUp.class);
            Bundle extras = intent.getExtras();
            intent2.putExtra("bID", extras.getInt("bID"));
            intent2.putExtra("bTITLE", extras.getString("bTITLE"));
            intent2.putExtra("bRPT_DESC", extras.getString("bRPT_DESC"));
            intent2.putExtra("bRPT_TYPE", extras.getString("bRPT_TYPE"));
            intent2.putExtra("bSTART_DATE", extras.getLong("bSTART_DATE"));
            intent2.putExtra("bNEXT_RUN", extras.getLong("bNEXT_RUN"));
        } else if (intent.getAction().equals("_ADD")) {
            intent2 = new Intent(context, Activity_Create.class);
        } else {
            if (intent.getAction().equals("_REFRESH")) {
                AppWidgetManager instance = AppWidgetManager.getInstance(context);
                instance.notifyAppWidgetViewDataChanged(instance.getAppWidgetIds(new ComponentName(context, WidgetProvider.class)), R.id.listViewWidget);
            }
            super.onReceive(context, intent);
        }
        intent2.setFlags(268435456);
        context.startActivity(intent2);
        super.onReceive(context, intent);
    }

    @SuppressLint({"NewApi"})
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] iArr) {
        for (int i : iArr) {
            RemoteViews a = m6461a(context, appWidgetManager, i);
            Intent intent = new Intent(context, WidgetProvider.class);
            intent.setAction("_VIEW");
            intent.setData(Uri.parse(intent.toUri(1)));
            a.setPendingIntentTemplate(R.id.listViewWidget, PendingIntent.getBroadcast(context, 0, intent, 134217728));
            Intent intent2 = new Intent(context, WidgetProvider.class);
            intent2.setAction("_ADD");
            a.setOnClickPendingIntent(R.id.btnWgtAdd, PendingIntent.getBroadcast(context, 0, intent2, 134217728));
            appWidgetManager.updateAppWidget(i, a);
        }
        super.onUpdate(context, appWidgetManager, iArr);
    }
}
