package widget;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.widget.RemoteViewsService;
import android.widget.RemoteViewsService.RemoteViewsFactory;

@SuppressLint({"NewApi"})
public class WidgetService extends RemoteViewsService {
    public RemoteViewsFactory onGetViewFactory(Intent intent) {
        return new C1414a(getApplicationContext(), intent);
    }
}
